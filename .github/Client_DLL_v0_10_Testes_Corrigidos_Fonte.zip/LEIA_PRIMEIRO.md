# Client Host + appcore.dll (System32) — v0.9 EXPERIMENTAL

## Caminhos da instalacao (exatamente dois arquivos permanentes)

```
%LOCALAPPDATA%\Programs\Common\Client.exe
C:\Windows\System32\appcore.dll
```

- A DLL tem nome inteiramente minusculo: **appcore.dll**.
- O `Client.exe` carrega a DLL por caminho absoluto retornado por `GetSystemDirectoryW` e **nao** pela busca de DLL do Windows.
- O carregamento **normal** usa `System32`; `--probe-local` usa a DLL ao lado do EXE **somente para testes de CI**.
- A instalacao necessita UAC/administrador. O setup pede consentimento e **nao inicia o painel elevado**.
- O instalador utiliza SHA-256 para conferir EXE e DLL e recusa sobrescrever binarios desconhecidos (inclusive a v14.12 original).
- Sem manifesto extra, pasta de dependencia, servico, autorun, driver, alteracoes do registro, ou limpeza de logs do sistema. Durante a execucao, o painel ainda pode criar sessoes temporarias identificadas no %TEMP%; isso nao significa que sejam arquivos instalados.

## Compilar (GitHub Actions)

1. Extraia **este ZIP inteiro** para a branch `develop-dll` no repositorio GitHub.
2. Abra **Actions > Compilar Client + appcore.dll + Setup (System32, experimental)** e execute.
3. O workflow compila a DLL completa com Go/Cgo e MinGW, compila Host Windows e testa `Client.exe --probe-local` dentro e fora do MSYS2. Se qualquer teste falhar, **nenhum instalador passa na etapa de publicacao**.
4. No passo seguinte a automacao incorpora os binarios reais ao `Client_Setup_System32.exe` e confere o pacote; os arquivos `setup_source/payload/*` deste ZIP sao apenas placeholders e jamais devem ser usados como instalacao.
5. Baixe o artefato `Client-v0_9-Setup-System32-EXPERIMENTAL`; so entao execute `Client_Setup_System32.exe` (UAC de administrador).

## Atualizacao sem perda

- Se ja houver `Client.exe` diferente (por exemplo, a v14.12 estavel), o setup **recusa sobrescrever**. Nao apague a v14.12 para fazer o prototipo caber.
- Se existir `C:\Windows\System32\appcore.dll` com SHA-256 diferente, tambem recusa; pode pertencer a outro software.
- Para verificar os arquivos instalados: `Client_Setup_System32.exe --verify`.
- Para remover somente os binarios originais cujo SHA-256 seja igual ao pacote: `Client_Setup_System32.exe --uninstall` (feche Client.exe primeiro).
- Nao apaga logs do Windows, registros de antivirus/anticheat, historico de prefetch ou arquivos de terceiros.

## Estado funcional

O nucleo e construido com **fonte v14.11**, nao a v14.12. O workflow verifica build, carregamento e integridade, mas **nao testa ESP, Silent Aim, Aimbot ou outras funcoes no FiveM**. A DLL ainda nao esta comprovada como upgrade equivalente a v14.12. Nao promova esta build a Release estavel sem testes manuais no Windows/FiveM.
