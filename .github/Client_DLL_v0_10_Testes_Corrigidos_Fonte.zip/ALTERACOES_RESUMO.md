# O que mudou em relação à v0.8

- `host_source/ClientHost.c` carrega `appcore.dll` com `GetSystemDirectoryW` + `LoadLibraryExW` por caminho absoluto, e usa **somente** `--probe-local` para testar a DLL ao lado do Host na esteira de compilação.
- `build_windows.cmd` usa o nome `appcore.dll` e `--probe-local` (compile manual: gera Host+DLL, sem instalar).
- `setup_source/main_windows.go` incorpora os binários REAIS gerados pelo workflow e instala exatamente `Client.exe` e `appcore.dll` nas duas localizações especificadas, com UAC, SHA-256, preflight anticollision e desinstalação limitada aos próprios binários verificados.
- `.github/workflows/build-windows.yml` compila o núcleo Cgo de v14.11, compila o Host, testa ABI sem MSYS2 e só depois incorpora os dois ao `Client_Setup_System32.exe`.
- O setup **não apaga** uma v14.12 existente ou `appcore.dll` de outra origem. Não transfere automaticamente funcionalidades exclusivas da v14.12.

**Status:** fonte e workflow prontos, compilação Windows do setup Go verificada. Binários completos Go/Cgo **não foram gerados nem executados neste ambiente**. Nao confundir o setup experimental com um upgrade aprovado.
