# Client DLL v0.10 — regressões corrigidas (fonte experimental)

Esta entrega mantém a arquitetura de dois arquivos **instalados**: `Client.exe` em `%LOCALAPPDATA%\Programs\Common` e `appcore.dll` em `%SystemRoot%\System32`. O ZIP contém o **código-fonte e ferramentas de build**, não um painel final.

## Correções

1. `aim_camera_servo_test.go`: a matriz sintética posicionava a cabeça no centro vertical enquanto todos os testes assumiam posição acima da mira. Corrigida a condição inicial, preservando os guardas contra deslocamentos errados.
2. `aim_logic.go`: acrescentada verificação **tolerante** contra pontos de cabeça que caiam fundo no corpo ou muito longe do retângulo estabilizado, para que a seleção não aceite um dado incoerente mesmo com flag `HeadVerified` obsoleta.
3. `main_test.go`: passou a fornecer nos testes autenticados a chave local e o cookie de sessão exigidos pelo código atual. Testes não autenticados continuam verificando HTTP 401; origem falsa continua exigindo 403; path traversal continua exigindo 400. Suprimidos apenas os efeitos reais de shutdown **nos testes**, sem mudança no código de produção; limpeza própria coberta por `owned_session_cleanup_test.go`.
4. `clean_start_test.go`: testa os controles que realmente habilitam efeitos, sem confundir `nearbyPlayers` (preferência informativa) com função ativada.
5. `v116_migration_test.go`: o produto passou a criar configurações efêmeras por sessão. Corrigido o teste antigo para garantir que arquivos de configurações velhos não reativem controles.
6. `vehicle_scan_order_test.go`: atualizado para refletir o quarto argumento `VehicleAliases`, mantendo a checagem da ordem de varredura independente de personagem.

## Validação realizada neste ambiente

- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test -c` no núcleo principal — **passou** (compilação, não execução dos testes Windows).
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet ./...` — **passou**.
- Compilação dos testes Windows do setup — **passou**.
- `go test ./aimv13` em Linux — **passou**.
- Testes isolados de câmera usando o algoritmo do projeto, com tipos mínimos de apoio — **10/10 passaram** em Linux.

## Limites

Não foi possível executar os testes completos para Windows aqui (sem Windows/Wine). É necessário rodar o novo workflow Windows; ele deve continuar **falhando** se qualquer regressão ainda ocorrer. Compilar, carregar o núcleo e rodar os testes não prova funcionamento de nenhuma ação no FiveM. A v14.12 funcional não foi alterada e não se deve publicar esta migração como versão estável.
