@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where go >nul 2>nul || (echo Go 1.23+ nao encontrado & exit /b 1)
where gcc >nul 2>nul || (echo GCC MinGW-w64 nao encontrado & exit /b 1)
if not exist dist mkdir dist
set GOOS=windows
set GOARCH=amd64
set CGO_ENABLED=1
set CC=gcc
pushd core_source
go test ./... -count=1
if errorlevel 1 (popd & echo Falha nos testes & exit /b 1)
go build -trimpath -buildmode=c-shared -o ..\dist\appcore.dll .
if errorlevel 1 (popd & echo Falha ao compilar DLL & exit /b 1)
popd
gcc -DUNICODE -D_UNICODE -O2 -Wall -Wextra -municode -mwindows -o dist\Client.exe host_source\ClientHost.c
if errorlevel 1 (echo Falha ao compilar Host & exit /b 1)
dist\Client.exe --probe-local
if errorlevel 1 (echo Carregamento/ABI falhou & exit /b 1)
echo DLL carregada e ABI validada. Compatibilidade FiveM NAO verificada.
