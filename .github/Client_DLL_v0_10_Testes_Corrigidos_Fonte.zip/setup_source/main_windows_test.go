//go:build windows
package main
import (
    "os"
    "path/filepath"
    "testing"
)
func TestHashAndPreflight(t *testing.T) {
    d := t.TempDir()
    file := filepath.Join(d,"client.bin")
    b := []byte("known client test data")
    hash := digest(b)
    exists, matches, err := fileMatches(file,hash)
    if err!=nil||exists||matches {t.Fatalf("missing: %v %v %v",exists,matches,err)}
    if err:=writeExclusive(file,b);err!=nil {t.Fatal(err)}
    exists,matches,err=fileMatches(file,hash)
    if err!=nil||!exists||!matches {t.Fatalf("matched: %v %v %v",exists,matches,err)}
    if err:=writeExclusive(file,b);err==nil {t.Fatal("allowed overwrite")}
    if err:=os.WriteFile(file,[]byte("changed"),0644);err!=nil {t.Fatal(err)}
    exists,matches,err=fileMatches(file,hash)
    if err!=nil||!exists||matches {t.Fatalf("modified: %v %v %v",exists,matches,err)}
}
func TestBinaryCheckConsistent(t *testing.T) {
    _,errClient := binary(clientName)
    _,errDLL := binary(dllName)
    if (errClient==nil)!=(errDLL==nil) {t.Fatalf("payloads mixed: %v %v",errClient,errDLL)}
}
