module client/system32setup

go 1.23
