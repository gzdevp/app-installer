//go:build windows
package main

import (
    "crypto/sha256"
    "bytes"
    "debug/pe"
    "embed"
    "errors"
    "fmt"
    "io"
    "os"
    "path/filepath"
    "strings"
    "syscall"
    "unsafe"
)

//go:embed payload/Client.exe payload/appcore.dll
var payload embed.FS

const clientName = "Client.exe"
const dllName = "appcore.dll"

var kernel32 = syscall.NewLazyDLL("kernel32.dll")
var getSystemDirectoryW = kernel32.NewProc("GetSystemDirectoryW")
var shell32 = syscall.NewLazyDLL("shell32.dll")
var shellExecuteW = shell32.NewProc("ShellExecuteW")
var user32 = syscall.NewLazyDLL("user32.dll")
var messageBoxW = user32.NewProc("MessageBoxW")

func systemDir() (string, error) {
    buf := make([]uint16, 32768)
    r, _, e := getSystemDirectoryW.Call(uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
    if r == 0 || int(r) >= len(buf) {
        return "", fmt.Errorf("GetSystemDirectoryW falhou: %v", e)
    }
    return syscall.UTF16ToString(buf[:r]), nil
}

func applicationPath() (string, error) {
    local := os.Getenv("LOCALAPPDATA")
    if local == "" { return "", errors.New("LOCALAPPDATA nao definido") }
    return filepath.Join(local,"Programs","Common",clientName), nil
}

func digest(b []byte) [32]byte { return sha256.Sum256(b) }
func fileMatches(path string, wanted [32]byte) (exists, matches bool, err error) {
    info, e := os.Lstat(path)
    if os.IsNotExist(e) { return false, false, nil }
    if e != nil { return false, false, e }
    if !info.Mode().IsRegular() { return true, false, fmt.Errorf("arquivo nao regular ou link: %s",path) }
    f, e := os.Open(path)
    if e != nil { return true, false, e }
    defer f.Close()
    h := sha256.New()
    if _, e = io.Copy(h, f); e != nil { return true, false, e }
    var got [32]byte
    copy(got[:], h.Sum(nil))
    return true, got == wanted, nil
}

func binary(name string) ([]byte,error) {
    b,e := payload.ReadFile("payload/" + name)
    if e != nil { return nil,e }
    // Prevent publishing a setup accidentally built with placeholder payloads.
    if len(b) < 1024 || b[0] != 'M' || b[1] != 'Z' {
        return nil,fmt.Errorf("payload %s nao e um binario Windows valido", name)
    }
    p,e:=pe.NewFile(bytes.NewReader(b))
    if e!=nil { return nil,fmt.Errorf("PE invalido no payload %s: %w",name,e) }
    defer p.Close()
    if p.FileHeader.Machine!=pe.IMAGE_FILE_MACHINE_AMD64 {return nil,fmt.Errorf("payload %s nao e Windows x64",name)}
    return b,nil
}

func writeExclusive(path string, data []byte) error {
    if err:=os.MkdirAll(filepath.Dir(path),0755); err!=nil { return err }
    f,err:=os.OpenFile(path,os.O_WRONLY|os.O_CREATE|os.O_EXCL,0644)
    if err!=nil {return err}
    ok:=false
    defer func(){ f.Close(); if !ok { _=os.Remove(path) } }()
    n,err:=f.Write(data)
    if err !=nil { return err }
    if n!=len(data) {return io.ErrShortWrite}
    if err=f.Sync();err!=nil{return err}
    if err=f.Close();err!=nil{return err}
    ok=true
    return nil
}

func paths() (string,string,error) {
    p,e:=applicationPath(); if e!=nil{return "","",e}
    sd,e:=systemDir(); if e!=nil{return "","",e}
    return p,filepath.Join(sd,dllName),nil
}

func install() error {
    client,dll,e:=paths();if e!=nil{return e}
    exeData,e:=binary(clientName);if e!=nil{return e}
    dllData,e:=binary(dllName);if e!=nil{return e}
    exPresent,exMatch,e:=fileMatches(client,digest(exeData));if e!=nil{return e}
    dllPresent,dllMatch,e:=fileMatches(dll,digest(dllData));if e!=nil{return e}
    // Protect both an installed stable v14.12 and unrelated Windows files.
    if exPresent&&!exMatch { return fmt.Errorf("Client.exe ja existe e e diferente: %s. Instalacao cancelada para preservar a versao anterior",client) }
    if dllPresent&&!dllMatch { return fmt.Errorf("Existe outra appcore.dll em %s. Instalacao cancelada para evitar sobrescrita",dll) }
    newDLL:=false
    if !dllPresent {
        if e=writeExclusive(dll,dllData);e!=nil {return fmt.Errorf("gravar DLL (requer administrador): %w",e)}
        newDLL=true
    }
    if !exPresent {
        if e=writeExclusive(client,exeData);e!=nil {
            if newDLL {if exists,match,_:=fileMatches(dll,digest(dllData));exists&&match {_=os.Remove(dll)} }
            return fmt.Errorf("gravar Client.exe: %w",e)
        }
    }
    if e=verify();e!=nil{return fmt.Errorf("instalacao incompleta: %w",e)}
    fmt.Printf("Instalacao concluida. Somente dois arquivos instalados:\n%s\n%s\n",client,dll)
    fmt.Println("Abra Client.exe normalmente. Este setup nao inicia o painel elevado.")
    return nil
}

func verify() error {
    client,dll,e:=paths();if e!=nil{return e}
    for _,f:=range []struct{name,path string}{{clientName,client},{dllName,dll}} {
        b,e:=binary(f.name);if e!=nil{return e}
        present,match,e:=fileMatches(f.path,digest(b));if e!=nil{return e}
        if !present||!match {return fmt.Errorf("arquivo ausente ou modificado: %s",f.path)}
    }
    fmt.Println("Integridade dos dois binarios confirmada (SHA-256).")
    return nil
}

func uninstall() error {
    client,dll,e:=paths();if e!=nil{return e}
    // Exact hash required for BOTH files, and no running Client.exe.
    // Windows blocks deletion of a loaded DLL; do not try to bypass it.
    if e=verify();e!=nil {return fmt.Errorf("desinstalacao recusada: %w",e)}
    // Remove the DLL first; if it is currently loaded, uninstall stops with both files untouched.
    if e=os.Remove(dll);e!=nil {return fmt.Errorf("DLL ainda esta em uso ou protegida: %w",e)}
    if e=os.Remove(client);e!=nil {
        b,be:=binary(dllName)
        if be==nil { _=writeExclusive(dll,b) } // best-effort rollback to avoid half-uninstall
        return fmt.Errorf("feche Client.exe primeiro: %w",e)
    }
    _=os.Remove(filepath.Dir(client)) // only if directory empty
    fmt.Println("Client.exe e appcore.dll removidos. Nenhum arquivo de outros programas foi apagado.")
    return nil
}

func elevate(args string) error {
    executable,e:=os.Executable();if e!=nil{return e}
    verb,_:=syscall.UTF16PtrFromString("runas")
    target,_:=syscall.UTF16PtrFromString(executable)
    params,_:=syscall.UTF16PtrFromString(args)
    ret,_,callErr:=shellExecuteW.Call(0,uintptr(unsafe.Pointer(verb)),uintptr(unsafe.Pointer(target)),uintptr(unsafe.Pointer(params)),0,1)
    if ret <= 32 { return fmt.Errorf("elevacao UAC nao autorizada (codigo %d): %v",ret,callErr) }
    return nil
}

func run() error {
    if len(os.Args)>3{return errors.New("argumentos demais")}
    operation:="--install"; elevated:=false; opSeen:=false
    for _,v:=range os.Args[1:] {
        switch strings.ToLower(v) {
        case "--install","--verify","--uninstall","--inspect-payload":
            if opSeen {return errors.New("operacoes em conflito")}
            operation=strings.ToLower(v); opSeen=true
        case "--elevated": elevated=true
        default:return fmt.Errorf("argumento invalido: %s",v)
        }
    }
    if operation!="--verify" && operation!="--inspect-payload" && !elevated {
        // UAC even for administrator accounts; never write to System32 without consent.
        return elevate(operation+" --elevated")
    }
    switch operation {
    case "--install":return install()
    case "--verify":return verify()
    case "--uninstall":return uninstall()
    case "--inspect-payload":
        a,e:=binary(clientName);if e!=nil{return e};b,e:=binary(dllName);if e!=nil{return e}
        fmt.Printf("Conteudo validado: Client.exe (%d bytes), appcore.dll (%d bytes)\n",len(a),len(b));return nil
    }
    return nil
}
func popup(message string, failure bool) {
    text,_:=syscall.UTF16PtrFromString(message)
    title,_:=syscall.UTF16PtrFromString("Client Setup - System32")
    typ:=uintptr(0x40) // MB_ICONINFORMATION
    if failure {typ=0x10} // MB_ICONERROR
    messageBoxW.Call(0,uintptr(unsafe.Pointer(text)),uintptr(unsafe.Pointer(title)),typ)
}
func main(){
    elevated:=false
    for _,a:=range os.Args[1:] {if strings.EqualFold(a,"--elevated") {elevated=true}}
    if e:=run();e!=nil {
        fmt.Fprintln(os.Stderr,"Client Setup:",e)
        if elevated {popup("Falha na instalacao: "+e.Error(),true)}
        os.Exit(1)
    }
    if elevated {popup("Operacao concluida. Arquivos permanentes: Client.exe em Programs\\Common e appcore.dll em System32.\nNenhum painel foi iniciado com privilegios elevados.",false)}
}
