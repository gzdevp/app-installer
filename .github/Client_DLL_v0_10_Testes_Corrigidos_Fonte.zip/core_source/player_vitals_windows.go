//go:build windows

package main

import (
	"fmt"
	"sync"
	"time"
)

var playerVitalsState = struct {
	sync.RWMutex
	status string
	at     string
	ok     bool
}{status: "Aguardando ação de vida"}
var playerVitalsMutex sync.Mutex

func playerVitalsReport(status string, ok bool) (string, bool) {
	playerVitalsState.Lock()
	playerVitalsState.status = status
	playerVitalsState.ok = ok
	playerVitalsState.at = time.Now().Format("15:04:05")
	playerVitalsState.Unlock()
	return status, ok
}
func playerVitalsGet() map[string]any {
	playerVitalsState.RLock()
	defer playerVitalsState.RUnlock()
	return map[string]any{"status": playerVitalsState.status, "ok": playerVitalsState.ok, "at": playerVitalsState.at}
}

// playerHealthAction changes only the LOCAL ped's numeric health fields.
// reviveMode is a best-effort health restoration, NOT a FiveM death-state transition.
func playerHealthAction(requested float32, reviveMode bool) (string, bool) {
	playerVitalsMutex.Lock()
	defer playerVitalsMutex.Unlock()
	a, err := attachWritableGame()
	if err != nil {
		return playerVitalsReport("Vida: "+err.Error(), false)
	}
	defer a.close()
	p := a.read
	if p.build != "b3258" {
		return playerVitalsReport("Vida: perfil de escrita não confirmado para "+p.build, false)
	}
	layout, exists := espLayouts[p.build]
	if !exists {
		return playerVitalsReport("Vida: perfil ESP indisponível", false)
	}
	world := p.ptr(p.base + layout.world)
	if world == 0 {
		return playerVitalsReport("Vida: mundo indisponível", false)
	}
	ped := p.ptr(world + 0x8)
	if ped < 0x10000 || ped > 0x7FFFFFFFFFFF {
		return playerVitalsReport("Vida: ped local indisponível", false)
	}
	position, posOK := p.vec3(ped + 0x90)
	if !posOK || !plausibleFiveMPosition(position) {
		return playerVitalsReport("Vida: posição do ped local inválida", false)
	}
	health, healthOK := readFloat32Game(p, ped+pedHealthField)
	maxHealth, maxOK := readFloat32Game(p, ped+pedMaxHealthField)
	if !healthOK || !maxOK {
		return playerVitalsReport("Vida: campos de vida ilegíveis", false)
	}
	// Revive uses a fixed, moderate health value. This alone may NOT end server-side death.
	if reviveMode {
		requested = 200
	}
	plan, e := planHealthWrite(pedVitals{health, maxHealth}, requested)
	if e != nil {
		return playerVitalsReport(fmt.Sprintf("Vida: %s (atual %.0f, máximo %.0f)", e, health, maxHealth), false)
	}
	if p.ptr(world+0x8) != ped {
		return playerVitalsReport("Vida: personagem mudou, operação cancelada", false)
	}
	if plan.RaiseMaximum && !writeFloat32Game(a.writer, ped+pedMaxHealthField, plan.NewMaximum) {
		return playerVitalsReport("Vida: falha ao aumentar vida máxima", false)
	}
	if !writeFloat32Game(a.writer, ped+pedHealthField, plan.Target) {
		if plan.RaiseMaximum {
			_ = writeFloat32Game(a.writer, ped+pedMaxHealthField, maxHealth)
		}
		return playerVitalsReport("Vida: falha ao escrever HP", false)
	}
	verify, readOK := readFloat32Game(p, ped+pedHealthField)
	if !readOK || !confirmedHealthValue(verify, plan.Target) {
		return playerVitalsReport("HP enviado, mas o jogo não confirmou o valor", false)
	}
	if plan.RaiseMaximum {
		actualMax, ok := readFloat32Game(p, ped+pedMaxHealthField)
		if !ok || !confirmedHealthValue(actualMax, plan.NewMaximum) {
			return playerVitalsReport("Vida máxima não permaneceu no valor solicitado", false)
		}
	}
	if reviveMode {
		// A dead ped's health is not the authoritative death flag. Be explicit.
		time.Sleep(130 * time.Millisecond)
		if p.ptr(world+0x8) != ped {
			return playerVitalsReport("Reviver: personagem trocado, estado não confirmado", false)
		}
		again, ok := readFloat32Game(p, ped+pedHealthField)
		if !ok || !confirmedHealthValue(again, plan.Target) {
			return playerVitalsReport("Reviver: servidor/jogo reverteu o HP; estado morto não foi alterado", false)
		}
		return playerVitalsReport("HP local restaurado a 200; reanimação real NÃO confirmada (exige estado de morte do FiveM/servidor)", false)
	}
	return playerVitalsReport(fmt.Sprintf("HP local definido em %.0f (antes %.0f; servidor ainda não verificado)", plan.Target, health), true)
}

// playerArmorAction changes only the local ped's numeric armor value.
// The armor offset is the same field already read by the b3258 ESP.
func playerArmorAction(requested float32) (string, bool) {
	playerVitalsMutex.Lock()
	defer playerVitalsMutex.Unlock()
	if !validArmorTarget(requested) {
		return playerVitalsReport("Armadura: valor deve estar entre 0 e 100", false)
	}
	a, err := attachWritableGame()
	if err != nil {
		return playerVitalsReport("Armadura: "+err.Error(), false)
	}
	defer a.close()
	p := a.read
	if p.build != "b3258" {
		return playerVitalsReport("Armadura: perfil de escrita não confirmado para "+p.build, false)
	}
	layout, ok := espLayouts[p.build]
	if !ok {
		return playerVitalsReport("Armadura: layout do ESP indisponível", false)
	}
	world := p.ptr(p.base + layout.world)
	if world == 0 {
		return playerVitalsReport("Armadura: mundo indisponível", false)
	}
	ped := p.ptr(world + 0x8)
	if ped < 0x10000 || ped > 0x7FFFFFFFFFFF {
		return playerVitalsReport("Armadura: personagem local indisponível", false)
	}
	position, posOK := p.vec3(ped + 0x90)
	if !posOK || !plausibleFiveMPosition(position) {
		return playerVitalsReport("Armadura: posição do personagem inválida", false)
	}
	current, readOK := readFloat32Game(p, ped+layout.armor)
	if !readOK || !plausibleArmorValue(current) {
		return playerVitalsReport("Armadura: campo ilegível ou incompatível", false)
	}
	if p.ptr(world+0x8) != ped {
		return playerVitalsReport("Armadura: personagem mudou; cancelado", false)
	}
	if !writeFloat32Game(a.writer, ped+layout.armor, requested) {
		return playerVitalsReport("Armadura: falha na escrita", false)
	}
	actual, ok := readFloat32Game(p, ped+layout.armor)
	if !ok || !confirmedHealthValue(actual, requested) {
		return playerVitalsReport("Armadura enviada, mas não confirmada pelo jogo", false)
	}
	return playerVitalsReport(fmt.Sprintf("Armadura local definida em %.0f (antes %.0f; servidor não verificado)", requested, current), true)
}
