# sete7 v12.35 — registro verificável

**Esta versão NÃO TEM GARANTIA de funcionar no FiveM.** Nenhuma simulação pode substituir a execução no mesmo jogo/servidor/configuração do usuário.

## Problemas observados no código anterior

1. A calibração enviava pequenos movimentos sem confirmar primeiro a direção correta em cada quadro. Um sentido errado podia ser aprendido antes de qualquer verificação de aproximação.
2. Não havia uma trava que impedisse outro comando antes de a matriz de câmera confirmar o comando anterior. Apenas aguardar o próximo quadro do ESP não garante que o jogo já consumiu o SendInput.
3. A ausência de resposta e o afastamento horizontal não eram verificados de maneira uniforme em todos os estados.

## Alterações

- `aim_camera_servo.go`: mantém no máximo um comando pendente; exige leitura posterior da câmera; limita a calibração a passos de 1 unidade; verifica piora do erro antes de liberar a correção; bloqueia sem resposta ou com deslocamento contraditório.
- `aim_windows.go`: verifica novamente o foco imediatamente antes do SendInput; cancela comando pendente quando perde alvo; expõe mensagem de espera sem chamá-la de centralização.
- `aim_camera_servo_test.go`, `aim_camera_headlock_guard_test.go`: testes Windows atualizados para a nova ordem de confirmação.
- `validation/camera_closed_loop_simulator`: 7 testes executáveis no Linux/Windows, com resposta de câmera sintética (incluindo Y invertido e mudança de sentido). Executar `cd validation/camera_closed_loop_simulator && go test -v`.

## Verificações que passaram neste ambiente

- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build .`
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test -c` (somente compilação dos testes Windows)
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet ./...`
- `go test -race -count=3` no simulador (7 testes).
- `node --check` no JavaScript extraído de `web/index.html`.
- SHA256 igual ao da versão confirmada v12.20 para `silent_windows.go`, `silent_patch.go`, `silent_signature_scan.go`.
- `noclip_windows.go` e `esp_windows.go` idênticos à v12.34.

## Ainda não validado

- O comportamento do `SendInput` dentro do FiveM real, incluindo a sensibilidade, input raw, modo de tela e configurações de câmera.
- A mira acompanhar a cabeça sem cair no chão em instalações reais.

Se a exigência for **garantia de mira funcionando dentro do FiveM**, este pacote ainda não satisfaz essa exigência.
