module sete7/external/ui

go 1.23
