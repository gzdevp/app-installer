package main

import "sync/atomic"

// An unverified session sees only a compact credential dialog. The normal
// dashboard size is restored after the server accepts the credentials.
var menuAuthenticated atomic.Bool

const (
	menuFullWidth   int32 = 1120
	menuFullHeight  int32 = 740
	menuLoginWidth  int32 = 480
	menuLoginHeight int32 = 570
)

func menuDimensions() (int32, int32) {
	if menuAuthenticated.Load() {
		return menuFullWidth, menuFullHeight
	}
	return menuLoginWidth, menuLoginHeight
}
