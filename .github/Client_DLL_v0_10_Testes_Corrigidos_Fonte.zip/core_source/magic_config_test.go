package main

import (
	"strings"
	"testing"
)

func TestMagicReadinessReport(t *testing.T) {
	if x := inspectMagicJSON([]byte(`{"shootHandler":0,"playerPedHandler":0,"damage":200}`)); !strings.Contains(x, "zerados") {
		t.Fatal(x)
	}
	if x := inspectMagicJSON([]byte(`{"shootHandler": 0x0}`)); !strings.Contains(x, "inválido") {
		t.Fatal(x)
	}
	if x := inspectMagicJSON([]byte(`{"shootHandler":123,"playerPedHandler":456,"damage":200}`)); !strings.Contains(x, "não instalado") {
		t.Fatal(x)
	}
}
