package main

import (
    "os"
    "strings"
    "testing"
)

func TestPanicShortcutRemovedFromUIAndStartup(t *testing.T) {
    ui, err := os.ReadFile("web/index.html")
    if err != nil { t.Fatal(err) }
    main, err := os.ReadFile("main.go")
    if err != nil { t.Fatal(err) }
    rendered := string(ui)
    for _, token := range []string{"Atalho Panic", "Tecla Panic", "Panic / Unload", "data-toggle=\"panic.enabled\""} {
        if strings.Contains(rendered, token) { t.Fatalf("unexpected removed control: %s", token) }
    }
    if !strings.Contains(rendered, "${act('Unload','unload')}") || !strings.Contains(rendered, "${act('Cleaner','cleaner')}") {
        t.Fatal("unload and cleaner must remain available")
    }
    if strings.Contains(string(main), "startPanicHotkey(s)") { t.Fatal("panic key listener still starts") }
}
