package main

import "testing"

func TestPedCapChoosesNearbyPlayersNotFirstAllocated(t *testing.T) {
	var collected []candidatePed
	for i := 0; i < 320; i++ {
		collected = retainBestPeds(collected, candidatePed{ptr: uintptr(1000 + i), distance: float64(320 - i), isNPC: i%3 == 0}, 256)
	}
	if len(collected) != 256 {
		t.Fatalf("length %d", len(collected))
	}
	seen := map[uintptr]bool{}
	for _, p := range collected {
		seen[p.ptr] = true
	}
	if !seen[1319] {
		t.Fatal("closest player omitted")
	}
	if seen[1000] {
		t.Fatal("far older NPC kept")
	}
}

func TestPedCapPrefersPlayers(t *testing.T) {
	var collected []candidatePed
	for i := 0; i < 300; i++ {
		collected = retainBestPeds(collected, candidatePed{ptr: uintptr(1000 + i), distance: 1, isNPC: true}, 256)
	}
	collected = retainBestPeds(collected, candidatePed{ptr: 9000, distance: 100, isNPC: false}, 256)
	var found bool
	for _, v := range collected {
		if v.ptr == 9000 {
			found = true
		}
	}
	if !found {
		t.Fatal("player excluded by NPC crowding")
	}
}

func TestPoolEvidenceStrength(t *testing.T) {
	if vehiclePoolEvidenceScore(1, 0, 0) != 0 {
		t.Fatal("coordinate-only pool accepted")
	}
	if vehiclePoolEvidenceScore(4, 2, 1) <= vehiclePoolEvidenceScore(4, 3, 0) {
		t.Fatal("catalogue evidence ignored")
	}
}

func TestReadRangeBounds(t *testing.T) {
	for _, tc := range []struct {
		addr uintptr
		size int
		want bool
	}{
		{0xFFFF, 10, false}, {0x10000, 1, true}, {0x7FFFFFFFFFFF, 1, true},
		{0x7FFFFFFFFFFF, 2, false}, {0x800000000000, 1, false},
		{0x10000, 0, false}, {0x10000, 1<<20 + 1, false},
	} {
		if got := validProcessReadRange(tc.addr, tc.size); got != tc.want {
			t.Fatalf("addr=%x size=%d got=%v want=%v", tc.addr, tc.size, got, tc.want)
		}
	}
}

// Regression: an allocated, sparse pool can contain a closer player past
// the first 256 active entities. The scan must reach all validated slots.
type densePedReader struct {
	list  uintptr
	count uint32
}

func (r densePedReader) ptr(at uintptr) uintptr {
	if at >= r.list && (at-r.list)%0x10 == 0 && (at-r.list)/0x10 < uintptr(r.count) {
		return 0x100000 + (at-r.list)/0x10*0x1000
	}
	if at >= 0x100000 && at < 0x100000+uintptr(r.count+2)*0x1000 && (at-0x100000)%0x1000 == 0x10A8%0x1000 {
		return 0x500000
	}
	return 0
}
func (r densePedReader) vec3(at uintptr) (vec3, bool) {
	if at < 0x100000+0x90 || at >= 0x100000+uintptr(r.count)*0x1000 || (at-0x100000)%0x1000 != 0x90 {
		return vec3{}, false
	}
	i := (at - 0x100000) / 0x1000
	return vec3{X: float32(r.count - uint32(i)), Y: 100, Z: 20}, true
}
func (r densePedReader) f32(at uintptr) float32 {
	if at%0x1000 == 0x280 {
		return 200
	}
	if at%0x1000 == 0x150C%0x1000 {
		return 50
	}
	return 0
}
func TestDensePoolScansPastFirst256(t *testing.T) {
	read := densePedReader{list: 0x700000, count: 320}
	var stats ESPDiagnostics
	peds := scanPlayersWithOffsets(read, read.list, read.count, 0, vec3{Y: 100, Z: 20}, 500, &stats, 0x10A8, 0x150C)
	if len(peds) != 256 {
		t.Fatalf("want 256 got %d, diagnostics %+v", len(peds), stats)
	}
	if stats.Positions != 320 {
		t.Fatalf("only read %d valid positions", stats.Positions)
	}
	last := uintptr(0x100000 + 319*0x1000)
	seen := false
	for _, ped := range peds {
		if ped.ptr == last {
			seen = true
			break
		}
	}
	if !seen {
		t.Fatal("closest ped in late slot omitted")
	}
}
