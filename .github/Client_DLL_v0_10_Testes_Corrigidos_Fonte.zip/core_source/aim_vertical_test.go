//go:build windows

package main

import "testing"

func TestAimVerticalDirectionConfig(t *testing.T) {
	head := AimCandidate{X: 1215, Y: 337}
	// The screenshot: head (1215,337), screen center (960,540), smooth 20.
	x, y := aimOutputDelta(head, 1920, 1080, 20, true)
	if x != 13 || y != 10 {
		t.Fatalf("FiveM adjusted displacement: %d,%d", x, y)
	}
	x, y = aimOutputDelta(head, 1920, 1080, 20, false)
	if x != 13 || y != -10 {
		t.Fatalf("native displacement: %d,%d", x, y)
	}
}

func TestAimVerticalDirectionBelowCenter(t *testing.T) {
	head := AimCandidate{X: 960, Y: 680}
	_, y := aimOutputDelta(head, 1920, 1080, 10, true)
	if y != -14 {
		t.Fatalf("expected inverse below-center delta, got %d", y)
	}
}
