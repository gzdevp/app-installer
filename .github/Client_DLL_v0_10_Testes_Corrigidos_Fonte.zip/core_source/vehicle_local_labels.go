package main

import (
	"io"
	"regexp"
	"strings"
	"unicode"
)

// Parse literal labels from locally readable Lua scripts without executing Lua.
// Vehicle packs commonly split AddTextEntry across lines, or use the hash
// variant with a literal GetHashKey argument. Both are safe to parse as text.
// Patterns deliberately reject interpolated expressions and markup.
var localAddTextEntryRE = regexp.MustCompile(`(?i)\bAddTextEntry\s*\(\s*['"]([A-Za-z0-9_-]{2,64})['"]\s*,\s*['"]([^'"\r\n]{2,100})['"]\s*\)`)
var localAddTextEntryByHashRE = regexp.MustCompile(`(?i)\bAddTextEntryByHash\s*\(\s*GetHashKey\s*\(\s*['"]([A-Za-z0-9_-]{2,64})['"]\s*\)\s*,\s*['"]([^'"\r\n]{2,100})['"]\s*\)`)

type localMetaModel struct {
	Model    string
	GameName string
}

func parseLocalTextEntries(r io.Reader) map[string]string {
	out := make(map[string]string)
	// 512 KiB is the same hard cap as the older line-by-line reader.
	// A whole bounded read allows a literal call to span multiple lines.
	data, _ := io.ReadAll(io.LimitReader(r, 512<<10))
	for _, re := range []*regexp.Regexp{localAddTextEntryRE, localAddTextEntryByHashRE} {
		for _, m := range re.FindAllStringSubmatch(string(data), 512) {
			key := strings.ToUpper(m[1])
			title := cleanedCatalogueTitle(m[2])
			if title != "" && len(out) < 512 {
				out[key] = title
			}
		}
	}
	return out
}

// When a gameName is a GXT key, only a real local AddTextEntry translation
// establishes a human display label. Otherwise preserve the literal model ID.
func localModelDisplayName(v localMetaModel, entries map[string]string) string {
	label := strings.TrimSpace(v.GameName)
	if n := entries[strings.ToUpper(label)]; n != "" {
		return n
	}
	// A user-facing literal may contain spaces, e.g. "Nissan Skyline R34".
	// Bare uppercase tokens are typically untranslated GXT keys.
	if strings.ContainsAny(label, " -") && len(label) >= 4 {
		meaningful := false
		for _, r := range label {
			if unicode.IsLetter(r) {
				meaningful = true
				break
			}
		}
		if meaningful {
			if n := cleanedCatalogueTitle(label); n != "" {
				return n
			}
		}
	}
	return v.Model
}
