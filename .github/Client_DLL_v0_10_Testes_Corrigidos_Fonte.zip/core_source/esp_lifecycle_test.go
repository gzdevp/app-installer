//go:build windows

package main

import (
	"testing"
	"time"
)

func TestESPCloseProcessDetachesImmediately(t *testing.T) {
	tracker := espAttachmentTracker{}
	now := time.Unix(100, 0)
	if !tracker.detach(now, true, true) {
		t.Fatal("exited process must detach even when a window was previously seen")
	}
	if tracker.windowMissingSince != (time.Time{}) {
		t.Fatal("exited process leaves stale state")
	}
}

func TestESPTemporaryWindowLossPreservesAttachment(t *testing.T) {
	tracker := espAttachmentTracker{}
	now := time.Unix(200, 0)
	if tracker.detach(now, false, false) {
		t.Fatal("must allow window reconfiguration")
	}
	if tracker.detach(now.Add(11*time.Second), false, false) {
		t.Fatal("detached before grace window")
	}
	if tracker.detach(now.Add(11*time.Second), false, true) {
		t.Fatal("reappearing window should reset grace timer")
	}
	if tracker.detach(now.Add(22*time.Second), false, false) {
		t.Fatal("must restart countdown after visible window")
	}
}

func TestESPPersistentWindowLossForcesReattach(t *testing.T) {
	tracker := espAttachmentTracker{}
	now := time.Unix(300, 0)
	tracker.detach(now, false, false)
	if !tracker.detach(now.Add(12*time.Second), false, false) {
		t.Fatal("stale attachment must close after grace period")
	}
	if tracker.windowMissingSince != (time.Time{}) {
		t.Fatal("reset needed to reattach")
	}
}
