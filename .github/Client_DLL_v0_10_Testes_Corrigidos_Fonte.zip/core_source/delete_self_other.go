//go:build !windows

package main

// Windows-only feature. Linux preview/tests never self-delete binaries.
func deleteOwnExecutableAfterExit() error { return nil }
