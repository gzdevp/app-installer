# sete7 v14.4 — busca de metadados locais

- Varredura somente leitura também em `%LOCALAPPDATA%/FiveM/FiveM.app/data/server-cache` e `server-cache-priv`, além de `mods` e `cache`.
- Descoberta pelo tipo XML `<CVehicleModelInfo__InitDataList>` em arquivos `.meta` com qualquer nome, rejeitando XMLs de outros recursos.
- Releitura assíncrona limitada a uma tentativa a cada 3 minutos somente quando forem observados modelos desconhecidos.
- Limites existentes de 25.000 arquivos percorridos, 3.000 arquivos `.meta` examinados e 4 MiB por arquivo mantidos.
- Três testes isolados passaram; compilação GOOS=windows/amd64 e `go vet` passaram.

Limitações: carros com metadados apenas empacotados não são resolvidos; nomes de sessão de players, FIX/Unlock e Through Wall não foram corrigidos nesta revisão.
