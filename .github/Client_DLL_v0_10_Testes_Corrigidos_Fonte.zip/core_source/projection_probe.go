//go:build windows

package main

import "math"

// cameraProjectionCandidate holds one plausible view-matrix layout. The scanner
// never writes to FiveM; candidates are evaluated against observed geometry.
type cameraProjectionCandidate struct {
	Offset     uintptr
	Transposed bool
	Matrix     matrix44
}

type projectedBodySample struct {
	Position vec3
	Height   float32
}

// scoreProjection evaluates a candidate across multiple *independent* target
// positions. A visible top and bottom, a correctly oriented bounding box and
// plausible height contribute evidence. This does NOT validate the underlying
// memory offsets or prove that the samples are actual players.
func scoreProjection(m matrix44, width, height int32, samples []projectedBodySample) int {
	score := 0
	for _, s := range samples {
		if !plausibleFiveMPosition(s.Position) || s.Height < 0.8 || s.Height > 3.0 {
			continue
		}
		x1, y1, ok1 := worldToScreen(m, s.Position, width, height)
		head := vec3{s.Position.X, s.Position.Y, s.Position.Z + s.Height}
		x2, y2, ok2 := worldToScreen(m, head, width, height)
		if !ok1 || !ok2 {
			continue
		}
		if _, _, _, _, valid := espBox(x2, y2, x1, y1, width, height, false); !valid {
			continue
		}
		score += 2
		h := y1 - y2
		if h > 6 && h < float64(height)*0.65 {
			score++
		}
		if math.Abs(x1-x2) < math.Max(h*0.2, 4) {
			score++
		}
	}
	return score
}

// chooseProjectionMatrix returns an index only when at least one projection is
// geometrically meaningful. Returning false is preferable to sky labels.
func chooseProjectionMatrix(width, height int32, candidates []cameraProjectionCandidate, samples []projectedBodySample) (int, []int, bool) {
	scores := make([]int, len(candidates))
	best, top := -1, 0
	for i, c := range candidates {
		scores[i] = scoreProjection(c.Matrix, width, height, samples)
		if scores[i] > top {
			best, top = i, scores[i]
		}
	}
	return best, scores, best >= 0
}

// chooseProjectionMatrixStable avoids jumping between near-equivalent camera
// offsets on successive frames. The preferred offset must still produce valid
// projected geometry; significantly better evidence overrides the preference.
func chooseProjectionMatrixStable(width, height int32, candidates []cameraProjectionCandidate, samples []projectedBodySample, preferredOffset uintptr) (int, []int, bool) {
	best, scores, valid := chooseProjectionMatrix(width, height, candidates, samples)
	if !valid {
		return best, scores, false
	}
	if preferredOffset == 0 {
		return best, scores, true
	}
	for i, candidate := range candidates {
		if candidate.Offset == preferredOffset && scores[i] >= 2 && scores[i]+1 >= scores[best] {
			return i, scores, true
		}
	}
	return best, scores, true
}

// transposeProjectionMatrix builds the alternate standard 4x4 layout.
// The external binary imports a matrix-transpose routine, but that does NOT
// establish the layout of its runtime camera data. This is an independent
// compatibility hypothesis, evaluated geometrically on each observed frame.
func transposeProjectionMatrix(m matrix44) (t matrix44) {
	for row := 0; row < 4; row++ {
		for col := 0; col < 4; col++ {
			t[row*4+col] = m[col*4+row]
		}
	}
	return
}

// Preserve the chosen orientation as well as the address. Two orientations
// from the same address must never be mistaken for the same stable candidate.
func chooseProjectionMatrixStableLayout(width, height int32, candidates []cameraProjectionCandidate, samples []projectedBodySample, preferredOffset uintptr, preferredTransposed bool) (int, []int, bool) {
	best, scores, valid := chooseProjectionMatrix(width, height, candidates, samples)
	if !valid || preferredOffset == 0 {
		return best, scores, valid
	}
	for i, c := range candidates {
		if c.Offset == preferredOffset && c.Transposed == preferredTransposed && scores[i] >= 2 && scores[i]+1 >= scores[best] {
			return i, scores, true
		}
	}
	return best, scores, true
}

// A stale or corrupted matrix must never generate direction-only markers.
// This check does not establish geometric validity for aim or boxes.
func directionMatrixNondegenerate(m matrix44) bool {
	rowNorm := func(a, b, c int) float64 {
		return math.Abs(float64(m[a])) + math.Abs(float64(m[b])) + math.Abs(float64(m[c]))
	}
	x, y, z := rowNorm(1, 5, 9), rowNorm(2, 6, 10), rowNorm(3, 7, 11)
	return x > 1e-7 && y > 1e-7 && z > 1e-7 && x < 1e8 && y < 1e8 && z < 1e8
}
