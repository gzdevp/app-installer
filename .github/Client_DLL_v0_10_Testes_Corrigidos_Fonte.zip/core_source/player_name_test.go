package main

import (
	"encoding/binary"
	"testing"
	"unicode/utf16"
)

type fakeNames map[uintptr][]byte

func (m fakeNames) read(at uintptr, out []byte) bool {
	v, ok := m[at]
	if !ok || len(v) < len(out) {
		return false
	}
	copy(out, v[:len(out)])
	return true
}
func makeBytes(input string) []byte { b := make([]byte, 80); copy(b, input); return b }
func TestNameInlineUTF8(t *testing.T) {
	m := fakeNames{0x200100: makeBytes("José_77")}
	if got := readFiveMPlayerName(0x200000, "b3258", m.read); got != "José_77" {
		t.Fatalf("%q", got)
	}
}
func TestNameInlineUTF16(t *testing.T) {
	b := make([]byte, 80)
	for i, c := range utf16.Encode([]rune("João Lima")) {
		binary.LittleEndian.PutUint16(b[i*2:], c)
	}
	m := fakeNames{0x200100: b}
	if got := readFiveMPlayerName(0x200000, "b3258", m.read); got != "João Lima" {
		t.Fatalf("%q", got)
	}
}
func TestNamePointer(t *testing.T) {
	field := make([]byte, 80)
	binary.LittleEndian.PutUint64(field, 0x900000)
	m := fakeNames{0x200100: field, 0x900000: makeBytes("Steam_Cesar")}
	if got := readFiveMPlayerName(0x200000, "b3258", m.read); got != "Steam_Cesar" {
		t.Fatalf("%q", got)
	}
}
func TestNameLegacy(t *testing.T) {
	m := fakeNames{0x200084: makeBytes("LegacyPlayer")}
	if got := readFiveMPlayerName(0x200000, "b2699", m.read); got != "LegacyPlayer" {
		t.Fatalf("%q", got)
	}
	if got := readFiveMPlayerName(0x200000, "b3258", m.read); got != "Jogador" {
		t.Fatalf("offset not safe: %q", got)
	}
}
func TestNameBadMemoryRejected(t *testing.T) {
	m := fakeNames{0x200100: make([]byte, 80)}
	if got := readFiveMPlayerName(0x200000, "b3258", m.read); got != "Jogador" {
		t.Fatalf("invalid: %q", got)
	}
}
func TestNameNoTerminatorRejected(t *testing.T) {
	m := fakeNames{0x200100: []byte("ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZAB")}
	if got := readFiveMPlayerName(0x200000, "b3258", m.read); got != "Jogador" {
		t.Fatalf("invalid: %q", got)
	}
}
func TestNameNoCrossRead(t *testing.T) {
	m := fakeNames{0x200100: makeBytes("Luna")}
	if got := readFiveMPlayerName(0x200000, "b3258", m.read); got != "Luna" {
		t.Fatalf("%q", got)
	}
}

func TestNameShortMemoryRegion(t *testing.T) {
	// Some PlayerInfo fields reside close to an unreadable page boundary.
	// A 24-byte readable name must not disappear just because 80 bytes fail.
	field := make([]byte, 24)
	copy(field, "Jogador_ComNome")
	m := fakeNames{0x200100: field}
	if got := readFiveMPlayerName(0x200000, "b3258", m.read); got != "Jogador_ComNome" {
		t.Fatalf("short field: %q", got)
	}
}

func TestNameNonLatinUTF16WithoutAlternatingNull(t *testing.T) {
	for _, input := range []string{"明月", "Сергей", "김민수"} {
		b := make([]byte, 80)
		for i, ch := range utf16.Encode([]rune(input)) {
			binary.LittleEndian.PutUint16(b[i*2:], ch)
		}
		m := fakeNames{0x200100: b}
		if got := readFiveMPlayerName(0x200000, "b3258", m.read); got != input {
			t.Fatalf("input=%q got=%q", input, got)
		}
	}
}

func TestNameUTF8StillPreferred(t *testing.T) {
	input := "Ayrton77"
	m := fakeNames{0x200100: makeBytes(input)}
	if got := readFiveMPlayerName(0x200000, "b3258", m.read); got != input {
		t.Fatalf("UTF-8 corrupted: %q", got)
	}
}

// Regression: printable address bytes must not be rendered as a person name.
func TestNamePointerPreferredOverAddressBytes(t *testing.T) {
	field := make([]byte, 80)
	binary.LittleEndian.PutUint64(field, 0x44434241) // low bytes spell "ABCD"
	m := fakeNames{0x200100: field, 0x44434241: makeBytes("RealSessionName")}
	if got := readFiveMPlayerName(0x200000, "b3258", m.read); got != "RealSessionName" {
		t.Fatalf("pointer bytes mistaken for username: %q", got)
	}
}

// Legacy layouts must take precedence when several offsets contain text.
func TestNameLegacyFieldPrecedence(t *testing.T) {
	m := fakeNames{0x200100: makeBytes("UnrelatedPrintableField"), 0x2000A4: makeBytes("LegacySession")}
	if got := readFiveMPlayerName(0x200000, "b2699", m.read); got != "LegacySession" {
		t.Fatalf("legacy offset precedence: %q", got)
	}
	if got := readFiveMPlayerName(0x200000, "b3258", m.read); got != "UnrelatedPrintableField" {
		t.Fatalf("modern offset precedence: %q", got)
	}
}
