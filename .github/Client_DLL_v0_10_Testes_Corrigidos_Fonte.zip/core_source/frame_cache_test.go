//go:build windows

package main

import (
	"sync"
	"testing"
	"time"
)

type frameViewport struct{ number uint64 }
type frameTarget struct{ number uint64 }

func TestFrameCachePublishesCoherentFrames(t *testing.T) {
	var c frameCache[frameTarget, frameViewport]
	var workers sync.WaitGroup
	workers.Add(2)
	go func() {
		defer workers.Done()
		for n := uint64(1); n <= 10000; n++ {
			c.publish(frameViewport{n}, []frameTarget{{n}})
		}
	}()
	go func() {
		defer workers.Done()
		for i := 0; i < 10000; i++ {
			vp, targets, _ := c.snapshot(time.Second)
			if len(targets) > 0 && targets[0].number != vp.number {
				t.Errorf("mixed frames: target=%d viewport=%d", targets[0].number, vp.number)
				return
			}
		}
	}()
	workers.Wait()
}

func TestFrameCacheIsolatesInputAndOutput(t *testing.T) {
	var c frameCache[frameTarget, frameViewport]
	source := []frameTarget{{7}}
	c.publish(frameViewport{7}, source)
	source[0].number = 999
	vp, got, seq := c.snapshot(time.Second)
	if seq != 1 || vp.number != 7 || got[0].number != 7 {
		t.Fatalf("input aliasing: %#v %#v seq=%d", vp, got, seq)
	}
	got[0].number = 123
	_, again, _ := c.snapshot(time.Second)
	if again[0].number != 7 {
		t.Fatal("output aliasing")
	}
	c.publish(frameViewport{}, nil)
	_, cleared, next := c.snapshot(time.Second)
	if len(cleared) != 0 || next != 2 {
		t.Fatalf("stale targets: %+v seq=%d", cleared, next)
	}
}

func TestFrameCacheExpiresOldRenderFrames(t *testing.T) {
	var c frameCache[frameTarget, frameViewport]
	c.publish(frameViewport{42}, []frameTarget{{42}})
	c.mu.Lock()
	c.updated = time.Now().Add(-3 * time.Second)
	c.mu.Unlock()
	vp, targets, _ := c.snapshot(800 * time.Millisecond)
	if vp.number != 0 || len(targets) != 0 {
		t.Fatalf("stale overlay is still rendered: %+v %+v", vp, targets)
	}
}
