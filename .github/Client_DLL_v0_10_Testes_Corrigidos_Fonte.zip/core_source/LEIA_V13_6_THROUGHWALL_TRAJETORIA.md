# sete7 v13.6 Black Edition — Through Wall / Trajetória (EXPERIMENTAL)

## Estado de validação
**Ainda NÃO foi demonstrado que atravesse paredes.** Este é um experimento isolado de redirecionamento da coordenada de DESTINO de disparos; ele não ignora colisão do mapa por si só e não controla o processamento de dano no servidor.

## Diferença técnica em relação à v13.5
- v13.5: fazia `CWeaponInfo::Penetration = 10.0f`, leitura de volta confirmada, mas tiros continuavam parando na parede no teste do usuário.
- v13.6: remove a escrita experimental de penetração e passa a testar redirecionar o ENDPOINT do disparo para uma cabeça validada no ESP. Não altera a origem do tiro, raycast ou regras de colisão, e não envia eventos forçados de dano.
- Reutiliza a função `silentRemote` existente sem alterar seu arquivo nem a lógica do Silent aprovado. Para não disputar os mesmos bytes de instrução, o Through Wall só funciona com o Silent desabilitado.
- Aimbot, Silent, ESP, TP, vida/armadura e outros arquivos aprovados na v13.3 permanecem byte a byte iguais.
- Executável da v13.3 original não foi modificado (SHA256: `23c8dc6e5b5be11875f0ba28b227e999d9a903bee387fe7d8064e382d1bd063f`).

## Teste sugerido em ambiente autorizado
1. Salve separadamente a v13.3 e **não rode dois executáveis ao mesmo tempo**.
2. Abra a v13.6, conecte ao FiveM b3258 com ESP exibindo os alvos.
3. **Desabilite o Silent Aim** (há trava para evitar dois hooks no mesmo trecho).
4. Ative Aim > Through Wall e configure uma tecla exclusiva (ex.: G ou Mouse 4).
5. Feche o menu com INSERT. Mire para uma posição projetada de outro jogador atrás de obstáculo e segure a tecla configurada enquanto dispara.
6. Solte a tecla. Abra o menu e confira o estado. A mensagem 'Destino do disparo redirecionado' indica apenas o hook da coordenada final, não prova dano.
7. Compare o dano no alvo visto por **outro** cliente/servidor; não confie só na sua tela, porque o dano pode ser rejeitado ou dessíncrono.

**Se continuar parando na parede**, o teste indicará que desviar o endpoint não é suficiente: precisamos investigar a colisão do motor e a validação de dano, em contexto de teste controlado. Nunca substituir a v13.3 por este experimento até validar o efeito.

## Verificações feitas neste ambiente
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build ...`: concluído.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test -c`: concluído (compilação dos testes, **sem execução Windows**).
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet ./...`: concluído.
- `node --check` de JS da interface e do preview: concluído.
- `go test ./aimv13`: passou.
- `go test ./...` nativo Linux: não é suportado pela base do app (componentes dependem de tags `windows`), e não indica falha do build Windows.
- **NÃO houve execução nem validação em FiveM** neste ambiente.

## Limitações
- A função testa apenas alvo elegível com cabeça 3D validada no ESP (jogadores; NPCs são ignorados neste protótipo).
- O filtro usa FOV de teste 500 px e distância máxima 500 m; não há uma checagem de linha de visão verdadeira no código externo.
- A rotina original Silent tem prioridade; se Silent estiver habilitado a experiência Through Wall para automaticamente.
- Risco de crash ou incompatibilidade com atualizações, então faça testes apenas em ambiente controlado.
