# Sete7 v13.9.17 — ajuste delicado do espaçamento

- Nome Sete7: letter-spacing de 0,25 px para 0,35 px.
- Mantidos logo, fonte, tamanho, cores, layout e funções da versão anterior.
- Versão e pasta de perfil separadas, para não alterar o executável base.
- Alteração de UI não validada no FiveM; conferir prévia e EXE no Windows.
