//go:build windows

package main

import (
	"encoding/binary"
	"fmt"
	"math"
	"sync"
	"time"
	"unsafe"
)

// The only blip list profile identified for this implementation is b3258.
// It is an experimental external community offset, not a stable FiveM API.
var tpBlipOffsets = map[string]uintptr{
	"b3258": 0x2023400,
}

var tpWayState = struct {
	sync.RWMutex
	Status  string `json:"status"`
	At      string `json:"at"`
	Success bool   `json:"success"`
}{Status: "Aguardando TP Waypoint"}
var tpWayMutex sync.Mutex

func tpWayReport(message string, success bool) (string, bool) {
	tpWayState.Lock()
	tpWayState.Status, tpWayState.Success = message, success
	tpWayState.At = time.Now().Format("15:04:05")
	tpWayState.Unlock()
	return message, success
}
func tpWayGet() map[string]any {
	tpWayState.RLock()
	defer tpWayState.RUnlock()
	return map[string]any{"status": tpWayState.Status, "success": tpWayState.Success, "at": tpWayState.At}
}
func tpWriteVector(handle uintptr, address uintptr, pos vec3) bool {
	if handle == 0 || address < 0x10000 || !plausibleFiveMPosition(pos) {
		return false
	}
	var b [12]byte
	binary.LittleEndian.PutUint32(b[0:4], math.Float32bits(pos.X))
	binary.LittleEndian.PutUint32(b[4:8], math.Float32bits(pos.Y))
	binary.LittleEndian.PutUint32(b[8:12], math.Float32bits(pos.Z))
	var count uintptr
	ok, _, _ := noclipWriteProcessMemory.Call(handle, address, uintptr(unsafe.Pointer(&b[0])), uintptr(len(b)), uintptr(unsafe.Pointer(&count)))
	return ok != 0 && count == uintptr(len(b))
}
func tpWayAction(z float32) (string, bool) {
	tpWayMutex.Lock()
	defer tpWayMutex.Unlock()
	if _, e := tpDestination(vec3{X: 1, Y: 1}, z); e != nil {
		return tpWayReport("TP Waypoint: "+e.Error(), false)
	}
	noclipController.RLock()
	noclipActive := noclipController.active && noclipController.settings.Enabled
	noclipController.RUnlock()
	if noclipActive {
		return tpWayReport("Desative o Noclip antes do TP Waypoint", false)
	}

	a, err := attachWritableGame()
	if err != nil {
		return tpWayReport("TP Waypoint: "+err.Error(), false)
	}
	defer a.close()
	p := a.read
	offset, known := tpBlipOffsets[p.build]
	if !known {
		return tpWayReport("TP Waypoint: leitura de waypoint sem perfil para "+p.build, false)
	}
	layout := espLayouts[p.build]
	world := p.ptr(p.base + layout.world)
	if world == 0 {
		return tpWayReport("TP Waypoint: mundo indisponível", false)
	}
	ped := p.ptr(world + 0x8)
	if ped == 0 {
		return tpWayReport("TP Waypoint: personagem local indisponível", false)
	}
	before, ok := p.vec3(ped + 0x90)
	if !ok || !plausibleFiveMPosition(before) {
		return tpWayReport("TP Waypoint: posição do personagem inválida", false)
	}

	// A navigation transform is needed to keep the engine and ped in sync.
	nav := p.ptr(ped + 0x30)
	if nav == 0 {
		return tpWayReport("TP Waypoint: navegação do personagem indisponível", false)
	}
	navBefore, ok := p.vec3(nav + 0x50)
	if !ok || !plausibleFiveMPosition(navBefore) || dist(navBefore, before) > 25 {
		return tpWayReport("TP Waypoint: navegação não corresponde ao personagem", false)
	}
	// Restrict this initial implementation to walking. Vehicle navigation and
	// replicated occupant position require separate verified state transitions.
	if profile, ok := vehicleWriteProfiles[p.build]; ok {
		vehicle := p.ptr(ped + profile.PedVehicle)
		if vehicle != 0 {
			if vehiclePos, readable := p.vec3(vehicle + 0x90); readable && plausibleFiveMPosition(vehiclePos) && dist(before, vehiclePos) < 8 {
				return tpWayReport("TP Waypoint: saia do veículo antes de teleportar", false)
			}
		}
	}

	waypoint, err := tpFindWaypoint(p.read, p.base+offset)
	if err != nil {
		return tpWayReport("TP Waypoint: "+err.Error(), false)
	}
	dest, err := tpDestination(waypoint, z)
	if err != nil {
		return tpWayReport("TP Waypoint: "+err.Error(), false)
	}
	// Recheck the selected local actor immediately before changing its transform.
	if p.ptr(world+0x8) != ped {
		return tpWayReport("TP Waypoint: personagem mudou; ação cancelada", false)
	}
	if !tpWriteVector(a.writer, nav+0x50, dest) {
		return tpWayReport("TP Waypoint: falha ao escrever navegação", false)
	}
	if !tpWriteVector(a.writer, ped+0x90, dest) {
		_ = tpWriteVector(a.writer, nav+0x50, navBefore)
		return tpWayReport("TP Waypoint: falha ao escrever personagem", false)
	}
	actualPed, pedOK := p.vec3(ped + 0x90)
	actualNav, navOK := p.vec3(nav + 0x50)
	if !pedOK || !navOK || dist(actualPed, dest) > 3 || dist(actualNav, dest) > 3 {
		// Readback can fail if the game immediately resimulates or the server
		// corrects a local edit. Do not claim server-side teleport success.
		return tpWayReport("TP enviado, mas leitura não confirmou a posição (servidor pode corrigir)", false)
	}
	return tpWayReport(fmt.Sprintf("TP enviado: X %.0f · Y %.0f · Z %.0f (servidor não verificado)", dest.X, dest.Y, dest.Z), true)
}
