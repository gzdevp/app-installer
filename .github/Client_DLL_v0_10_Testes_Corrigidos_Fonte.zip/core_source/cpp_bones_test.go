package main

import "testing"

type fakeCPPBoneReader struct {
	p map[uintptr]uintptr
	u map[uintptr]uint32
	m map[uintptr]matrix44
}

func (r fakeCPPBoneReader) ptr(a uintptr) uintptr             { return r.p[a] }
func (r fakeCPPBoneReader) uint32(a uintptr) uint32           { return r.u[a] }
func (r fakeCPPBoneReader) matrix(a uintptr) (matrix44, bool) { v, ok := r.m[a]; return v, ok }

func identityBoneMatrix(x, y, z float32) matrix44 {
	m := matrix44{}
	m[0], m[5], m[10], m[15] = 1, 1, 1, 1
	m[12], m[13], m[14] = x, y, z
	return m
}

func setupCPPFake() fakeCPPBoneReader {
	r := fakeCPPBoneReader{p: map[uintptr]uintptr{}, u: map[uintptr]uint32{}, m: map[uintptr]matrix44{}}
	const ped, frag, mid, skel, meta, tf, mats, table = uintptr(0x100000), uintptr(0x200000), uintptr(0x300000), uintptr(0x400000), uintptr(0x500000), uintptr(0x600000), uintptr(0x700000), uintptr(0x800000)
	r.p[ped+0x1430] = frag
	r.p[frag+0x68] = mid
	r.p[mid+0x178] = skel
	r.p[skel] = meta
	r.p[skel+0x8] = tf
	r.p[skel+0x18] = mats
	r.p[meta+0x10] = table
	r.u[meta+0x18] = 11
	r.u[meta+0x1a] = 1
	r.m[tf] = identityBoneMatrix(10, 10, 20)
	masks := []struct {
		mask uint32
		id   uint32
		pos  vec3
	}{
		{cppHead, 1, vec3{0, 0, 1.7}},
		{cppNeck, 2, vec3{0, 0, 1.48}},
		{cppPelvis, 3, vec3{0, 0, .88}},
		{0x3779, 4, vec3{-.15, 0, .05}},
		{0xcc4d, 5, vec3{.15, 0, .05}},
		{0xe39f, 6, vec3{-.15, 0, .7}},
		{0xca72, 7, vec3{.15, 0, .7}},
		{0x49d9, 8, vec3{-.5, 0, 1.12}},
		{0xdead, 9, vec3{.5, 0, 1.12}},
	}
	for i, b := range masks {
		node := uintptr(0xA00000 + i*0x40)
		bucket := table + uintptr(b.mask%11)*8
		r.p[node+8] = r.p[bucket]
		r.p[bucket] = node
		r.u[node] = b.mask
		r.u[node+4] = b.id
		r.m[mats+uintptr(b.id)*0x40] = identityBoneMatrix(b.pos.X, b.pos.Y, b.pos.Z)
	}
	return r
}
func TestCPPBoneReferenceResolvesHeadFromHashTable(t *testing.T) {
	r := setupCPPFake()
	pts, valid, stage := cppReadPose(r, 0x100000, vec3{10, 10, 20})
	if stage != cppBoneVerified || !valid[0] || pts[0].Z < 21.69 || pts[0].Z > 21.71 {
		t.Fatalf("head not recovered: stage=%v valid=%v pos=%v", stage, valid[0], pts[0])
	}
}
func TestCPPBoneNoFragmentFailsClosed(t *testing.T) {
	r := fakeCPPBoneReader{p: map[uintptr]uintptr{}, u: map[uintptr]uint32{}, m: map[uintptr]matrix44{}}
	_, _, stage := cppReadPose(r, 0x100000, vec3{})
	if stage != cppBoneNoFragment {
		t.Fatalf("stage = %v", stage)
	}
}
func TestCPPBoneRejectsBadPose(t *testing.T) {
	r := setupCPPFake()
	// Force pelvis above the head. The pose must be discarded, even if the
	// hash table and every pointer are readable.
	r.m[0x700000+3*0x40] = identityBoneMatrix(0, 0, 2.2)
	_, _, stage := cppReadPose(r, 0x100000, vec3{10, 10, 20})
	if stage != cppBoneBadPose {
		t.Fatalf("stage = %v", stage)
	}
}
