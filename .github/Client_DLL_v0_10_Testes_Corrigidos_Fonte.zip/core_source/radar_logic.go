package main

import "math"

// North-up radar math, independent from projection and screen-space ESP.
type radarPoint struct{ X, Y float64 }

func radarProject(origin, other vec3, meters float64, radius float64) (radarPoint, bool) {
	if meters <= 0 || radius <= 0 {
		return radarPoint{}, false
	}
	x := float64(other.X - origin.X)
	y := float64(other.Y - origin.Y)
	if math.IsNaN(x) || math.IsNaN(y) || math.IsInf(x, 0) || math.IsInf(y, 0) {
		return radarPoint{}, false
	}
	if math.Hypot(x, y) > meters {
		return radarPoint{}, false
	}
	return radarPoint{X: x * radius / meters, Y: -y * radius / meters}, true
}
func clampRadarRange(r int) int {
	if r < 50 {
		return 50
	}
	if r > 500 {
		return 500
	}
	return r
}
func clampRadarSize(s int) int {
	if s < 50 {
		return 50
	}
	if s > 200 {
		return 200
	}
	return s
}
func clampRadarOpacity(a int) int {
	if a < 0 {
		return 0
	}
	if a > 100 {
		return 100
	}
	return a
}
