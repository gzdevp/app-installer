package main

import (
	"strconv"
	"strings"
)

// rgbToColorRef turns #RRGGBB into Windows GDI 0x00BBGGRR.
// Invalid input falls back to the supplied color; no code or markup is evaluated.
func rgbToColorRef(s string, fallback uint32) uint32 {
	if len(s) != 7 || s[0] != '#' {
		return fallback
	}
	n, err := strconv.ParseUint(s[1:], 16, 24)
	if err != nil {
		return fallback
	}
	return uint32((n&0xff)<<16 | (n & 0xff00) | (n >> 16))
}

func normalizedHex(s, fallback string) string {
	if len(s) != 7 || s[0] != '#' {
		return fallback
	}
	_, err := strconv.ParseUint(s[1:], 16, 24)
	if err != nil {
		return fallback
	}
	return "#" + strings.ToUpper(s[1:])
}
