//go:build windows

package main

import "time"

// prewarmMenuBrowser prepares Chromium in the background so the first INSERT
// does not have to wait for a cold browser start. No window is presented until
// the user presses INSERT in FiveM, and no browser is started outside FiveM.
// The existing requestMenuBrowser atomic guard prevents duplicate launches if
// INSERT is pressed while prewarming is underway.
func prewarmMenuBrowser(s *service) {
	ticker := time.NewTicker(1500 * time.Millisecond)
	defer ticker.Stop()
	for {
		if s.stopping.Load() {
			return
		}
		if s.findFiveM() {
			if menuWindow() == 0 && !menuWanted.Load() {
				requestMenuBrowser(s)
			}
			return
		}
		<-ticker.C
	}
}
