package main

import (
	"math"
	"testing"
)

func TestWeaponPlausibility(t *testing.T) {
	for _, v := range []float32{0, 1, 12, 100} {
		if !weaponValuePlausible(v) {
			t.Fatalf("plausible %f", v)
		}
	}
	for _, v := range []float32{-1, 101, float32(math.NaN()), float32(math.Inf(1))} {
		if weaponValuePlausible(v) {
			t.Fatalf("invalid %f", v)
		}
	}
}
func TestWeaponZero(t *testing.T) {
	if !weaponZeroConfirmed(0) || weaponZeroConfirmed(0.1) {
		t.Fatal("zero confirmation")
	}
}
