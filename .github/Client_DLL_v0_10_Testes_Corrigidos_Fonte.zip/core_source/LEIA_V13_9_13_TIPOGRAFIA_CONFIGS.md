# sete7 v13.9.13 — tipografia e organização do Settings

- Base integral v13.9.12, com modificações restritas a `web/index.html`, `main.go` e `window_title.go`.
- Prioridade de fonte: SF Pro Text e SF Pro Display, quando instaladas no Windows; Inter carregada remotamente como alternativa, seguida de Segoe UI Variable/Segoe UI. Não inclui arquivos de fontes. Portanto o resultado não é garantidamente idêntico se as fontes da referência não estiverem disponíveis.
- Settings -> Interface: somente orientações de navegação/movimentação da janela.
- Settings -> Configs: perfis, importar/exportar, Unload e Cleaner, com confirmação preexistente preservada.
- Títulos e pasta local da instância atualizados para v13.9.13 para prevenir conflito entre janelas e configurações da base.
- NÃO alteramos a lógica de jogo, as rotinas nativas, os endpoints, nem as semânticas do Cleaner e Unload.
- Compilação Windows/testes estáticos não comprovam comportamento do FiveM em jogo.
