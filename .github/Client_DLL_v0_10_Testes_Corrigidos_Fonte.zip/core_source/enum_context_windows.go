//go:build windows

package main

import (
	"sync"
	"sync/atomic"
)

// A fixed Win32 EnumWindows callback can serve concurrent enumerations.
// The LParam is an opaque, incrementing handle to Go-owned scan state. Avoid
// converting a foreign uintptr to a Go pointer or registering new callbacks
// on every scan. Each entry disappears as soon as EnumWindows returns.
var windowEnumNextID atomic.Uint64
var windowEnumContexts sync.Map

func enumWindowsWithContext(callback uintptr, state any) {
	id := uintptr(windowEnumNextID.Add(1))
	windowEnumContexts.Store(id, state)
	defer windowEnumContexts.Delete(id)
	enumWindows.Call(callback, id)
}
