//go:build !windows

package main

func localUnlockSet(enabled bool)       {}
func localUnlockSetEntryKey(key string) {}
func localUnlockGet() map[string]any {
	return map[string]any{"enabled": false, "status": "Somente Windows", "serverConfirmed": false}
}
func startLocalAutoUnlock()                                          {}
func localVehicleLockAttempt(id uint64, desired byte) (string, bool) { return "Somente Windows", false }
