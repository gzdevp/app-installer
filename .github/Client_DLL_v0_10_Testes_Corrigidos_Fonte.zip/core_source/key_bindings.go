package main

import "strings"

// Reserved keys must not trigger unrelated destructive actions in the app.
func validBindingKey(key string) bool {
	key = strings.ToLower(strings.TrimSpace(key))
	if len(key) == 1 {
		c := key[0]
		return (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')
	}
	switch key {
	case "mouse1", "mouse2", "mouse3", "mouse4", "mouse5", "shift", "ctrl", "alt", "space",
		"enter", "tab", "backspace", "delete", "home", "end", "pageup", "pagedown",
		"up", "down", "left", "right", "capslock", "numlock", "scrolllock", "pause",
		"numadd", "numsub", "nummul", "numdiv", "numdecimal":
		return true
	}
	if len(key) == 4 && strings.HasPrefix(key, "num") && key[3] >= '0' && key[3] <= '9' {
		return true
	}
	if len(key) >= 2 && key[0] == 'f' {
		n := 0
		for _, c := range key[1:] {
			if c < '0' || c > '9' {
				return false
			}
			n = n*10 + int(c-'0')
		}
		return n >= 1 && n <= 12 && n != 6
	}
	return false
}

func genericKeyVK(key string, fallback uintptr) uintptr {
	key = strings.ToLower(strings.TrimSpace(key))
	if !validBindingKey(key) {
		return fallback
	}
	if len(key) == 1 {
		c := key[0]
		if c >= 'a' && c <= 'z' {
			return uintptr(c - 'a' + 'A')
		}
		return uintptr(c)
	}
	switch key {
	case "mouse1":
		return 0x01
	case "mouse2":
		return 0x02
	case "mouse3":
		return 0x04
	case "mouse4":
		return 0x05
	case "mouse5":
		return 0x06
	case "shift":
		return 0x10
	case "ctrl":
		return 0x11
	case "alt":
		return 0x12
	case "space":
		return 0x20
	case "enter":
		return 0x0D
	case "tab":
		return 0x09
	case "backspace":
		return 0x08
	case "delete":
		return 0x2E
	case "home":
		return 0x24
	case "end":
		return 0x23
	case "pageup":
		return 0x21
	case "pagedown":
		return 0x22
	case "up":
		return 0x26
	case "down":
		return 0x28
	case "left":
		return 0x25
	case "right":
		return 0x27
	case "capslock":
		return 0x14
	case "numlock":
		return 0x90
	case "scrolllock":
		return 0x91
	case "pause":
		return 0x13
	case "numadd":
		return 0x6B
	case "numsub":
		return 0x6D
	case "nummul":
		return 0x6A
	case "numdiv":
		return 0x6F
	case "numdecimal":
		return 0x6E
	}
	if len(key) == 4 && strings.HasPrefix(key, "num") {
		return uintptr(0x60 + int(key[3]-'0'))
	}
	n := 0
	for _, c := range key[1:] {
		n = n*10 + int(c-'0')
	}
	return uintptr(0x6F + n)
}
