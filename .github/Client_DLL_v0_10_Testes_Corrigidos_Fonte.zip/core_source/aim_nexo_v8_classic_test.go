package main

import (
	"math"
	"testing"
)

func TestClassicV8AboveIsNegativeY(t *testing.T) {
	_, y, ok := classicNexoV8Step(960, 337, 1920, 1080, 12)
	if !ok || y != -32 {
		t.Fatalf("above must move up, got %d %v", y, ok)
	}
}
func TestClassicV8BelowIsPositiveY(t *testing.T) {
	_, y, ok := classicNexoV8Step(960, 740, 1920, 1080, 12)
	if !ok || y != 32 {
		t.Fatalf("below must move down, got %d %v", y, ok)
	}
}
func TestClassicV8Left(t *testing.T) {
	x, _, ok := classicNexoV8Step(100, 540, 1920, 1080, 12)
	if !ok || x != -32 {
		t.Fatalf("left %d %v", x, ok)
	}
}
func TestClassicV8Right(t *testing.T) {
	x, _, ok := classicNexoV8Step(1400, 540, 1920, 1080, 12)
	if !ok || x != 32 {
		t.Fatalf("right %d %v", x, ok)
	}
}
func TestClassicV8Centre(t *testing.T) {
	_, _, ok := classicNexoV8Step(960, 540, 1920, 1080, 12)
	if ok {
		t.Fatal("centre should not move")
	}
}
func TestClassicV8RejectsNaN(t *testing.T) {
	_, _, ok := classicNexoV8Step(math.NaN(), 540, 1920, 1080, 12)
	if ok {
		t.Fatal("nan")
	}
}
func TestClassicV8RejectsOutsideViewport(t *testing.T) {
	_, _, ok := classicNexoV8Step(2000, 540, 1920, 1080, 12)
	if ok {
		t.Fatal("outside")
	}
}
func TestClassicV8ExactQuarter(t *testing.T) {
	x, y, ok := classicNexoV8Step(990, 520, 1920, 1080, 12)
	if !ok || x != 8 || y != -5 {
		t.Fatalf("quarter expected +8,-5 got %+d,%+d %v", x, y, ok)
	}
}
func TestClassicV8SmoothMonotonic(t *testing.T) {
	x1, _, _ := classicNexoV8Step(980, 540, 1920, 1080, 6)
	x2, _, _ := classicNexoV8Step(980, 540, 1920, 1080, 12)
	if x1 <= x2 {
		t.Fatalf("smooth scaling %d %d", x1, x2)
	}
}
