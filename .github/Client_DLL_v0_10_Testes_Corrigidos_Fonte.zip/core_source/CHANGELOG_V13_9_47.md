# 77 v13.9.47 — Fix Car no veículo atual

- Botão Fix Car da aba Vehicles funciona sem selecionar carro e sem habilitar ESP.
- O comando usa `POST /api/fixcar` com identificador 0, reservado ao veículo local.
- F6 permanece disponível no FiveM.
- Antes de escrever, exige veículo no pool ativo, valida posições, saúde e identidade.
- Motor, lataria e tanque: escrita experimental b3258; não é uma chamada completa ao native de reparo (pneus e deformações não são garantidos).
- Nenhuma outra função ou controle foi intencionalmente modificado.
- Testes estáticos Windows não demonstram êxito real no FiveM.
