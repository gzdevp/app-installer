//go:build windows

package main

// Experimental external FiveM ESP reader with build profiles.
// Actual pointer chains are validated independently for each supported build.
// This ESP scanner uses PROCESS_VM_READ only; the separate optional No clip module
// writes validated local position coordinates when explicitly enabled.
// Offset snapshots are build-dependent; unsupported builds are refused.
import (
	"encoding/binary"
	"fmt"
	"math"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

type ESPSettings struct {
	Enabled        bool              `json:"enabled"`
	Nearby         bool              `json:"nearby"`
	NearbyRange    int               `json:"nearbyRange"`
	ShowNPC        bool              `json:"showNpc"`
	Skeleton       bool              `json:"skeleton"`
	SkeletonColor  string            `json:"skeletonColor"`
	FriendColor    string            `json:"friendColor"`
	Offscreen      bool              `json:"offscreen"`
	WeaponESP      bool              `json:"weaponEsp"`
	IgnoreDowned   bool              `json:"ignoreDowned"`
	FocusName      string            `json:"focusName"`
	ShowDistance   bool              `json:"showDistance"`
	Boxes          bool              `json:"boxes"`
	Names          bool              `json:"names"`
	Friends        []string          `json:"friends"`
	Health         bool              `json:"health"`
	Armor          bool              `json:"armor"`
	Vehicles       bool              `json:"vehicles"`
	VehicleRange   int               `json:"vehicleRange"`
	VehicleName    bool              `json:"vehicleName"`
	VehicleAliases map[string]string `json:"vehicleAliases,omitempty"`
	Distance       int               `json:"distance"`
	RefreshMS      int               `json:"refreshMS"`
	BoxStyle       string            `json:"boxStyle"`
	Snaplines      bool              `json:"snaplines"`
}
type targetESP struct {
	X, Y, W, H    int32
	Distance      int
	Health, Armor int
	Vehicle       bool
	IsNPC         bool
	Name          string
	Friend        bool
	NameAmbiguous bool
	Offscreen     bool
	Behind        bool
	WeaponName    string
	Focus         bool
	Downed        bool
	Bones         [][4]int32
	// Internal-only data for candidate selection. Not drawn or sent to Worker.
	World        vec3
	Origin       vec3
	PedID        uint64
	AimX, AimY   int32 // current frame's screen-space aim anchor
	AimFromBone  bool  // true only when real joint data was validated
	HeadWorld    vec3  // verified world-space skull, never estimated from box
	HeadVerified bool
}
type espViewport struct {
	X, Y, W, H int32
	PID        uint32
	// This immutable camera matrix belongs to the same frame as its projected heads.
	Camera      matrix44
	CameraValid bool
}
type nearbyPlayerLabel struct {
	Name       string `json:"name"`
	Distance   int    `json:"distance"`
	Friend     bool   `json:"friend"`
	Ambiguous  bool   `json:"ambiguous"`
	Offscreen  bool   `json:"offscreen"`
	Behind     bool   `json:"behind"`
	Weapon     string `json:"weapon,omitempty"`
	Source     string `json:"source"`
	Identified bool   `json:"identified"`
	Downed     bool   `json:"downed"`
}
type ESPStatus struct {
	LivePlayers []nearbyPlayerLabel `json:"livePlayers"`
	Build       string              `json:"build"`
	Process     string              `json:"process"`
	Support     string              `json:"support"`
	Status      string              `json:"status"`
	Targets     int                 `json:"targets"`
	Frames      int                 `json:"frames"`
	ReadHz      float64             `json:"readHz"`
	Settings    ESPSettings         `json:"settings"`
	Diagnostics ESPDiagnostics      `json:"diagnostics"`
}

var espData = struct {
	sync.RWMutex
	settings ESPSettings
	status   ESPStatus
}{settings: ESPSettings{Boxes: true, Names: true, ShowDistance: true, Skeleton: true, Health: true, Armor: true, Vehicles: false, Distance: 190, RefreshMS: 25, SkeletonColor: "#FFFFFF", FriendColor: "#42E5A0"}}

var espRendered frameCache[targetESP, espViewport]
var espSettingsRevision atomic.Uint64

// A camera transform accepted by the existing ESP projection tests may also
// be reused for local noclip motion. This is read-only shared state; the
// v12.20 Silent and bone-reader algorithms are unchanged.
var lastValidatedCamera = struct {
	sync.RWMutex
	matrix matrix44
	pid    uint32
	when   time.Time
}{}

func verifiedCamera(pid uint32) (matrix44, bool) {
	lastValidatedCamera.RLock()
	defer lastValidatedCamera.RUnlock()
	return lastValidatedCamera.matrix, lastValidatedCamera.pid == pid && time.Since(lastValidatedCamera.when) < time.Second
}

func espGet() ESPStatus {
	espData.RLock()
	defer espData.RUnlock()
	s := espData.status
	s.Settings = espData.settings
	return s
}
func espSet(s ESPSettings) {
	s.SkeletonColor = normalizedHex(s.SkeletonColor, "#FFFFFF")
	s.FriendColor = normalizedHex(s.FriendColor, "#42E5A0")
	if s.BoxStyle != "full" {
		s.BoxStyle = "corner"
	}
	// Automatic low-latency setting, no UI knob or old profile override.
	s.RefreshMS = 25
	s.VehicleRange = clampVehicleESPRange(s.VehicleRange)
	s.Friends = normalizeFriends(s.Friends)
	if s.NearbyRange < 30 {
		s.NearbyRange = 30
	}
	if s.NearbyRange > 500 {
		s.NearbyRange = 500
	}
	s.VehicleAliases = normalizeVehicleAliases(s.VehicleAliases)
	s.FocusName = strings.TrimSpace(s.FocusName)
	if len(s.FocusName) > 45 {
		s.FocusName = ""
	}
	if s.Distance < 30 {
		s.Distance = 30
	}
	if s.Distance > 500 {
		s.Distance = 500
	}
	espData.Lock()
	espData.settings = s
	espData.Unlock()
	espSettingsRevision.Add(1)
}
func espFrame() (espViewport, []targetESP) {
	viewport, targets, _ := espRendered.snapshot(800 * time.Millisecond)
	return viewport, targets
}
func espSetDiagnostics(d ESPDiagnostics) {
	espData.Lock()
	espData.status.Diagnostics = d
	espData.Unlock()
}

// buildNearbyPlayerList is only fed validated network-ped candidates. Unknown
// nicknames remain visible for distance awareness, but cannot be friended.
func buildNearbyPlayerList(players []candidatePed, names map[uintptr]string, counts map[string]int, friends []string, maxRange int) []nearbyPlayerLabel {
	if maxRange < 30 {
		maxRange = 30
	}
	if maxRange > 500 {
		maxRange = 500
	}
	result := make([]nearbyPlayerLabel, 0, len(players))
	for _, p := range players {
		if p.isNPC || p.distance < 0.1 || p.distance > float64(maxRange) {
			continue
		}
		name := names[p.ptr]
		identified := validFriendName(name)
		if !identified {
			name = "Nome FiveM indisponível"
		}
		result = append(result, nearbyPlayerLabel{
			Name: name, Distance: int(math.Round(p.distance)), Source: map[bool]string{true: "Nome lido (origem não verificada)", false: "Nome indisponível"}[identified],
			Identified: identified, Friend: identified && verifiedFriend(name, friends, counts),
			Ambiguous: !identified || counts[friendKey(name)] > 1, Downed: p.health <= 100,
		})
	}
	sort.SliceStable(result, func(i, j int) bool {
		if result[i].Distance != result[j].Distance {
			return result[i].Distance < result[j].Distance
		}
		return friendKey(result[i].Name) < friendKey(result[j].Name)
	})
	if len(result) > 256 {
		result = result[:256]
	}
	return result
}

func espPublish(build, process, support, status string, viewport espViewport, targets []targetESP, nearby []nearbyPlayerLabel, frame bool) {
	espData.Lock()
	defer espData.Unlock()
	espData.status.Build = build
	espData.status.Process = process
	espData.status.Support = support
	espData.status.Status = status
	espData.status.Targets = len(targets)
	espData.status.LivePlayers = append([]nearbyPlayerLabel{}, nearby...)
	if frame {
		espData.status.Frames++
	}
	// Publish the camera transform with its matching ESP frame. Calibration of
	// camera movement must never compare two unrelated reads of the view matrix.
	if frame && viewport.PID != 0 {
		viewport.Camera, viewport.CameraValid = verifiedCamera(viewport.PID)
	}
	// The render frame is atomic: viewport and target positions must correspond.
	espRendered.publish(viewport, targets)
}

var snapshotProc = kernel32Process.NewProc("CreateToolhelp32Snapshot")
var espProcessFirst = kernel32Process.NewProc("Process32FirstW")
var espProcessNext = kernel32Process.NewProc("Process32NextW")
var moduleFirst = kernel32Process.NewProc("Module32FirstW")
var moduleNext = kernel32Process.NewProc("Module32NextW")
var openProcessProc = kernel32Process.NewProc("OpenProcess")
var readProcessMemory = kernel32Process.NewProc("ReadProcessMemory")
var espCloseHandleProc = kernel32Process.NewProc("CloseHandle")
var waitForSingleObject = kernel32Process.NewProc("WaitForSingleObject")

const (
	espTh32csSnapProcess = 0x2
	th32csSnapModule     = 0x8
	th32csSnapModule32   = 0x10
	processVMRead        = 0x10
	processQueryLimited  = 0x1000
	processSynchronize   = 0x00100000
)

type procEntry32 struct {
	Size, Use, PID            uint32
	Heap                      uintptr
	ModuleID, Threads, Parent uint32
	Priority                  int32
	Flags                     uint32
	Name                      [260]uint16
}
type moduleEntry32 struct {
	Size, ModuleID, PID, GlobalUses, ProcessUses uint32
	Base                                         uintptr
	BaseSize                                     uint32
	Module                                       uintptr
	Name                                         [256]uint16
	Path                                         [260]uint16
}
type attachedESP struct {
	handle               uintptr
	pid                  uint32
	base                 uintptr
	build                string
	name                 string
	lastMatrixOffset     uintptr
	lastMatrixTransposed bool
	nearby               []nearbyPlayerLabel
}

// Windows process handles become signalled when the process exits.  Checking
// liveness prevents the reader from remaining attached to a dead FiveM PID.
func espProcessExited(h uintptr) bool {
	if h == 0 || h == ^uintptr(0) {
		return true
	}
	result, _, _ := waitForSingleObject.Call(h, 0)
	// WAIT_FAILED does not mean the process exited.  It may be a rights or
	// transient API error, so allow the subsequent read check to decide.
	return espWaitReportsExit(result)
}

func closeESP(h uintptr) {
	if h != 0 && h != ^uintptr(0) {
		espCloseHandleProc.Call(h)
	}
}

// Profiles do not guarantee live-game behavior. Fail closed when layouts differ.
// b3095 addresses are experimental community references and must be validated on-device.
type espLayout struct{ world, replay, viewport, boneList, playerInfo, armor uintptr }

var espLayouts = map[string]espLayout{
	// Community offset profiles are experimental; pointer/geometry checks
	// must succeed before any entity data is displayed.
	"b3407": {0x25D7108, 0x1F9A9D8, 0x20431C0, 0x410, 0x10A8, 0x150C},
	"b3323": {0x25C15B0, 0x1F85458, 0x202DC50, 0x410, 0x10A8, 0x150C},
	"b3258": {0x25B14B0, 0x1FBD4F0, 0x201DBA0, 0x410, 0x10A8, 0x150C},
	"b3095": {0x2593320, 0x1F58B58, 0x20019E0, 0x410, 0x10A8, 0x150C},
	"b2944": {0x257BEA0, 0x1F42068, 0x1FEAAC0, 0x410, 0x10A8, 0x150C},
	"b2802": {0x254D448, 0x1F5B820, 0x1FBC100, 0x410, 0x10A8, 0x150C},
	"b2699": {0x26684D8, 0x20304C8, 0x20D8C90, 0x430, 0x10C8, 0x1530},
}

func parseFiveMBuild(name string) string {
	lower := strings.ToLower(name)
	if strings.HasPrefix(lower, "fivem_b") && strings.HasSuffix(lower, "_gtaprocess.exe") {
		b := strings.TrimSuffix(strings.TrimPrefix(lower, "fivem_"), "_gtaprocess.exe")
		if len(b) == 5 && b[0] == 'b' {
			for _, ch := range b[1:] {
				if ch < '0' || ch > '9' {
					return ""
				}
			}
			return b
		}
	}
	return ""
}
func findESP() (*attachedESP, string, string, error) {
	snap, _, _ := snapshotProc.Call(espTh32csSnapProcess, 0)
	if snap == 0 || snap == ^uintptr(0) {
		return nil, "", "", fmt.Errorf("Não foi possível enumerar processos")
	}
	defer closeESP(snap)
	var p procEntry32
	p.Size = uint32(unsafe.Sizeof(p))
	var unsupportedBuild, unsupportedName string
	var failedBuild, failedName string
	var firstFailure error
	recordFailure := func(build, name, reason string) {
		if firstFailure == nil {
			failedBuild, failedName = build, name
			firstFailure = fmt.Errorf("%s", reason)
		}
	}
	ok, _, _ := espProcessFirst.Call(snap, uintptr(unsafe.Pointer(&p)))
	for ok != 0 {
		name := strings.ToLower(syscall.UTF16ToString(p.Name[:]))
		build := parseFiveMBuild(name)
		if build != "" {
			if _, supported := espLayouts[build]; !supported {
				// Another running FiveM process may use a supported build.
				// Do not stop enumerating at the first unsupported one.
				if unsupportedBuild == "" {
					unsupportedBuild, unsupportedName = build, name
				}
				ok, _, _ = espProcessNext.Call(snap, uintptr(unsafe.Pointer(&p)))
				continue
			}
			h, _, _ := openProcessProc.Call(processVMRead|processQueryLimited|processSynchronize, 0, uintptr(p.PID))
			if h == 0 {
				recordFailure(build, name, "Acesso de leitura negado ao FiveM")
				ok, _, _ = espProcessNext.Call(snap, uintptr(unsafe.Pointer(&p)))
				continue
			}
			modSnap, _, _ := snapshotProc.Call(th32csSnapModule|th32csSnapModule32, uintptr(p.PID))
			if modSnap == 0 || modSnap == ^uintptr(0) {
				closeESP(h)
				recordFailure(build, name, "Falha ao localizar módulo do jogo")
				ok, _, _ = espProcessNext.Call(snap, uintptr(unsafe.Pointer(&p)))
				continue
			}
			var m moduleEntry32
			m.Size = uint32(unsafe.Sizeof(m))
			has, _, _ := moduleFirst.Call(modSnap, uintptr(unsafe.Pointer(&m)))
			var base uintptr
			for has != 0 {
				if strings.EqualFold(syscall.UTF16ToString(m.Name[:]), name) {
					base = m.Base
					break
				}
				has, _, _ = moduleNext.Call(modSnap, uintptr(unsafe.Pointer(&m)))
			}
			closeESP(modSnap)
			if base == 0 {
				closeESP(h)
				recordFailure(build, name, "Módulo do FiveM não encontrado")
				ok, _, _ = espProcessNext.Call(snap, uintptr(unsafe.Pointer(&p)))
				continue
			}
			return &attachedESP{handle: h, pid: p.PID, base: base, build: build, name: name}, build, name, nil
		}
		ok, _, _ = espProcessNext.Call(snap, uintptr(unsafe.Pointer(&p)))
	}
	if firstFailure != nil {
		return nil, failedBuild, failedName, firstFailure
	}
	if unsupportedBuild != "" {
		if unsupportedBuild == "b3058" {
			return nil, unsupportedBuild, unsupportedName, fmt.Errorf("FiveM b3058 identificado no EXE, mas sem offsets confirmados; confirme se a build é b3095 (Chop Shop). Não usar offsets de outra build sem validação")
		}
		return nil, unsupportedBuild, unsupportedName, fmt.Errorf("FiveM %s detectado. Leitor ainda não implementado para este build", unsupportedBuild)
	}
	return nil, "", "", fmt.Errorf("FiveM não iniciado")
}
func (p *attachedESP) read(addr uintptr, b []byte) bool {
	if !validProcessReadRange(addr, len(b)) {
		return false
	}
	var n uintptr
	success, _, _ := readProcessMemory.Call(p.handle, addr, uintptr(unsafe.Pointer(&b[0])), uintptr(len(b)), uintptr(unsafe.Pointer(&n)))
	return success != 0 && n == uintptr(len(b))
}

// Snapshot pointers in small contiguous groups. This is much cheaper than
// 2048 individual system calls when most ped-list slots are empty.
func (p *attachedESP) pedSlots(list uintptr, count uint32) []uintptr {
	if count == 0 || count > 2048 {
		return nil
	}
	out := make([]uintptr, count)
	const chunk = uint32(64)
	for first := uint32(0); first < count; first += chunk {
		n := chunk
		if count-first < n {
			n = count - first
		}
		buf := make([]byte, n*0x10)
		if p.read(list+uintptr(first)*0x10, buf) {
			for j := uint32(0); j < n; j++ {
				out[first+j] = uintptr(binary.LittleEndian.Uint64(buf[j*0x10 : j*0x10+8]))
			}
			continue
		}
		for j := uint32(0); j < n; j++ {
			out[first+j] = p.ptr(list + uintptr(first+j)*0x10)
		}
	}
	return out
}

func (p *attachedESP) ptr(a uintptr) uintptr {
	var b [8]byte
	if !p.read(a, b[:]) {
		return 0
	}
	return uintptr(binary.LittleEndian.Uint64(b[:]))
}
func (p *attachedESP) uint32(a uintptr) uint32 {
	var b [4]byte
	if !p.read(a, b[:]) {
		return 0
	}
	return binary.LittleEndian.Uint32(b[:])
}
func (p *attachedESP) f32(a uintptr) float32 {
	var b [4]byte
	if !p.read(a, b[:]) {
		return 0
	}
	return math.Float32frombits(binary.LittleEndian.Uint32(b[:]))
}

func (p *attachedESP) vec3(a uintptr) (v vec3, ok bool) {
	var b [12]byte
	if !p.read(a, b[:]) {
		return v, false
	}
	v = vec3{math.Float32frombits(binary.LittleEndian.Uint32(b[0:4])), math.Float32frombits(binary.LittleEndian.Uint32(b[4:8])), math.Float32frombits(binary.LittleEndian.Uint32(b[8:12]))}
	return v, finite(v.X) && finite(v.Y) && finite(v.Z)
}
func finite(x float32) bool {
	return !math.IsInf(float64(x), 0) && !math.IsNaN(float64(x)) && math.Abs(float64(x)) < 1000000
}
func dist(a, b vec3) float64 {
	dx := float64(a.X - b.X)
	dy := float64(a.Y - b.Y)
	dz := float64(a.Z - b.Z)
	return math.Sqrt(dx*dx + dy*dy + dz*dz)
}

func (p *attachedESP) matrix(addr uintptr) (m matrix44, ok bool) {
	var b [64]byte
	if !p.read(addr, b[:]) {
		return m, false
	}
	for i := 0; i < 16; i++ {
		m[i] = math.Float32frombits(binary.LittleEndian.Uint32(b[i*4 : i*4+4]))
		if !finite(m[i]) {
			return m, false
		}
	}
	return m, true
}

// FiveM CPlayerInfo contains session-name data, but different builds store
// that data either inline or behind a string pointer. Read both representations
// without assuming random memory bytes are a valid account identity.
func (p *attachedESP) playerName(info uintptr) string {
	// Prefer the canonical CPlayerInfo name field. Never let a speculative
	// legacy alias replace a valid name on modern layouts.
	name := readFiveMPlayerName(info, p.build, p.read)
	if name != "Jogador" || info < 0x10000 {
		return name
	}
	// Some custom FiveM layouts retain the legacy name buffer. Require two
	// identical observations for the same process/PlayerInfo before showing it.
	fallback := readFiveMFallbackPlayerName(info, p.build, p.read)
	if validated := cautiousPlayerNameFallback.observe(p.pid, info, fallback, time.Now()); validated != "" {
		return validated
	}
	return name
}

// The experimental skeleton chain is checked against the ped position.
// One coherent bulk read limits both RPM calls and between-joint time skew.
func (p *attachedESP) projectSkeleton(ped uintptr, origin vec3, matrix matrix44, w, h int32) ([][4]int32, [2]int32, vec3, bool) {
	// The pointer chain is experimental on every supported build; the
	// validation below rejects stale/incompatible joint coordinates.
	frag := p.ptr(ped + 0xFF8)
	if frag == 0 {
		return nil, [2]int32{}, vec3{}, false
	}
	bones := p.ptr(frag + 0x78)
	if bones == 0 {
		return nil, [2]int32{}, vec3{}, false
	}
	indexes := [...]int{0, 7, 6, 5, 8, 3, 4}
	// Indices 0..8, bone struct stride 0x40, position +0xC.
	// A single ReadProcessMemory call replaces seven individual calls.
	var data [8*0x40 + 0xC + 12]byte
	if !p.read(bones, data[:]) {
		return nil, [2]int32{}, vec3{}, false
	}
	var points [9][2]int32
	var valid [9]bool
	var headWorld vec3
	for _, idx := range indexes {
		o := idx*0x40 + 0xC
		v := vec3{
			X: math.Float32frombits(binary.LittleEndian.Uint32(data[o : o+4])),
			Y: math.Float32frombits(binary.LittleEndian.Uint32(data[o+4 : o+8])),
			Z: math.Float32frombits(binary.LittleEndian.Uint32(data[o+8 : o+12])),
		}
		if !plausibleFiveMPosition(v) || dist(v, origin) > 3.8 {
			continue
		}
		sx, sy, ok := worldToScreen(matrix, v, w, h)
		if !ok {
			continue
		}
		points[idx] = [2]int32{int32(math.Round(sx)), int32(math.Round(sy))}
		valid[idx] = true
		if idx == 0 {
			headWorld = v
		}
	}
	pairs := [...][2]int{{0, 7}, {7, 6}, {7, 5}, {7, 8}, {8, 3}, {8, 4}}
	result := make([][4]int32, 0, 6)
	for _, pair := range pairs {
		a, b := pair[0], pair[1]
		if !valid[a] || !valid[b] {
			continue
		}
		x1, y1, x2, y2 := points[a][0], points[a][1], points[b][0], points[b][1]
		length := math.Hypot(float64(x1-x2), float64(y1-y2))
		if length < 2 || length > float64(h)*.42 {
			continue
		}
		result = append(result, [4]int32{x1, y1, x2, y2})
	}
	return result, points[0], headWorld, valid[0]
}

// Read one coherent 9-joint pose and one transform per entity. Fall back to
// the old validated pointer chain if an older game build uses that layout.
func (p *attachedESP) projectBonesFromPed(ped uintptr, origin vec3, view matrix44, w, h int32) ([][4]int32, [2]int32, vec3, bool, boneReadStage) {
	layout, ok := espLayouts[p.build]
	if !ok || layout.boneList == 0 {
		return nil, [2]int32{}, vec3{}, false, boneReadNoPointer
	}
	localMatrix, ok := p.matrix(ped + 0x60)
	if !ok {
		return nil, [2]int32{}, vec3{}, false, boneReadFailed
	}
	raw, status := readPedBoneSnapshot(ped, layout.boneList, p.ptr, p.read)
	if status != boneReadOK {
		return nil, [2]int32{}, vec3{}, false, status
	}
	bones, skull, head, verified := bonePoseFromLocalWorld(raw[:], localMatrix, origin, view, w, h)
	return bones, skull, head, verified, status
}

// estimatedSkeleton is a 2D silhouette when validated game-bone data is
// unavailable. It never claims to show the actual pose or aiming direction.
// All points are defined relative to the current entity box (same frame).
func estimatedSkeleton(x, y, w, h int32) [][4]int32 {
	if w < 2 || h < 3 {
		return nil
	}
	fx := func(frac float64) int32 { return x + int32(math.Round(frac*float64(w))) }
	fy := func(frac float64) int32 { return y + int32(math.Round(frac*float64(h))) }
	pts := [][2]int32{
		{fx(.50), fy(.12)},                                         // head
		{fx(.50), fy(.23)},                                         // neck
		{fx(.50), fy(.48)},                                         // chest
		{fx(.50), fy(.60)},                                         // pelvis
		{fx(.20), fy(.29)}, {fx(.10), fy(.43)}, {fx(.06), fy(.58)}, // left arm
		{fx(.80), fy(.29)}, {fx(.90), fy(.43)}, {fx(.94), fy(.58)}, // right arm
		{fx(.31), fy(.78)}, {fx(.27), fy(.98)}, // left leg
		{fx(.69), fy(.78)}, {fx(.73), fy(.98)}, // right leg
	}
	edges := [][2]int{{0, 1}, {1, 2}, {2, 3}, {1, 4}, {4, 5}, {5, 6}, {1, 7}, {7, 8}, {8, 9}, {3, 10}, {10, 11}, {3, 12}, {12, 13}}
	result := make([][4]int32, 0, len(edges))
	for _, e := range edges {
		a, b := pts[e[0]], pts[e[1]]
		if a != b {
			result = append(result, [4]int32{a[0], a[1], b[0], b[1]})
		}
	}
	return result
}

func (p *attachedESP) readTargets(settings ESPSettings, width, height int32) ([]targetESP, ESPDiagnostics, error) {
	p.nearby = nil
	d := ESPDiagnostics{}
	fail := func(message string) ([]targetESP, ESPDiagnostics, error) {
		d.Reason = message
		return nil, d, fmt.Errorf("%s", message)
	}
	layout, ok := espLayouts[p.build]
	if !ok {
		return fail("Layout indisponível para " + p.build)
	}
	world, replay, vp := p.ptr(p.base+layout.world), p.ptr(p.base+layout.replay), p.ptr(p.base+layout.viewport)
	if world == 0 || replay == 0 || vp == 0 {
		return fail("Ponteiro de mundo/replay/câmera inválido")
	}
	me := p.ptr(world + 0x8)
	if me == 0 {
		return fail("Jogador local não carregado")
	}
	origin, ok := p.vec3(me + 0x90)
	if !ok || !plausibleFiveMPosition(origin) {
		return fail("Coordenadas locais inválidas")
	}
	// Separate validated 3D vehicle list: independent of whether players
	// happen to be visible in the same camera frame.
	var carList []vehicleNearby
	if settings.Vehicles {
		carList = p.scanNearbyVehicles(replay, origin, settings.VehicleRange, settings.VehicleAliases)
		vehicleEspPublish(vehicleFrame{PID: p.pid, Status: "Leitura de veículos disponível", Count: len(carList), Cars: carList})
	} else {
		vehicleEspPublish(vehicleFrame{Status: "Vehicle ESP desligado"})
	}

	iface := p.ptr(replay + 0x18)
	if iface == 0 {
		return fail("Interface de personagens ausente")
	}
	list := p.ptr(iface + 0x100)
	active := p.uint32(iface + 0x110)
	capacity := p.uint32(iface + 0x108)
	count, validList := pedScanCapacity(active, capacity)
	if list == 0 || !validList {
		return fail(fmt.Sprintf("Lista de personagens inválida (ativos=%d, capacidade=%d)", active, capacity))
	}
	radarSettings := radarGet()
	triggerSettings := triggerScanSettings()
	// All active readers use the same scan, so the effective range must
	// include the Aimbot, even when the visual ESP or Silent are disabled.
	aimController.RLock()
	aimEnabled, aimRange, aimNPC := aimController.settings.Enabled, aimController.settings.Range, aimController.settings.TargetNPC
	aimController.RUnlock()
	silentState.RLock()
	silentEnabled, silentRange, silentNPC := silentState.settings.Enabled, silentState.settings.Range, !silentState.settings.IgnoreNPC
	silentState.RUnlock()
	targetRange := effectiveTargetRange(settings.Distance, aimEnabled, aimRange, silentEnabled, silentRange)
	if radarSettings.Enabled && radarSettings.Range > targetRange {
		targetRange = radarSettings.Range
	}
	includeNPC := settings.ShowNPC || (aimEnabled && aimNPC) || (silentEnabled && silentNPC) || (radarSettings.Enabled && radarSettings.ShowNPC)
	// A disabled visual ESP must not prevent the Triggerbot from receiving
	// valid NPC candidates at its own configured range.
	targetRange, includeNPC = triggerScanScope(targetRange, includeNPC, triggerSettings)
	scanRange := targetRange
	if settings.Nearby && settings.NearbyRange > scanRange {
		scanRange = settings.NearbyRange
	}
	players := scanPedsWithOffsets(p, list, count, me, origin, float64(scanRange), &d, layout.playerInfo, layout.armor, includeNPC)
	// The Friends list uses a world-space ped snapshot, not camera projection.
	// This is intentionally independent of ESP boxes, screen visibility and aim.
	playerNames := make(map[uintptr]string, len(players))
	nameCounts := make(map[string]int, len(players))
	for _, player := range players {
		if player.isNPC {
			continue
		}
		n := stablePlayerNames.resolve(p.pid, player.ptr, player.info, player.position, p.playerName(player.info), time.Now())
		playerNames[player.ptr] = n
		if !validFriendName(n) {
			d.NamesMissing++
			continue
		}
		d.NamesResolved++
		nameCounts[friendKey(n)]++
	}
	if settings.Nearby {
		p.nearby = buildNearbyPlayerList(players, playerNames, nameCounts, settings.Friends, settings.NearbyRange)
	}
	// Avoid costly matrix/bone projection when the only active consumer is Friends.
	if settings.Nearby && !settings.Enabled && !aimEnabled && !silentEnabled && !settings.Vehicles && !radarSettings.Enabled && !triggerEnabled() && !noclipIsEnabled() {
		return nil, d, nil
	}
	// Nearby scan can extend to 500m without expanding the player's ESP/aim range.
	projectedPlayers := players[:0:0]
	for _, player := range players {
		if player.distance <= float64(targetRange) {
			projectedPlayers = append(projectedPlayers, player)
		}
	}
	players = projectedPlayers
	if radarSettings.Enabled {
		radarPublish(p.pid, origin, players)
	}
	if len(players) == 0 && len(carList) == 0 {
		d.Reason = reportStage(d)
		return nil, d, nil
	}
	// Matrices are scored on likely players only; random NPC or stale replay
	// pointers must not affect the chosen camera representation.
	cameraCandidates := make([]cameraProjectionCandidate, 0, 4)
	for _, offset := range [...]uintptr{0x250, 0x24C} {
		if m, valid := p.matrix(vp + offset); valid {
			cameraCandidates = append(cameraCandidates,
				cameraProjectionCandidate{Offset: offset, Transposed: false, Matrix: m},
				cameraProjectionCandidate{Offset: offset, Transposed: true, Matrix: transposeProjectionMatrix(m)},
			)
		}
	}
	if len(cameraCandidates) == 0 {
		return fail("Nenhuma matriz de câmera legível")
	}
	samples := make([]projectedBodySample, 0, 32)
	for _, player := range players {
		if len(samples) >= 32 {
			break
		}
		samples = append(samples, projectedBodySample{Position: player.position, Height: 1.9})
	}
	// When no player is visible, allow the existing matrix checker to use
	// vehicle shapes, rather than blindly trusting a camera memory offset.
	if len(samples) == 0 {
		for _, car := range carList {
			if len(samples) >= 24 {
				break
			}
			samples = append(samples, projectedBodySample{Position: car.Position, Height: 2.2})
		}
	}
	index, scores, verified := chooseProjectionMatrixStableLayout(width, height, cameraCandidates, samples, p.lastMatrixOffset, p.lastMatrixTransposed)
	for i, candidate := range cameraCandidates {
		if i > 0 {
			d.MatrixScores += " / "
		}
		layout := "normal"
		if candidate.Transposed {
			layout = "transposta"
		}
		d.MatrixScores += fmt.Sprintf("0x%X/%s:%d", candidate.Offset, layout, scores[i])
	}
	// A previously verified camera layout stays usable for *direction markers*
	// when everybody leaves the field of view. Do not use this fallback for
	// screen-space aim, skeletal boxes or vehicle box projection.
	directionOnly := false
	if !verified && settings.Enabled && settings.Offscreen && p.lastMatrixOffset != 0 {
		for i, c := range cameraCandidates {
			if c.Offset == p.lastMatrixOffset && c.Transposed == p.lastMatrixTransposed && directionMatrixNondegenerate(c.Matrix) {
				index, directionOnly = i, true
				break
			}
		}
	}
	if !verified && !directionOnly {
		d.Reason = "Nenhuma geometria de câmera validada: jogadores fora da visão ou layout incompatível"
		return nil, d, nil
	}
	d.MatrixOffset = fmt.Sprintf("0x%X", cameraCandidates[index].Offset)
	if cameraCandidates[index].Transposed {
		d.MatrixOffset += " (transposta)"
	}
	p.lastMatrixOffset = cameraCandidates[index].Offset
	p.lastMatrixTransposed = cameraCandidates[index].Transposed
	matrix := cameraCandidates[index].Matrix
	if !directionOnly {
		lastValidatedCamera.Lock()
		lastValidatedCamera.matrix = matrix
		lastValidatedCamera.pid = p.pid
		lastValidatedCamera.when = time.Now()
		lastValidatedCamera.Unlock()
	}
	found := make([]targetESP, 0, len(players))
	for _, player := range players {
		bx, by, feetVisible := worldToScreen(matrix, player.position, width, height)
		tx, ty, headVisible := worldToScreen(matrix, vec3{player.position.X, player.position.Y, player.position.Z + 1.9}, width, height)
		if directionOnly || !feetVisible || !headVisible {
			// Off-screen direction is read-only. Only project entities in front
			// of a coherent camera; never turn these into aim candidates.
			if settings.Enabled && settings.Offscreen && !player.isNPC && (!settings.IgnoreDowned || player.health > 100) {
				sx, sy, ok, behind := projectOffscreen360(matrix, player.position, width, height)
				if ok {
					label := playerNames[player.ptr]
					if label == "" {
						label = "Jogador"
					}
					found = append(found, targetESP{Offscreen: true, Behind: behind, X: sx, Y: sy, W: 0, H: 0, PedID: uint64(player.ptr), Name: label, Distance: int(player.distance + .5),
						Friend: verifiedFriend(label, settings.Friends, nameCounts), NameAmbiguous: validFriendName(label) && nameCounts[friendKey(label)] > 1})
				}
			}
			d.ProjectionRejected++
			continue
		}
		d.OnScreen++
		x, y, bw, bh, valid := espBox(tx, ty, bx, by, width, height, false)
		if !valid {
			continue
		}
		d.Boxes++
		name := "NPC"
		if !player.isNPC {
			name = playerNames[player.ptr]
			if name == "" {
				name = "Jogador"
			}
		}
		friend := !player.isNPC && verifiedFriend(name, settings.Friends, nameCounts)
		ambiguous := !player.isNPC && validFriendName(name) && nameCounts[friendKey(name)] > 1
		target := targetESP{Friend: friend, NameAmbiguous: ambiguous, Downed: player.health <= 100, Focus: !ambiguous && validFriendName(name) && settings.FocusName != "" && strings.EqualFold(name, settings.FocusName), X: x, Y: y, W: bw, H: bh, Distance: int(player.distance + .5), Health: player.health, Armor: player.armor, Name: name, IsNPC: player.isNPC, World: player.position, Origin: origin, PedID: uint64(player.ptr)}
		if settings.WeaponESP && !player.isNPC && throughWallSupportedBuild(p.build) {
			if manager := p.ptr(player.ptr + weaponManagerPedOffset); manager >= 0x10000 && manager < 0x7FFFFFFFFFFF {
				if info := p.ptr(manager + currentWeaponInfoOffset); info >= 0x10000 && info < 0x7FFFFFFFFFFF {
					if weapon, known := knownEquippedWeapon(p.uint32(info + 0x10)); known {
						target.WeaponName = weapon
					}
				}
			}
		}
		// Read the real skeleton even if its lines are hidden: boxes, names,
		// health/armor bars and snaplines all require the SAME bone anchor.
		// Diagnose the exact bone-read stage with no additional RPM calls.
		var bones [][4]int32
		var visualBones [][4]int32 // Draw-only. Never used by aim or ESP box calculations.
		var skull [2]int32
		var headWorld vec3
		var validSkull bool
		// The C++ reader verifies head > neck > pelvis in world space.
		// That anatomical ordering is a stronger signal than a fixed
		// height measured from the (variable) ped origin.
		var verifiedCPPAnatomy bool
		// Use the same anatomically validated C++ skeleton chain on EVERY
		// build whose global pointers have already passed the ESP checks.
		// Previously this path ran only on b3258; older builds produced
		// correct-looking boxes but zero verified heads for the Aimbot.
		// If a build has a different ped/skeleton layout, this fails closed
		// and the existing, build-specific fallbacks are attempted below.
		var stage cppBoneStage
		bones, visualBones, skull, headWorld, validSkull, stage = cppProjectPosePair(p, player.ptr, player.position, matrix, width, height, settings.Skeleton)
		switch stage {
		case cppBoneVerified:
			d.BoneCPPVerified++
			verifiedCPPAnatomy = validSkull
		case cppBoneNoFragment:
			d.BoneCPPNoFragment++
		case cppBoneNoSkeleton, cppBoneBadMatrices:
			d.BoneCPPNoSkeleton++
		case cppBoneNoHead:
			d.BoneCPPNoHead++
		case cppBoneBadPose:
			d.BoneCPPBadPose++
		}
		if !validSkull {
			var boneStage boneReadStage
			bones, skull, headWorld, validSkull, boneStage = p.projectBonesFromPed(player.ptr, player.position, matrix, width, height)
			switch boneStage {
			case boneReadOK:
				d.BonePointerReadable++
			case boneReadNoPointer:
				d.BonePointerMissing++
			default:
				d.BoneReadFailed++
			}
		}
		if validSkull {
			d.BonePoseVerified++
		} else {
			d.BonePoseRejected++
		}
		if !validSkull {
			bones, skull, headWorld, validSkull = p.projectSkeleton(player.ptr, player.position, matrix, width, height)
			if validSkull {
				d.BoneFallbackVerified++
			}
		}
		if validSkull && len(bones) >= 3 {
			if anchored, ok := alignPlayerBoxToBones(target, bones, skull, width, height); ok {
				target.X, target.Y, target.W, target.H = anchored.X, anchored.Y, anchored.W, anchored.H
			}
		}
		// Aim and all visual widgets are computed from the final box geometry.
		target.AimX = target.X + target.W/2
		target.AimY = target.Y + target.H*12/100
		if validSkull {
			if !headWorldHeightCompatible(headWorld.Z, player.position.Z, verifiedCPPAnatomy) {
				d.HeadHeightRejected++
			} else if !headAnchorInsidePlayer(skull[0], skull[1], target.X, target.Y, target.W, target.H) {
				d.HeadAnchorRejected++
			} else {
				target.AimX, target.AimY = skull[0], skull[1]
				target.AimFromBone = true
				target.HeadWorld = headWorld
				target.HeadVerified = true
				d.HeadVerified++
				if verifiedCPPAnatomy && headWorld.Z <= player.position.Z+0.75 {
					d.HeadCPPRelativeAccepted++
				}
			}
		}
		if len(bones) >= 3 {
			// A richer drawing must not change boxes, head anchors or aim input.
			if settings.Skeleton && len(visualBones) >= 3 && stage == cppBoneVerified {
				target.Bones = visualBones
			} else {
				target.Bones = bones
			}
			d.Skeletons++
		}
		found = append(found, target)
	}
	// Vehicle annotations reuse the same projection only after camera
	// validation. Range and labels are independent from player ESP settings.
	if settings.Vehicles && !directionOnly {
		for _, car := range carList {
			if len(found) >= 200 {
				break
			}
			bx, by, okFeet := worldToScreen(matrix, car.Position, width, height)
			tx, ty, okTop := worldToScreen(matrix, vec3{car.Position.X, car.Position.Y, car.Position.Z + 2.2}, width, height)
			if !okFeet || !okTop {
				continue
			}
			x, y, bw, bh, valid := espBox(tx, ty, bx, by, width, height, true)
			if valid {
				found = append(found, targetESP{X: x, Y: y, W: bw, H: bh, Distance: car.Distance, Vehicle: true, Name: car.Name, PedID: car.ID})
			}
		}
	}
	if len(found) == 0 {
		d.Reason = reportStage(d)
	} else {
		d.Reason = "Leitura experimental: entidades desenhadas não verificadas no jogo"
	}
	return found, d, nil
}

// A read-only external ESP scanner. It only supports layouts listed above;
// it never writes FiveM memory, injects a DLL, or bypasses anti-cheat.
func startESPReader() {
	go guardedEssentialWorker("esp-reader", func() {
		var connected *attachedESP
		var lastAttach time.Time
		var lastWindowCheck time.Time
		var viewport espViewport
		frameMeterStarted := time.Now()
		frameMeterCount := 0
		badFrames := 0
		stabilizer := espStabilizer{}
		lifecycle := espAttachmentTracker{}
		detach := func() {
			if connected != nil {
				closeESP(connected.handle)
				connected = nil
			}
			badFrames = 0
			stabilizer.reset()
			lifecycle.reset()
			viewport = espViewport{}
		}
		defer detach() // release game handle even if a worker panics
		for {
			started := time.Now()
			setting := espGet().Settings
			if (!setting.Enabled && !setting.Nearby && !setting.Vehicles && !aimIsEnabled() && !silentIsEnabled() && !noclipIsEnabled() && !radarGet().Enabled && !triggerEnabled()) || overlayPaused.Load() {
				stabilizer.reset()
				if connected != nil {
					detach()
				}
				espPublish("", "", "experimental", "ESP desativado", espViewport{}, nil, nil, false)
				espData.Lock()
				espData.status.ReadHz = 0
				espData.Unlock()
				time.Sleep(180 * time.Millisecond)
				continue
			}
			if connected == nil {
				if time.Since(lastAttach) < 2*time.Second {
					time.Sleep(120 * time.Millisecond)
					continue
				}
				lastAttach = time.Now()
				p, build, process, err := findESP()
				if err != nil {
					espSetDiagnostics(ESPDiagnostics{Reason: err.Error()})
					espPublish(build, process, "experimental", err.Error(), espViewport{}, nil, nil, false)
					time.Sleep(200 * time.Millisecond)
					continue
				}
				connected = p
				lastWindowCheck = time.Time{}
				lifecycle.reset()
			}
			if lifecycle.detach(time.Now(), espProcessExited(connected.handle), true) {
				detach()
				espPublish("", "", "experimental", "FiveM reiniciado; procurando processo", espViewport{}, nil, nil, false)
				continue
			}
			// Detect the client size/position 4 times per second instead of every
			// ESP frame. Move/resize handling stays responsive without blocking reads.
			if time.Since(lastWindowCheck) >= 250*time.Millisecond {
				lastWindowCheck = time.Now()
				if vp, found := locateFiveMWindow(connected.pid); found {
					viewport = vp
					lifecycle.reset()
				} else {
					viewport = espViewport{}
				}
			}
			if viewport.W < 320 || viewport.H < 240 {
				stabilizer.reset()
				if lifecycle.detach(time.Now(), false, false) {
					detach()
				}
				espPublish("", "", "experimental", "Janela FiveM indisponível", espViewport{}, nil, nil, false)
				time.Sleep(110 * time.Millisecond)
				continue
			}
			if !fiveMIsForeground(connected.pid) {
				stabilizer.reset()
				espPublish(connected.build, connected.name, "experimental", "FiveM em segundo plano", espViewport{}, nil, nil, false)
				time.Sleep(90 * time.Millisecond)
				continue
			}
			targets, diag, err := connected.readTargets(setting, viewport.W, viewport.H)
			espSetDiagnostics(diag)
			if err != nil {
				badFrames++
				// Short read failures should not wipe a full frame immediately.
				// Data expires strictly, so stale entities cannot persist.
				held := stabilizer.hold(time.Now(), viewport)
				if len(held) > 0 {
					espPublish(connected.build, connected.name, "experimental", "Leitura instável; último quadro válido", viewport, held, connected.nearby, false)
				} else {
					espPublish(connected.build, connected.name, "experimental", err.Error(), espViewport{}, nil, connected.nearby, false)
				}
				if badFrames >= 8 {
					detach()
				}
			} else {
				badFrames = 0
				targets = stabilizer.merge(time.Now(), viewport, targets)
				espPublish(connected.build, connected.name, "experimental", "Leitura ativa (experimental)", viewport, targets, connected.nearby, true)
				frameMeterCount++
				if elapsed := time.Since(frameMeterStarted); elapsed >= time.Second {
					hz := float64(frameMeterCount) / elapsed.Seconds()
					espData.Lock()
					espData.status.ReadHz = math.Round(hz*10) / 10
					espData.Unlock()
					frameMeterCount = 0
					frameMeterStarted = time.Now()
				}
			}
			refresh := time.Duration(setting.RefreshMS) * time.Millisecond
			if setting.Nearby && !setting.Enabled && !setting.Vehicles && !aimIsEnabled() && !silentIsEnabled() && !radarGet().Enabled && !triggerEnabled() && !noclipIsEnabled() {
				refresh = 250 * time.Millisecond
			}
			if refresh < 25*time.Millisecond {
				refresh = 25 * time.Millisecond
			}
			elapsed := time.Since(started)
			if elapsed < refresh {
				time.Sleep(refresh - elapsed)
			} else {
				time.Sleep(time.Millisecond)
			}
		}
	})
}
