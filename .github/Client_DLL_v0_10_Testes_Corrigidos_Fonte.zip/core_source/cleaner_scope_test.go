package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestCleanerOnlyRemovesOwnTempSession(t *testing.T) {
	root := t.TempDir()
	mine := filepath.Join(root, "Sete7-session-abc123")
	other := filepath.Join(root, "not-my-data")
	if err := os.Mkdir(mine, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.Mkdir(other, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(mine, "cache"), []byte("private"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(other, "important"), []byte("keep"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := cleanOwnedSessionPath(other, root); err == nil {
		t.Fatal("must reject unrelated folder")
	}
	if err := cleanOwnedSessionPath(root, root); err == nil {
		t.Fatal("must reject parent temp root")
	}
	if err := cleanOwnedSessionPath(mine, root); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(mine); !os.IsNotExist(err) {
		t.Fatalf("owned session should be gone: %v", err)
	}
	if _, err := os.Stat(filepath.Join(other, "important")); err != nil {
		t.Fatalf("unrelated data must remain: %v", err)
	}
}
