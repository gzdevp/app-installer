# sete7 v13.9.8 — Player > Health / God Mode Hotkey

## Mudanças

- God Mode foi movido de Player > Protection para Player > Health, abaixo de Vida e Armadura.
- Seletor explícito de teclas (letras, números, F1–F12 exceto F6, Shift/Ctrl/Alt/Espaço e Mouse 3–5). Padrão F9.
- Tecla de alternância: um pressionamento liga o estado `player.god`, outro desliga. Segurar não gera alternâncias repetidas.
- Monitor só aciona com FiveM em primeiro plano e menu fechado, e persiste no arquivo de configurações.
- Estado do God no switch do painel sincroniza com a mudança feita pelo atalho.
- Protection continua somente com Semi God e No Ragdoll.
- Pasta de perfil nova v13.9.8. Versões anteriores não foram modificadas.

## Limitação importante

A base v13.9.7 **não contém rotina nativa que aplique invulnerabilidade real à entidade do GTA/FiveM**: o campo `player.god` era uma preferência de interface. A v13.9.8 implementa o bind e a alternância *dessa preferência*, mas NÃO é prova de invulnerabilidade no jogo. Não afirmar que o God Mode real foi implementado ou validado sem integrar um mecanismo autorizado e testá-lo dentro do FiveM.

## Verificações

- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -ldflags='-H=windowsgui' .`: passou
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet ./...`: passou
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test -c`: compilou
- `go test god_config.go god_config_test.go`: passou (alternância true/false e preservação dos demais campos)
- JavaScript: passou, UI em Chromium (HTML via set_content) validada, aba Protection sem God, seletor em Health; nenhuma exceção JS.
- Executável NÃO foi testado em Windows/FiveM.
