package main

import "testing"

func TestFriendNamesValidation(t *testing.T) {
	xs := normalizeFriends([]string{"  Alice ", "alice", "NPC", "Jogador", "", "Bob", "Bad\nName"})
	if len(xs) != 2 || xs[0] != "Alice" || xs[1] != "Bob" {
		t.Fatalf("unexpected sanitized names: %#v", xs)
	}
}
func TestFriendAmbiguousNamesFailClosed(t *testing.T) {
	saved := []string{"Alice"}
	if verifiedFriend("Alice", saved, map[string]int{"alice": 2}) {
		t.Fatal("duplicate nickname cannot identify a friend")
	}
	if !verifiedFriend("ALICE", saved, map[string]int{"alice": 1}) {
		t.Fatal("unique nickname not matched")
	}
	if verifiedFriend("Jogador", []string{"Jogador"}, map[string]int{"jogador": 1}) {
		t.Fatal("generic nickname not allowed")
	}
}
