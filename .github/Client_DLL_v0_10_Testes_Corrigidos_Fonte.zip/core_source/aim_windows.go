//go:build windows

package main

import (
	"fmt"
	"math"
	"sete7/external/ui/aimv13"
	"strings"
	"sync"
	"time"
)

var aimController = struct {
	sync.RWMutex
	settings     AimSettings
	status       string
	tracking     uint64
	lastInGame   string
	lastInGameAt string
	moved        uint64
}{settings: AimSettings{FOV: 130, Range: 250, Smooth: 10, Key: "mouse2", Bone: "head", Sticky: true, InvertY: false, AutoY: false}, status: "Desativado"}

func aimSet(s AimSettings) {
	if s.FOV < 5 {
		s.FOV = 5
	}
	if s.FOV > 500 {
		s.FOV = 500
	}
	if s.Range < 0 || s.Range > 500 {
		s.Range = 500
	}
	if s.Smooth < 1 {
		s.Smooth = 1
	}
	if s.Smooth > 20 {
		s.Smooth = 20
	}
	// Malformed / legacy preferences must not silently fall back to a body point.
	s.Bone = strings.ToLower(strings.TrimSpace(s.Bone))
	switch s.Bone {
	case "head", "neck", "chest", "pelvis":
	default:
		s.Bone = "head"
	}
	aimController.Lock()
	aimController.settings = s
	if !s.Enabled {
		aimController.tracking = 0
		aimController.status = "Desativado"
	}
	aimController.Unlock()
}

// Reader stays active for aim assist even when visual annotations are hidden.
func aimIsEnabled() bool {
	aimController.RLock()
	defer aimController.RUnlock()
	return aimController.settings.Enabled
}

func aimGet() map[string]any {
	aimController.RLock()
	defer aimController.RUnlock()
	return map[string]any{"enabled": aimController.settings.Enabled, "status": aimController.status, "mode": "Head / FollowPedCamera", "target": aimController.tracking != 0, "lastInGame": aimController.lastInGame, "lastInGameAt": aimController.lastInGameAt, "moves": aimController.moved}
}
func aimStatus(status string, target uint64) {
	aimController.Lock()
	aimController.status = status
	aimController.tracking = target
	aimController.Unlock()
}
func aimStatusInGame(status string, target uint64, moved bool) {
	aimController.Lock()
	aimController.status = status
	aimController.tracking = target
	aimController.lastInGame = status
	aimController.lastInGameAt = time.Now().Format("15:04:05")
	if moved {
		aimController.moved++
	}
	aimController.Unlock()
}
func aimNearestText(distance float64) string {
	if math.IsNaN(distance) || math.IsInf(distance, 0) || distance < 0 {
		return "indisponível"
	}
	return fmt.Sprintf("%.0f px", distance)
}
func keyVK(key string) uintptr {
	return genericKeyVK(key, 0x02)
}

var getAsyncKeyState = u32.NewProc("GetAsyncKeyState")

// Direct camera movement rebuilt from the supplied FivemSDK's
// ProcessCameraMovement. Uses the FollowPedCamera class, not the viewport.
func startAimAssist() {
	go func() {
        defer recoverServiceWorker("aim_windows.go")
		ticker := time.NewTicker(33 * time.Millisecond)
		defer ticker.Stop()
		var attached *noclipAttachment
		var lastPID uint32
		var previous uint64
		var lastAttach time.Time
		detach := func() {
			if attached != nil {
				attached.close()
				attached = nil
			}
			previous = 0
			lastPID = 0
		}
		defer detach()
		for range ticker.C {
			aimController.RLock()
			settings := aimController.settings
			aimController.RUnlock()
			if !settings.Enabled || overlayPaused.Load() {
				detach()
				continue
			}
			view, targets, _ := espRendered.snapshot(120 * time.Millisecond)
			if view.PID == 0 || view.W < 320 || view.H < 240 || !view.CameraValid || !fiveMIsForeground(view.PID) {
				detach()
				aimStatus("Aguardando FiveM/câmera válida", 0)
				continue
			}
			if lastPID != view.PID {
				detach()
				lastPID = view.PID
			}
			pressed, _, _ := getAsyncKeyState.Call(keyVK(settings.Key))
			if pressed&0x8000 == 0 {
				previous = 0
				aimStatusInGame("Aguardando tecla: "+settings.Key, 0, false)
				continue
			}
			target, ok, stats := selectAimTargetInFrame(targets, view, settings, previous)
			if !ok || !target.RealBone || !plausibleFiveMPosition(target.HeadWorld) {
				previous = 0
				aimStatusInGame(fmt.Sprintf("Aguardando cabeça real: jogadores=%d cabeças=%d no FOV=%d", stats.Players, stats.Heads, stats.InFOV), 0, false)
				continue
			}
			if attached == nil {
				if time.Since(lastAttach) < time.Second {
					continue
				}
				lastAttach = time.Now()
				var e error
				attached, e = attachNoclip()
				if e != nil {
					aimStatusInGame("Sem acesso à câmera: "+e.Error(), 0, false)
					continue
				}
			}
			p := attached.read
			if p == nil || p.pid != view.PID || espProcessExited(p.handle) {
				detach()
				continue
			}
			local, _, localOK := attached.readLocal()
			if !localOK {
				aimStatusInGame("Posição do jogador local indisponível", 0, false)
				continue
			}
			cam, e := readV13Camera(p, local)
			if e != nil {
				aimStatusInGame(e.Error(), 0, false)
				continue
			}
			// Direct target-to-camera control, as in the supplied C++ SDK.
			// Projection is only used for target selection/FOV; it must not be
			// treated as the FollowPedCamera's own transform and veto every write.
			point := targetWorldPoint(target.HeadWorld, settings.Bone)
			output, move := aimv13.Step(aimv13.Camera{
				Eye: v13FromVec(cam.eye), View: v13FromVec(cam.view), ThirdPerson: v13FromVec(cam.third),
			}, v13FromVec(point), settings.Smooth)
			if !move {
				aimStatusInGame("Sem correção segura (cabeça centralizada ou dados inválidos)", target.ID, false)
				continue
			}
			if !fiveMIsForeground(view.PID) {
				detach()
				continue
			}
			if !writeV13Camera(attached, cam, output) {
				aimStatusInGame("Falha na escrita/leitura dos dois vetores da câmera — bloqueado", target.ID, false)
				continue
			}
			previous = target.ID
			aimStatusInGame(fmt.Sprintf("Mira → %s", settings.Bone), target.ID, true)
		}
	}()
}
