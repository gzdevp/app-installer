package main

import (
	"bytes"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestPatchOnlyShootThru(t *testing.T) {
	orig := []byte("# MATERIAL Friction ShootThru ShootThruFX SeeThru\r\nCONCRETE 0.9 0 0 0\r\nCAR_METAL 0.5 0 1 0\r\nWOOD 0.3 1 0 1\r\n")
	out, n, e := patchShootThru(orig)
	if e != nil || n != 2 {
		t.Fatalf("n=%d err=%v", n, e)
	}
	expected := []byte("# MATERIAL Friction ShootThru ShootThruFX SeeThru\r\nCONCRETE 0.9 1 0 0\r\nCAR_METAL 0.5 1 1 0\r\nWOOD 0.3 1 0 1\r\n")
	if !bytes.Equal(out, expected) {
		t.Fatalf("got %q", out)
	}
}
func TestRefuseWithoutHeader(t *testing.T) {
	_, _, err := patchShootThru([]byte("CONCRETE 1 0 0\n"))
	if err == nil {
		t.Fatal("expected refusal")
	}
}
func TestRefuseUnknownFlag(t *testing.T) {
	_, _, err := patchShootThru([]byte("# Name ShootThru Something\nCONCRETE whatever 3\n"))
	if err == nil {
		t.Fatal("expected refusal")
	}
}
func TestNoOverwrite(t *testing.T) {
	dir := t.TempDir()
	src := filepath.Join(dir, "source.dat")
	dst := filepath.Join(dir, "output.dat")
	os.WriteFile(src, []byte("# NAME ShootThru X\nCONCRETE 0 3\n"), 0600)
	if _, err := mainProcess(src, dst); err != nil {
		t.Fatal(err)
	}
	if _, err := mainProcess(src, dst); err == nil {
		t.Fatal("expected no overwrite")
	}
}
func TestNoBinary(t *testing.T) {
	_, _, err := patchShootThru([]byte{0, 1, 2, 3})
	if err == nil || !strings.Contains(err.Error(), "binary") {
		t.Fatal("expected binary rejection")
	}
}
