package main

// GetAsyncKeyState high-order bit represents the current physical key state.
// The low-order bit only records a press since the previous query and must
// never be used as a toggle to activate Silent.
func silentKeyHeld(keyState uintptr) bool {
	return keyState&0x8000 != 0
}
