//go:build !windows

package main

import "fmt"

func openAppWindow(url string) error { fmt.Println("Preview local: " + url); return nil }

func runWindowShortcut() {}

func monitorOwnWindow(s *service)     {}
func showStartupError(message string) { fmt.Println(message) }

func closeOwnWindow() {}

func dragOwnPanel(action string, dx, dy int32, seq uint64) bool { return false }

func stopSessionBrowsers() {}
