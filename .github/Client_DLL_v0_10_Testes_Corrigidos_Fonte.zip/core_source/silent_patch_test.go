package main

import (
	"bytes"
	"encoding/binary"
	"testing"
)

func TestBulletTrampolineAndEntryPatch(t *testing.T) {
	const entry = uintptr(0x140010000)
	const cave = uintptr(0x123450000)
	target := vec3{100, 200, 35}
	body, e := bulletTrampoline(entry, cave, target)
	if e != nil {
		t.Fatal(e)
	}
	if len(body) != 76 {
		t.Fatalf("trampoline length %d", len(body))
	}
	// RIP-relative loads of XMM3, XMM0, XMM2; stores back into [R9, R9+4, R9+8]
	for i, q := range []struct {
		off, displacement int
		load, store       []byte
	}{
		{0, 56, []byte{0xF3, 0x0F, 0x10, 0x1D}, []byte{0xF3, 0x41, 0x0F, 0x11, 0x19}},
		{13, 47, []byte{0xF3, 0x0F, 0x10, 0x05}, []byte{0xF3, 0x41, 0x0F, 0x11, 0x41, 0x04}},
		{27, 37, []byte{0xF3, 0x0F, 0x10, 0x15}, []byte{0xF3, 0x41, 0x0F, 0x11, 0x51, 0x08}},
	} {
		if !bytes.Equal(body[q.off:q.off+4], q.load) {
			t.Fatalf("load %d", i)
		}
		if int(int32(binary.LittleEndian.Uint32(body[q.off+4:q.off+8]))) != q.displacement {
			t.Fatalf("RIP displacement %d", i)
		}
		if !bytes.Equal(body[q.off+8:q.off+8+len(q.store)], q.store) {
			t.Fatalf("store %d", i)
		}
	}
	if !bytes.Equal(body[41:43], []byte{0xFF, 0x25}) {
		t.Fatal("missing return jump")
	}
	if binary.LittleEndian.Uint64(body[47:55]) != uint64(entry+17) {
		t.Fatal("wrong return address")
	}
	xyz, e := bulletTargetBytes(target)
	if e != nil || !bytes.Equal(body[64:], xyz) {
		t.Fatal("invalid xyz")
	}
	patch, e := bulletEntryPatch(cave)
	if e != nil || len(patch) != 17 || binary.LittleEndian.Uint64(patch[6:14]) != uint64(cave) {
		t.Fatal("invalid entry patch")
	}
}
func TestBulletTargetRejectsInvalid(t *testing.T) {
	if _, e := bulletTargetBytes(vec3{X: 30000}); e == nil {
		t.Fatal("out of bounds accepted")
	}
}
