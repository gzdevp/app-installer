//go:build windows

package main

import (
	"encoding/binary"
	"fmt"
	"math"
	"sync"
	"time"
	"unsafe"
)

// Dedicated local-ped noclip module. No modification to the v12.20 Silent
// execution path. Reads the game's already-supported build layout and writes
// only the verified local ped's three position floats.
type NoclipSettings struct {
	Enabled bool   `json:"enabled"`
	Key     string `json:"key"`
	Speed   int    `json:"speed"`
}

var noclipController = struct {
	sync.RWMutex
	settings      NoclipSettings
	active        bool
	status        string
	pid           uint32
	positionReady bool
}{settings: NoclipSettings{Key: "f2", Speed: 15}, status: "Desativado"}

func noclipSet(s NoclipSettings) {
	if s.Key == "" {
		s.Key = "f2"
	}
	if s.Speed < 1 {
		s.Speed = 1
	}
	if s.Speed > 500 {
		s.Speed = 500
	}
	noclipController.Lock()
	if s.Enabled != noclipController.settings.Enabled {
		// Panel toggle takes effect immediately. The hotkey may subsequently
		// suspend or resume while the panel's master enable stays on.
		noclipController.active = s.Enabled
	}
	noclipController.settings = s
	if !s.Enabled {
		noclipController.active = false
		noclipController.status = "Desativado"
		noclipController.positionReady = false
	}
	noclipController.Unlock()
}
func noclipIsEnabled() bool {
	noclipController.RLock()
	defer noclipController.RUnlock()
	return noclipController.settings.Enabled
}
func noclipGet() map[string]any {
	noclipController.RLock()
	defer noclipController.RUnlock()
	return map[string]any{"enabled": noclipController.settings.Enabled, "active": noclipController.active, "status": noclipController.status, "key": noclipController.settings.Key, "speed": noclipController.settings.Speed, "pid": noclipController.pid, "positionReady": noclipController.positionReady}
}
func noclipReport(text string, pid uint32, ready bool) {
	noclipController.Lock()
	noclipController.status = text
	noclipController.pid = pid
	noclipController.positionReady = ready
	noclipController.Unlock()
}
func noclipSwitch() {
	noclipController.Lock()
	if noclipController.settings.Enabled {
		noclipController.active = !noclipController.active
	}
	noclipController.Unlock()
}

var noclipWriteProcessMemory = kernel32Process.NewProc("WriteProcessMemory")

const noclipWritePermission uintptr = 0x0020 | 0x0008 | processQueryLimited // VM_WRITE, VM_OPERATION, QUERY

type noclipAttachment struct {
	read   *attachedESP
	writer uintptr
	ped    uintptr
}

func (a *noclipAttachment) close() {
	if a == nil {
		return
	}
	if a.read != nil {
		closeESP(a.read.handle)
		a.read = nil
	}
	if a.writer != 0 {
		closeESP(a.writer)
		a.writer = 0
	}
	a.ped = 0
}
func attachNoclip() (*noclipAttachment, error) {
	p, _, _, err := findESP()
	if err != nil {
		return nil, err
	}
	h, _, e := openProcessProc.Call(noclipWritePermission, 0, uintptr(p.pid))
	if h == 0 {
		closeESP(p.handle)
		return nil, fmt.Errorf("FiveM não permitiu acesso de escrita: %v", e)
	}
	return &noclipAttachment{read: p, writer: h}, nil
}
func (a *noclipAttachment) readLocal() (vec3, uintptr, bool) {
	p := a.read
	if p == nil || espProcessExited(p.handle) {
		return vec3{}, 0, false
	}
	layout, ok := espLayouts[p.build]
	if !ok {
		return vec3{}, 0, false
	}
	world := p.ptr(p.base + layout.world)
	if world == 0 {
		return vec3{}, 0, false
	}
	ped := p.ptr(world + 0x8)
	if ped == 0 {
		return vec3{}, 0, false
	}
	pos, ok := p.vec3(ped + 0x90)
	if !ok || !plausibleFiveMPosition(pos) {
		return vec3{}, 0, false
	}
	return pos, ped, true
}
func (a *noclipAttachment) writeLocal(ped uintptr, position vec3) bool {
	if a.writer == 0 || ped == 0 || !plausibleFiveMPosition(position) {
		return false
	}
	var buf [12]byte
	binary.LittleEndian.PutUint32(buf[0:4], math.Float32bits(position.X))
	binary.LittleEndian.PutUint32(buf[4:8], math.Float32bits(position.Y))
	binary.LittleEndian.PutUint32(buf[8:12], math.Float32bits(position.Z))
	var wrote uintptr
	ok, _, _ := noclipWriteProcessMemory.Call(a.writer, ped+0x90, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)), uintptr(unsafe.Pointer(&wrote)))
	return ok != 0 && wrote == uintptr(len(buf))
}

func noclipKeyHeld(vk uintptr) bool {
	value, _, _ := getAsyncKeyState.Call(vk)
	return value&0x8000 != 0
}
func chooseNoclipCamera(p *attachedESP, origin vec3) (matrix44, bool) {
	if m, ok := verifiedCamera(p.pid); ok {
		return m, true
	}
	layout := espLayouts[p.build]
	vp := p.ptr(p.base + layout.viewport)
	if vp == 0 {
		return matrix44{}, false
	}
	viewport, found := locateFiveMWindow(p.pid)
	if !found || viewport.W < 320 || viewport.H < 240 {
		return matrix44{}, false
	}
	// Fall back only if the player projects plausibly near the screen center.
	// Otherwise refuse position writes instead of trusting an unknown camera.
	best := math.Inf(1)
	var picked matrix44
	for _, offset := range [...]uintptr{0x250, 0x24C} {
		m, ok := p.matrix(vp + offset)
		if !ok {
			continue
		}
		for _, v := range [...]matrix44{m, transposeProjectionMatrix(m)} {
			if _, _, valid := noclipBasis(v); !valid {
				continue
			}
			head := vec3{X: origin.X, Y: origin.Y, Z: origin.Z + 1.5}
			x, y, visible := worldToScreen(v, head, viewport.W, viewport.H)
			if !visible {
				continue
			}
			dx := (x - float64(viewport.W)/2) / float64(viewport.W)
			dy := (y - float64(viewport.H)/2) / float64(viewport.H)
			score := dx*dx + dy*dy
			if math.Abs(dx) > .35 || math.Abs(dy) > .4 {
				continue
			}
			if score < best {
				best = score
				picked = v
			}
		}
	}
	return picked, !math.IsInf(best, 1)
}

func startNoclip() {
	go func() {
        defer recoverServiceWorker("noclip_windows.go")
		ticker := time.NewTicker(8 * time.Millisecond)
		defer ticker.Stop()
		var attached *noclipAttachment
		var heldLast bool
		var anchor vec3
		var anchored bool
		var lastAttach time.Time
		var lastStep = time.Now()
		defer func() {
			if attached != nil {
				attached.close()
			}
		}()
		for now := range ticker.C {
			noclipController.RLock()
			cfg, active := noclipController.settings, noclipController.active
			noclipController.RUnlock()
			keyDown := noclipKeyHeld(keyVK(cfg.Key))
			if keyDown && !heldLast && cfg.Enabled {
				noclipSwitch()
				noclipController.RLock()
				active = noclipController.active
				noclipController.RUnlock()
				anchored = false
			}
			heldLast = keyDown
			if !cfg.Enabled || !active || overlayPaused.Load() {
				anchored = false
				if attached != nil {
					attached.close()
					attached = nil
				}
				if !cfg.Enabled {
					noclipReport("Desativado", 0, false)
				} else {
					noclipReport("Pausado pela tecla "+cfg.Key, 0, false)
				}
				continue
			}
			if attached == nil {
				if now.Sub(lastAttach) < time.Second {
					continue
				}
				lastAttach = now
				var err error
				attached, err = attachNoclip()
				if err != nil {
					noclipReport(err.Error(), 0, false)
					continue
				}
				anchored = false
			}
			p := attached.read
			if espProcessExited(p.handle) {
				attached.close()
				attached = nil
				anchored = false
				noclipReport("FiveM reiniciado; aguardando conexão", 0, false)
				continue
			}
			if !fiveMIsForeground(p.pid) {
				anchored = false
				noclipReport("Pausado: FiveM fora de foco", p.pid, false)
				continue
			}
			pos, ped, valid := attached.readLocal()
			if !valid {
				anchored = false
				noclipReport("Jogador local não validado", p.pid, false)
				continue
			}
			if attached.ped != ped {
				anchored = false
				attached.ped = ped
			}
			if !anchored {
				anchor = pos
				anchored = true
				lastStep = now
			}
			view, ok := chooseNoclipCamera(p, pos)
			if !ok {
				noclipReport("Câmera não validada: nenhuma escrita", p.pid, true)
				anchored = false
				continue
			}
			forward, right, ok := noclipBasis(view)
			if !ok {
				noclipReport("Eixos da câmera incompatíveis", p.pid, true)
				continue
			}
			var x, y, z float64
			if noclipKeyHeld('D') {
				x++
			}
			if noclipKeyHeld('A') {
				x--
			}
			if noclipKeyHeld('W') {
				y++
			}
			if noclipKeyHeld('S') {
				y--
			}
			if noclipKeyHeld(0x20) {
				z++
			}
			if noclipKeyHeld(0x11) {
				z--
			}
			speed := float64(cfg.Speed)
			if noclipKeyHeld(0x10) {
				speed *= 2.5
			}
			seconds := now.Sub(lastStep).Seconds()
			if seconds > .05 {
				seconds = .05
			}
			lastStep = now
			next, good := noclipStep(anchor, forward, right, x, y, z, speed, seconds)
			if !good {
				noclipReport("Movimento inválido; escrita bloqueada", p.pid, true)
				continue
			}
			if !attached.writeLocal(ped, next) {
				anchored = false
				noclipReport("Escrita recusada pelo FiveM", p.pid, true)
				continue
			}
			anchor = next
			noclipReport("Ativo · WASD / Espaço / Ctrl / Shift", p.pid, true)
		}
	}()
}
