# sete7 v14.11 — preparação EXTERNA

Esta revisão **não instala `sete7_names`**, não executa Lua no FiveM, não injeta DLL, não altera UEFI e não muda a interface Black Edition. Mantém os nomes de veículos da v14.10.

## Implementado
- Cálculo matemático da reta original da mira (250m), sem desviar para jogador algum.
- Leituras **somente de memória** da direção/posição da câmera, quando a tecla Through Wall estiver pressionada, em builds suportadas pelo leitor FollowPedCamera.
- API de diagnóstico existente (`throughWall.aimLine`): origem, direção, fim e status válido/indisponível; sem mudar o layout ou menus.
- Testes de direção, colinearidade e rejeição de dados inválidos.

## Limites reais
**Não dispara, não atravessa paredes e não produz dano.** A native `ShootSingleBulletBetweenCoords` roda dentro do FiveM e não pode ser chamada diretamente pelo EXE externo. O estado `operational=false` permanece. A antiga tentativa de modificar a penetração permanece apenas experimental, sem garantia.

A leitura FollowPedCamera depende de offsets identificados em builds específicas, e sem confirmação dentro do jogo não há garantia de sucesso.
