package main

import "testing"

func TestAimAxisDetectRepeatedWrongVerticalDirection(t *testing.T) {
	var f aimAxisFeedback
	for i := 0; i < 3; i++ {
		f.record(42, 1215, 337, 13, -10)
		f.observe(42, 1205, 327) // screen goes up when pressing up: wrong
	}
	if !f.reversed || f.flips != 1 || f.samples != 3 {
		t.Fatalf("feedback=%+v", f)
	}
	// After flipping, positive relative mouse sends the head down on the screen.
	for i := 0; i < 3; i++ {
		f.record(42, 1215, 337, 13, 10)
		f.observe(42, 1205, 327)
	}
	if !f.reversed || f.flips != 1 {
		t.Fatalf("unstable flip: %+v", f)
	}
}
func TestAimAxisRejectsTargetChangeAndHugeCameraJump(t *testing.T) {
	var f aimAxisFeedback
	for i := 0; i < 10; i++ {
		f.record(42, 1215, 337, 13, -10)
		f.observe(43, 1205, 327)
	}
	if f.samples != 0 || f.reversed {
		t.Fatalf("different target influenced Y: %+v", f)
	}
	f.record(42, 1215, 337, 13, -10)
	f.observe(42, 1205, 180)
	if f.samples != 0 {
		t.Fatalf("jump influenced Y: %+v", f)
	}
}
func TestAimAxisDoesNotInvertNormalVerticalDirection(t *testing.T) {
	var f aimAxisFeedback
	for i := 0; i < 10; i++ {
		f.record(42, 1215, 337, 13, -10)
		f.observe(42, 1205, 348)
	}
	if f.reversed || f.flips != 0 {
		t.Fatalf("normal Y flipped: %+v", f)
	}
}
