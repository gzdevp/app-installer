# sete7 v13.3 — Painel Limpo / Silent HOLD / b3258 Camera experimental

## Ajustes
- A aba Silent Aim deixou de exibir instruções de teste, status do módulo, último teste, leitura de ossos, assinatura b3258 e botão de copiar diagnóstico. Dados técnicos continuam disponíveis na API local para análise, sem poluir o painel.
- Silent: texto da UI deixa claro que o checkbox é a habilitação geral e que a tecla selecionada deve ser **mantida pressionada**. Na worker, o bit alto de `GetAsyncKeyState` é verificado por `silentKeyHeld`: o bit de evento/toggle não serve para ativar. Soltar a tecla chama `disable` no patch, preservando a rotina de restauração preexistente.
- Aba Aimbot: status compactado em uma linha.
- b3258: alterada referência da câmera para `CamGameplayDirector = 0x201ED50` em vez de `Camera = 0x201E7D0`. **Atenção: hipótese fundamentada em dump externo, não homologada em FiveM.** Proteções de ponteiros, norma vetorial, origem e leitura continuam. As falhas agora identificam se a leitura ou validação vetorial falhou.
- O botão Reviver saiu do painel por mudança de escopo; o endpoint legado continua no código sem ser exposto no menu.
- Mantidas as implementações de ESP, No clip e Silent v12.20, sem alterar o hook de disparo além da checagem explícita da tecla pressionada.

## Validação realizada
- `go test ./aimv13` — passou (Linux, lógica matemática).
- `go test silent_activation.go silent_activation_test.go` — passou (Linux, tecla pressionada versus solta).
- `node --check validation/_script_v13.js` — passou.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-s -w -H=windowsgui'` — compilou.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test -c` — compilou testes Windows, sem executá-los.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet ./...` — passou.

## Limitações
- Não foi possível executar o EXE ou testar câmera/Silent dentro de FiveM neste ambiente Linux.
- Uma compilação bem-sucedida não prova que o Aimbot mira corretamente nem que o Silent tenha efeito em uma build/cidade real.
- A mudança para `0x201ED50` é um ajuste experimental sujeito à validação em cada build.
- Se a câmera continuar inválida, a rotina bloqueia a escrita, evitando suposições perigosas de offset.
