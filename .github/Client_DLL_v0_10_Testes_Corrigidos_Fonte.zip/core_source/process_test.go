package main

import "testing"

func TestFiveMProcessNames(t *testing.T) {
	for _, tc := range []struct {
		name string
		want bool
	}{
		{"FiveM_b3258_GTAProcess.exe", true},
		{"FiveM.exe", true},
		{"GTA5.exe", true},
		{"gTaPrOcEsS.exe", true},
		{"msedge.exe", false},
		{"cmd.exe", false},
		{"tasklist.exe", false},
		{"Discord.exe", false},
	} {
		if got := isFiveMProcess(tc.name); got != tc.want {
			t.Errorf("process %q: got %v want %v", tc.name, got, tc.want)
		}
	}
}
