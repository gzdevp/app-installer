package main

import "math"

// The C++ reference supplied by the user does not treat ped+0x410 as an
// array of joint positions. Instead, it resolves a fragment-instance chain,
// finds a masked joint ID in skeleton metadata, and transforms a 64-byte joint
// matrix into world coordinates. This reader mirrors that *read-only* path.
// The reference is older than b3258, so the chain must be validated at runtime.

type cppBoneReader interface {
	ptr(uintptr) uintptr
	uint32(uintptr) uint32
	matrix(uintptr) (matrix44, bool)
}

type cppBoneStage string

const (
	cppBoneNoFragment  cppBoneStage = "frag ausente"
	cppBoneNoSkeleton  cppBoneStage = "skeleton ausente"
	cppBoneBadMatrices cppBoneStage = "matrizes ausentes"
	cppBoneNoHead      cppBoneStage = "SKEL_Head não mapeado"
	cppBoneBadPose     cppBoneStage = "pose não validada"
	cppBoneVerified    cppBoneStage = "cabeça validada"
)

const (
	cppHead   uint32 = 0x796e
	cppNeck   uint32 = 0x9995
	cppPelvis uint32 = 0x2e28
)

func cppSafePointer(v uintptr) bool { return v >= 0x10000 && v < 0x0000800000000000 }

// Resolve a ped fragment through the reference chain:
// ped + FragInsNmGTA -> frag + 0x68 -> intermediary + 0x178 -> skeleton.
// 0x1430 is present in the provided C++ reference; 0xFF8 was the prior
// project's legacy frag field, which is attempted only when still readable.
func cppSkeletonChain(r cppBoneReader, ped, fragOffset uintptr) (uintptr, cppBoneStage) {
	frag := r.ptr(ped + fragOffset)
	if !cppSafePointer(frag) {
		return 0, cppBoneNoFragment
	}
	mid := r.ptr(frag + 0x68)
	if !cppSafePointer(mid) {
		return 0, cppBoneNoSkeleton
	}
	skel := r.ptr(mid + 0x178)
	if !cppSafePointer(skel) {
		return 0, cppBoneNoSkeleton
	}
	return skel, cppBoneVerified
}

// The C++ reference resolves bone MASK to array index using a short chained
// hash table: metadata = *skeleton; table = *(metadata+0x10), bucket count
// uint16 at +0x18, hash flag at +0x1A. We limit every walk to avoid bogus RPM.
func cppBoneIndex(r cppBoneReader, skel uintptr, mask uint32) (uint32, bool) {
	meta := r.ptr(skel)
	if !cppSafePointer(meta) {
		return 0, false
	}
	if r.uint32(meta+0x1a)&0xffff != 0 {
		bucketCount := r.uint32(meta+0x18) & 0xffff
		if bucketCount == 0 || bucketCount > 4096 {
			return 0, false
		}
		table := r.ptr(meta + 0x10)
		if !cppSafePointer(table) {
			return 0, false
		}
		item := r.ptr(table + uintptr(mask%bucketCount)*8)
		for n := 0; n < 4 && cppSafePointer(item); n++ {
			if r.uint32(item) == mask {
				id := r.uint32(item + 4)
				return id, id > 0 && id < 512
			}
			item = r.ptr(item + 8)
		}
		return 0, false
	}
	// The original SDK also has a no-hash-table path for direct indices.
	limit := r.uint32(meta + 0x5e)
	return mask, mask != 0 && mask < limit && mask < 512
}

func cppBoneWorld(r cppBoneReader, skel uintptr, transform matrix44, matrices uintptr, mask uint32) (vec3, bool) {
	id, ok := cppBoneIndex(r, skel, mask)
	if !ok {
		return vec3{}, false
	}
	bone, ok := r.matrix(matrices + uintptr(id)*0x40)
	if !ok {
		return vec3{}, false
	}
	local := vec3{bone[12], bone[13], bone[14]}
	point := vec3{
		X: local.X*transform[0] + local.Y*transform[4] + local.Z*transform[8] + transform[12],
		Y: local.X*transform[1] + local.Y*transform[5] + local.Z*transform[9] + transform[13],
		Z: local.X*transform[2] + local.Y*transform[6] + local.Z*transform[10] + transform[14],
	}
	return point, plausibleFiveMPosition(point)
}

// Returns genuine joint positions only after the head, neck and pelvis agree
// in world space. It never fabricates a head from a 2D box.
func cppReadPose(r cppBoneReader, ped uintptr, origin vec3) ([9]vec3, [9]bool, cppBoneStage) {
	var points [9]vec3
	var valid [9]bool
	stage := cppBoneNoFragment
	for _, off := range [...]uintptr{0x1430, 0xFF8} {
		skel, result := cppSkeletonChain(r, ped, off)
		if result != cppBoneVerified {
			if result != cppBoneNoFragment {
				stage = result
			}
			continue
		}
		transformPtr, matrices := r.ptr(skel+0x8), r.ptr(skel+0x18)
		if !cppSafePointer(transformPtr) || !cppSafePointer(matrices) {
			stage = cppBoneBadMatrices
			continue
		}
		transform, ok := r.matrix(transformPtr)
		if !ok {
			stage = cppBoneBadMatrices
			continue
		}
		masks := [...]uint32{
			cppHead, 0x3779, 0xcc4d, 0xe39f, 0xca72,
			0x49d9, 0xdead, cppNeck, cppPelvis,
		}
		for i := range masks {
			points[i], valid[i] = cppBoneWorld(r, skel, transform, matrices, masks[i])
			if valid[i] && poseDist(points[i], origin) > 3.8 {
				valid[i] = false
			}
		}
		if !valid[0] {
			stage = cppBoneNoHead
			continue
		}
		if !valid[7] || !valid[8] ||
			points[0].Z <= points[7].Z || points[7].Z <= points[8].Z ||
			points[0].Z-points[8].Z < .35 || points[0].Z-points[8].Z > 2.9 ||
			poseDist(points[0], points[7]) > .75 || poseDist(points[7], points[8]) > 1.35 ||
			poseDist(points[0], origin) < .15 {
			stage = cppBoneBadPose
			continue
		}
		return points, valid, cppBoneVerified
	}
	return [9]vec3{}, [9]bool{}, stage
}

// Additional GTA V joints are requested ONLY when the visual skeleton is
// enabled. The regular 9-joint reader and aim/head anchor remain untouched.
// IDs originate from Cfx.re's ePedBoneId reference.
const (
	cppSpine3    uint32 = 0x60f2
	cppLClavicle uint32 = 0xfcd9
	cppRClavicle uint32 = 0x29d2
	cppLUpperArm uint32 = 0xb1c5
	cppRUpperArm uint32 = 0x9d4d
	cppLForearm  uint32 = 0xeeeb
	cppRForearm  uint32 = 0x6e5c
	cppLCalf     uint32 = 0xf9bb
	cppRCalf     uint32 = 0x9000
)

// cppReadExtraVisualBones never guesses a location from an arbitrary pointer:
// the candidate skeleton must reproduce the already-validated head position.
// Missing joints are simply skipped, so older/custom builds fail gracefully.
func cppReadExtraVisualBones(r cppBoneReader, ped uintptr, origin, verifiedHead vec3) ([9]vec3, [9]bool) {
	var points [9]vec3
	var valid [9]bool
	masks := [...]uint32{cppSpine3, cppLClavicle, cppRClavicle, cppLUpperArm, cppRUpperArm, cppLForearm, cppRForearm, cppLCalf, cppRCalf}
	for _, off := range [...]uintptr{0x1430, 0xFF8} {
		skel, stage := cppSkeletonChain(r, ped, off)
		if stage != cppBoneVerified {
			continue
		}
		transformPtr, matrices := r.ptr(skel+0x8), r.ptr(skel+0x18)
		if !cppSafePointer(transformPtr) || !cppSafePointer(matrices) {
			continue
		}
		transform, ok := r.matrix(transformPtr)
		if !ok {
			continue
		}
		head, ok := cppBoneWorld(r, skel, transform, matrices, cppHead)
		if !ok || poseDist(head, verifiedHead) > .15 {
			continue
		}
		for i, mask := range masks {
			point, found := cppBoneWorld(r, skel, transform, matrices, mask)
			if found && poseDist(point, origin) <= 3.8 {
				points[i], valid[i] = point, true
			}
		}
		return points, valid
	}
	return points, valid
}

// Preserve the original 9-joint geometry for box placement and aim/head
// tracking, and produce an independent rich skeleton ONLY for rendering.
func cppProjectPose(r cppBoneReader, ped uintptr, origin vec3, view matrix44, w, h int32) ([][4]int32, [2]int32, vec3, bool, cppBoneStage) {
	base, _, skull, head, ok, stage := cppProjectPosePair(r, ped, origin, view, w, h, false)
	return base, skull, head, ok, stage
}

func cppProjectPosePair(r cppBoneReader, ped uintptr, origin vec3, view matrix44, w, h int32, richVisual bool) (baseBones, visualBones [][4]int32, headScreen [2]int32, headWorld vec3, verified bool, stage cppBoneStage) {
	base, baseValid, stage := cppReadPose(r, ped, origin)
	if stage != cppBoneVerified {
		return nil, nil, [2]int32{}, vec3{}, false, stage
	}
	var points [18]vec3
	var valid [18]bool
	copy(points[:], base[:])
	copy(valid[:], baseValid[:])
	if richVisual {
		extras, ok := cppReadExtraVisualBones(r, ped, origin, base[0])
		for i := range extras {
			points[9+i], valid[9+i] = extras[i], ok[i]
		}
	}
	var screen [18][2]int32
	for i := range points {
		if !valid[i] {
			continue
		}
		sx, sy, ok := worldToScreen(view, points[i], w, h)
		if !ok {
			valid[i] = false
			continue
		}
		screen[i] = [2]int32{int32(math.Round(sx)), int32(math.Round(sy))}
	}
	if !valid[0] {
		return nil, nil, [2]int32{}, vec3{}, false, cppBoneBadPose
	}

	// Identical to the original projectSkeleton topology and quality filters.
	baseBones = make([][4]int32, 0, 8)
	for _, pair := range [...][2]int{{0, 7}, {7, 8}, {7, 5}, {7, 6}, {8, 3}, {3, 1}, {8, 4}, {4, 2}} {
		a, b := pair[0], pair[1]
		if !valid[a] || !valid[b] {
			continue
		}
		px, py, qx, qy := screen[a][0], screen[a][1], screen[b][0], screen[b][1]
		length := math.Hypot(float64(px-qx), float64(py-qy))
		if length >= 1 && length <= float64(h)*.55 {
			baseBones = append(baseBones, [4]int32{px, py, qx, qy})
		}
	}
	if !richVisual {
		return baseBones, baseBones, screen[0], points[0], true, cppBoneVerified
	}

	visualBones = make([][4]int32, 0, 19)
	addSegment := func(a, b int) {
		if !valid[a] || !valid[b] {
			return
		}
		// Prevent lines across stale/different-ped joints.
		if poseDist(points[a], points[b]) > 1.40 {
			return
		}
		px, py, qx, qy := screen[a][0], screen[a][1], screen[b][0], screen[b][1]
		length := math.Hypot(float64(px-qx), float64(py-qy))
		if length >= 1 && length <= float64(h)*.55 {
			visualBones = append(visualBones, [4]int32{px, py, qx, qy})
		}
	}
	addChain := func(chain ...int) {
		previous := -1
		for _, index := range chain {
			if !valid[index] {
				continue
			}
			if previous != -1 {
				addSegment(previous, index)
			}
			previous = index
		}
	}
	// Verified head, neck, spine and hip center.
	addChain(0, 7, 9, 8)
	// Shoulder -> elbow -> hand: no more diagonal neck-to-wrist triangle.
	if valid[9] {
		addChain(9, 10, 12, 14, 5)
		addChain(9, 11, 13, 15, 6)
	} else {
		addChain(7, 10, 12, 14, 5)
		addChain(7, 11, 13, 15, 6)
	}
	// Separate hip, knee, shin and foot on each side.
	addChain(8, 3, 16, 1)
	addChain(8, 4, 17, 2)
	if len(visualBones) < 3 {
		visualBones = baseBones
	}
	return baseBones, visualBones, screen[0], points[0], true, cppBoneVerified
}
