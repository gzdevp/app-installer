# sete7 13.9.70 — correção de encerramento inesperado

**Causa identificada no código:** Em três funções de consulta de janelas, a aplicação criava um novo callback Win32 via `syscall.NewCallback` a cada varredura. No Go/Windows a tabela desses callbacks tem limite fixo; ao esgotá-lo, o runtime encerra o processo imediatamente, sem que `recover()` consiga impedir. Isso explica uma classe específica de encerramentos após uso contínuo, embora outros tipos de crash ainda possam existir.

**Correção:** `browserTopWindow`, `locateAnyFiveMWindow` e `locateFiveMWindow` agora usam um callback estático cada, criado uma única vez durante a vida do processo. Os dados de cada busca passam por contexto local separado e associado a um identificador temporário seguro durante a enumeração, preservando segurança e varreduras concorrentes.

Preservados: 13.9.70, painel, aparência, hotkeys, ESP, Friends, veículos e combate. Mantidas as melhorias de recuperação da 13.9.70 Estável.

Limitações: compilação Windows e análise estática; não houve teste de execução dentro do FiveM nesta sessão. Outros erros nativos, antivírus e reinicializações do jogo ainda podem afetar a aplicação.
