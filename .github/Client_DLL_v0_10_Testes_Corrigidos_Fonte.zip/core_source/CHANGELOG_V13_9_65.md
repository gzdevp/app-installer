# 77 v13.9.65 — recuperação do Insert e diagnóstico de sessão

- Corrige o caso do log `insert_hotkey_registration_failed`: em vez de encerrar para sempre o listener do Insert, o 77 tenta registrar novamente a cada 2 segundos até ficar livre.
- Remove a caixa modal de erro no registro do Insert, que podia bloquear a interação e aparentar um fechamento.
- Retenta também o registro do Insert se o loop de mensagens terminar inesperadamente, sem sair do processo principal.
- Cria eventos periódicos de atividade (20 segundos), sem credenciais nem dados de jogadores, no arquivo `%TEMP%\77-diagnostics.log`.
- Duplica eventos de ciclo de vida neste registro persistente: deixa claro se foi executado Unload/Cleaner ou se o servidor retornou sem solicitação de saída.
- Não modifica a lógica de FPS, a renderização de ESP, o login, o Cleaner ou as funções de mira.
- O log antigo sozinho não prova crash: só registra uma falha de registro do Insert e a criação da janela. Ainda requer teste real no Windows para confirmar o fechamento relatado.
