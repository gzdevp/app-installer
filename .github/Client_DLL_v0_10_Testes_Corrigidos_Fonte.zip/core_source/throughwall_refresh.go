package main

// This pure decision function makes the penetration-field maintenance testable
// without requiring access to the game's memory. A foreign value must never be
// overwritten: only the value we installed, or the exact original value which
// the game may have reloaded, is recognized.
type penetrationRefreshDecision uint8

const (
	penetrationKeep penetrationRefreshDecision = iota
	penetrationReapply
	penetrationStop
)

func classifyPenetrationRefresh(current, original, installed float32) penetrationRefreshDecision {
	if current == installed {
		return penetrationKeep
	}
	if current == original {
		return penetrationReapply
	}
	return penetrationStop
}
