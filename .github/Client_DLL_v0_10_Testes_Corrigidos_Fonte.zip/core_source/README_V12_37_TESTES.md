# V12.37 — Diagnostico e verificacoes

## Por que as 36 versoes anteriores nao reproduziram Nexo v8.4

O atualizador Nexo v8.4 contem um PE Go original embutido. As funcoes
`main.startCameraAimLoop` e `main.cameraDirectionStep` foram verificadas
na tabela de funcoes do binario. O loop original le um vetor 3D na camera
em `+0x60`, le sua direcao atual em `+0x3D0` e escreve um novo vetor de
3 floats em `+0x3D0`. A revisao 12.36 usava apenas `SendInput` e tinha sido
anunciada como equivalente ao metodo antigo — nao era.

## Integracao revisada

O controlador 12.37 resolve camera, leitor de ossos e projecao, rejeita
enderecos inconsistentes e substitui **apenas** o metodo de orientacao.
O valor de direcao calculado e limitado a 4 graus por tick e gravado
apenas se a posicao da camera for compatível com o jogador local e
sua orientacao coincidir com a matriz de projecao. Se a camera nao
mudar como esperado, desativa outros movimentos ate a tecla ser solta.
Nao existe fallback para o antigo SendInput.

## Verificacoes efetuadas

- Compilacao Windows amd64: OK.
- Compilacao dos testes Windows: OK (executavel de teste nao foi rodado).
- Vet Go multiplataforma: OK.
- Simulacoes nativas: 4 cenarios aprovados (acima/abaixo/lados,
  convergencia em multiplos quadros, corrompidos, movimento contrario).
- JavaScript: OK.
- Execucao dentro do FiveM: **NAO EFETUADA**.

## Limites

A confirmacao de gravacao de 12 bytes nao comprova que a camera visivel
segue o alvo. Isso depende da implementacao da build atual do jogo,
que nao esta disponivel neste ambiente. Status "camera nao corresponde"
indica que o controlador recusou escrever; nao forca orientacao estimada.
