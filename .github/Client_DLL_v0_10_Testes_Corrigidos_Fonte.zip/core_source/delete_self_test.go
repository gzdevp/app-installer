package main

import (
	"bytes"
	"os"
	"testing"
)

func TestCleanerOnlyDeletesOwnBinaryAndSession(t *testing.T) {
	src, err := os.ReadFile("delete_self_windows.go")
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Contains(src, []byte("os.Executable()")) {
		t.Fatal("cleaner must target its own executable")
	}
	if bytes.Contains(src, []byte("*.exe")) {
		t.Fatal("cleaner must never delete arbitrary executables")
	}
	ui, err := files.ReadFile("web/index.html")
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Contains(ui, []byte("case 'unload':case 'cleaner':")) {
		t.Fatal("one click actions removed")
	}
}
