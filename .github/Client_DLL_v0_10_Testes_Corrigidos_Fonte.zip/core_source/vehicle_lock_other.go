//go:build !windows

package main

func vehicleLockActionForID(vehicleID uint64, lock bool, command, key string) (string, bool) {
	return "Somente Windows", false
}
