# sete7 v13.2 — Vida e Reviver (experimental)

Base: sete7 v13.2 TP Waypoint, altura Z padrão 35.

## Implementado

- Aba **Player → Actions**: slider **HP desejado** (101–500), botão **Restaurar HP** e botão **Tentar reviver**.
- Rotas autenticadas **POST /api/player/health** (body: `{ "hp": 200 }`) e **POST /api/player/revive**.
- Procura o ped LOCAL (via world pointer existente); recusa ponteiro, build e posição inválidos.
- Lê HP em CPed+0x280 e HP máximo em CPed+0x284 (corrigido conforme CitizenFX Entity.cs); permite aumentar também o máximo quando solicitado.
- Compara leituras após escrita; não anuncia sucesso quando escrita/leitura é rejeitada.
- O retorno do botão "Tentar reviver" é sempre **não homologado**, mesmo se o HP numérico permanecer em 200. A alteração de HP não equivale a `NETWORK_RESURRECT_LOCAL_PLAYER`, nem limpa estados de morte de recursos/servidores.

## Não implementado / não afirmar que funciona

- **Reanimação real**: alguns servidores mantêm variáveis de morte (por exemplo dead/laststand) e é necessário acionar uma rotina de ressurreição autorizada no cliente/servidor para sair desse estado. O EXE externo não dispõe dessa interface com garantia. Não existe um offset universal chamado `PLAYER_ALIVE_ADDRESS`.
- **Coletar itens**: não foi solicitado como funcionalidade; os endereços no exemplo são fictícios.
- **Teste em FiveM**: não executado neste ambiente. A leitura e a gravação reais na build b3258 continuam experimentais e podem ser revertidas pelo servidor.

## Proteções e preservação

- Somente o ped local, com perfil de escrita limitado à build b3258.
- Não modifica flags de morte desconhecidas, scripts do servidor nem outros jogadores.
- Compila no subsistema Windows GUI: não abre CMD.
- Os arquivos de TP Waypoint, Silent, ESP, Aimbot, Noclip, FIX CAR e host gráfico estão byte a byte idênticos à base.
- Funções adicionadas: `player_vitals_windows.go`, `player_vitals_logic.go` e testes; pequenas alterações em `main.go`, `settings_windows.go` e `web/index.html`.

## Testes locais (não são testes in-game)

- Cinco testes Go para planejamento de saúde normal, boost acima da vida máxima, HP zero, rejeição de valores inválidos e verificação de leitura: PASS.
- Compilação Windows x64: PASS.
- `go vet` com alvo Windows x64: PASS.
- Verificação de sintaxe JS: PASS.
- `go test -c` com alvo Windows x64: PASS (compilação, sem execução do teste em Windows).
- Binário PE: subsistema Windows GUI (`2`): PASS.

## Atualização de compatibilidade

A correção posterior também implementou `Set armor` para o ped local na b3258. Consulte `LEIA_CORRECAO_HP_ARMADURA.md` para as alterações atuais.
