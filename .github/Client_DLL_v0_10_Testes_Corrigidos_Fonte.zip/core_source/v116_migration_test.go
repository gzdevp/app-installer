package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

// Fresh, disposable sessions replaced the old v11.6 disk migration.
// Ensure an obsolete profile cannot silently switch on the visual overlays.
func TestLegacyConfigDoesNotReenableVisualFeaturesAtStartup(t *testing.T) {
	folder := t.TempDir()
	old := []byte(`{"aim":{"fov":200,"enabled":true},"visual":{"playerEsp":true,"skeleton":true,"boxes":true,"refreshMS":25}}`)
	if err := os.WriteFile(filepath.Join(folder, "config.json"), old, 0600); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 2; i++ {
		svc, err := newService(folder)
		if err != nil {
			t.Fatal(err)
		}
		var obj struct {
			Aim struct {
				Enabled bool `json:"enabled"`
				FOV     int  `json:"fov"`
			} `json:"aim"`
			Visual struct {
				PlayerESP bool `json:"playerEsp"`
				Skeleton  bool `json:"skeleton"`
				Boxes     bool `json:"boxes"`
			} `json:"visual"`
		}
		if err := json.Unmarshal(svc.config, &obj); err != nil {
			t.Fatal(err)
		}
		if obj.Aim.Enabled || obj.Aim.FOV == 200 || obj.Visual.PlayerESP || obj.Visual.Skeleton || obj.Visual.Boxes {
			t.Fatalf("old profile reactivated features: %+v", obj)
		}
	}
}
