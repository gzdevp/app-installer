//go:build windows

package main

import (
	"encoding/json"
)

// Read-only ESP, transparent FOV and experimental OS-mouse aim assist are native.
// Silent Aim and other game-affecting toggles remain preferences only.
func applyNativeSettings(data json.RawMessage) {
	var cfg struct {
		Aim struct {
			ShowFOV        bool    `json:"showFov"`
			FOV            int     `json:"fov"`
			FOVColor       string  `json:"fovColor"`
			Enabled        bool    `json:"enabled"`
			TargetNPC      bool    `json:"targetNpc"`
			Key            string  `json:"key"`
			Bone           string  `json:"bone"`
			Smooth         float64 `json:"smooth"`
			InvertY        *bool   `json:"invertY"`
			AutoY          *bool   `json:"autoY"`
			VisualFallback bool    `json:"visualFallback"`
			Sticky         bool    `json:"sticky"`
			ThroughWall    bool    `json:"throughWall"`
			Range          int     `json:"range"`
		} `json:"aim"`
		Player struct {
			autoVitalsConfig
			Health      int    `json:"health"`
			Armor       int    `json:"armor"`
			God         bool   `json:"god"`
			GodKey      string `json:"godKey"`
			Noclip      bool   `json:"noclip"`
			NoclipKey   string `json:"noclipKey"`
			NoclipSpeed int    `json:"noclipSpeed"`
		} `json:"player"`
		SilentAim struct {
			Enabled   bool   `json:"enabled"`
			Key       string `json:"key"`
			ShowFOV   bool   `json:"showFov"`
			FOV       int    `json:"fov"`
			FOVColor  string `json:"fovColor"`
			Range     int    `json:"range"`
			Visible   bool   `json:"visible"`
			IgnoreNPC bool   `json:"ignoreNpc"`
			Miss      int    `json:"miss"`
		} `json:"silentAim"`
		Crosshair CrosshairSettings `json:"crosshair"`
		Trigger   TriggerSettings   `json:"trigger"`
		Panic     PanicSettings     `json:"panic"`
		Settings  struct {
			StreamMode bool `json:"streamMode"`
		} `json:"settings"`
		Weapon struct {
			NoRecoil     bool `json:"noRecoil"`
			NoSpread     bool `json:"noSpread"`
			NoReload     bool `json:"noReload"`
			InfiniteAmmo bool `json:"infiniteAmmo"`
		} `json:"weapon"`
		World struct {
			Radar      bool `json:"radar"`
			RadarRange int  `json:"radarRange"`
			RadarScale int  `json:"radarScale"`
			RadarAlpha int  `json:"radarAlpha"`
			RadarNPC   bool `json:"radarNPC"`
		} `json:"world"`
		Vehicle struct {
			Aliases   map[string]string `json:"aliases"`
			UnlockAll bool              `json:"unlockAll"`
			EnterKey  string            `json:"enterKey"`
		} `json:"vehicle"`
		Visual struct {
			PlayerESP     bool     `json:"playerEsp"`
			Nearby        bool     `json:"nearbyPlayers"`
			NearbyRange   int      `json:"nearbyRange"`
			ShowNPC       bool     `json:"showNpc"`
			Boxes         bool     `json:"boxes"`
			Names         bool     `json:"names"`
			Friends       []string `json:"friends"`
			Health        bool     `json:"health"`
			Armor         bool     `json:"armor"`
			Distance      bool     `json:"distance"`
			Skeleton      bool     `json:"skeleton"`
			SkeletonColor string   `json:"skeletonColor"`
			FriendColor   string   `json:"friendColor"`
			WeaponESP     bool     `json:"weaponEsp"`
			Offscreen     bool     `json:"offscreen"`
			IgnoreDowned  bool     `json:"ignoreDowned"`
			FocusName     string   `json:"focusName"`
			VehicleESP    bool     `json:"vehicleEsp"`
			VehicleRange  int      `json:"vehicleRange"`
			VehicleName   bool     `json:"vehicleName"`
			Range         int      `json:"range"`
			RefreshMS     int      `json:"refreshMS"`
			RenderMS      int      `json:"renderMS"`
			Snaplines     bool     `json:"snaplines"`
			BoxStyle      string   `json:"boxStyle"`
		} `json:"visual"`
	}
	if json.Unmarshal(data, &cfg) != nil {
		return
	}
	streamModeSet(cfg.Settings.StreamMode)
	localUnlockSetEntryKey(cfg.Vehicle.EnterKey)
	localUnlockSet(cfg.Vehicle.UnlockAll)
	autoConfig := cfg.Player.autoVitalsConfig
	autoConfig.TargetHealth = cfg.Player.Health
	autoConfig.TargetArmor = cfg.Player.Armor
	autoVitalsSet(autoConfig)
	if cfg.Visual.Range == 0 {
		cfg.Visual.Range = 250
	}
	// Performance parameters are internal now; ignore legacy profile values.
	cfg.Visual.RefreshMS = 25
	cfg.Visual.RenderMS = 8
	espSet(ESPSettings{Enabled: cfg.Visual.PlayerESP, Nearby: cfg.Visual.Nearby, NearbyRange: cfg.Visual.NearbyRange, ShowNPC: cfg.Visual.ShowNPC, Skeleton: cfg.Visual.Skeleton, SkeletonColor: cfg.Visual.SkeletonColor, FriendColor: cfg.Visual.FriendColor, WeaponESP: cfg.Visual.WeaponESP, Offscreen: cfg.Visual.Offscreen, IgnoreDowned: cfg.Visual.IgnoreDowned, FocusName: cfg.Visual.FocusName, ShowDistance: cfg.Visual.Distance,
		Boxes: cfg.Visual.Boxes, Names: cfg.Visual.Names, Friends: cfg.Visual.Friends, Health: cfg.Visual.Health, Armor: cfg.Visual.Armor,
		Vehicles: cfg.Visual.VehicleESP, VehicleRange: cfg.Visual.VehicleRange, VehicleName: cfg.Visual.VehicleName, VehicleAliases: cfg.Vehicle.Aliases, Distance: cfg.Visual.Range, RefreshMS: cfg.Visual.RefreshMS, Snaplines: cfg.Visual.Snaplines, BoxStyle: cfg.Visual.BoxStyle})
	if cfg.Aim.FOV == 0 {
		cfg.Aim.FOV = 130
	}
	// Normal Windows mouse coordinates: targets above center need negative Y.
	invertY := false
	if cfg.Aim.InvertY != nil {
		invertY = *cfg.Aim.InvertY
	}
	autoY := false
	if cfg.Aim.AutoY != nil {
		autoY = *cfg.Aim.AutoY
	}
	aimSet(AimSettings{TargetNPC: cfg.Aim.TargetNPC, VisualFallback: cfg.Aim.VisualFallback, AutoY: autoY, Enabled: cfg.Aim.Enabled, Key: cfg.Aim.Key, FOV: cfg.Aim.FOV, Range: cfg.Aim.Range, Smooth: cfg.Aim.Smooth, Bone: cfg.Aim.Bone, Sticky: cfg.Aim.Sticky, InvertY: invertY})
	throughWallSet(cfg.Aim.ThroughWall) // experimental native-weapon penetration, not bypass
	noclipSet(NoclipSettings{Enabled: cfg.Player.Noclip, Key: cfg.Player.NoclipKey, Speed: cfg.Player.NoclipSpeed})
	silentSet(SilentSettings{Enabled: cfg.SilentAim.Enabled, Key: cfg.SilentAim.Key, FOV: cfg.SilentAim.FOV, Range: cfg.SilentAim.Range, Visible: cfg.SilentAim.Visible, IgnoreNPC: cfg.SilentAim.IgnoreNPC, Miss: cfg.SilentAim.Miss})
	radarSet(RadarSettings{Enabled: cfg.World.Radar, Range: cfg.World.RadarRange, Size: cfg.World.RadarScale, Opacity: cfg.World.RadarAlpha, ShowNPC: cfg.World.RadarNPC})
	weaponSet(WeaponControlSettings{NoRecoil: cfg.Weapon.NoRecoil, NoSpread: cfg.Weapon.NoSpread, NoReload: cfg.Weapon.NoReload, InfiniteAmmo: cfg.Weapon.InfiniteAmmo})
	triggerSet(cfg.Trigger)
	panicSet(cfg.Panic)
	godHotkeySet(GodHotkeySettings{Enabled: cfg.Player.God, Key: cfg.Player.GodKey})
	setOverlaySettings(OverlaySettings{Crosshair: cfg.Crosshair, ShowAimFOV: cfg.Aim.ShowFOV, AimRadius: cfg.Aim.FOV,
		ShowSilentFOV: cfg.SilentAim.ShowFOV, SilentRadius: cfg.SilentAim.FOV, AimColor: cfg.Aim.FOVColor, SilentColor: cfg.SilentAim.FOVColor, RenderMS: cfg.Visual.RenderMS})
}
func nativeStatus() any {
	return map[string]any{"esp": espGet(), "overlay": getOverlaySettings(), "engineConnected": espGet().Status == "Leitura ativa (experimental)", "aimbot": aimGet(), "silent": silentGet(), "noclip": noclipGet(), "throughWall": throughWallGet(), "fixCar": vehicleFixGet(), "unlockAll": localUnlockGet(), "tpWaypoint": tpWayGet(), "playerVitals": playerVitalsGet(), "autoVitals": autoVitalsGet(), "magic": magicStatusWithKey(dataFolder()), "weaponControl": weaponGet(), "radar": radarGet(), "vehicleEsp": vehicleEspGet(), "trigger": triggerGet(), "panic": panicGet(), "godHotkey": godHotkeyGet(), "streamMode": streamModeGet()}
}
