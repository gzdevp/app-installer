package main

import (
	"bytes"
	"encoding/binary"
	"testing"
)

func TestMaterialsRPFStructure(t *testing.T) {
	payload := []byte("# MATERIAL ShootThru\nCONCRETE 1\n")
	b, err := buildMaterialsModRPF(payload)
	if err != nil {
		t.Fatal(err)
	}
	if got := binary.LittleEndian.Uint32(b[0:4]); got != 0x52504637 {
		t.Fatalf("magic: %#x", got)
	}
	if got := binary.LittleEndian.Uint32(b[12:16]); got != 0x4E45504F {
		t.Fatalf("encryption: %#x", got)
	}
	if n := binary.LittleEndian.Uint32(b[4:8]); n != 4 {
		t.Fatalf("TOC entries: %d", n)
	}
	if !bytes.Contains(b[512:1024], []byte(`target="Five"`)) {
		t.Fatal("missing valid FiveM assembly")
	}
	if !bytes.Contains(b[512:1024], []byte(`path="update\update.rpf"`)) {
		t.Fatal("missing archive target")
	}
	if !bytes.Equal(b[1024:], payload) {
		t.Fatal("payload mismatch")
	}
	if idx := binary.LittleEndian.Uint32(b[16+2*16+8 : 16+2*16+12]); idx != 3 {
		t.Fatalf("content child index %d", idx)
	}
}
func TestMaterialsRPFRejectedInput(t *testing.T) {
	if _, e := buildMaterialsModRPF(nil); e == nil {
		t.Fatal("empty accepted")
	}
	if _, e := buildMaterialsModRPF(make([]byte, 1<<20+1)); e == nil {
		t.Fatal("large accepted")
	}
}
