//go:build !windows

package main

type vehicleFrame struct {
	PID    uint32          `json:"pid"`
	Status string          `json:"status"`
	Count  int             `json:"count"`
	Cars   []vehicleNearby `json:"cars"`
}

func vehicleEspGet() vehicleFrame { return vehicleFrame{Status: "Somente Windows"} }
