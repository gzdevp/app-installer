//go:build !windows || !cgo

package main

func managedDLLMode() bool { return false }
func markManagedCleanup()  {}
