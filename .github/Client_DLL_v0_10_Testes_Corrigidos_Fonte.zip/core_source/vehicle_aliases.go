package main

import (
	"strconv"
	"strings"
	"unicode"
)

// User-defined model names are scoped to a verified model hash; they cannot
// reveal a real custom car name without a supplied mapping.
func normalizeVehicleAliases(in map[string]string) map[string]string {
	out := make(map[string]string)
	for raw, name := range in {
		if len(out) >= 2048 {
			break
		}
		n, err := strconv.ParseUint(strings.TrimSpace(raw), 10, 32)
		if err != nil || n == 0 {
			continue
		}
		name = strings.TrimSpace(name)
		if len(name) == 0 || len(name) > 80 || len([]rune(name)) > 45 {
			continue
		}
		bad := false
		for _, r := range name {
			if unicode.IsControl(r) {
				bad = true
				break
			}
		}
		if bad {
			continue
		}
		out[strconv.FormatUint(n, 10)] = name
	}
	return out
}
func resolvedVehicleName(hash uint32, aliases map[string]string) (string, bool) {
	if hash == 0 {
		return "", false
	}
	if s, ok := aliases[strconv.FormatUint(uint64(hash), 10)]; ok && s != "" {
		return s, true
	}
	// Prefer a verified display name including manufacturer if the public
	// catalogue was downloaded; keep the bundled map as an offline fallback.
	if name, ok := storedPublicVehicleName(hash); ok {
		return name, true
	}
	if name, ok := vehicleNameByHash(hash); ok {
		return name, true
	}
	return storedLocalVehicleName(hash)
}
