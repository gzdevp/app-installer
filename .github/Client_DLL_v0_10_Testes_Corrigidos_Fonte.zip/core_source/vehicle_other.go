//go:build !windows

package main

func fixVehicleAction() (string, bool)              { return "Fix Car disponível apenas no Windows", false }
func fixVehicleActionForID(_ uint64) (string, bool) { return fixVehicleAction() }
func vehicleFixGet() map[string]any                 { return map[string]any{"status": "Somente Windows"} }
func startVehicleFixHotkey()                        {}
func throughWallSet(enabled bool)                   {}
func throughWallGet() map[string]any {
	return map[string]any{"enabled": false, "status": "Somente Windows"}
}
func startThroughWall()    {}
func throughWallShutdown() {}

func vehicleRepairViaCityCommand(command string) (string, bool) { return "Somente Windows", false }
