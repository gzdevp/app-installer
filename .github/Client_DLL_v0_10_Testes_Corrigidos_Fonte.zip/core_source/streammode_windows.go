//go:build windows

package main

// Capture protection applies only to our native top-level menu host and ESP
// overlay. It does not protect content rendered within FiveM or prevent
// cameras, external capture cards, or unsupported recording APIs from seeing
// the screen. The Windows API is NOT a DRM/security boundary.
import (
	"fmt"
	"sync"
	"syscall"
	"unsafe"
)

var (
	streamUser32             = syscall.NewLazyDLL("user32.dll")
	streamKernel32           = syscall.NewLazyDLL("kernel32.dll")
	streamDWM                = syscall.NewLazyDLL("dwmapi.dll")
	setWindowDisplayAffinity = streamUser32.NewProc("SetWindowDisplayAffinity")
	getWindowDisplayAffinity = streamUser32.NewProc("GetWindowDisplayAffinity")
	streamIsWindow           = streamUser32.NewProc("IsWindow")
	streamWindowProcess      = streamUser32.NewProc("GetWindowThreadProcessId")
	streamCurrentProcess     = streamKernel32.NewProc("GetCurrentProcessId")
	streamDWMEnabled         = streamDWM.NewProc("DwmIsCompositionEnabled")
)

var streamMode = struct {
	sync.Mutex
	enabled                          bool
	panel, overlay                   uintptr
	panelState, overlayState         string
	panelProtected, overlayProtected bool
}{panelState: "Aguardando janela", overlayState: "Aguardando overlay"}

func streamDwmReady() bool {
	var enabled int32
	hr, _, _ := streamDWMEnabled.Call(uintptr(unsafe.Pointer(&enabled)))
	return int32(hr) == 0 && enabled != 0
}

// SetWindowDisplayAffinity succeeds only with top-level windows owned by the
// calling process. Checking ownership avoids a misleading "protected" status.
func streamOwnWindow(hwnd uintptr) bool {
	if hwnd == 0 {
		return false
	}
	exists, _, _ := streamIsWindow.Call(hwnd)
	if exists == 0 {
		return false
	}
	var pid uint32
	streamWindowProcess.Call(hwnd, uintptr(unsafe.Pointer(&pid)))
	ourPID, _, _ := streamCurrentProcess.Call()
	return pid != 0 && uintptr(pid) == ourPID
}

func streamReadAffinity(hwnd uintptr) (uintptr, bool) {
	var actual uint32
	ok, _, _ := getWindowDisplayAffinity.Call(hwnd, uintptr(unsafe.Pointer(&actual)))
	return uintptr(actual), ok != 0
}

func streamApplyAffinity(hwnd uintptr, enabled bool, name string) (string, bool) {
	if hwnd == 0 {
		return "Aguardando " + name, false
	}
	if !streamOwnWindow(hwnd) {
		return "Janela indisponível/não pertence ao 77", false
	}
	if enabled && !streamDwmReady() {
		return "Composição de janelas (DWM) indisponível", false
	}
	flag := wdaNone
	if enabled {
		flag = wdaExcludeFromCapture
	}
	r, _, err := setWindowDisplayAffinity.Call(hwnd, flag)
	if r == 0 {
		if err != nil && err != syscall.Errno(0) {
			return fmt.Sprintf("Windows recusou: %v", err), false
		}
		return "Windows recusou a proteção", false
	}
	actual, ok := streamReadAffinity(hwnd)
	return streamClassify(enabled, actual, ok)
}

// Do a read-back on each UI status poll. If the window was recreated or its
// affinity was reset (for example after display changes), reapply once.
func streamCheckAffinity(hwnd uintptr, enabled bool, name string) (string, bool) {
	if hwnd == 0 {
		return "Aguardando " + name, false
	}
	if !streamOwnWindow(hwnd) {
		return "Janela indisponível/não pertence ao 77", false
	}
	if enabled && !streamDwmReady() {
		return "DWM indisponível", false
	}
	actual, ok := streamReadAffinity(hwnd)
	desired := wdaNone
	if enabled {
		desired = wdaExcludeFromCapture
	}
	if !ok || actual != desired {
		// Some older Windows systems map 0x11 to 0x01: report that limitation.
		if enabled && ok && actual == wdaMonitor {
			return streamClassify(enabled, actual, ok)
		}
		return streamApplyAffinity(hwnd, enabled, name)
	}
	return streamClassify(enabled, actual, ok)
}

func streamModeSet(enabled bool) {
	streamMode.Lock()
	defer streamMode.Unlock()
	streamMode.enabled = enabled
	streamMode.panelState, streamMode.panelProtected = streamApplyAffinity(streamMode.panel, enabled, "painel")
	streamMode.overlayState, streamMode.overlayProtected = streamApplyAffinity(streamMode.overlay, enabled, "overlay")
}

func streamRegisterPanel(hwnd uintptr) {
	streamMode.Lock()
	defer streamMode.Unlock()
	streamMode.panel = hwnd
	streamMode.panelState, streamMode.panelProtected = streamApplyAffinity(hwnd, streamMode.enabled, "painel")
}

func streamRegisterOverlay(hwnd uintptr) {
	streamMode.Lock()
	defer streamMode.Unlock()
	streamMode.overlay = hwnd
	streamMode.overlayState, streamMode.overlayProtected = streamApplyAffinity(hwnd, streamMode.enabled, "overlay")
}

func streamUnregisterPanel(hwnd uintptr) {
	streamMode.Lock()
	defer streamMode.Unlock()
	if streamMode.panel != hwnd {
		return
	}
	streamMode.panel = 0
	streamMode.panelProtected = false
	streamMode.panelState = "Aguardando janela"
}
func streamUnregisterOverlay(hwnd uintptr) {
	streamMode.Lock()
	defer streamMode.Unlock()
	if streamMode.overlay != hwnd {
		return
	}
	streamMode.overlay = 0
	streamMode.overlayProtected = false
	streamMode.overlayState = "Aguardando overlay"
}

func streamModeGet() map[string]any {
	streamMode.Lock()
	defer streamMode.Unlock()
	if streamMode.enabled {
		streamMode.panelState, streamMode.panelProtected = streamCheckAffinity(streamMode.panel, true, "painel")
		streamMode.overlayState, streamMode.overlayProtected = streamCheckAffinity(streamMode.overlay, true, "overlay")
	}
	ready := streamMode.enabled && streamMode.panelProtected && streamMode.overlayProtected
	return map[string]any{
		"enabled":         streamMode.enabled,
		"panel":           streamMode.panelState,
		"overlay":         streamMode.overlayState,
		"windowsReady":    ready,
		"windowsStatus":   streamReadyLabel(streamMode.enabled, ready),
		"captureVerified": false, // requires a real OBS/capture test on Windows
		"note":            "Somente janelas do 77. Proteção de captura depende do Windows e da fonte de gravação; sem garantia universal.",
	}
}
