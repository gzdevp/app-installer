//go:build windows

package main

import (
	"strings"
	"testing"
	"time"
)

func TestHeadlockGuardStopsHorizontalReverse(t *testing.T) {
	s := cameraHeadServo{pid: 42}
	aim := AimCandidate{ID: 3, X: 1050, Y: 335, RealBone: true, HeadWorld: vec3{X: 15, Y: 10, Z: 25}}
	for i := 0; i < 2; i++ {
		_, dy, _ := s.command(aim, 1920, 1080, 10, false)
		s.record(aim.ID, aim.HeadWorld, syntheticCam(0), dy)
		s.recordedAt = time.Now().Add(-70 * time.Millisecond)
		s.seeFrame(syntheticCam(-.0074), 1920, 1080)
	}
	if !s.ready() {
		t.Fatal("expected Y calibration")
	}
	before := syntheticCam(0)
	after := syntheticCam(0)
	// Projection X is determined by matrix element [13]. A negative shift
	// moves the head right, farther from the viewport center (960 px).
	after[13] = .0125
	s.recordXY(aim.ID, aim.HeadWorld, before, 3, 0)
	s.recordedAt = time.Now().Add(-70 * time.Millisecond)
	s.seeFrame(after, 1920, 1080)
	if !s.fault || !strings.Contains(s.status(), "eixo X") {
		t.Fatalf("horizontal reverse should halt: %+v", s)
	}
}

func TestHeadlockGuardNoHorizontalFalseYTimeout(t *testing.T) {
	s := cameraHeadServo{pid: 42}
	aim := AimCandidate{ID: 3, X: 1000, Y: 335, RealBone: true, HeadWorld: vec3{X: 15, Y: 10, Z: 25}}
	before := syntheticCam(0)
	before[13] = .05 // target right of center
	after := before
	after[13] = .04 // target moved toward center
	s.recordXY(aim.ID, aim.HeadWorld, before, 2, 0)
	s.recordedAt = time.Now().Add(-70 * time.Millisecond)
	s.seeFrame(after, 1920, 1080)
	if s.noResponse != 0 || s.fault {
		t.Fatalf("horizontal-only sample polluted vertical calibration: %+v", s)
	}
}

func TestHeadlockGuardRejectsBadProjection(t *testing.T) {
	s := cameraHeadServo{}
	cases := []AimCandidate{
		{ID: 1, X: -1, Y: 30, RealBone: true, HeadWorld: vec3{X: 1, Y: 2, Z: 3}},
		{ID: 2, X: 960, Y: 1080, RealBone: true, HeadWorld: vec3{X: 1, Y: 2, Z: 3}},
	}
	for _, a := range cases {
		dx, dy, _ := s.command(a, 1920, 1080, 2, false)
		if dx != 0 || dy != 0 {
			t.Fatalf("invalid target moved mouse: %+v -> %d,%d", a, dx, dy)
		}
	}
}
