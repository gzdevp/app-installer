# Sete7 v13.9.29 — materiais ShootThru (opção de edição local)

Esta etapa acrescenta uma segunda abordagem à aba **AIM > Through Wall**: criar uma nova versão de `materials.dat` alterando apenas a coluna `ShootThru` de materiais que tinham valor `0` para `1`. O arquivo original não é alterado. O software devolve um arquivo com novo nome, destinado à instalação manual em um ambiente de GTA V modificado que aceite substituição de materiais.

**Importante:** Isso é uma edição de arquivo real, diferente do campo `CWeaponInfo::Penetration` (que permanece experimental e inalterado na v13.9.29). O arquivo **não é instalado automaticamente**, **não** altera a colisão de uma sessão já aberta, **não** permite ativar/desativar material com uma tecla em tempo real, **não** modifica o servidor, **não** garante funcionamento em todos os servidores FiveM e **não** contorna pure mode. Não foi testado dentro de FiveM.

## Uso

1. Abra o sete7 e navegue à aba **AIM > Through Wall**.
2. Clique em **Preparar materiais ShootThru** e selecione um arquivo `materials.dat` textual de sua própria instalação de GTA V (extraído para uma pasta local via ferramenta apropriada).
3. Se o arquivo contiver um cabeçalho identificável com a coluna `ShootThru`, o painel salva `materials_sete7_shootthru.dat` em sua pasta de downloads.
4. Para testar em GTA V com mods permitidos, preserve um backup, instale o novo arquivo no lugar correto com ferramenta de mods e reinicie o jogo. Se o servidor proibir modificações de arquivos locais, não prossiga.
5. Para desfazer, restaure seu `materials.dat` original.

## Medidas de integridade

- A API recebe até 1 MiB por solicitação e opera apenas sobre o arquivo explicitamente enviado.
- Nenhum arquivo do jogo é aberto/sobrescrito pelo sete7 nesta funcionalidade.
- Se não identificar a coluna `ShootThru` com segurança, o programa recusa a conversão.
- Colunas como `ShootThruFX`, `SeeThru` e propriedades de aderência não são alteradas.
- Preserve o original para restauração.

## Validação

- Compilação GOOS=windows GOARCH=amd64 CGO_ENABLED=0: aprovada.
- Testes unitários do parser executados em Go isolado: aprovados.
- Análise de sintaxe do JavaScript: aprovada.
- Execução no Windows/FiveM e resultado de colisão/dano: **não validados**.
