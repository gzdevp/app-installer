# Sete7 v13.9.21 — Vehicle Control (seleção segura)

- ESP de veículos: marca visualmente o veículo local quando o ponteiro PedVehicle coincide, só na b3258.
- Lista selecionável (mouse/teclado) e painel de veículo selecionado; selection só nesta sessão.
- FIX CAR da v13.9.20 preservado, agora botão habilitado somente para o veículo local selecionado. Backend valida novamente o ID antes da escrita. A tecla F6 original continua operando no veículo local.
- Trancar/destrancar permanecem indisponíveis sem a integração autorizada no FiveM. Não foram inventados offsets de trava.
- Leitura posterior confirma apenas valores locais. Não há confirmação de persistência no servidor.
- Nenhuma alteração em Aimbot, Silent, Radar, ESP de jogadores, No Recoil/Spread, Triggerbot ou outras rotinas existentes.
- Distribuição EXE único, sem pastas permanentes ao lado, conforme v13.9.20.
- Compilação no Linux cross-target Windows não significa teste em FiveM. Testar no Windows antes de considerar pronto.
