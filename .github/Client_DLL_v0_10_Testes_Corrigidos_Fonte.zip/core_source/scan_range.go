package main

// effectiveTargetRange computes the common entity-reader radius. Range 0 on
// the Aimbot means unlimited (up to the supported maximum of 500m).
func effectiveTargetRange(visual int, aimEnabled bool, aim int, silentEnabled bool, silent int) int {
	radius := visual
	if aimEnabled {
		if aim <= 0 || aim > 500 {
			aim = 500
		}
		if aim > radius {
			radius = aim
		}
	}
	if silentEnabled && silent > radius {
		radius = silent
	}
	if radius > 500 {
		radius = 500
	}
	if radius < 0 {
		radius = 0
	}
	return radius
}
