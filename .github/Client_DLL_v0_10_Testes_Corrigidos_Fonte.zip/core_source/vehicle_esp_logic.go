package main

import (
	"math"
	"sort"
	"time"
)

type vehicleNearby struct {
	ID             uint64   `json:"id"`
	IsLocal        bool     `json:"isLocal,omitempty"`
	Name           string   `json:"name"`
	ModelHash      uint32   `json:"modelHash,omitempty"`
	Distance       int      `json:"distance"`
	SpeedKMH       *int     `json:"speedKmh,omitempty"`
	EngineHealth   *int     `json:"engineHealth,omitempty"`
	Occupants      *int     `json:"occupants,omitempty"`
	DriverKnown    bool     `json:"driverKnown,omitempty"`
	Driver         string   `json:"driver,omitempty"`
	Passengers     []string `json:"passengers,omitempty"`
	NamedOccupants []string `json:"namedOccupants,omitempty"`
	EngineState    string   `json:"engineState,omitempty"`
	Position       vec3     `json:"-"`
}

// Pools can be sparse. An active entity count is not the number of slots to
// inspect: vehicles may occupy any slot below the pool capacity. Return zero
// when the candidate is too large or has inconsistent counters.
func vehiclePoolScanSlots(active, capacity uint32) (uint32, bool) {
	if capacity == 0 || capacity > 2048 || active > capacity {
		return 0, false
	}
	if active == 0 {
		return 0, true
	}
	return capacity, true
}

func clampVehicleESPRange(n int) int {
	if n < 50 {
		return 50
	}
	if n > 500 {
		return 500
	}
	return n
}
func sortNearbyVehicles(v []vehicleNearby) {
	sort.Slice(v, func(i, j int) bool {
		if v[i].Distance != v[j].Distance {
			return v[i].Distance < v[j].Distance
		}
		return v[i].ID < v[j].ID
	})
}
func validVehicleDistance(d float64, max int) bool {
	return !math.IsNaN(d) && !math.IsInf(d, 0) && d >= 0 && d <= float64(clampVehicleESPRange(max))
}

// Estimate speed from two validated, separated position samples. A very short
// interval would amplify read jitter, so unsupported values remain absent.
func vehicleSpeedKMH(a, b vec3, elapsed time.Duration) (int, bool) {
	if elapsed < 120*time.Millisecond || elapsed > 3*time.Second {
		return 0, false
	}
	secs := elapsed.Seconds()
	d := dist(a, b)
	if math.IsNaN(d) || math.IsInf(d, 0) || d/secs > 110 {
		return 0, false
	}
	if d < 0.30 {
		return 0, true
	}
	v := int(math.Round(d / secs * 3.6))
	if v > 400 {
		return 0, false
	}
	return v, true
}

// Informative estimate from validated engine health, not a server repair state.
func vehicleEngineState(hp int) string {
	if hp < 0 || hp > 1000 {
		return ""
	}
	if hp < 250 {
		return "Crítico"
	}
	if hp < 650 {
		return "Desgastado"
	}
	return "Normal"
}

// Prioritize known model hashes over arbitrary model-info bytes. Candidate
// ordering must not override stronger evidence from a later pool layout.
func vehiclePoolEvidenceScore(positions, hashes, named int) int {
	if positions <= 0 || hashes <= 0 {
		return 0
	}
	if hashes > positions {
		hashes = positions
	}
	if named > hashes {
		named = hashes
	}
	return named*100 + hashes*4 + positions
}
