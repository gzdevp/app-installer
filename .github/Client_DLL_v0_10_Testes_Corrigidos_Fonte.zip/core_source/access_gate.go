package main

import (
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"net/http"
	"strings"
	"time"
)

// Credentials are hashed inside the executable. The cleartext key is supplied
// separately to the owner; this is an offline access gate, not online licensing.
const accessSalt = "b3b989e008a385ba33bbdc0ae1f2296b"
const accessDigest = "f877c828b50d39118fc5f682bc87924bbbba00960ce82f78e1b23395d9791c06"
const sessionCookieName = "sete7_session"

func validCredentials(username, license string) bool {
	if len(username) == 0 || len(username) > 64 || len(license) == 0 || len(license) > 128 {
		return false
	}
	got := sha256.Sum256([]byte(accessSalt + "\x00" + username + "\x00" + license))
	want, e := hex.DecodeString(accessDigest)
	return e == nil && subtle.ConstantTimeCompare(got[:], want) == 1
}

func (s *service) sessionAllowed(r *http.Request) bool {
	c, e := r.Cookie(sessionCookieName)
	if e != nil {
		return false
	}
	s.mu.Lock()
	token := s.accessToken
	s.mu.Unlock()
	return len(token) != 0 && subtle.ConstantTimeCompare([]byte(c.Value), []byte(token)) == 1
}

func (s *service) accessLogin(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	if !s.authOrigin(w, r) {
		return
	}
	if r.Method == http.MethodGet && r.URL.Path == "/api/auth/status" {
		jsonOut(w, map[string]bool{"authenticated": s.sessionAllowed(r)})
		return
	}
	if r.Method != http.MethodPost || r.URL.Path != "/api/auth/login" {
		http.NotFound(w, r)
		return
	}
	if r.ContentLength > 2048 {
		http.Error(w, "Dados invalidos", http.StatusBadRequest)
		return
	}
	var request struct {
		Username string `json:"username"`
		Key      string `json:"key"`
	}
	raw, e := decodeJSON(r)
	if e != nil || len(raw) > 2048 || json.Unmarshal(raw, &request) != nil {
		http.Error(w, "Dados invalidos", http.StatusBadRequest)
		return
	}
	s.mu.Lock()
	locked := time.Now().Before(s.accessBlocked)
	s.mu.Unlock()
	if locked {
		http.Error(w, "Aguarde antes de tentar novamente", http.StatusTooManyRequests)
		return
	}
	if !validCredentials(strings.TrimSpace(request.Username), request.Key) {
		s.mu.Lock()
		s.accessFailures++
		if s.accessFailures >= 5 {
			s.accessBlocked = time.Now().Add(30 * time.Second)
			s.accessFailures = 0
		}
		s.mu.Unlock()
		http.Error(w, "Username ou key incorretos", http.StatusUnauthorized)
		return
	}
	rawToken := make([]byte, 32)
	if _, e := rand.Read(rawToken); e != nil {
		http.Error(w, "Falha de inicializacao", http.StatusInternalServerError)
		return
	}
	s.mu.Lock()
	s.accessToken = hex.EncodeToString(rawToken)
	s.accessFailures = 0
	s.accessBlocked = time.Time{}
	token := s.accessToken
	s.mu.Unlock()
	// The UI starts as a small login window and may expand only on success.
	menuAuthenticated.Store(true)
	http.SetCookie(w, &http.Cookie{Name: sessionCookieName, Value: token, Path: "/api", HttpOnly: true, SameSite: http.SameSiteStrictMode})
	jsonOut(w, map[string]bool{"authenticated": true})
}
