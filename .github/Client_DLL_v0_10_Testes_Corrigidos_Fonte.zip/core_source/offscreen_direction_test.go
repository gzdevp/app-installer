package main

import "testing"

func TestOffscreen360DirectionsAndGuards(t *testing.T) {
	var m matrix44
	m[1], m[6], m[11] = 1, 1, 1
	cases := []struct {
		name   string
		point  vec3
		want   bool
		behind bool
		edge   string
	}{
		{"visible", vec3{0, 0, 10}, false, false, ""},
		{"front right", vec3{20, 0, 10}, true, false, "right"},
		{"rear right", vec3{10, 0, -10}, true, true, "right"},
		{"rear left", vec3{-10, 0, -10}, true, true, "left"},
		{"rear center", vec3{0, 0, -10}, true, true, "bottom"},
		{"near-plane", vec3{10, 0, 0}, true, false, "right"},
		{"invalid coords", vec3{30000, 0, 10}, false, false, ""},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			x, y, got, back := projectOffscreen360(m, tc.point, 1920, 1080)
			if got != tc.want || back != tc.behind {
				t.Fatalf("got marker=%v behind=%v, want=%v/%v", got, back, tc.want, tc.behind)
			}
			if !got {
				return
			}
			if x < 35 || x > 1920-35 || y < 35 || y > 1080-35 {
				t.Fatalf("marker outside safe viewport: (%d,%d)", x, y)
			}
			switch tc.edge {
			case "right":
				if x < 1800 {
					t.Fatalf("expected right, x=%d", x)
				}
			case "left":
				if x > 120 {
					t.Fatalf("expected left, x=%d", x)
				}
			case "bottom":
				if y < 1000 {
					t.Fatalf("expected rear center at bottom, y=%d", y)
				}
			}
		})
	}
}
