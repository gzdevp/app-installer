# 77 Black Edition v13.9.55 — Cleaner confiável

- Cleaner de um clique; Unload permanece separado.
- Removeu a limpeza genérica de arquivos `.tmp`/`.temp` de outros programas.
- Limpeza restrita à sessão temporária própria e ao EXE atual, com validação de escopo e verificação de ausência após exclusão.
- Rejeita pastas de sessão contendo links simbólicos/reparse points, prevenindo desvios de diretório.
- Recupera até 24 sessões próprias abandonadas, SOMENTE com marcador válido, idade mínima de 24h e PID comprovadamente inativo; não interfere em outras sessões em funcionamento.
- Não toca em Prefetch, logs do Windows, histórico de terceiros, dados do FiveM ou registros de segurança.
- Testes de segurança de escopo e compilação Windows devem ser executados antes da distribuição.
- Encerramento do Chrome/Edge isolado reforçado com Job Object nativo do Windows (quando permitido pelo sistema). Sem encerrar Chrome/Edge pessoal.
- A rotina de remoção de pastas verifica a ausência depois da exclusão e usa tentativas limitadas para arquivos momentaneamente bloqueados.
- Testes isolados da rotina de escopo e de recuperação de sessões antigas passaram no Linux. O EXE Windows compilou, mas o comportamento no Windows e o autoapagamento não foram testados neste ambiente.
