package aimv13

import (
	"math"
	"time"
)

// FrameGate requires fresh, monotonically convergent camera observations.
// Checking each new frame against only the original error was insufficient:
// a recovery of 100 -> 80 -> 98 pixels incorrectly counted as two successes.
type FrameGate struct {
	seenSeq       uint64
	width, height int32
	positive      uint8
	lastError     float64
	haveError     bool
}

func (g *FrameGate) Begin(seq uint64, width, height int32) {
	*g = FrameGate{seenSeq: seq, width: width, height: height}
}

func (g *FrameGate) Observe(seq uint64, width, height int32, before, after float64, elapsed time.Duration) Feedback {
	if elapsed >= 320*time.Millisecond {
		return Unresponsive
	}
	if width != g.width || height != g.height || width < 320 || height < 240 {
		return Reversed
	}
	if seq <= g.seenSeq {
		return Wait
	}
	g.seenSeq = seq
	if !isFiniteError(after) || !isFiniteError(before) {
		return Reversed
	}
	if g.haveError && after > g.lastError+0.7 {
		// Regression between fresh frames matters even when each frame is
		// still closer than the pre-write baseline.
		return Reversed
	}
	result := CheckFeedback(before, after, elapsed)
	if result == Reversed || result == Unresponsive {
		return result
	}
	if result == Wait {
		g.positive = 0
		g.lastError, g.haveError = after, true
		return Wait
	}
	if g.haveError {
		if !isFiniteError(after) || after > g.lastError+0.7 {
			// A second frame regressed, despite still being better than the
			// baseline. Do not permit the next camera write.
			return Reversed
		}
		if g.lastError-after < 0.4 {
			g.positive = 0
			g.lastError = after
			return Wait
		}
	}
	g.lastError, g.haveError = after, true
	g.positive++
	if g.positive >= 2 {
		return Improved
	}
	return Wait
}

func isFiniteError(v float64) bool {
	return v >= 0 && !math.IsNaN(v) && !math.IsInf(v, 0)
}
