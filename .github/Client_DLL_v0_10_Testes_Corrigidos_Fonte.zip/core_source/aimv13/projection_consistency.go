package aimv13

import "math"

// RayCentered verifies the memory camera's origin/forward direction against
// the actual projection transform consumed by ESP. A direction-vector check
// alone cannot detect a valid-looking camera owned by a different viewport.
// The projection coefficient layout matches the existing worldToScreen reader.
// It only authorizes a write if two points on the camera's forward ray are
// both projected close to the viewport centre and have positive clip depth.
func RayCentered(eye, forward Vec3, m [16]float32) bool {
	if !finite(eye) || !ValidDirection(forward) {
		return false
	}
	f, _ := Unit(forward)
	// If the camera's claimed world position is not close to the projection
	// origin, the pointer may belong to a different camera altogether.
	depthScale := math.Sqrt(float64(m[3])*float64(m[3]) + float64(m[7])*float64(m[7]) + float64(m[11])*float64(m[11]))
	zAtEye := float64(m[3])*eye.X + float64(m[7])*eye.Y + float64(m[11])*eye.Z + float64(m[15])
	if depthScale < 1e-6 || math.IsNaN(depthScale) || math.IsInf(depthScale, 0) || math.Abs(zAtEye/depthScale) > 18 {
		return false
	}
	for _, depth := range [...]float64{30, 60} {
		p := Add(eye, Mul(f, depth))
		x := float64(m[1])*p.X + float64(m[5])*p.Y + float64(m[9])*p.Z + float64(m[13])
		y := float64(m[2])*p.X + float64(m[6])*p.Y + float64(m[10])*p.Z + float64(m[14])
		z := float64(m[3])*p.X + float64(m[7])*p.Y + float64(m[11])*p.Z + float64(m[15])
		if math.IsNaN(x) || math.IsNaN(y) || math.IsNaN(z) || math.IsInf(x, 0) || math.IsInf(y, 0) || math.IsInf(z, 0) || z <= 0.1 {
			return false
		}
		// A wide geometric margin allows ordinary third-person camera offsets,
		// without mistaking a camera facing an unrelated world direction.
		if math.Abs(x/z) > 0.24 || math.Abs(y/z) > 0.24 {
			return false
		}
	}
	return true
}
