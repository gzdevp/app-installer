package aimv13

import (
	"testing"
	"time"
)

func TestFrameGateRejectsReplayAndResize(t *testing.T) {
	var g FrameGate
	g.Begin(200, 1920, 1080)
	if got := g.Observe(200, 1920, 1080, 100, 80, 90*time.Millisecond); got != Wait {
		t.Fatalf("replayed sequence accepted: %v", got)
	}
	if got := g.Observe(201, 1920, 1080, 100, 80, 90*time.Millisecond); got != Wait {
		t.Fatalf("single frame accepted: %v", got)
	}
	if got := g.Observe(201, 1920, 1080, 100, 80, 95*time.Millisecond); got != Wait {
		t.Fatalf("duplicate positive frame accepted: %v", got)
	}
	if got := g.Observe(202, 1920, 1080, 100, 76, 120*time.Millisecond); got != Improved {
		t.Fatalf("fresh corroboration denied: %v", got)
	}
	g.Begin(300, 1920, 1080)
	if got := g.Observe(301, 1600, 900, 100, 50, 90*time.Millisecond); got != Reversed {
		t.Fatalf("resized window accepted: %v", got)
	}
}
func TestFrameGateRejectsJitterAndTimeout(t *testing.T) {
	var g FrameGate
	g.Begin(10, 1920, 1080)
	for i := uint64(11); i < 18; i++ {
		if got := g.Observe(i, 1920, 1080, 80, 79.79, 80*time.Millisecond); got != Wait {
			t.Fatalf("jitter %d accepted: %v", i, got)
		}
	}
	if got := g.Observe(18, 1920, 1080, 80, 79.79, 321*time.Millisecond); got != Unresponsive {
		t.Fatalf("timeout wrong: %v", got)
	}
	g.Begin(20, 1920, 1080)
	if got := g.Observe(20, 1920, 1080, 80, 65, 321*time.Millisecond); got != Unresponsive {
		t.Fatalf("stale snapshot survived timeout: %v", got)
	}
}
func TestFrameGateRejectsReverse(t *testing.T) {
	var g FrameGate
	g.Begin(5, 1920, 1080)
	if got := g.Observe(6, 1920, 1080, 80, 90, 60*time.Millisecond); got != Reversed {
		t.Fatalf("reversed accepted: %v", got)
	}
}

func TestAxisGuardBlocksDownwardDriftHiddenByHorizontalGain(t *testing.T) {
	// Euclidean total error improves 113 -> 90, but Y gets worse 80 -> 90.
	if !AxisDiverged(80, 80, 0, 90) {
		t.Fatal("horizontal correction hid vertical regression")
	}
	if AxisDiverged(80, 80, 0, 79) {
		t.Fatal("valid improvement rejected")
	}
	if !AxisDiverged(0, 30, 0, 34) {
		t.Fatal("camera moving to floor allowed")
	}
}

func TestFrameGateRejectsFalseSecondImprovement(t *testing.T) {
	var g FrameGate
	g.Begin(100, 1920, 1080)
	if got := g.Observe(101, 1920, 1080, 100, 80, 80*time.Millisecond); got != Wait {
		t.Fatalf("first observation: %v", got)
	}
	// Both samples are better than baseline 100; however 80 -> 98
	// is a serious backwards movement and must not approve another write.
	if got := g.Observe(102, 1920, 1080, 100, 98, 120*time.Millisecond); got != Reversed {
		t.Fatalf("regressed camera accepted: %v", got)
	}
}

func TestFrameGateRejectsStalledSecondFrame(t *testing.T) {
	var g FrameGate
	g.Begin(100, 1920, 1080)
	if got := g.Observe(101, 1920, 1080, 100, 80, 80*time.Millisecond); got != Wait {
		t.Fatalf("first observation: %v", got)
	}
	if got := g.Observe(102, 1920, 1080, 100, 80.1, 120*time.Millisecond); got == Improved {
		t.Fatalf("camera did not advance, but gate accepted: %v", got)
	}
}
