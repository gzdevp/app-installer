package aimv13

import (
	"math"
	"time"
)

type Feedback uint8

const (
	Wait Feedback = iota
	Improved
	Reversed
	Unresponsive
)

// CheckFeedback accepts only an objectively reduced screen-space error.
// It cannot prove real FiveM response without observing that game's viewport.
func CheckFeedback(before, after float64, elapsed time.Duration) Feedback {
	if math.IsNaN(before) || math.IsNaN(after) || math.IsInf(before, 0) || math.IsInf(after, 0) || before < 0 || after < 0 {
		return Reversed
	}
	if elapsed < 45*time.Millisecond {
		return Wait
	}
	if after > before+1.5 {
		return Reversed
	}
	// Require meaningful screen-space movement rather than a 0.21px jitter.
	threshold := math.Max(0.8, math.Min(2.5, before*0.025))
	if before-after > threshold {
		return Improved
	}
	if elapsed < 320*time.Millisecond {
		return Wait
	}
	return Unresponsive
}

// AxisDiverged detects a camera moving farther from a target on either axis,
// even if a large improvement on the other axis hides that regression in the
// total Euclidean distance. All four arguments are signed center offsets.
func AxisDiverged(beforeX, beforeY, afterX, afterY float64) bool {
	for _, v := range []float64{beforeX, beforeY, afterX, afterY} {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return true
		}
	}
	const tolerance = 2.0 // px: tolerate minor projection jitter
	return math.Abs(afterX) > math.Abs(beforeX)+tolerance ||
		math.Abs(afterY) > math.Abs(beforeY)+tolerance
}
