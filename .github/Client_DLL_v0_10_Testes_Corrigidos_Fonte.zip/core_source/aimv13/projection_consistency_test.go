package aimv13

import "testing"

func projTestCamera(eye Vec3) [16]float32 {
	// Forward +X, screen-right +Y and screen-up +Z.
	var m [16]float32
	m[5], m[10], m[3] = 1, 1, 1
	m[13] = -float32(eye.Y)
	m[14] = -float32(eye.Z)
	m[15] = -float32(eye.X)
	return m
}

func TestRayCenteredRejectsWrongCameraEvenWithGoodVector(t *testing.T) {
	eye := Vec3{X: 5, Y: 2, Z: 3}
	m := projTestCamera(eye)
	if !RayCentered(eye, Vec3{X: 1}, m) {
		t.Fatal("genuine camera ray rejected")
	}
	if RayCentered(Vec3{X: 5, Y: 120, Z: 3}, Vec3{X: 1}, m) {
		t.Fatal("world-offset camera accepted")
	}
	if RayCentered(eye, Vec3{X: 0, Y: 1}, m) {
		t.Fatal("orthogonal camera accepted")
	}
	if RayCentered(eye, Vec3{X: -1}, m) {
		t.Fatal("reversed camera accepted")
	}
}

func TestRayCenteredRejectsCorruptProjection(t *testing.T) {
	eye := Vec3{X: 0}
	m := projTestCamera(eye)
	m[15] = 1000
	if RayCentered(eye, Vec3{X: 1}, m) {
		t.Fatal("inconsistent projection accepted")
	}
}
