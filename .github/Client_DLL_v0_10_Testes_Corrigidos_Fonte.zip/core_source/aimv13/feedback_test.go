package aimv13

import (
	"math"
	"testing"
	"time"
)

func TestFeedbackPreventsRepeatedWrongMoves(t *testing.T) {
	cases := []struct {
		before, after float64
		elapsed       time.Duration
		expect        Feedback
	}{
		{80, 65, 60 * time.Millisecond, Improved},
		{80, 90, 60 * time.Millisecond, Reversed},
		{80, 80, 60 * time.Millisecond, Wait},
		{80, 80, 321 * time.Millisecond, Unresponsive},
		{80, 80, 20 * time.Millisecond, Wait},
		{80, math.NaN(), 60 * time.Millisecond, Reversed},
		{80, 81.6, 60 * time.Millisecond, Reversed},
		{80, 79.9, 60 * time.Millisecond, Wait},
		{80, 76, 60 * time.Millisecond, Improved},
		{80, 79, 60 * time.Millisecond, Wait},
	}
	for _, c := range cases {
		if got := CheckFeedback(c.before, c.after, c.elapsed); got != c.expect {
			t.Fatalf("%+v: got %v", c, got)
		}
	}
}
