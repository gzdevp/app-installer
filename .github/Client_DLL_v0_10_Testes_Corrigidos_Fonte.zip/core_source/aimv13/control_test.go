package aimv13

import (
	"math"
	"testing"
)

func near(a, b float64) bool { return math.Abs(a-b) < 0.0001 }
func TestHeadAnglesAllDirections(t *testing.T) {
	eye := Vec3{0, 0, 2}
	heads := []Vec3{{20, 0, 6}, {20, 0, -2}, {20, 5, 2}, {20, -5, 2}, {30, 7, 8}, {30, -7, -4}}
	for _, h := range heads {
		cam := Camera{Eye: eye, View: Vec3{1, 0, 0}, ThirdPerson: Vec3{1, 0, -0.03}}
		desired, _ := Unit(Sub(h, eye))
		before := Angle(cam.View, desired)
		out, ok := Step(cam, h, 8)
		if !ok || Angle(out.View, desired) >= before || Angle(cam.View, out.View) > 4.01*math.Pi/180 {
			t.Fatalf("failed %v: %+v %v", h, out, ok)
		}
		if !near(out.View.Z-out.ThirdPerson.Z, 0.03) {
			t.Fatalf("pitch offset not preserved: %+v", out)
		}
	}
}
func TestConverges(t *testing.T) {
	eye := Vec3{0, 0, 1}
	head := Vec3{25, 5, 4}
	cam := Camera{Eye: eye, View: Vec3{1, 0, 0}, ThirdPerson: Vec3{1, 0, -0.02}}
	desired, _ := Unit(Sub(head, eye))
	for i := 0; i < 250; i++ {
		o, ok := Step(cam, head, 7)
		if !ok {
			break
		}
		cam.View = o.View
		cam.ThirdPerson = o.ThirdPerson
	}
	if Angle(cam.View, desired) > 0.003 {
		t.Fatal("not converged", cam.View)
	}
}
func TestRejectBadValues(t *testing.T) {
	normal := Camera{Eye: Vec3{0, 0, 2}, View: Vec3{1, 0, 0}, ThirdPerson: Vec3{1, 0, 0}}
	bads := []Camera{{Eye: Vec3{math.NaN(), 0, 0}, View: normal.View, ThirdPerson: normal.ThirdPerson},
		{Eye: normal.Eye, View: Vec3{0, 0, 0}, ThirdPerson: normal.ThirdPerson},
		{Eye: normal.Eye, View: normal.View, ThirdPerson: Vec3{0, 0, 0}},
		{Eye: normal.Eye, View: Vec3{math.Inf(1), 0, 0}, ThirdPerson: normal.ThirdPerson}}
	for _, cam := range bads {
		if _, ok := Step(cam, Vec3{20, 0, 4}, 8); ok {
			t.Fatalf("accepted corrupt %+v", cam)
		}
	}
	for _, head := range []Vec3{{math.NaN(), 0, 0}, {0, 0, 2}, {1000, 0, 2}, {20, 0, 2}} {
		if _, ok := Step(normal, head, 8); ok {
			t.Fatal("accepted invalid/no-op", head)
		}
	}
}
func TestIndependentVerticalHorizontal(t *testing.T) {
	cam := Camera{Eye: Vec3{0, 0, 1}, View: Vec3{1, 0, 0}, ThirdPerson: Vec3{1, 0, -0.05}}
	up, _ := Step(cam, Vec3{20, 0, 8}, 10)
	down, _ := Step(cam, Vec3{20, 0, -4}, 10)
	left, _ := Step(cam, Vec3{20, -5, 1}, 10)
	right, _ := Step(cam, Vec3{20, 5, 1}, 10)
	if !(up.View.Z > 0 && down.View.Z < 0 && left.View.Y < 0 && right.View.Y > 0) {
		t.Fatal("wrong axis", up, down, left, right)
	}
}
