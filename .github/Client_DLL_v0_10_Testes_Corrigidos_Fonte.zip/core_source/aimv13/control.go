// Package aimv13 implements the camera-vector maths independently of the
// Windows process reader. The input semantics match the supplied C++ SDK:
// FollowPedCamera +0x40 (view), +0x60 (crosshair position), +0x3D0 (third-person).
package aimv13

import "math"

type Vec3 struct{ X, Y, Z float64 }

type Camera struct {
	Eye         Vec3
	View        Vec3
	ThirdPerson Vec3
}

type Output struct {
	View         Vec3
	ThirdPerson  Vec3
	AngularError float64
}

func finite(v Vec3) bool {
	return !(math.IsNaN(v.X) || math.IsNaN(v.Y) || math.IsNaN(v.Z) ||
		math.IsInf(v.X, 0) || math.IsInf(v.Y, 0) || math.IsInf(v.Z, 0))
}
func Add(a, b Vec3) Vec3         { return Vec3{a.X + b.X, a.Y + b.Y, a.Z + b.Z} }
func Sub(a, b Vec3) Vec3         { return Vec3{a.X - b.X, a.Y - b.Y, a.Z - b.Z} }
func Mul(a Vec3, k float64) Vec3 { return Vec3{a.X * k, a.Y * k, a.Z * k} }
func Dot(a, b Vec3) float64      { return a.X*b.X + a.Y*b.Y + a.Z*b.Z }
func Length(v Vec3) float64      { return math.Sqrt(Dot(v, v)) }
func Unit(v Vec3) (Vec3, bool) {
	if !finite(v) {
		return Vec3{}, false
	}
	n := Length(v)
	if n < 1e-6 || n > 1e10 {
		return Vec3{}, false
	}
	return Mul(v, 1/n), true
}
func ValidDirection(v Vec3) bool      { n := Length(v); return finite(v) && n > 0.75 && n < 1.25 }
func clamp(x, lo, hi float64) float64 { return math.Min(hi, math.Max(lo, x)) }
func Angle(a, b Vec3) float64 {
	x, ok := Unit(a)
	if !ok {
		return math.NaN()
	}
	y, ok := Unit(b)
	if !ok {
		return math.NaN()
	}
	return math.Acos(clamp(Dot(x, y), -1, 1))
}

// Step preserves the C++ SDK's third-person pitch offset. Returns no
// instruction when any critical input is invalid; never predicts an axis sign.
func Step(camera Camera, head Vec3, smooth float64) (Output, bool) {
	if !finite(camera.Eye) || !finite(head) || !ValidDirection(camera.View) || !ValidDirection(camera.ThirdPerson) {
		return Output{}, false
	}
	d := Sub(head, camera.Eye)
	distance := Length(d)
	if !finite(d) || distance < 1.0 || distance > 600 {
		return Output{}, false
	}
	desired, _ := Unit(d)
	current, _ := Unit(camera.View)
	degrees := Angle(current, desired) * 180 / math.Pi
	if math.IsNaN(degrees) || degrees < 0.08 || degrees > 80 {
		return Output{}, false
	}
	smooth = clamp(smooth, 1, 20)
	// Same interpolation semantics as ProcessCameraMovement in the supplied SDK;
	// one UI control drives both independent axes for this existing panel.
	delta := Sub(desired, current)
	final := Vec3{current.X + delta.X/smooth, current.Y + delta.Y/smooth, current.Z + delta.Z/smooth}
	final, ok := Unit(final)
	if !ok {
		return Output{}, false
	}
	// A bounded step prevents a corrupt / rapidly moving target from snapping.
	stepAngle := Angle(current, final)
	maxAngle := 4.0 * math.Pi / 180
	if stepAngle > maxAngle {
		blend := maxAngle / stepAngle
		final, ok = Unit(Add(current, Mul(Sub(final, current), blend)))
		if !ok {
			return Output{}, false
		}
	}
	if Angle(final, desired) >= Angle(current, desired)-1e-7 {
		return Output{}, false
	}
	// Preserve existing camera-specific pitch difference as the source SDK does.
	pitchOffset := camera.View.Z - camera.ThirdPerson.Z
	third := Vec3{final.X, final.Y, final.Z - pitchOffset}
	if !finite(third) || Length(third) < 0.5 || Length(third) > 1.5 {
		return Output{}, false
	}
	return Output{View: final, ThirdPerson: third, AngularError: degrees}, true
}
