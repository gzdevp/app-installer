package main

import (
	"bytes"
	"encoding/json"
	"os"
	"testing"
)

func TestCleanStartupNoActiveFeatures(t *testing.T) {
	dir := t.TempDir()
	if err := os.WriteFile(dir+"/config.json", []byte(`{"settings":{"streamMode":true},"visual":{"playerEsp":true},"weapon":{"noReload":true},"aim":{"enabled":true,"showFov":true}}`), 0600); err != nil {
		t.Fatal(err)
	}
	svc, err := newService(dir)
	if err != nil {
		t.Fatal(err)
	}
	var cfg map[string]any
	if err := json.Unmarshal(svc.config, &cfg); err != nil {
		t.Fatal(err)
	}
	// A nearby-list UI preference can default to true without activating an
	// ESP or changing game state. Only action-bearing toggles must be false.
	checks := map[string][]string{
		"aim":       {"enabled", "showFov", "throughWall", "trigger"},
		"silentAim": {"enabled", "showFov"},
		"visual":    {"playerEsp", "vehicleEsp", "boxes", "skeleton"},
		"weapon":    {"noReload", "noRecoil", "noSpread", "infiniteAmmo"},
		"player":    {"god", "semigod", "noclip"},
		"chams":     {"enabled"},
		"world":     {"radar"},
		"settings":  {"streamMode"},
	}
	for section, fields := range checks {
		obj, ok := cfg[section].(map[string]any)
		if !ok {
			t.Fatalf("config section %s missing", section)
		}
		for _, field := range fields {
			value, present := obj[field]
			if !present {
				continue
			} // optional toggles default false
			if enabled, isBool := value.(bool); !isBool || enabled {
				t.Errorf("%s.%s must be disabled at fresh startup (got %v)", section, field, value)
			}
		}
	}
	html, err := os.ReadFile("web/index.html")
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(html, []byte("localStorage.getItem")) {
		t.Fatal("old browser profile read at boot")
	}
	if bytes.Contains(html, []byte("Estado geral")) {
		t.Fatal("verbose Stream Mode status shown")
	}
}
