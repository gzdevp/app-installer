//go:build windows

package main

import (
	"encoding/binary"
	"fmt"
	"math"
	"sete7/external/ui/aimv13"
	"time"
	"unsafe"
)

// Named camera globals supplied in the actual source references. Do not infer
// this value from the viewport: those are distinct classes in the FiveM SDK.
var cameraDirectorOffsets = map[string]uintptr{
	"b3258": 0x201ED50, // CamGameplayDirector; 0x201E7D0 is Camera, a different global
	"b3095": 0x2002888, // supplied FivemSDK/Fivem.cpp
	"b2944": 0x1FEB968,
	"b2802": 0x1FBCFA8,
	"b2699": 0x20D9B38,
}

const (
	directorFollowPedOffset       uintptr = 0x3C0
	followViewAnglesOffset        uintptr = 0x40
	followCrosshairOffset         uintptr = 0x60
	followThirdPersonAnglesOffset uintptr = 0x3D0
	followCameraPositionOffset    uintptr = 0x3F0
)

func v13FromVec(v vec3) aimv13.Vec3 {
	return aimv13.Vec3{X: float64(v.X), Y: float64(v.Y), Z: float64(v.Z)}
}
func v13ToVec(v aimv13.Vec3) vec3 { return vec3{X: float32(v.X), Y: float32(v.Y), Z: float32(v.Z)} }

// This owns the follow-ped camera pointer, never a viewport pointer.
// All addresses and vector values are checked before write operations.
type v13Camera struct {
	follow           uintptr
	eye, view, third vec3
}

func readV13Camera(p *attachedESP, local vec3) (v13Camera, error) {
	if p == nil || p.handle == 0 || espProcessExited(p.handle) {
		return v13Camera{}, fmt.Errorf("processo não disponível")
	}
	off, ok := cameraDirectorOffsets[p.build]
	if !ok {
		return v13Camera{}, fmt.Errorf("build %s sem offset de câmera verificado", p.build)
	}
	director := p.ptr(p.base + off)
	if director < 0x10000 {
		return v13Camera{}, fmt.Errorf("ponteiro CamGameplayDirector inválido")
	}
	follow := p.ptr(director + directorFollowPedOffset)
	if follow < 0x10000 || follow == director || follow == p.ptr(p.base+espLayouts[p.build].viewport) {
		return v13Camera{}, fmt.Errorf("ponteiro FollowPedCamera inválido")
	}
	// The working C++ SDK exposes two independent 3D origins. 0x60 is its
	// crosshair anchor and 0x3F0 is the actual camera position. A zero or
	// stale crosshair anchor must not disable otherwise valid aim movement.
	crosshair, crossOK := p.vec3(follow + followCrosshairOffset)
	cameraPos, cameraOK := p.vec3(follow + followCameraPositionOffset)
	view, viewOK := p.vec3(follow + followViewAnglesOffset)
	third, thirdOK := p.vec3(follow + followThirdPersonAnglesOffset)
	if !viewOK || !thirdOK {
		return v13Camera{}, fmt.Errorf("câmera não legível na build %s (visão: %t, terceira pessoa: %t)", p.build, viewOK, thirdOK)
	}
	if !aimv13.ValidDirection(v13FromVec(view)) || !aimv13.ValidDirection(v13FromVec(third)) {
		return v13Camera{}, fmt.Errorf("vetores da câmera inválidos na build %s (visão: %.2f; terceira pessoa: %.2f)", p.build, aimv13.Length(v13FromVec(view)), aimv13.Length(v13FromVec(third)))
	}
	if !plausibleFiveMPosition(local) {
		return v13Camera{}, fmt.Errorf("jogador local indisponível")
	}
	// CrosshairPosition is the point used by ProcessCameraMovement in the
	// reference SDK. Prefer it when it is coherent with the local ped, then
	// use the independent camera origin. Never use an arbitrary zero vector.
	validEye := func(v vec3, readOK bool) bool {
		return readOK && plausibleFiveMPosition(v) && poseDist(v, local) <= 25
	}
	var eye vec3
	switch {
	case validEye(crosshair, crossOK):
		eye = crosshair
	case validEye(cameraPos, cameraOK):
		eye = cameraPos
	default:
		return v13Camera{}, fmt.Errorf("origem da câmera indisponível")
	}
	return v13Camera{follow: follow, eye: eye, view: view, third: third}, nil
}
func writeV13Vec(a *noclipAttachment, addr uintptr, v aimv13.Vec3) bool {
	if a == nil || a.writer == 0 || addr < 0x10000 || math.IsNaN(v.X) || math.IsNaN(v.Y) || math.IsNaN(v.Z) || math.IsInf(v.X, 0) || math.IsInf(v.Y, 0) || math.IsInf(v.Z, 0) {
		return false
	}
	var b [12]byte
	binary.LittleEndian.PutUint32(b[:4], math.Float32bits(float32(v.X)))
	binary.LittleEndian.PutUint32(b[4:8], math.Float32bits(float32(v.Y)))
	binary.LittleEndian.PutUint32(b[8:], math.Float32bits(float32(v.Z)))
	var written uintptr
	ok, _, _ := noclipWriteProcessMemory.Call(a.writer, addr, uintptr(unsafe.Pointer(&b[0])), 12, uintptr(unsafe.Pointer(&written)))
	return ok != 0 && written == 12
}
func v13Approx(a, b vec3) bool {
	return math.Abs(float64(a.X-b.X))+math.Abs(float64(a.Y-b.Y))+math.Abs(float64(a.Z-b.Z)) < 0.025
}
func writeV13Camera(a *noclipAttachment, c v13Camera, o aimv13.Output) bool {
	if a == nil || a.read == nil || a.writer == 0 {
		return false
	}
	// The supplied C++ implementation writes third-person first, primary second.
	// Best-effort rollback if a write/readback fails (memory writes aren't atomic).
	if !writeV13Vec(a, c.follow+followThirdPersonAnglesOffset, o.ThirdPerson) {
		return false
	}
	if !writeV13Vec(a, c.follow+followViewAnglesOffset, o.View) {
		_ = writeV13Vec(a, c.follow+followThirdPersonAnglesOffset, v13FromVec(c.third))
		return false
	}
	newView, ok1 := a.read.vec3(c.follow + followViewAnglesOffset)
	newThird, ok2 := a.read.vec3(c.follow + followThirdPersonAnglesOffset)
	if !ok1 || !ok2 || !v13Approx(newView, v13ToVec(o.View)) || !v13Approx(newThird, v13ToVec(o.ThirdPerson)) {
		_ = writeV13Vec(a, c.follow+followThirdPersonAnglesOffset, v13FromVec(c.third))
		_ = writeV13Vec(a, c.follow+followViewAnglesOffset, v13FromVec(c.view))
		return false
	}
	return true
}

// The first motion cannot be considered successful from memory readback alone.
// Require proof that the actual viewport projection moved toward the SAME
// 3D point. No additional writes while this verification is pending.
type v13ResponseGuard struct {
	pending  bool
	failed   bool
	targetID uint64
	before   matrix44
	head     vec3
	since    time.Time
	frames   aimv13.FrameGate
}

func (g *v13ResponseGuard) reset() { *g = v13ResponseGuard{} }
func (g *v13ResponseGuard) mark(view espViewport, seq uint64, id uint64, head vec3) {
	g.pending = true
	g.targetID = id
	g.before = view.Camera
	g.head = head
	g.since = time.Now()
	g.frames.Begin(seq, view.W, view.H)
}
func (g *v13ResponseGuard) observe(view espViewport, seq uint64, id uint64) (bool, string) {
	if g.failed {
		return false, "Resposta incorreta da câmera — solte a tecla para reiniciar"
	}
	if !g.pending {
		return true, ""
	}
	if g.targetID != id {
		g.failed = true
		g.pending = false
		return false, "Alvo mudou durante movimento — solte a tecla"
	}
	if time.Since(g.since) < 45*time.Millisecond {
		return false, "Aguardando resposta da câmera"
	}
	x1, y1, ok1 := worldToScreen(g.before, g.head, view.W, view.H)
	x2, y2, ok2 := worldToScreen(view.Camera, g.head, view.W, view.H)
	if !ok1 || !ok2 {
		g.failed = true
		g.pending = false
		return false, "Projeção inválida após movimento"
	}
	// Never accept "overall closer" when the camera is actually drifting
	// DOWN while improving horizontal alignment (or vice-versa).
	if aimv13.AxisDiverged(x1-float64(view.W)/2, y1-float64(view.H)/2, x2-float64(view.W)/2, y2-float64(view.H)/2) {
		g.failed = true
		g.pending = false
		return false, "Um eixo da câmera se afastou do alvo — bloqueado"
	}
	e1 := math.Hypot(x1-float64(view.W)/2, y1-float64(view.H)/2)
	e2 := math.Hypot(x2-float64(view.W)/2, y2-float64(view.H)/2)
	switch g.frames.Observe(seq, view.W, view.H, e1, e2, time.Since(g.since)) {
	case aimv13.Improved:
		g.pending = false
		return true, ""
	case aimv13.Reversed:
		g.failed = true
		g.pending = false
		return false, fmt.Sprintf("Câmera se afastou da cabeça (%.1f→%.1f px) — bloqueada", e1, e2)
	case aimv13.Unresponsive:
		g.failed = true
		g.pending = false
		return false, "Câmera sem resposta em 320ms — bloqueada"
	default:
		return false, "Aguardando duas projeções novas e coerentes"
	}

}
