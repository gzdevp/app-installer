# 77 v13.9.51 — Cleaner local e sessão privada
- Cleaner: remove o arquivo EXE da localização exata em que foi iniciado, usando o caminho retornado por os.Executable(). Remove a pasta pai SOMENTE caso esteja vazia e se chame exatamente 77, 77 Black Edition, sete7 ou sete7 Black Edition; não faz remoção recursiva. Pastas comuns como Downloads/Desktop/Documents e arquivos de terceiros permanecem intocados.
- Browser: dá preferência ao Chrome com --incognito; para Chrome e Edge mantém --user-data-dir numa pasta temporária isolada apagada no encerramento. Não combina --inprivate e --app no Edge porque há incompatibilidade documentada que impede abrir a interface em algumas versões.
- Não elimina histórico do SO, logs de segurança, registros do FiveM ou vestígios de execução fora dos arquivos temporários do próprio aplicativo.
- Não foram alteradas rotinas de jogo, desenho, binds, Insert ou respostas de Unload/Cleaner (um clique).
