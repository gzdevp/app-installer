# sete7 v13.9.12 — Inter + Segmented Navigation

Alterações de apresentação apenas, sobre a v13.9.11:
- Fonte **Inter** solicitada pela URL CSS oficial do Google Fonts, com fallback `SF Pro Text`, `SF Pro Display` e Segoe UI. A fonte não é incluída no pacote e precisa de conexão para carregar se não estiver instalada localmente.
- Navegação interna padronizada com seletor de abas arredondado, células do mesmo tamanho, seleção elevada/sombreada, e estilos compatíveis com tema claro/escuro (conforme referência do usuário).
- `Settings → Interface | Appearance | Configs`; Configs é só o novo título de Profiles; nenhum mecanismo de salvar/carregar perfis foi removido.
- Botões internos de tema e densidade usam o mesmo visual segmentado.
- Perfil de navegador separado `sete7-v13.9.12-data` e identificação de título atualizada para evitar conflito de janela antiga.

Arquivos alterados em relação à v13.9.11: `web/index.html`, `main.go`, `window_title.go`. A lógica nativa de jogo foi preservada byte a byte.

Limites: a interface foi verificada no Chromium Linux; execução nativa e carregamento da fonte Inter no Windows/FiveM ainda precisam ser confirmados pelo usuário. Nenhum arquivo de fonte é distribuído.
