//go:build windows

package main

import (
	"syscall"
	"unsafe"
)

const th32csSnapProcess = 0x00000002

var (
	kernel32Process   = syscall.NewLazyDLL("kernel32.dll")
	createSnapshot    = kernel32Process.NewProc("CreateToolhelp32Snapshot")
	processFirst      = kernel32Process.NewProc("Process32FirstW")
	processNext       = kernel32Process.NewProc("Process32NextW")
	closeKernelHandle = kernel32Process.NewProc("CloseHandle")
)

// Windows PROCESSENTRY32W, including pointer alignment on x64.
// Native Toolhelp32 enumeration avoids starting any console subprocess.
type processEntry32 struct {
	Size            uint32
	Usage           uint32
	ProcessID       uint32
	DefaultHeapID   uintptr
	ModuleID        uint32
	Threads         uint32
	ParentProcessID uint32
	BasePriority    int32
	Flags           uint32
	ExeFile         [260]uint16
}

func detectFiveMProcess() bool {
	snapshot, _, _ := createSnapshot.Call(th32csSnapProcess, 0)
	if snapshot == ^uintptr(0) {
		return false
	}
	defer closeKernelHandle.Call(snapshot)

	entry := processEntry32{Size: uint32(unsafe.Sizeof(processEntry32{}))}
	ok, _, _ := processFirst.Call(snapshot, uintptr(unsafe.Pointer(&entry)))
	for ok != 0 {
		if isFiveMProcess(syscall.UTF16ToString(entry.ExeFile[:])) {
			return true
		}
		ok, _, _ = processNext.Call(snapshot, uintptr(unsafe.Pointer(&entry)))
	}
	return false
}
