# 77 v13.9.59 — Login 77 com JACK original

- Login redesenhado com **o mesmo `web/logo.png` PNG RGBA com transparência** já usado no painel. Removida a caixa de fundo do mascote.
- Marca da tela de acesso agora é somente **77**, sem "Black Edition".
- Vermelho (#E11D38) como cor padrão de destaque da autenticação e do painel; o seletor de cores existente permanece.
- Nome da janela do navegador interno `77 | v13.9.59`; reconhecedor e testes atualizados para não quebrar a tecla Insert.
- Mantidos o mesmo sistema local de login, credenciais anteriores, Cleaner e demais recursos de v13.9.58.

**Limite:** compatibilidade de abertura e comportamento em FiveM/Windows exigem teste no próprio Windows.
