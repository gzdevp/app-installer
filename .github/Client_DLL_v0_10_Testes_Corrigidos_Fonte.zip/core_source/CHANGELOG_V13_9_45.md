# 77 v13.9.45
- Mira movida da aba AIM para Settings > Appearance.
- Ponto central agora é um círculo preenchido (`Ellipse` do GDI), também na prévia SVG.
- Default 5 px, branco, mantendo contorno e alongamento configuráveis.
- Vehicles: leitura de ModelInfo/modelHash ampliada às builds suportadas. Para hashes não cadastrados, mostra hexadecimal sem inventar nome.
- Veículo atual: seleção e botões Fix/Trancar/Destrancar. Fix continua limitado ao veículo local e offsets que passam na verificação.
- Trancar/destrancar: endpoints conectados, porém bloqueados (sem rotina nativa segura no processo externo); nenhuma alteração de jogo é reivindicada.
