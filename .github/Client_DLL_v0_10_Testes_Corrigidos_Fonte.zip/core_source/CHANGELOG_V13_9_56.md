# 77 Black Edition v13.9.56 — Funções integradas (experimental)

## Incluído no EXE e ligado a controles reais
- **ESP de arma equipada:** lê a cadeia de arma de jogadores no mesmo perfil do mecanismo de penetração já presente. Exibe apenas hashes de armas de GTA V mapeados; customizadas/desconhecidas não são adivinhadas. Leitura experimental, sujeita ao build e integridade de ponteiros.
- **Setas fora da tela:** usa projeção da câmera para desenhar setas de jogadores fora da área visível, mas na frente da câmera; alvos atrás da câmera não recebem setas sem orientação verificável. Somente com Player ESP ativo. Essas entidades nunca viram alvos de mira.
- **Amigos:** preservados os filtros já existentes no Aimbot, Silent Aim e Triggerbot; nomes duplicados não recebem flag de amigo.
- **Filtro de caídos:** opção única em Visuals > Players, aplicada aos três sistemas de mira. O filtro é heurístico (HP lido <= 100), não prova o estado de morte do servidor; não é ativado automaticamente.
- **Localizador:** Visuals > Locator pesquisa por nick na lista atual de alvos do ESP e destaca uma correspondência única no rótulo. Nomes duplicados não são destacados. O alvo deixa de aparecer quando sai do alcance.
- **Auto Health / Auto Armor:** Player > Health, acionados somente se habilitados; leem valores do próprio ped; reabastecimento b3258 conforme limites definidos, com intervalo mínimo de 10s, sem prometer estado autoritativo no servidor. Não atuam enquanto o menu está aberto ou fora do jogo.
- **Favoritos de teleporte:** Player > Movement permite salvar a posição local por nome, listar até 12 favoritos e solicitar TP por coordenadas com as mesmas checagens do TP Waypoint (b3258, fora do veículo, Noclip desligado, navegação confirmada, readback local). Favoritos duram apenas a sessão; Cleaner continua apagando a sessão.
- **Vehicle ESP:** painel de seleção agora apresenta velocidade, saúde do motor e ocupantes quando o leitor existente os forneceu. Não inventa placa nem motorista onde não há leitura validada.

## Ainda não implementado
- Placa do veículo e nickname do motorista: não existe no código uma cadeia de leitura validada e específica por build/assento para essas informações. Não se apresenta uma identificação falsa.
- Setas para entidades atrás da câmera: orientação da câmera ainda não validada.

## Preservado
- Lógica do Silent Aim previamente testada; apenas um gate de caídos opcional na seleção.
- Cleaner v13.9.55 e o Unload separados.
- Todas as opções novas começam desligadas. Configurações e favoritos permanecem somente nesta sessão.
- Sem alteração no Prefetch, nos logs do Windows e nos registros de segurança.

## Validação
- O Go compila para Windows amd64 (GUI), e o JavaScript da interface passa em `node --check`.
- O executável não foi executado nem testado dentro de FiveM neste ambiente. Compatibilidade e desempenho de cada novo recurso precisam de teste em jogo; nenhuma operação é garantida pelo servidor.
