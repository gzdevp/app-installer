package main

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

// File-level GTA V materials.dat editing. It modifies exactly the ShootThru
// material column, not weapon penetration, camera, raycasts, or damage events.
// It is intentionally an opt-in OFFLINE editor: GTA loads this data at startup.
// Never silently edit user game files or infer field positions by guesswork.
var splitWord = regexp.MustCompile(`\S+`)
var shootColumn = regexp.MustCompile(`(?i)^shoot[_ -]?thru$|^shoot[_ -]?through$`)
var materialName = regexp.MustCompile(`^[A-Z][A-Z0-9_]{2,}$`)

func scanHeader(lines [][]byte) (col int, foundLine int, err error) {
	// Require an unambiguous, comment/heading-led column map.
	col, foundLine = -1, -1
	for i, line := range lines {
		txt := strings.TrimSpace(string(line))
		if txt == "" {
			continue
		}
		lead := txt[0]
		if lead != '#' && lead != ';' && lead != '/' && lead != '*' {
			continue
		}
		for _, candidate := range []string{strings.TrimSpace(strings.TrimLeft(txt, "#;/* "))} {
			cells := splitWord.FindAllString(candidate, -1)
			for j, v := range cells {
				if !shootColumn.MatchString(v) {
					continue
				}
				if foundLine >= 0 && col != j {
					return -1, -1, fmt.Errorf("column ShootThru ambiguous on lines %d and %d", foundLine+1, i+1)
				}
				col, foundLine = j, i
			}
		}
	}
	if col < 0 {
		return -1, -1, errors.New("header ShootThru not found; file was not changed")
	}
	return col, foundLine, nil
}

// Change ShootThru 0 -> 1 only. No edits to FX or other material properties.
func patchShootThru(input []byte) ([]byte, int, error) {
	if bytes.IndexByte(input, 0) != -1 {
		return nil, 0, errors.New("binary input refused: expected text materials.dat")
	}
	endings := []byte("\n")
	if bytes.Contains(input, []byte("\r\n")) {
		endings = []byte("\r\n")
	}
	normalized := bytes.ReplaceAll(input, []byte("\r\n"), []byte("\n"))
	rows := bytes.Split(normalized, []byte("\n"))
	col, header, err := scanHeader(rows)
	if err != nil {
		return nil, 0, err
	}
	count := 0
	for i := header + 1; i < len(rows); i++ {
		row := rows[i]
		words := splitWord.FindAllIndex(row, -1)
		if len(words) == 0 {
			continue
		}
		first := string(row[words[0][0]:words[0][1]])
		if !materialName.MatchString(first) {
			continue
		}
		if col >= len(words) {
			continue
		}
		cell := row[words[col][0]:words[col][1]]
		if bytes.Equal(cell, []byte("1")) {
			continue
		}
		if !bytes.Equal(cell, []byte("0")) {
			return nil, 0, fmt.Errorf("refusing unexpected ShootThru value %q on row %d", cell, i+1)
		}
		copied := append([]byte(nil), row...)
		copied[words[col][0]] = '1'
		rows[i] = copied
		count++
	}
	if count == 0 {
		return nil, 0, errors.New("no ShootThru flags with value 0 found; file was not changed")
	}
	out := bytes.Join(rows, []byte("\n"))
	if len(endings) == 2 {
		out = bytes.ReplaceAll(out, []byte("\n"), []byte("\r\n"))
	}
	return out, count, nil
}

func checksum(p []byte) string { x := sha256.Sum256(p); return hex.EncodeToString(x[:]) }

func mainProcess(src, dst string) (string, error) {
	a, err := os.ReadFile(src)
	if err != nil {
		return "", err
	}
	b, n, err := patchShootThru(a)
	if err != nil {
		return "", err
	}
	if src == dst {
		return "", errors.New("refusing in-place output; use separate destination and manual installation")
	}
	if _, err = os.Stat(dst); err == nil {
		return "", errors.New("destination already exists; refusing overwrite")
	}
	if err = os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		return "", err
	}
	f, err := os.OpenFile(dst, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if err != nil {
		return "", err
	}
	defer f.Close()
	w := bufio.NewWriter(f)
	if _, err = w.Write(b); err != nil {
		return "", err
	}
	if err = w.Flush(); err != nil {
		return "", err
	}
	return fmt.Sprintf("Edited %d material ShootThru flags. Original SHA256 %s. Output SHA256 %s", n, checksum(a), checksum(b)), nil
}
