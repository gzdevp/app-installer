# sete7 v14 — revisão técnica de 29/10/2026

Base: v14 revisada, preservando a correção de callbacks e as funções experimentais anteriores.

## Alterações verificáveis

1. **Vehicles / pool cheio:** removido o teto de 512 veículos ativos na validação do pool (capacidade total validada até 2048). A rotina de varredura deixa de interromper a coleta ao encontrar 512 veículos. Continua aplicando alcance configurado e ordenando por distância.
2. **Catálogo de carros GTA V:** botão `World > Vehicles > Carregar nomes oficiais` obtém um catálogo público de veículos apenas ao ser clicado. Os nomes de exibição e fabricantes oficiais são associados aos hashes correspondentes. Aliases manuais já existentes têm prioridade. Falhas na internet ou formato rejeitam o catálogo sem modificar as configurações.
3. **Quantidade de aliases:** normalização passa a aceitar até 2048 hashes para acomodar o catálogo oficial e nomes manuais de modelos da cidade. Apenas dados válidos são aceitos.
4. Código compilado para Windows/amd64; análise estática Go (`go vet`) aprovada; testes isolados da API de catálogo, da ordenação e da validação de pool aprovados. A versão não foi executada em servidor FiveM.

## Limitações mantidas (não marcar como consertadas)

- Os nomes reais Steam/FiveM de todos os players **não** podem ser extraídos universalmente por leitura de `CPlayerInfo`. `GetPlayerName` requer uma integração autorizada com o runtime do FiveM.
- O catálogo cobre modelos conhecidos GTA V, **não** modelos adicionados por cada servidor. Modelos exclusivos requerem metadados e podem ser definidos como alias.
- `FIX CAR` e `Lock/Unlock` continuam limitados aos métodos locais experimentais e comandos autorizados pelas cidades; o servidor pode rejeitar as alterações. Não foi implementado reparo universal da deformação visual, nem desbloqueio de qualquer carro.
- Through Wall permanece apenas uma alteração experimental do parâmetro de penetração da arma e **não** cria passagem real de projéteis pelos obstáculos.

## Fonte do catálogo (obtida ao clicar)

https://fam-tools.com/data/vehicles.json — fonte de 921 veículos GTA V em outubro de 2026. Dados de terceiros, sujeitos a disponibilidade e alterações. Esta versão não baixa dados em segundo plano.

## Instalação

1. Extraia e execute somente `77.exe` (Windows). 
2. Em `World > Vehicles`, ative a lista, ajuste o raio, clique `Carregar nomes oficiais` se desejar os nomes completos das marcas/modelos GTA V.
3. Se um carro da cidade for personalizado, selecione-o na lista e use `Nome personalizado` para definir um alias para aquele hash.

Nenhum outro arquivo precisa ficar ao lado do executável. Os dados do painel permanecem no diretório temporário de sessão, com o comportamento anterior do projeto.
