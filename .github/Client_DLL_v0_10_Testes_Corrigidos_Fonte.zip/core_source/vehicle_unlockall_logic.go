package main

import "math"

// The candidate offset has NOT been verified against a live b3258 game.
// Only the documented small integer lock-state domain is accepted.
func plausibleLocalDoorLockState(v byte) bool { return v <= 10 }
func needsLocalUnlock(v byte) bool            { return v >= 2 && v <= 10 }
func validUnlockTargetDistance(v float64) bool {
	return !math.IsNaN(v) && !math.IsInf(v, 0) && v >= 0 && v <= 5.5
}

// A vehicle entry attempt is a key-down edge, not proximity alone. Losing
// focus or disabling the feature must not turn a held key into a new press.
type entryPressDetector struct{ wasDown bool }

func (d *entryPressDetector) update(enabled, focused, down bool) bool {
	pressed := enabled && focused && down && !d.wasDown
	d.wasDown = down
	return pressed
}
