//go:build windows

package main

import "testing"

func TestNPCScanOptInOnly(t *testing.T) {
	reader := baseReader()
	delete(reader.pointers, 0x5000+0x10A8) // no PlayerInfo => NPC
	for _, includeNPC := range []bool{false, true} {
		d := ESPDiagnostics{}
		out := scanPedsWithOffsets(reader, 0x1000, 2, 0xDEAD, vec3{Z: 20}, 500, &d, 0x10A8, 0x150C, includeNPC)
		if !includeNPC && (len(out) != 0 || d.NPCs != 0) {
			t.Fatalf("NPC accepted without opt-in: %+v %+v", out, d)
		}
		if includeNPC && (len(out) != 1 || !out[0].isNPC || out[0].ptr != 0x5000 || d.NPCs != 1 || d.Players != 0) {
			t.Fatalf("NPC not found with opt-in: %+v %+v", out, d)
		}
	}
}

func TestNPCScanKeepsPlayersAndSkipsLocal(t *testing.T) {
	reader := baseReader()
	delete(reader.pointers, 0x6000+0x10A8)
	reader.positions[0x6000+0x90] = vec3{X: 160, Y: 0, Z: 20}
	d := ESPDiagnostics{}
	out := scanPedsWithOffsets(reader, 0x1000, 2, 0xDEAD, vec3{Z: 20}, 500, &d, 0x10A8, 0x150C, true)
	if len(out) != 2 || out[0].isNPC || !out[1].isNPC || d.Players != 1 || d.NPCs != 1 {
		t.Fatalf("mixed scan unexpected: %+v %+v", out, d)
	}
	d = ESPDiagnostics{}
	out = scanPedsWithOffsets(reader, 0x1000, 2, 0x6000, vec3{Z: 20}, 500, &d, 0x10A8, 0x150C, true)
	if len(out) != 1 || out[0].ptr != 0x5000 {
		t.Fatalf("local character incorrectly added: %+v", out)
	}
}

func TestNPCAimRequiresToggleAndVerifiedHead(t *testing.T) {
	target := targetESP{PedID: 0x5000, IsNPC: true, X: 940, Y: 480, W: 60, H: 180, Distance: 20,
		AimX: 960, AimY: 500, AimFromBone: true, HeadVerified: true,
		World: vec3{X: 100, Y: 100, Z: 32}, HeadWorld: vec3{X: 100, Y: 100, Z: 33}}
	s := AimSettings{Bone: "head", FOV: 250, Range: 100}
	if _, ok := selectAimTarget([]targetESP{target}, 1920, 1080, s, 0); ok {
		t.Fatal("NPC selected with toggle disabled")
	}
	s.TargetNPC = true
	if chosen, ok := selectAimTarget([]targetESP{target}, 1920, 1080, s, 0); !ok || chosen.ID != target.PedID {
		t.Fatalf("verified NPC target not selected: %+v %v", chosen, ok)
	}
	target.HeadVerified = false
	if _, ok := selectAimTarget([]targetESP{target}, 1920, 1080, s, 0); ok {
		t.Fatal("unverified NPC head incorrectly selected")
	}
}

func TestSilentNPCIgnoreSetting(t *testing.T) {
	target := targetESP{PedID: 0x5000, IsNPC: true, AimFromBone: true, HeadVerified: true,
		AimX: 960, AimY: 540, Distance: 15, World: vec3{X: 10, Y: 20, Z: 20}, HeadWorld: vec3{X: 10, Y: 20, Z: 21}}
	view := espViewport{W: 1920, H: 1080}
	s := SilentSettings{Range: 100, FOV: 200, IgnoreNPC: true}
	if _, _, ok := selectSilentHead([]targetESP{target}, view, s); ok {
		t.Fatal("Silent ignored IgnoreNPC setting")
	}
	s.IgnoreNPC = false
	if _, id, ok := selectSilentHead([]targetESP{target}, view, s); !ok || id != target.PedID {
		t.Fatalf("Silent did not allow requested NPC target: %x %v", id, ok)
	}
}

func TestNPCSelectWithRealProjectedCameraFrame(t *testing.T) {
	cam := matrix44{}
	cam[5] = 1
	cam[10] = 1
	cam[14] = -1.3
	cam[3] = 1
	view := espViewport{W: 1920, H: 1080, Camera: cam, CameraValid: true}
	ped := targetESP{PedID: 77, IsNPC: true, X: 925, Y: 475, W: 70, H: 180,
		Distance: 20, World: vec3{X: 10, Y: 0, Z: 1}, HeadWorld: vec3{X: 10, Y: 0, Z: 2},
		AimX: 960, AimY: 500, AimFromBone: true, HeadVerified: true}
	s := AimSettings{Bone: "head", FOV: 500, Range: 150, TargetNPC: true}
	if got, ok, _ := selectAimTargetInFrame([]targetESP{ped}, view, s, 0); !ok || got.ID != ped.PedID {
		t.Fatalf("verified NPC rejected in real projected selection: %+v %v", got, ok)
	}
	s.TargetNPC = false
	if _, ok, _ := selectAimTargetInFrame([]targetESP{ped}, view, s, 0); ok {
		t.Fatal("NPC accepted by camera path with toggle disabled")
	}
}
