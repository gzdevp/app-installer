//go:build windows

package main

import (
	"strings"
	"testing"
)

func TestPrivateBrowserArgs(t *testing.T) {
	chrome := strings.Join(privateAppArguments(`C:\Chrome\chrome.exe`, `C:\temp\77profile`, "http://127.0.0.1:7777/"), " ")
	if !strings.Contains(chrome, "--incognito") || !strings.Contains(chrome, "--user-data-dir=") || !strings.Contains(chrome, "--app=http://127.0.0.1:7777/") {
		t.Fatalf("Chrome flags: %s", chrome)
	}
	edge := strings.Join(privateAppArguments(`C:\Edge\msedge.exe`, `C:\temp\77profile`, "http://127.0.0.1:7777/"), " ")
	if strings.Contains(edge, "--inprivate") || strings.Contains(edge, "--incognito") {
		t.Fatalf("unsafe InPrivate+app Edge flags: %s", edge)
	}
	fallback := strings.Join(browserAppArguments(`C:\Chrome\chrome.exe`, `C:\temp\77profile`, "http://127.0.0.1:7777/", false), " ")
	if strings.Contains(fallback, "--incognito") || !strings.Contains(fallback, "--user-data-dir=") {
		t.Fatalf("bad fallback: %s", fallback)
	}
	if !strings.Contains(edge, "--user-data-dir=") {
		t.Fatal("isolated profile missing")
	}
}
func TestCleanerDedicatedFolderAllowlist(t *testing.T) {
	for _, name := range []string{"77", "sete7", "77 Black Edition"} {
		if !isDedicatedAppFolder(name) {
			t.Fatalf("must allow app folder: %s", name)
		}
	}
	for _, name := range []string{"Downloads", "Documents", "Desktop", "Temp", "System32", "Other", "77_backup"} {
		if isDedicatedAppFolder(name) {
			t.Fatalf("must never remove arbitrary folder: %s", name)
		}
	}
}

func TestCleanerUsesExplicitFileAbsenceCheck(t *testing.T) {
	cmd := selfDeleteHelperCommand()
	if !strings.Contains(cmd, `if not exist "%SETE7_DELETE_ME%"`) {
		t.Fatalf("helper must verify file absence: %s", cmd)
	}
	for _, forbidden := range []string{"Prefetch", "wevtutil", "reg delete", "taskkill /IM"} {
		if strings.Contains(strings.ToLower(cmd), strings.ToLower(forbidden)) {
			t.Fatalf("must not clear Windows diagnostics: %s", forbidden)
		}
	}
}
