package main

import "testing"

func TestEffectiveTargetRange(t *testing.T) {
	cases := []struct {
		name   string
		visual int
		ae     bool
		aim    int
		se     bool
		silent int
		want   int
	}{
		{"aim exceeds visual", 40, true, 250, false, 0, 250},
		{"silent exceeds aim", 50, true, 125, true, 500, 500},
		{"visual only", 190, false, 500, false, 0, 190},
		{"unlimited aim", 50, true, 0, false, 0, 500},
		{"all disabled", 0, false, 0, false, 0, 0},
		{"clamped", 600, true, 300, true, 600, 500},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got := effectiveTargetRange(tc.visual, tc.ae, tc.aim, tc.se, tc.silent)
			if got != tc.want {
				t.Fatalf("got %d want %d", got, tc.want)
			}
		})
	}
}
