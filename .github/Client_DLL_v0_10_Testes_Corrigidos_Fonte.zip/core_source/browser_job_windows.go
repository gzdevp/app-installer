//go:build windows

package main

import (
	"os"
	"syscall"
	"unsafe"
)

// A Windows Job Object can keep Chromium's children attached to their exact
// launcher. Closing it on shutdown terminates only our private browser tree,
// not unrelated personal browser instances. If Windows refuses the assignment,
// the existing root-process shutdown path remains available.
type jobBasicLimit struct {
	PerProcessUserTimeLimit int64
	PerJobUserTimeLimit     int64
	LimitFlags              uint32
	MinimumWorkingSetSize   uintptr
	MaximumWorkingSetSize   uintptr
	ActiveProcessLimit      uint32
	Affinity                uintptr
	PriorityClass           uint32
	SchedulingClass         uint32
}

type jobIOCounters struct {
	ReadOperationCount  uint64
	WriteOperationCount uint64
	OtherOperationCount uint64
	ReadTransferCount   uint64
	WriteTransferCount  uint64
	OtherTransferCount  uint64
}

type jobExtendedLimit struct {
	Basic                 jobBasicLimit
	IO                    jobIOCounters
	ProcessMemoryLimit    uintptr
	JobMemoryLimit        uintptr
	PeakProcessMemoryUsed uintptr
	PeakJobMemoryUsed     uintptr
}

var (
	jobKernel = syscall.NewLazyDLL("kernel32.dll")
	jobCreate = jobKernel.NewProc("CreateJobObjectW")
	jobSet    = jobKernel.NewProc("SetInformationJobObject")
	jobAssign = jobKernel.NewProc("AssignProcessToJobObject")
)

func attachOwnedBrowserJob(p *os.Process) syscall.Handle {
	if p == nil {
		return 0
	}
	job, _, _ := jobCreate.Call(0, 0)
	if job == 0 {
		return 0
	}
	handle := syscall.Handle(job)
	closeOnFailure := func() syscall.Handle { _ = syscall.CloseHandle(handle); return 0 }
	var info jobExtendedLimit
	info.Basic.LimitFlags = 0x2000 // JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
	ok, _, _ := jobSet.Call(job, 9, uintptr(unsafe.Pointer(&info)), unsafe.Sizeof(info))
	if ok == 0 {
		return closeOnFailure()
	}
	target, err := syscall.OpenProcess(0x100|0x1, false, uint32(p.Pid)) // SET_QUOTA|TERMINATE
	if err != nil {
		return closeOnFailure()
	}
	defer syscall.CloseHandle(target)
	ok, _, _ = jobAssign.Call(job, uintptr(target))
	if ok == 0 {
		return closeOnFailure()
	}
	return handle
}

func closeOwnedBrowserJob(h syscall.Handle) {
	if h != 0 {
		_ = syscall.CloseHandle(h)
	}
}
