package main

import (
	"math"
	"sete7/external/ui/aimv13"
	"testing"
)

func TestExternalRayIsStraightAndKeepsCameraDirection(t *testing.T) {
	a, err := computeExternalAimRay(aimv13.Vec3{X: 10, Y: 20, Z: 3}, aimv13.Vec3{X: 0.6, Y: 0.8, Z: 0}, 250)
	if err != nil {
		t.Fatal(err)
	}
	if math.Abs(a.End.X-160) > 1e-7 || math.Abs(a.End.Y-220) > 1e-7 || math.Abs(a.End.Z-3) > 1e-7 {
		t.Fatalf("wrong camera ray end: %+v", a.End)
	}
	for _, dist := range []float64{0, 10, 180, 250} {
		point, ok := a.pointAt(dist)
		if !ok {
			t.Fatal("missing valid line point")
		}
		expected := aimv13.Add(a.Origin, aimv13.Mul(a.Direction, dist))
		if point != expected {
			t.Fatalf("point not on original line: %+v != %+v", point, expected)
		}
	}
}

func TestExternalRayRejectsFabricatedCollisionOrUnreliableInput(t *testing.T) {
	eye := aimv13.Vec3{X: 3, Y: 4, Z: 2}
	for _, dir := range []aimv13.Vec3{{}, {X: math.NaN()}, {X: 100, Y: 0, Z: 0}} {
		if _, e := computeExternalAimRay(eye, dir, 250); e == nil {
			t.Fatalf("bad direction accepted: %+v", dir)
		}
	}
	for _, meters := range []float64{0, -1, 999, math.NaN(), math.Inf(1)} {
		if _, e := computeExternalAimRay(eye, aimv13.Vec3{X: 0, Y: 1, Z: 0}, meters); e == nil {
			t.Fatalf("bad range accepted: %v", meters)
		}
	}
	ray, err := computeExternalAimRay(eye, aimv13.Vec3{X: 0, Y: 1, Z: 0}, 250)
	if err != nil {
		t.Fatal(err)
	}
	for _, distance := range []float64{-1, 251, math.NaN(), math.Inf(1)} {
		if _, ok := ray.pointAt(distance); ok {
			t.Fatalf("bad obstruction distance accepted: %v", distance)
		}
	}
}
