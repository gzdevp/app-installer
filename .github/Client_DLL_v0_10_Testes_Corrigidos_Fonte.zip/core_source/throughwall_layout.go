package main

// This module intentionally holds pointer-chain validation only. All changes
// to game memory remain in throughwall_windows.go and are opt-in.
const (
	weaponManagerPedOffset  uintptr = 0x10B8 // b3258 CPed::WeaponManager
	currentWeaponInfoOffset uintptr = 0x20   // CWeaponManager::WeaponInfo
	weaponPenetrationOffset uintptr = 0x110  // CWeaponInfo::Penetration
)

// weaponChain is the complete resolved chain for the LOCAL ped. Checking the
// entire chain both before and after writing reduces the risk of a stale field
// after ped respawn, weapon swaps or memory layout changes.
type weaponChain struct {
	ped, manager, info, field uintptr
}

func validGamePointer(p uintptr) bool {
	return p >= 0x10000 && p <= 0x7FFFFFFFFFFF-0x200
}

func resolveWeaponChain(world uintptr, ptr func(uintptr) uintptr) (weaponChain, bool) {
	var c weaponChain
	if !validGamePointer(world) {
		return c, false
	}
	c.ped = ptr(world + 0x8)
	if !validGamePointer(c.ped) {
		return weaponChain{}, false
	}
	c.manager = ptr(c.ped + weaponManagerPedOffset)
	if !validGamePointer(c.manager) {
		return weaponChain{}, false
	}
	c.info = ptr(c.manager + currentWeaponInfoOffset)
	if !validGamePointer(c.info) {
		return weaponChain{}, false
	}
	c.field = c.info + weaponPenetrationOffset
	return c, true
}

func (c weaponChain) stillCurrent(world uintptr, ptr func(uintptr) uintptr) bool {
	current, ok := resolveWeaponChain(world, ptr)
	return ok && current == c
}
