package main

import "testing"

func TestNewVehicleAliases(t *testing.T) {
	aliases := normalizeVehicleAliases(map[string]string{"3078201489": "Bugatti", "oops": "fake", "123": "bad\nname"})
	if len(aliases) != 1 {
		t.Fatalf("invalid aliases kept: %v", aliases)
	}
	got, ok := resolvedVehicleName(3078201489, aliases)
	if !ok || got != "Bugatti" {
		t.Fatalf("%q %v", got, ok)
	}
	got, ok = resolvedVehicleName(3078201489, nil)
	if !ok || got != "Truffade Adder" {
		t.Fatalf("%q %v", got, ok)
	}
}
func TestExtraVehicleNames(t *testing.T) {
	for _, x := range []struct {
		hash uint32
		want string
	}{{3400983137, "Obey 10F"}, {1032823388, "9F"}} {
		name, ok := vehicleNameByHash(x.hash)
		if !ok || name != x.want {
			t.Fatalf("%d: %q", x.hash, name)
		}
	}
}
