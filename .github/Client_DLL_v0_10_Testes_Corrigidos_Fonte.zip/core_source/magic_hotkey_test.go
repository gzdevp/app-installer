package main

import (
	"testing"
)

func TestMagicKey(t *testing.T) {
	for _, pair := range [][2]string{{"F7", "f7"}, {"mouse5", "mouse5"}, {"insert", "f7"}, {"F6", "f7"}, {"f2", "f2"}, {"G", "g"}, {"0", "0"}, {"", "f7"}} {
		if got := normalizeMagicKey(pair[0]); got != pair[1] {
			t.Fatalf("normalize %q = %q", pair[0], got)
		}
	}
	if magicKeyVK("f7") != 0x76 || magicKeyVK("mouse4") != 0x05 {
		t.Fatal("VK mapping incorrect")
	}
}
func TestMagicConfigSettings(t *testing.T) {
	key, collision, enabled := parseMagicHotkeySettings([]byte(`{"magic":{"key":"f7"},"aim":{"key":"mouse2","throughWall":true},"silentAim":{"key":"f7"}}`))
	if key != "f7" || !collision || !enabled {
		t.Fatal(key, collision, enabled)
	}
}
func TestThroughWallOnlyWhileHeld(t *testing.T) {
	for _, v := range []struct{ armed, held, focus, collision, paused, want bool }{
		{true, true, true, false, false, true},
		{true, false, true, false, false, false},
		{false, true, true, false, false, false},
		{true, true, false, false, false, false},
		{true, true, true, true, false, false},
		{true, true, true, false, true, false},
	} {
		if got := shouldEngageThroughWall(v.armed, v.held, v.focus, v.collision, v.paused); got != v.want {
			t.Fatalf("case %+v returned %t", v, got)
		}
	}
}
func TestKeyboardAndMouseBindings(t *testing.T) {
	for _, key := range []string{"g", "k", "0", "9", "f1", "f7", "f12", "shift", "ctrl", "alt", "space", "mouse4", "mouse5"} {
		if !validMagicKey(key) || magicKeyVK(key) == 0 {
			t.Fatalf("binding not recognized: %s", key)
		}
	}
	for _, key := range []string{"insert", "f6", "escape", "f13"} {
		if validMagicKey(key) {
			t.Fatalf("reserved key accepted: %s", key)
		}
	}
}
