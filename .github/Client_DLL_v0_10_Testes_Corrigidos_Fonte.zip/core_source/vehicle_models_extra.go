package main

// Extra stock GTA V model hashes calculated with the game's standard
// lower-case JOAAT algorithm from published spawn names. Add-on/custom
// vehicles cannot be resolved without their actual model-name mapping.
var recognizedVehicleModelsExtra = map[uint32]string{
	2891838741: "Zentorno",                // zentorno
	2174267100: "Entity XXR",              // entity2
	1748565021: "Entity MT",               // entity3
	338562499:  "Vacca",                   // vacca
	1663218586: "T20",                     // t20
	408192225:  "Turismo R",               // turismor
	3312836369: "Turismo Classic",         // turismo2
	223240013:  "Cheetah Classic",         // cheetah2
	2889029532: "Infernus Classic",        // infernus2
	3249425686: "Comet",                   // comet2
	2272483501: "Comet Retro Custom",      // comet3
	1561920505: "Comet Safari",            // comet4
	661493923:  "Comet SR",                // comet5
	2568944644: "Comet S2",                // comet6
	1141395928: "Comet S2 Cabrio",         // comet7
	1939284556: "Vagner",                  // vagner
	2123327359: "X80 Proto",               // prototipo
	3981782132: "Autarch",                 // autarch
	1392481335: "Cyclone",                 // cyclone
	386089410:  "Cyclone II",              // cyclone2
	2445973230: "Neon",                    // neon
	3630826055: "Krieger",                 // krieger
	1323778901: "Emerus",                  // emerus
	1044193113: "Thrax",                   // thrax
	272929391:  "Tempesta",                // tempesta
	1034187331: "Nero",                    // nero
	1093792632: "Nero Custom",             // nero2
	917809321:  "XA-21",                   // xa21
	2672523198: "Voltic",                  // voltic
	989294410:  "Rocket Voltic",           // voltic2
	1031562256: "Tezeract",                // tezeract
	234062309:  "Reaper",                  // reaper
	2465164804: "811",                     // pfister811
	2850852987: "Ignus",                   // ignus
	3612858749: "Zorrusso",                // zorrusso
	960812448:  "Furia",                   // furia
	3052358707: "Vigilante",               // vigilante
	3656405053: "Scramjet",                // scramjet
	2067820283: "Tyrus",                   // tyrus
	3970348707: "S80RR",                   // s80
	2246633323: "Itali GTB",               // italigtb
	3812247419: "Itali GTB Custom",        // italigtb2
	1352136073: "SC1",                     // sc1
	3379732821: "Champion",                // champion
	4284049613: "LM87",                    // lm87
	669204833:  "Virtue",                  // virtue
	1944473628: "Weaponized Ignus",        // weaponizedignus
	3306466016: "Cheburek",                // cheburek
	970598228:  "Sultan",                  // sultan
	3999278268: "Sultan RS",               // sultanrs
	872704284:  "Sultan Classic",          // sultan2
	4003946083: "Sultan RS Classic",       // sultan3
	3990165190: "Buffalo",                 // buffalo
	736902334:  "Buffalo S",               // buffalo2
	237764926:  "Buffalo Sprunk",          // buffalo3
	3675036420: "Buffalo STX",             // buffalo4
	80636076:   "Dominator",               // dominator
	3379262425: "Pisswasser Dominator",    // dominator2
	3308022675: "Dominator GTX",           // dominator3
	426742808:  "Dominator ASP",           // dominator7
	736672010:  "Dominator GTT",           // dominator8
	2536587772: "Vigero ZX",               // vigero2
	2494797253: "Gauntlet",                // gauntlet
	349315417:  "Redwood Gauntlet",        // gauntlet2
	722226637:  "Gauntlet Classic",        // gauntlet3
	1934384720: "Gauntlet Hellfire",       // gauntlet4
	3162245632: "Imorgon",                 // imorgon
	2360515092: "Rapid GT",                // rapidgt
	1737773231: "Rapid GT Cabrio",         // rapidgt2
	2049897956: "Rapid GT Classic",        // rapidgt3
	1032823388: "9F",                      // ninef
	2833484545: "9F Cabrio",               // ninef2
	2072687711: "Carbonizzare",            // carbonizzare
	4152024626: "Massacro",                // massacro
	3663206819: "Massacro (Racecar)",      // massacro2
	108773431:  "Coquette",                // coquette
	1011753235: "Coquette Classic",        // coquette2
	784565758:  "Coquette BlackFin",       // coquette3
	2566281822: "Coquette D10",            // coquette4
	1886268224: "Specter",                 // specter
	1074745671: "Specter Custom",          // specter2
	2299640309: "Feltzer",                 // feltzer2
	2728226064: "Stirling GT",             // feltzer3
	3917501776: "Penumbra",                // penumbra
	3663644634: "Penumbra FF",             // penumbra2
	2016857647: "Futo",                    // futo
	2787736776: "Futo GTX",                // futo2
	3101054893: "Calico GTF",              // calico
	1377217886: "Remus",                   // remus
	2436313176: "ZR350",                   // zr350
	3842363289: "RT3000",                  // rt3000
	2754593701: "Vectre",                  // vectre
	1755697647: "Cypher",                  // cypher
	1373123368: "Warrener",                // warrener
	579912970:  "Warrener HKR",            // warrener2
	3039514899: "Schafter",                // schafter2
	2809443750: "Schafter V12",            // schafter3
	1489967196: "Schafter LWB",            // schafter4
	3486135912: "Baller",                  // baller
	142944341:  "Baller II",               // baller2
	1878062887: "Baller LE",               // baller3
	634118882:  "Baller LE LWB",           // baller4
	470404958:  "Baller LE Armored",       // baller5
	666166960:  "Baller LE LWB Armored",   // baller6
	1203490606: "XLS",                     // xls
	3862958888: "XLS Armored",             // xls2
	2006918058: "Cavalcade",               // cavalcade
	3505073125: "Cavalcade II",            // cavalcade2
	486987393:  "Huntley S",               // huntley
	2136773105: "Rocoto",                  // rocoto
	83136452:   "Rebla GTS",               // rebla
	2465530446: "Novak",                   // novak
	3126015148: "Toros",                   // toros
	461465043:  "Jubilee",                 // jubilee
	3486509883: "Patriot",                 // patriot
	3874056184: "Patriot Stretch",         // patriot2
	3113062838: "Grace",                   // grace
	914654722:  "Mesa",                    // mesa
	3546958660: "Mesa Merryweather",       // mesa2
	2230595153: "Mesa Offroad",            // mesa3
	2434067162: "Insurgent",               // insurgent
	2071877360: "Insurgent Pickup",        // insurgent2
	2370534026: "Insurgent Pickup Custom", // insurgent3
	433954513:  "Nightshark",              // nightshark
	2922118804: "Kuruma",                  // kuruma
	410882957:  "Kuruma Armored",          // kuruma2
	1254014755: "Caracara",                // caracara
	2945871676: "Caracara 4x4",            // caracara2
	3105951696: "Sandking XL",             // sandking
	989381445:  "Sandking SWB",            // sandking2
	3087195462: "Rebel",                   // rebel
	2249373259: "Rebel Clean",             // rebel2
	2762269779: "Riata",                   // riata
	4173521127: "Kamacho",                 // kamacho
	2815302597: "Brawler",                 // brawler
	2859047862: "Bodhi",                   // bodhi2
	3932816511: "Hellion",                 // hellion
	408825843:  "Outlaw",                  // outlaw
	740289177:  "Vagrant",                 // vagrant
	3526730918: "Draugur",                 // draugur
	1162065741: "Rumpo",                   // rumpo
	1475773103: "Rumpo Custom",            // rumpo3
	2948279460: "Burrito",                 // burrito
	3387490166: "Burrito Bugstars",        // burrito2
	2551651283: "Burrito",                 // burrito3
	3484649228: "Speedo",                  // speedo
	728614474:  "Speedo Clown",            // speedo2
	219613597:  "Speedo Custom",           // speedo4
	2307837162: "Boxville",                // boxville
	4061868990: "Boxville",                // boxville2
	121658888:  "Boxville",                // boxville3
	444171386:  "Boxville",                // boxville4
	904750859:  "Mule",                    // mule
	3244501995: "Mule",                    // mule2
	2242229361: "Mule",                    // mule3
	1945374990: "Mule Custom",             // mule4
	2112052861: "Pounder",                 // pounder
	1653666139: "Pounder Custom",          // pounder2
	2157618379: "Phantom",                 // phantom
	2645431192: "Phantom Wedge",           // phantom2
	569305213:  "Packer",                  // packer
	1518533038: "Hauler",                  // hauler
	387748548:  "Hauler Custom",           // hauler2
	3471458123: "Barracks",                // barracks
	1074326203: "Barracks",                // barracks2
	630371791:  "Barracks",                // barracks3
	3581397346: "Bus",                     // bus
	2222034228: "Coach",                   // coach
	2046537925: "Police Cruiser",          // police
	2667966721: "Police Buffalo",          // police2
	1912215274: "Police Interceptor",      // police3
	2321795001: "Unmarked Police Cruiser", // police4
	4260343491: "Police Bike",             // policeb
	2758042359: "Police Rancher",          // policeold1
	2515846680: "Police Cruiser Classic",  // policeold2
	2611638396: "Sheriff Cruiser",         // sheriff
	1922257928: "Sheriff SUV",             // sheriff2
	1127131465: "FIB Buffalo",             // fbi
	2647026068: "FIB Granger",             // fbi2
	1938952078: "Fire Truck",              // firetruk
	1171614426: "Ambulance",               // ambulance
	1917016601: "Trashmaster",             // trash
	3039269212: "Trashmaster",             // trash2
	1131912276: "BMX",                     // bmx
	4108429845: "Scorcher",                // scorcher
	448402357:  "Cruiser",                 // cruiser
	3458454463: "Fixter",                  // fixter
	1127861609: "Tri-Cycles Race Bike",    // tribike
	4180675781: "Bati 801",                // bati
	3403504941: "Bati 801RR",              // bati2
	1672195559: "Akuma",                   // akuma
	11251904:   "Carbon RS",               // carbonrs
	1265391242: "Hakuchou",                // hakuchou
	4039289119: "Hakuchou Drag",           // hakuchou2
	884483972:  "Oppressor",               // oppressor
	2069146067: "Oppressor Mk II",         // oppressor2
	3889340782: "Shotaro",                 // shotaro
	3401388520: "Ruffian",                 // ruffian
	788045382:  "Sanchez",                 // sanchez
	2841686334: "Sanchez (Livery)",        // sanchez2
	1753414259: "Enduro",                  // enduro
	86520421:   "BF400",                   // bf400
	2771538552: "Manchez",                 // manchez
	1086534307: "Manchez Scout",           // manchez2
	2452219115: "Faggio",                  // faggio
	55628203:   "Faggio",                  // faggio2
	3005788552: "Faggio Mod",              // faggio3
	640818791:  "Lectro",                  // lectro
	2941886209: "Vindicator",              // vindicator
	627535535:  "FCR 1000",                // fcr
	3537231886: "FCR 1000 Custom",         // fcr2
	6774487:    "Chimera",                 // chimera
	2176659152: "Avenger",                 // avenger
	408970549:  "Avenger",                 // avenger2
	970385471:  "Hydra",                   // hydra
	3013282534: "P-996 LAZER",             // lazer
	239897677:  "F-160 Raiju",             // raiju
	1824333165: "Besra",                   // besra
	3650256867: "Cuban 800",               // cuban800
	621481054:  "Luxor",                   // luxor
	3080673438: "Luxor Deluxe",            // luxor2
	3080461301: "Shamal",                  // shamal
	1341619767: "Vestra",                  // vestra
	2548391185: "Mammatus",                // mammatus
	3393804037: "Dodo",                    // dodo
	3902291871: "Seabreeze",               // seabreeze
	3545667823: "Mogul",                   // mogul
	1036591958: "Nokota",                  // nokota
	2594093022: "Starling",                // starling
	2908775872: "Pyro",                    // pyro
	3319621991: "Rogue",                   // rogue
	1565978651: "Molotok",                 // molotok
	447548909:  "Volatol",                 // volatol
	4262088844: "Bombushka",               // bombushka
	368211810:  "Cargo Plane",             // cargoplane
	4244420235: "Cargobob",                // cargobob
	1621617168: "Cargobob",                // cargobob2
	1394036463: "Cargobob",                // cargobob3
	2025593404: "Cargobob",                // cargobob4
	788747387:  "Buzzard",                 // buzzard
	745926877:  "Buzzard Attack Chopper",  // buzzard2
	2634305738: "Maverick",                // maverick
	744705981:  "Frogger",                 // frogger
	1949211328: "Frogger",                 // frogger2
	3955379698: "Swift",                   // swift
	1075432268: "Swift Deluxe",            // swift2
	710198397:  "SuperVolito",             // supervolito
	2623428164: "SuperVolito Carbon",      // supervolito2
	2694714877: "Valkyrie",                // valkyrie
	1543134283: "Valkyrie MOD.0",          // valkyrie2
	1181327175: "Akula",                   // akula
	4212341271: "Savage",                  // savage
	4252008158: "FH-1 Hunter",             // hunter
	837858166:  "Annihilator",             // annihilator
	295054921:  "Annihilator Stealth",     // annihilator2
	3568198617: "Sea Sparrow",             // seasparrow
	1229411063: "Sparrow",                 // seasparrow2
	1593933419: "Sparrow",                 // seasparrow3
	2449479409: "Volatus",                 // volatus
	3817135397: "Conada",                  // conada
	2635962482: "Weaponized Conada",       // conada2
	782665360:  "Rhino Tank",              // rhino
	2859440138: "TM-02 Khanjali",          // khanjali
	562680400:  "APC",                     // apc
	4262731174: "Half-track",              // halftrack
	3602674979: "Chernobog",               // chernobog
	1483171323: "Deluxo",                  // deluxo
	886810209:  "Stromberg",               // stromberg
	1455990255: "Toreador",                // toreador
	771711535:  "Submersible",             // submersible
	3228633070: "Kraken",                  // submersible2
	1336872304: "Kosatka",                 // kosatka
	1033245328: "Dinghy",                  // dinghy
	276773164:  "Dinghy",                  // dinghy2
	509498602:  "Dinghy",                  // dinghy3
	867467158:  "Dinghy",                  // dinghy4
	231083307:  "Speeder",                 // speeder
	437538602:  "Speeder",                 // speeder2
	3264692260: "Seashark",                // seashark
	3678636260: "Seashark Lifeguard",      // seashark2
	3983945033: "Seashark",                // seashark3
	861409633:  "Jetmax",                  // jetmax
	400514754:  "Squalo",                  // squalo
	3251507587: "Marquis",                 // marquis
	4012021193: "Suntrap",                 // suntrap
	1070967343: "Toro",                    // toro
	908897389:  "Toro",                    // toro2
	1861786828: "Longfin",                 // longfin
	4018222598: "Kurtz 31 Patrol Boat",    // patrolboat
}
