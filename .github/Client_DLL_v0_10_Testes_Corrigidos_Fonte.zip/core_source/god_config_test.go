package main

import (
	"encoding/json"
	"testing"
)

func TestGodConfigTogglePreservesRest(t *testing.T) {
	before := json.RawMessage(`{"aim":{"enabled":true,"key":"mouse2"},"player":{"god":false,"godKey":"f9","health":200},"visual":{"playerEsp":true}}`)
	a, enabled, err := flipGodConfig(before)
	if err != nil || !enabled {
		t.Fatalf("first toggle: %v enabled %v", err, enabled)
	}
	b, enabled, err := flipGodConfig(a)
	if err != nil || enabled {
		t.Fatalf("second toggle: %v enabled %v", err, enabled)
	}
	var root map[string]json.RawMessage
	json.Unmarshal(b, &root)
	if string(root["visual"]) != `{"playerEsp":true}` {
		t.Fatalf("visual lost: %s", root["visual"])
	}
	var player map[string]json.RawMessage
	json.Unmarshal(root["player"], &player)
	if string(player["health"]) != "200" || string(player["godKey"]) != `"f9"` || string(player["god"]) != "false" {
		t.Fatalf("player data changed: %s", root["player"])
	}
}
func TestGodConfigBadJSON(t *testing.T) {
	if _, _, err := flipGodConfig(json.RawMessage(`[]`)); err == nil {
		t.Fatal("expected rejection")
	}
}
