package main

import "testing"

func TestResolveWeaponChain(t *testing.T) {
	world, ped, manager, weapon := uintptr(0x100000), uintptr(0x200000), uintptr(0x300000), uintptr(0x400000)
	m := map[uintptr]uintptr{world + 0x8: ped, ped + weaponManagerPedOffset: manager, manager + currentWeaponInfoOffset: weapon}
	ptr := func(a uintptr) uintptr { return m[a] }
	got, ok := resolveWeaponChain(world, ptr)
	if !ok || got.field != weapon+0x110 || got.info != weapon {
		t.Fatalf("wanted equipped weapon info + penetration field, got %+v, ok %v", got, ok)
	}
	if got.field == manager+0x110 {
		t.Fatal("regression: field accidentally based on manager rather than weapon info")
	}
	if !got.stillCurrent(world, ptr) {
		t.Fatal("stable chain should remain current")
	}
	m[manager+currentWeaponInfoOffset] = 0x500000
	if got.stillCurrent(world, ptr) {
		t.Fatal("weapon change must invalidate old chain")
	}
}

func TestWeaponChainRejectsBadPointers(t *testing.T) {
	world, ped, manager := uintptr(0x100000), uintptr(0x200000), uintptr(0x300000)
	m := map[uintptr]uintptr{world + 0x8: ped, ped + weaponManagerPedOffset: manager}
	ptr := func(a uintptr) uintptr { return m[a] }
	if _, ok := resolveWeaponChain(world, ptr); ok {
		t.Fatal("nil equipped weapon should be rejected")
	}
	m[manager+currentWeaponInfoOffset] = 0xFFFFFFFFFFFFFFFF
	if _, ok := resolveWeaponChain(world, ptr); ok {
		t.Fatal("non-canonical equipped weapon should be rejected")
	}
	if _, ok := resolveWeaponChain(0, ptr); ok {
		t.Fatal("null world should be rejected")
	}
}
