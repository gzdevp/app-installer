//go:build !windows

package main

func startOverlay()   {}
func startESPReader() {}
