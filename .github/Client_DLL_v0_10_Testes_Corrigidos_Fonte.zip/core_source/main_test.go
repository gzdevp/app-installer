package main

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
)

// authorizeTestRequest supplies both layers required by the real API:
// the per-process key and an authenticated session cookie. It does not
// weaken the production authentication flow.
func authorizeTestRequest(s *service, req *http.Request) {
	const testSession = "regression-test-session-token"
	s.mu.Lock()
	s.accessToken = testSession
	s.mu.Unlock()
	req.Header.Set("X-Nexo-Key", s.key)
	req.AddCookie(&http.Cookie{Name: sessionCookieName, Value: testSession, Path: "/api"})
}

func TestLocalAPIStartsFreshAndAuthenticates(t *testing.T) {
	dir := t.TempDir()
	s, e := newService(dir)
	if e != nil {
		t.Fatal(e)
	}
	h := s.handler()
	req := httptest.NewRequest("GET", "http://localhost/api/config", nil)
	rr := httptest.NewRecorder()
	h.ServeHTTP(rr, req)
	if rr.Code != http.StatusUnauthorized {
		t.Fatalf("no token: %d", rr.Code)
	}
	req = httptest.NewRequest("PUT", "http://localhost/api/config", bytes.NewBufferString(`{"aim":{"enabled":true}}`))
	authorizeTestRequest(s, req)
	rr = httptest.NewRecorder()
	h.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("put: %d %s", rr.Code, rr.Body.String())
	}
	b, e := os.ReadFile(filepath.Join(dir, "config.json"))
	if e != nil {
		t.Fatal(e)
	}
	if !json.Valid(b) || !bytes.Contains(b, []byte("enabled")) {
		t.Fatalf("saved config bad %s", b)
	}
	s2, e := newService(dir)
	if e != nil {
		t.Fatal(e)
	}
	var fresh struct {
		Aim struct {
			Enabled bool `json:"enabled"`
		} `json:"aim"`
	}
	if err := json.Unmarshal(s2.config, &fresh); err != nil || fresh.Aim.Enabled {
		t.Fatalf("old configuration unexpectedly loaded; err=%v, config=%s", err, s2.config)
	}
}
func TestProfileAndOriginValidation(t *testing.T) {
	s, e := newService(t.TempDir())
	if e != nil {
		t.Fatal(e)
	}
	h := s.handler()
	req := httptest.NewRequest("POST", "http://127.0.0.1:7000/api/profile", bytes.NewBufferString(`{"name":"Treino","config":{"aim":{"enabled":false}}}`))
	authorizeTestRequest(s, req)
	req.Header.Set("Origin", "https://malicious.example")
	rr := httptest.NewRecorder()
	h.ServeHTTP(rr, req)
	if rr.Code != http.StatusForbidden {
		t.Fatalf("cross origin %d", rr.Code)
	}
	req.Header.Set("Origin", "http://127.0.0.1:7000")
	rr = httptest.NewRecorder()
	h.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("profile write: %d %s", rr.Code, rr.Body.String())
	}
	if len(s.profiles()) != 2 {
		t.Fatal("profile not listed")
	}
	req = httptest.NewRequest("GET", "http://127.0.0.1:7000/api/profile?name=..%2F..%2Fevil", nil)
	authorizeTestRequest(s, req)
	rr = httptest.NewRecorder()
	h.ServeHTTP(rr, req)
	if rr.Code != 400 {
		t.Fatalf("traversal not denied %d", rr.Code)
	}
}
func TestIndexAndUnknownActions(t *testing.T) {
	s, e := newService(t.TempDir())
	if e != nil {
		t.Fatal(e)
	}
	h := s.handler()
	req := httptest.NewRequest("GET", "http://localhost/", nil)
	rr := httptest.NewRecorder()
	h.ServeHTTP(rr, req)
	if rr.Code != 200 || !bytes.Contains(rr.Body.Bytes(), []byte("sete7 <span")) {
		t.Fatalf("panel unavailable: %d", rr.Code)
	}
	req = httptest.NewRequest("POST", "http://localhost/api/fix", nil)
	authorizeTestRequest(s, req)
	rr = httptest.NewRecorder()
	h.ServeHTTP(rr, req)
	if rr.Code != 404 {
		t.Fatalf("game action incorrectly accepted %d", rr.Code)
	}
}

func TestLogoTransparentServed(t *testing.T) {
	s, err := newService(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	w := httptest.NewRecorder()
	s.handler().ServeHTTP(w, httptest.NewRequest("GET", "http://localhost/logo.png", nil))
	if w.Code != 200 {
		t.Fatalf("logo status %d", w.Code)
	}
	if w.Header().Get("Content-Type") != "image/png" {
		t.Fatalf("wrong type %q", w.Header().Get("Content-Type"))
	}
	if !bytes.HasPrefix(w.Body.Bytes(), []byte{137, 80, 78, 71, 13, 10, 26, 10}) {
		t.Fatal("invalid png")
	}
}

func TestUnloadAndCleanerAreAuthenticatedAndScoped(t *testing.T) {
	root := t.TempDir()
	folder := filepath.Join(root, "sete7-data")
	s, e := newService(folder)
	if e != nil {
		t.Fatal(e)
	}
	keep := filepath.Join(root, "other-application.txt")
	if e := os.WriteFile(keep, []byte("preserve"), 0600); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(filepath.Join(folder, "config.json"), []byte(`{"example":true}`), 0600); e != nil {
		t.Fatal(e)
	}
	req := httptest.NewRequest("POST", "http://localhost/api/cleaner", bytes.NewBufferString(`{"confirm":"REMOVER SETE7"}`))
	rr := httptest.NewRecorder()
	s.handler().ServeHTTP(rr, req)
	if rr.Code != 401 {
		t.Fatalf("cleaner auth: %d", rr.Code)
	}
	// Suppress the background shutdown worker in this API test; the cleanup
	// implementation has separate scoped-file tests and must never try to
	// delete the running test binary or a browser during CI.
	s.stopping.Store(true)
	// A single authenticated POST with no confirmation/body is sufficient.
	req = httptest.NewRequest("POST", "http://localhost/api/cleaner", nil)
	authorizeTestRequest(s, req)
	rr = httptest.NewRecorder()
	s.handler().ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("cleaner request: %d: %s", rr.Code, rr.Body.String())
	}
	// The API must not perform unscoped deletion while handling the HTTP
	// request. Real deletion is independently verified by owned_session tests.
	if _, e := os.ReadFile(keep); e != nil {
		t.Fatalf("other file wrongly removed: %v", e)
	}
	unload, e := newService(filepath.Join(root, "fresh"))
	if e != nil {
		t.Fatal(e)
	}
	unload.stopping.Store(true)
	req = httptest.NewRequest("POST", "http://localhost/api/unload", nil)
	authorizeTestRequest(unload, req)
	rr = httptest.NewRecorder()
	unload.handler().ServeHTTP(rr, req)
	if rr.Code != 200 || !bytes.Contains(rr.Body.Bytes(), []byte(`"closing":true`)) {
		t.Fatalf("unload status %d %s", rr.Code, rr.Body.String())
	}
}
