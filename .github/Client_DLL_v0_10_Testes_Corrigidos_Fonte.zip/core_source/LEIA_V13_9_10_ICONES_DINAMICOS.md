# sete7 v13.9.10 — ícones dinâmicos

Base: v13.9.9 Rounded & Drag Edition. Não substitui a versão estável do usuário.

## Alterações
- Barra lateral: SVGs de Aim, Weapons, Visuals, Chams, World, Player e Settings redesenhados conforme a referência.
- Todos os ícones inativos usam `var(--accent)`; item selecionado usa ícone de contraste e o fundo assume a cor escolhida.
- A seleção de cor customizada em Settings > Appearance agora responde imediatamente no painel; ao escolher cor customizada as marcas das amostras se atualizam.
- Janela e perfil local usam identificação v13.9.10 para evitar reaproveitamento de janela antiga.
- Código-fonte dos módulos de jogo permanece byte a byte idêntico ao ZIP v13.9.9.

## Testes efetuados
- GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags=-H=windowsgui: passou.
- go vet na compilação Windows: passou.
- node --check do script embutido: passou.
- Chromium/Playwright: carregamento das 7 opções de navegação, cor padrão laranja, troca ao azul #23a6db, modo contraste claro #f2d671, navegação e zero erros JavaScript: passou.
- Não foi executado no FiveM/Windows.

## Uso
Settings > Appearance > Cor de destaque. Escolha amostra ou cor personalizada; os ícones acompanham instantaneamente.
