//go:build windows

package main

// Native borderless shell for the existing sete7 HTML dashboard.
// Chromium's browser window is reparented inside a native WS_POPUP window.
// The native shell is never a normal taskbar window and has no OS caption.
// This changes only the UI: game process, input, memory, and protections are untouched.
import (
	"fmt"
	"runtime"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

var (
	nativeHostHWND            atomic.Uintptr
	standaloneBrowserHWND     atomic.Uintptr
	nativeChildHWND           atomic.Uintptr
	nativeHostPrepared        atomic.Bool
	nativeHostCloseAuthorized atomic.Bool
	nativeHostStarting        atomic.Bool
	nativeHostGeneration      atomic.Uint64
	nativeSetParent           = u32.NewProc("SetParent")
	nativeIsWindow            = u32.NewProc("IsWindow")
	nativePostQuit            = u32.NewProc("PostQuitMessage")
	nativeBringToTop          = u32.NewProc("BringWindowToTop")
	nativeMoveWindow          = u32.NewProc("MoveWindow")
	nativeGetSysMetrics       = u32.NewProc("GetSystemMetrics")
	nativeAttachInput         = u32.NewProc("AttachThreadInput")
	nativeSetFocus            = u32.NewProc("SetFocus")
	nativeGetFocus            = u32.NewProc("GetFocus")
	nativeGetCurrentTid       = k32.NewProc("GetCurrentThreadId")
	nativeRoundRegion         = syscall.NewLazyDLL("gdi32.dll").NewProc("CreateRoundRectRgn")
)

const (
	nativeCaptionCropX   = int32(8)
	nativeCaptionCropY   = int32(32)
	nativeCornerDiameter = int32(46)
	nativeWSClipChildren = uintptr(0x02000000)
	nativeWSChild        = uintptr(0x40000000)
	nativeWSVisible      = uintptr(0x10000000)
	nativeGWlStyle       = ^uintptr(15)
	nativeWSOverlapped   = uintptr(0x00C00000)
	nativeWMClose        = uint32(0x0010)
	nativeWMDestroy      = uint32(0x0002)
	nativeWMSetFocus     = uint32(0x0007)
	nativeWMFocusBrowser = uint32(0x8000 + 77)
)

func menuWindow() uintptr {
	if standalone := standaloneBrowserHWND.Load(); standalone != 0 {
		if alive, _, _ := nativeIsWindow.Call(standalone); alive != 0 {
			return standalone
		}
		standaloneBrowserHWND.CompareAndSwap(standalone, 0)
	}
	host, child := nativeHostHWND.Load(), nativeChildHWND.Load()
	if host != 0 && child != 0 && nativeHostPrepared.Load() {
		hostOK, _, _ := nativeIsWindow.Call(host)
		childOK, _, _ := nativeIsWindow.Call(child)
		if hostOK != 0 && childOK != 0 {
			return host
		}
		// Reparented Chromium children may be destroyed and recreated.
		// Do not keep a stale handle forever: let the window watchdog recover.
		if childOK == 0 {
			nativeHostPrepared.Store(false)
			nativeChildHWND.CompareAndSwap(child, 0)
		}
	}
	// Unattached Chromium windows must never be treated as the visible menu.
	return 0
}

func startNativeMenuHost() {
	if nativeHostCloseAuthorized.Load() || !nativeHostStarting.CompareAndSwap(false, true) {
		return
	}
	ready := make(chan struct{})
	go func() {
		defer nativeHostStarting.Store(false)
		defer recoverServiceWorker("native_host_windows.go")
		runtime.LockOSThread()
		defer runtime.UnlockOSThread()
		className, _ := syscall.UTF16PtrFromString(fmt.Sprintf("SETE7_native_shell_v1210_%d", nativeHostGeneration.Add(1)))
		windowName, _ := syscall.UTF16PtrFromString("sete7 native UI")
		cb := syscall.NewCallback(func(hwnd uintptr, message uint32, wp, lp uintptr) uintptr {
			defer recoverServiceWorker("native_host_windows.go:native-callback")
			// A stray WM_CLOSE (Chromium focus changes, Alt+F4 or a system
			// caption command) is not a request to exit 77. The explicit
			// Unload/Cleaner path authorizes normal window destruction.
			if message == nativeWMClose && !nativeHostCloseAuthorized.Load() {
				// Ignore unexpected close requests. Only an explicit Unload
				// or Cleaner should destroy the host window.
				return 0
			}
			if message == nativeWMSetFocus || message == nativeWMFocusBrowser {
				focusNativeBrowserChild(hwnd)
				return 0
			}
			if message == nativeWMDestroy {
				nativePostQuit.Call(0)
				return 0
			}
			returnDefault, _, _ := defaultProc.Call(hwnd, uintptr(message), wp, lp)
			return returnDefault
		})
		class := wndClassEx{Size: uint32(unsafe.Sizeof(wndClassEx{})), WndProc: cb,
			ClassName: className}
		class.Instance, _, _ = moduleHandle.Call(0)
		if ok, _, _ := regCls.Call(uintptr(unsafe.Pointer(&class))); ok == 0 {
			close(ready)
			return
		}
		width, height := menuDimensions()
		// WS_POPUP and WS_EX_TOOLWINDOW mean no title bar / taskbar button.
		// WS_CLIPCHILDREN physically clips all child decorations at the host edge.
		hwnd, _, _ := winEx.Call(
			exTool|exTopmost, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(windowName)),
			wsPopup|nativeWSClipChildren, 40, 40, uintptr(width), uintptr(height),
			0, 0, class.Instance, 0)
		if hwnd != 0 {
			nativeHostHWND.Store(hwnd)
			streamRegisterPanel(hwnd)
			roundNativeHost(hwnd, width, height)
		}
		close(ready)
		if hwnd == 0 {
			return
		}
		// Win32 message loop must remain on the window-creator OS thread.
		var message msg
		for {
			rv, _, _ := getMsg.Call(uintptr(unsafe.Pointer(&message)), 0, 0, 0)
			if int32(rv) <= 0 {
				break
			}
			translateMsg.Call(uintptr(unsafe.Pointer(&message)))
			dispatchMsg.Call(uintptr(unsafe.Pointer(&message)))
		}
		nativeHostPrepared.Store(false)
		nativeChildHWND.Store(0)
		streamUnregisterPanel(hwnd)
		// Never erase the handle of a replacement host spawned after this one.
		nativeHostHWND.CompareAndSwap(hwnd, 0)
	}()
	select {
	case <-ready:
	case <-time.After(4 * time.Second):
	}
}

func attachBrowserToNativeHost() bool {
	if host := nativeHostHWND.Load(); host != 0 {
		tick := time.NewTicker(80 * time.Millisecond)
		defer tick.Stop()
		timer := time.NewTimer(20 * time.Second)
		defer timer.Stop()
		for {
			select {
			case <-timer.C:
				return false
			case <-tick.C:
				child := browserTopWindow()
				if child == 0 || child == host {
					continue
				}
				// Win32 SetParent requires WS_CHILD to be set *before*
				// reparenting a top-level window. If Windows rejects it
				// (e.g. DPI-awareness incompatibility), restore the style.
				// Never allow the top-level Chromium window to render on screen
				// during its conversion into the native host's child.
				showWindow.Call(child, swHide)
				oldStyle, _, _ := getWindowLongPtr.Call(child, nativeGWlStyle)
				childStyle := (oldStyle &^ (wsPopup | nativeWSOverlapped |
					uintptr(0x00080000) | uintptr(0x00040000) |
					uintptr(0x00020000) | uintptr(0x00010000) |
					nativeWSVisible)) | nativeWSChild
				setWindowLongPtr.Call(child, nativeGWlStyle, childStyle)
				nativeSetParent.Call(child, host)
				parent, _, _ := u32.NewProc("GetParent").Call(child)
				if parent != host {
					setWindowLongPtr.Call(child, nativeGWlStyle, oldStyle)
					continue
				}
				nativeHostPrepared.Store(false)
				nativeChildHWND.Store(child)
				// Child is positioned before it can become visible. Parent is still
				// hidden, so no UI is shown until INSERT is explicitly requested.
				resizeNativeChild(host)
				showWindow.Call(child, 4) // SW_SHOWNOACTIVATE; never steals game focus
				showWindow.Call(host, swHide)
				nativeHostPrepared.Store(true)
				return true
			}
		}
	}
	return false
}

func resizeNativeChild(host uintptr) {
	child := nativeChildHWND.Load()
	if host == 0 || child == 0 {
		return
	}
	r := rect{}
	if ok, _, _ := getClientRect.Call(host, uintptr(unsafe.Pointer(&r))); ok == 0 {
		return
	}
	w, h := r.Right-r.Left, r.Bottom-r.Top
	if w < 1 || h < 1 {
		return
	}
	// Hide Chromium-generated top strip and 8px frame *outside* host bounds.
	negX, negY := -nativeCaptionCropX, -nativeCaptionCropY
	nativeMoveWindow.Call(child, uintptr(int64(negX)), uintptr(int64(negY)),
		uintptr(w+2*nativeCaptionCropX), uintptr(h+nativeCaptionCropY), 1)
}

// Apply a real Win32 rounded region: CSS alone cannot clip the native popup.
// The system owns the HRGN on successful SetWindowRgn.
func roundNativeHost(hwnd uintptr, w, h int32) bool {
	if hwnd == 0 || w < 100 || h < 100 {
		return false
	}
	diameter := nativeCornerDiameter
	rgn, _, _ := nativeRoundRegion.Call(0, 0, uintptr(w+1), uintptr(h+1), uintptr(diameter), uintptr(diameter))
	if rgn == 0 {
		return false
	}
	ok, _, _ := setWindowRgnFrame.Call(hwnd, rgn, 1)
	if ok == 0 {
		deleteObjectFrame.Call(rgn)
		return false
	}
	return true
}

func positionNativeHost(hwnd uintptr, vp espViewport) {
	if vp.W < 320 || vp.H < 240 {
		return
	}
	w, h := menuDimensions()
	if w > vp.W {
		w = vp.W
	}
	if h > vp.H {
		h = vp.H
	}
	x := vp.X + (vp.W-w)/2
	y := vp.Y + (vp.H-h)/2
	panelPosition.Lock()
	if panelPosition.custom {
		x, y = panelPosition.x, panelPosition.y
	}
	panelPosition.Unlock()
	x, y = clampPanel(x, y, w, h, vp)
	const hwndTopmost = ^uintptr(0)
	setWindowPos.Call(hwnd, hwndTopmost, uintptr(int64(x)), uintptr(int64(y)), uintptr(w), uintptr(h), uintptr(0x0010))
	roundNativeHost(hwnd, w, h)
	resizeNativeChild(hwnd)
}

// Chromium's reparented window lives on a different GUI thread than this
// WS_POPUP shell. Focusing only the shell causes HTML inputs to ignore keys.
// This runs in the native host's own message thread and temporarily connects
// the input queues to give the child keyboard focus (no hooks/injection).
func focusNativeBrowserChild(host uintptr) bool {
	if host == 0 || !menuWanted.Load() || nativeHostHWND.Load() != host || !nativeHostPrepared.Load() {
		return false
	}
	child := nativeChildHWND.Load()
	if child == 0 {
		return false
	}
	if valid, _, _ := nativeIsWindow.Call(child); valid == 0 {
		return false
	}
	currentTid, _, _ := nativeGetCurrentTid.Call()
	childTid, _, _ := getWindowPid.Call(child, 0)
	if currentTid == 0 || childTid == 0 {
		return false
	}
	attached := false
	if currentTid != childTid {
		ok, _, _ := nativeAttachInput.Call(currentTid, childTid, 1)
		if ok == 0 {
			return false
		}
		attached = true
	}
	nativeSetFocus.Call(child)
	focused, _, _ := nativeGetFocus.Call()
	if attached {
		nativeAttachInput.Call(currentTid, childTid, 0)
	}
	return focused == child
}

// Ask the host's thread to forward focus after Windows foreground activation.
func requestNativeBrowserFocus(hwnd uintptr) {
	if hwnd == 0 || hwnd != nativeHostHWND.Load() {
		return
	}
	postMessage.Call(hwnd, uintptr(nativeWMFocusBrowser), 0, 0)
}
