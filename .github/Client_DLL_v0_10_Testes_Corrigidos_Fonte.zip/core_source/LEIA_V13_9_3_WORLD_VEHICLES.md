# sete7 v13.9.3 — Vehicles dentro de World

Base: v13.9.2, preservada sem alterações.

- Barra lateral: removido item Vehicles independente.
- World: primeira aba **Vehicles**, imediatamente à esquerda de **Radar**.
- Os controles Vehicle ESP, alcance, nomes, lista de carros, velocidade, motor, ocupantes, FIX CAR e controles desabilitados de trancar/destrancar permanecem exclusivos da aba World > Vehicles.
- Radar continua na segunda aba de World e não foi modificado funcionalmente.
- Ajustadas somente a navegação HTML/JS, identificação da nova janela (para não repetir o bug do globo), versão e diretório de configurações exclusivo da v13.9.3.
- Nenhum módulo de Aimbot, Silent, ESP, Triggerbot, Radar, arma, TP, jogador ou veículos foi alterado.
- FIX CAR permanece uma tentativa local; trancar e destrancar permanecem desabilitados porque não há integração autorizada com o servidor.
- A compilação e os testes automatizados não substituem validação prática do FiveM.

Para abrir: feche totalmente versões anteriores, inicie somente a v13.9.3 e use INSERT. Em World aparecem, na ordem, **Vehicles | Radar**.
