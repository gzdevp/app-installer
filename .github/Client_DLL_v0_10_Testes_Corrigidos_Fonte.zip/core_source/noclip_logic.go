package main

import "math"

// The noclip movement controls are resolved in camera-relative world space.
// The matrix is already the validated world-to-screen projection used by ESP.
// GTA's horizontal ground plane is XY and Z is vertical.
func noclipBasis(m matrix44) (forward, right vec3, ok bool) {
	// The projection convention used by worldToScreen stores depth in indices
	// 3,7,11 and screen-right in indices 1,5,9.
	fx, fy := float64(m[3]), float64(m[7])
	fl := math.Hypot(fx, fy)
	if fl < 1e-5 || (math.IsNaN(fl) || math.IsInf(fl, 0)) {
		return vec3{}, vec3{}, false
	}
	fx, fy = fx/fl, fy/fl
	rx, ry := float64(m[1]), float64(m[5])
	proj := rx*fx + ry*fy
	rx, ry = rx-proj*fx, ry-proj*fy
	rl := math.Hypot(rx, ry)
	if rl < 1e-5 || math.IsNaN(rl) || math.IsInf(rl, 0) {
		return vec3{}, vec3{}, false
	}
	return vec3{X: float32(fx), Y: float32(fy)}, vec3{X: float32(rx / rl), Y: float32(ry / rl)}, true
}

// x: -1 A, +1 D; y: -1 S, +1 W; z: -1 Ctrl, +1 Space.
// A normalized combination avoids faster diagonal movement.
func noclipStep(position, forward, right vec3, x, y, z, speed, seconds float64) (vec3, bool) {
	if speed < 1 || speed > 500 || seconds <= 0 || seconds > .08 {
		return position, false
	}
	vx := float64(right.X)*x + float64(forward.X)*y
	vy := float64(right.Y)*x + float64(forward.Y)*y
	vz := z
	length := math.Sqrt(vx*vx + vy*vy + vz*vz)
	if length > 1 {
		vx /= length
		vy /= length
		vz /= length
	}
	out := vec3{X: position.X + float32(vx*speed*seconds),
		Y: position.Y + float32(vy*speed*seconds), Z: position.Z + float32(vz*speed*seconds)}
	return out, plausibleFiveMPosition(out)
}
