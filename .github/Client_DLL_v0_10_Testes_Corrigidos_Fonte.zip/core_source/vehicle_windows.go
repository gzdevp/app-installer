//go:build windows

package main

import (
	"encoding/binary"
	"fmt"
	"math"
	"sync"
	"time"
	"unsafe"
)

// These offsets come from the supplied PoC and are NOT confirmed game-layout
// signatures. Write attempts are limited to the known b3258 process and
// fail closed if vehicle identity/position/health values are implausible.
type vehicleWriteProfile struct {
	PedVehicle, Engine, Body, Tank uintptr
}

// b3258 has multiple historic candidate vehicle health layouts. Keep only
// the newer documented candidate; guessing amongst memory offsets can write
// unrelated vehicle fields. This remains experimental until tested in game.
var vehicleWriteProfiles = map[string]vehicleWriteProfile{
	"b3258": {PedVehicle: 0xD10, Engine: 0xA48, Body: 0x840, Tank: 0x130},
}
var vehicleFixState = struct {
	sync.RWMutex
	status  string
	at      string
	success bool
}{status: "Aguardando F6 ou botão FIX CAR"}
var vehicleFixMutex sync.Mutex

func vehicleFixReport(s string, success bool) {
	vehicleFixState.Lock()
	vehicleFixState.status = s
	vehicleFixState.at = time.Now().Format("15:04:05")
	vehicleFixState.success = success
	vehicleFixState.Unlock()
}
func vehicleFixGet() map[string]any {
	vehicleFixState.RLock()
	defer vehicleFixState.RUnlock()
	return map[string]any{"status": vehicleFixState.status, "at": vehicleFixState.at, "success": vehicleFixState.success}
}
func readFloat32Game(p *attachedESP, addr uintptr) (float32, bool) {
	var data [4]byte
	if !p.read(addr, data[:]) {
		return 0, false
	}
	v := math.Float32frombits(binary.LittleEndian.Uint32(data[:]))
	if math.IsNaN(float64(v)) || math.IsInf(float64(v), 0) {
		return 0, false
	}
	return v, true
}
func writeFloat32Game(h, addr uintptr, v float32) bool {
	var data [4]byte
	binary.LittleEndian.PutUint32(data[:], math.Float32bits(v))
	var n uintptr
	ok, _, _ := noclipWriteProcessMemory.Call(h, addr, uintptr(unsafe.Pointer(&data[0])), 4, uintptr(unsafe.Pointer(&n)))
	return ok != 0 && n == 4
}
func attachWritableGame() (*noclipAttachment, error) {
	p, _, _, err := findESP()
	if err != nil {
		return nil, err
	}
	h, _, e := openProcessProc.Call(noclipWritePermission, 0, uintptr(p.pid))
	if h == 0 {
		closeESP(p.handle)
		return nil, fmt.Errorf("Escrita recusada pelo FiveM: %v", e)
	}
	return &noclipAttachment{read: p, writer: h}, nil
}

// resolveVerifiedLocalVehicle refuses the stale "last vehicle" field unless
// it is confirmed by the driver's ped slot. A current vehicle candidate also
// needs active-pool membership, matching position, and no conflict.
func (p *attachedESP) resolveVerifiedLocalVehicle(ped uintptr) (uintptr, uintptr, bool) {
	pedPos, ok := p.vec3(ped + 0x90)
	if !ok || !plausibleFiveMPosition(pedPos) {
		return 0, 0, false
	}
	var chosen, chosenField uintptr
	for _, field := range []uintptr{0xD10, 0xDD0} {
		vehicle := p.ptr(ped + field)
		if vehicle < 0x10000 || vehicle > 0x7FFFFFFFFFFF || !p.vehicleIsActiveInPool(vehicle) {
			continue
		}
		carPos, ok := p.vec3(vehicle + 0x90)
		if !ok || !plausibleFiveMPosition(carPos) || !vehicleCloseEnough(dist(pedPos, carPos)) {
			continue
		}
		// 0xDD0 is frequently a last-used pointer. It needs a verified driver
		// slot: do not fix a parked car merely because it is beside the player.
		if field == 0xDD0 && p.verifiedVehicleDriverPed(vehicle, carPos) != ped {
			continue
		}
		if chosen != 0 && chosen != vehicle {
			return 0, 0, false
		}
		if chosen == 0 {
			chosen, chosenField = vehicle, field
		}
	}
	return chosen, chosenField, chosen != 0
}

// An optional requested ID must match the player's current vehicle.
// The vehicle list may contain other players' cars; selecting one never
// grants permission to mutate it. Zero retains the legacy local-car action.
func fixVehicleAction() (string, bool) { return fixVehicleActionForID(0) }
func fixVehicleActionForID(requested uint64) (string, bool) {
	vehicleFixMutex.Lock()
	defer vehicleFixMutex.Unlock()
	a, err := attachWritableGame()
	if err != nil {
		s := "Fix Car: " + err.Error()
		vehicleFixReport(s, false)
		return s, false
	}
	defer a.close()
	p := a.read
	profile, ok := vehicleWriteProfiles[p.build]
	if !ok {
		s := "Fix Car indisponível: offsets do veículo não validados para " + p.build
		vehicleFixReport(s, false)
		return s, false
	}
	layout := espLayouts[p.build]
	world := p.ptr(p.base + layout.world)
	if world == 0 {
		s := "Fix Car: mundo não identificado"
		vehicleFixReport(s, false)
		return s, false
	}
	ped := p.ptr(world + 0x8)
	if ped == 0 {
		s := "Fix Car: jogador local não identificado"
		vehicleFixReport(s, false)
		return s, false
	}
	// Find only a vehicle whose active-pool entity is independently tied to
	// the local ped. 0xD10 and 0xDD0 are build-dependent candidates; 0xDD0
	// may also refer to the *last* driven vehicle, so never trust it alone.
	vehicle, vehicleOffset, found := p.resolveVerifiedLocalVehicle(ped)
	if !found {
		s := "Fix Car: não consegui confirmar o carro atual (não altera memória)"
		vehicleFixReport(s, false)
		return s, false
	}
	if !vehicleRepairTargetMatches(uint64(vehicle), requested) {
		s := "Fix Car bloqueado: selecione o veículo em que você está"
		vehicleFixReport(s, false)
		return s, false
	}
	engine, eok := readFloat32Game(p, vehicle+profile.Engine)
	body, bok := readFloat32Game(p, vehicle+profile.Body)
	tank, tok := readFloat32Game(p, vehicle+profile.Tank)
	previous := vehicleHealthValues{Engine: engine, Body: body, Tank: tank}
	if !(eok && bok && tok) || !vehicleHealthPlausible(previous) {
		s := "Fix Car bloqueado: campos de saúde do veículo incompatíveis com o layout"
		vehicleFixReport(s, false)
		return s, false
	}
	// Recheck local ped/vehicle identity immediately before changing memory.
	if p.ptr(world+0x8) != ped || p.ptr(ped+vehicleOffset) != vehicle {
		s := "Fix Car cancelado: veículo atual mudou"
		vehicleFixReport(s, false)
		return s, false
	}
	// Memory health values are not equivalent to GTA native SetVehicleFixed:
	// they do not restore visual deformation or prove server replication.
	if !writeFloat32Game(a.writer, vehicle+profile.Engine, 1000) {
		s := "Fix Car: falha ao escrever motor"
		vehicleFixReport(s, false)
		return s, false
	}
	if !writeFloat32Game(a.writer, vehicle+profile.Body, 1000) {
		_ = writeFloat32Game(a.writer, vehicle+profile.Engine, engine)
		s := "Fix Car: falha ao escrever lataria (motor restaurado)"
		vehicleFixReport(s, false)
		return s, false
	}
	if !writeFloat32Game(a.writer, vehicle+profile.Tank, 1000) {
		_ = writeFloat32Game(a.writer, vehicle+profile.Body, body)
		_ = writeFloat32Game(a.writer, vehicle+profile.Engine, engine)
		s := "Fix Car: falha ao escrever tanque (valores anteriores restaurados)"
		vehicleFixReport(s, false)
		return s, false
	}
	// Give the game a short update interval before checking; an immediate
	// read alone would report success on values reverted the next tick.
	time.Sleep(90 * time.Millisecond)
	// Read-back is required; success means the local fields stayed written,
	// not that the remote server accepted or replicated the repair.
	e, eo := readFloat32Game(p, vehicle+profile.Engine)
	b, bo := readFloat32Game(p, vehicle+profile.Body)
	t, to := readFloat32Game(p, vehicle+profile.Tank)
	if !eo || !bo || !to || e != 1000 || b != 1000 || t != 1000 {
		s := "Fix Car: escrita não confirmada pelo jogo/servidor"
		vehicleFixReport(s, false)
		return s, false
	}
	s := "Saúde local aplicada (motor/lataria/tanque). Amassados e servidor não confirmados"
	vehicleFixReport(s, true)
	return s, true
}
func startVehicleFixHotkey() {
	go func() {
		defer recoverServiceWorker("vehicle_windows.go")
		ticker := time.NewTicker(45 * time.Millisecond)
		defer ticker.Stop()
		held := false
		for range ticker.C {
			// F6 only works while the game window has focus; no desktop side effects.
			down := noclipKeyHeld(0x75) // VK_F6
			if down && !held {
				if a, err := attachWritableGame(); err == nil {
					foreground := fiveMIsForeground(a.read.pid)
					a.close()
					if foreground {
						fixVehicleAction()
					}
				}
			}
			held = down
		}
	}()
}

// An optional legitimate city repair command covers vehicles of arbitrary
// models, provided the city actually offers and authorizes the command.
// It is never called implicitly when experimental local repair fails.
func vehicleRepairViaCityCommand(command string) (string, bool) {
	vehicleFixMutex.Lock()
	defer vehicleFixMutex.Unlock()
	vehicleLockActionMutex.Lock()
	defer vehicleLockActionMutex.Unlock()
	status, ok := submitCityVehicleInput(command, "")
	if ok {
		status = "Reparo solicitado: " + status
	}
	vehicleFixReport(status, false) // input delivered != repair confirmed
	return status, ok
}
