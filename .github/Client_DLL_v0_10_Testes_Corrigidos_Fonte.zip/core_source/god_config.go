package main

import (
	"encoding/json"
	"errors"
)

// flipGodConfig changes only the stored God Mode preference, leaving every
// other setting untouched. This does not itself grant in-game invulnerability.
func flipGodConfig(raw json.RawMessage) (json.RawMessage, bool, error) {
	var root map[string]json.RawMessage
	if err := json.Unmarshal(raw, &root); err != nil || root == nil {
		return nil, false, errors.New("invalid config")
	}
	var player map[string]json.RawMessage
	if len(root["player"]) > 0 && string(root["player"]) != "null" {
		if err := json.Unmarshal(root["player"], &player); err != nil {
			return nil, false, err
		}
	}
	if player == nil {
		player = map[string]json.RawMessage{}
	}
	var current bool
	if len(player["god"]) > 0 {
		if err := json.Unmarshal(player["god"], &current); err != nil {
			return nil, false, err
		}
	}
	next := !current
	if next {
		player["god"] = json.RawMessage("true")
	} else {
		player["god"] = json.RawMessage("false")
	}
	b, err := json.Marshal(player)
	if err != nil {
		return nil, false, err
	}
	root["player"] = b
	b, err = json.Marshal(root)
	if err != nil {
		return nil, false, err
	}
	return b, next, nil
}
