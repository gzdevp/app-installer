package main

import (
	"math"
	"testing"
)

func TestRadarNorthUpAndRange(t *testing.T) {
	p, ok := radarProject(vec3{X: 10, Y: 10}, vec3{X: 60, Y: 110}, 200, 100)
	if !ok || math.Abs(p.X-25) > 0.01 || math.Abs(p.Y+50) > 0.01 {
		t.Fatalf("north-up: %+v %v", p, ok)
	}
	if _, ok = radarProject(vec3{}, vec3{X: 300}, 200, 100); ok {
		t.Fatal("far entity must be rejected")
	}
}
func TestRadarInputs(t *testing.T) {
	if clampRadarRange(1) != 50 || clampRadarRange(900) != 500 || clampRadarSize(0) != 50 || clampRadarOpacity(200) != 100 {
		t.Fatal("bad clamps")
	}
}
