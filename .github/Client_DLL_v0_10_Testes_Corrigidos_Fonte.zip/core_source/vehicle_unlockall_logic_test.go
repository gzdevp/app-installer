package main

import "testing"

func TestLocalDoorLockDomain(t *testing.T) {
	for i := 0; i < 256; i++ {
		if plausibleLocalDoorLockState(byte(i)) != (i <= 10) {
			t.Fatalf("state %d", i)
		}
	}
	for i := 0; i < 256; i++ {
		if needsLocalUnlock(byte(i)) != (i >= 2 && i <= 10) {
			t.Fatalf("locked %d", i)
		}
	}
}
func TestLocalUnlockRange(t *testing.T) {
	for _, d := range []float64{-1, 5.51, 30} {
		if validUnlockTargetDistance(d) {
			t.Errorf("accepted %f", d)
		}
	}
	for _, d := range []float64{0, 3, 5.5} {
		if !validUnlockTargetDistance(d) {
			t.Errorf("rejected %f", d)
		}
	}
}

func TestEntryPressOnlyOncePerKeystroke(t *testing.T) {
	var d entryPressDetector
	seq := []struct{ enabled, focused, down, want bool }{
		{true, true, false, false},
		{true, true, true, true},
		{true, true, true, false},
		{true, true, true, false},
		{true, true, false, false},
		{true, true, true, true},
		{true, false, true, false},
		{true, true, true, false}, // held through focus regain
		{false, true, true, false},
		{true, true, true, false}, // held through re-enable
		{true, true, false, false},
		{true, true, true, true},
	}
	for i, v := range seq {
		if got := d.update(v.enabled, v.focused, v.down); got != v.want {
			t.Fatalf("event %d: got %v, want %v", i, got, v.want)
		}
	}
}
