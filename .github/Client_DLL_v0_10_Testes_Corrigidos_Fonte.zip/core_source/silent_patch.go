package main

import (
	"encoding/binary"
	"errors"
	"math"
)

// The original 17-byte SSE bullet-destination sequence from the supplied
// C++ reference. This is checked byte-for-byte before any patch is attempted.
var bulletOriginal = []byte{
	0xF3, 0x41, 0x0F, 0x10, 0x19,
	0xF3, 0x41, 0x0F, 0x10, 0x41, 0x04,
	0xF3, 0x41, 0x0F, 0x10, 0x51, 0x08,
}

const bulletCaveTargetOffset = 64

func validBulletWorld(v vec3) bool {
	return plausibleFiveMPosition(v) &&
		math.Abs(float64(v.X)) < 20000 && math.Abs(float64(v.Y)) < 20000 &&
		math.Abs(float64(v.Z)) < 10000
}

func bulletTargetBytes(v vec3) ([]byte, error) {
	if !validBulletWorld(v) {
		return nil, errors.New("invalid verified head coordinates")
	}
	b := make([]byte, 12)
	binary.LittleEndian.PutUint32(b[:4], math.Float32bits(v.X))
	binary.LittleEndian.PutUint32(b[4:8], math.Float32bits(v.Y))
	binary.LittleEndian.PutUint32(b[8:12], math.Float32bits(v.Z))
	return b, nil
}
func absoluteX64Jump(address uintptr) []byte {
	b := []byte{0xff, 0x25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
	binary.LittleEndian.PutUint64(b[6:], uint64(address))
	return b
}
func bulletEntryPatch(cave uintptr) ([]byte, error) {
	if cave < 0x10000 || cave >= 0x0000800000000000 {
		return nil, errors.New("invalid remote code address")
	}
	b := absoluteX64Jump(cave)
	return append(b, 0x90, 0x90, 0x90), nil
}

// Preserve the original 17-byte SSE result registers *and* update the
// coordinates pointed to by R9. The preceding experimental trampoline loaded
// XMM3/XMM0/XMM2 but never updated [R9]. The original C++ base explicitly
// writes all three coordinates through R9 before continuing the game code.
// This distinction is crucial when later game instructions use the pointed-to
// coordinates, rather than just the XMM values. No GPRs, flags, or unrelated
// registers are altered here.
func bulletTrampoline(entry, cave uintptr, target vec3) ([]byte, error) {
	if entry < 0x10000 || entry >= 0x0000800000000000-17 || cave < 0x10000 || cave >= 0x0000800000000000-76 {
		return nil, errors.New("invalid jump address")
	}
	xyz, err := bulletTargetBytes(target)
	if err != nil {
		return nil, err
	}
	code := make([]byte, 0, 76)
	loads := [][]byte{
		{0xF3, 0x0F, 0x10, 0x1D}, // movss xmm3, [rip+target.x]
		{0xF3, 0x0F, 0x10, 0x05}, // movss xmm0, [rip+target.y]
		{0xF3, 0x0F, 0x10, 0x15}, // movss xmm2, [rip+target.z]
	}
	stores := [][]byte{
		{0xF3, 0x41, 0x0F, 0x11, 0x19},       // movss [r9], xmm3
		{0xF3, 0x41, 0x0F, 0x11, 0x41, 0x04}, // movss [r9+4], xmm0
		{0xF3, 0x41, 0x0F, 0x11, 0x51, 0x08}, // movss [r9+8], xmm2
	}
	for i := range loads {
		code = append(code, loads[i]...)
		displacement := int32(bulletCaveTargetOffset + i*4 - (len(code) + 4))
		var buf [4]byte
		binary.LittleEndian.PutUint32(buf[:], uint32(displacement))
		code = append(code, buf[:]...)
		code = append(code, stores[i]...)
	}
	code = append(code, absoluteX64Jump(entry+uintptr(len(bulletOriginal)))...)
	if len(code) > bulletCaveTargetOffset {
		return nil, errors.New("trampoline overflow")
	}
	for len(code) < bulletCaveTargetOffset {
		code = append(code, 0x90)
	}
	code = append(code, xyz...)
	return code, nil
}
