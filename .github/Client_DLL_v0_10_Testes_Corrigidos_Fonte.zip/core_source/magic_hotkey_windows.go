//go:build windows

package main

import (
	"fmt"
	"sync"
	"time"
)

var magicKeyRuntime = struct {
	sync.RWMutex
	Key     string
	Event   string
	Held    bool
	Presses uint64
}{Key: "f7", Event: "Aguardando tecla configurada"}

func magicKeyStatus() map[string]any {
	magicKeyRuntime.RLock()
	defer magicKeyRuntime.RUnlock()
	return map[string]any{"key": magicKeyRuntime.Key, "event": magicKeyRuntime.Event,
		"held": magicKeyRuntime.Held, "presses": magicKeyRuntime.Presses}
}
func reportMagicKey(key, event string, held bool, pressedEdge bool) {
	magicKeyRuntime.Lock()
	magicKeyRuntime.Key = key
	magicKeyRuntime.Event = event
	magicKeyRuntime.Held = held
	if pressedEdge {
		magicKeyRuntime.Presses++
	}
	magicKeyRuntime.Unlock()
}

// Holding a configured keyboard/mouse key works like Aimbot/Silent Aim.
// No disk-write toggles; releasing or losing focus immediately disarms
// this module independently from the persistent UI enable switch.
func startMagicHotkey(s *service) {
	go func() {
        defer recoverServiceWorker("magic_hotkey_windows.go")
		ticker := time.NewTicker(20 * time.Millisecond)
		defer ticker.Stop()
		previousKey := ""
		wasActive := false
		for range ticker.C {
			if s.stopping.Load() {
				throughWallPressed(false)
				return
			}
			s.mu.Lock()
			key, collision, armed := parseMagicHotkeySettings(s.config)
			s.mu.Unlock()
			fg, _, _ := getForeground.Call()
			focused := activeFiveMWindow(fg)
			down := noclipKeyHeld(magicKeyVK(key))
			engaged := shouldEngageThroughWall(armed, down, focused, collision, overlayPaused.Load())
			throughWallPressed(engaged)
			changedKey := key != previousKey
			if changedKey || wasActive != engaged {
				var status string
				switch {
				case collision:
					status = "Tecla em conflito com outra funcao; escolha outra"
				case !armed:
					status = "Through Wall desligado no painel"
				case !focused:
					status = "Aguardando FiveM em primeiro plano"
				case overlayPaused.Load():
					status = "Feche o menu para usar a tecla"
				case engaged:
					status = fmt.Sprintf("Segurando %s: teste de penetração nativa da arma (não garante paredes)", key)
				default:
					status = fmt.Sprintf("Pronto: segure %s para ativar, solte para desativar", key)
				}
				reportMagicKey(key, status, engaged, engaged && !wasActive)
			}
			wasActive, previousKey = engaged, key
		}
	}()
}

func magicStatusWithKey(folder string) map[string]any {
	status := magicStatus(folder)
	status["hotkey"] = magicKeyStatus()
	return status
}
