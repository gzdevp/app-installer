package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestEssentialWorkerRecoversAndRetries(t *testing.T) {
	t.Setenv("TMPDIR", t.TempDir())
	attempts := 0
	guardedEssentialWorker("test-once", func() {
		attempts++
		if attempts == 1 {
			panic("temporary failure")
		}
	})
	if attempts != 2 {
		t.Fatalf("expected recovery and retry, got %d", attempts)
	}
	data, err := os.ReadFile(filepath.Join(os.TempDir(), "77-diagnostics.log"))
	if err != nil || !strings.Contains(string(data), "test-once") {
		t.Fatal("missing diagnostic")
	}
}
func TestOptionalWorkerPanicDoesNotPropagate(t *testing.T) {
	t.Setenv("TMPDIR", t.TempDir())
	func() { defer recoverServiceWorker("test-optional"); panic("temporary failure") }()
	data, err := os.ReadFile(filepath.Join(os.TempDir(), "77-diagnostics.log"))
	if err != nil || !strings.Contains(string(data), "test-optional") {
		t.Fatal("missing diagnostic")
	}
}
