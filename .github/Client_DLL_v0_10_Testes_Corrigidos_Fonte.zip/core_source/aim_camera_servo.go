//go:build windows

package main

import (
	"fmt"
	"math"
	"time"
)

// cameraHeadServo drives the camera using feedback from the REAL view matrix.
// It never guesses camera-memory offsets or writes to the game process.
// During calibration, it sends tiny vertical probes. We reproject the SAME
// stationary 3D head into the next matrix to isolate camera movement from
// the tracked player's movement. The sign and gain are observed, not guessed.
type cameraHeadServo struct {
	pid              uint32
	pending          bool
	ped              uint64
	head             vec3
	before           matrix44
	sentY            int32
	sentX            int32
	candidateSign    int
	votes            int
	sign             int
	gain             float64 // signed pixels of head displacement per positive mouse Y
	samples          int
	ignored          int
	noResponse       int
	fault            bool
	faultReason      string
	lastShiftY       float64
	wasReadyWhenSent bool
	recordedAt       time.Time
	wrongProbe       int
}

func (s *cameraHeadServo) reset(pid uint32) { *s = cameraHeadServo{pid: pid} }
func (s *cameraHeadServo) clearPending()    { s.pending = false }
func (s *cameraHeadServo) stop(reason string) {
	s.pending = false
	s.fault = true
	s.faultReason = reason
}
func (s *cameraHeadServo) ready() bool { return s.votes >= 2 && s.sign != 0 && s.gain >= .25 }

func (s *cameraHeadServo) status() string {
	if s.fault {
		if s.faultReason != "" {
			return "movimento vertical bloqueado: " + s.faultReason + " (solte a tecla para reiniciar)"
		}
		return "sem resposta verificável da câmera ao mouse; solte a tecla para reiniciar"
	}
	if s.ready() {
		return fmt.Sprintf("câmera calibrada · sinal %s · %.1f px/passo · %d amostras", map[bool]string{true: "invertido", false: "normal"}[s.sign < 0], s.gain, s.samples)
	}
	return fmt.Sprintf("calibrando resposta da câmera (%d/2 amostras)", s.votes)
}

// seeFrame compares the projection of one unchanged world position before and
// after our *single* mouse pulse. This does not use the target's latest 2D
// position, which can change because the other player moved.
func (s *cameraHeadServo) seeFrame(view matrix44, w, h int32) {
	if !s.pending || s.fault {
		return
	}
	// One mouse pulse must be matched to an actual later game-camera read.
	// The first 25 ms ESP frame can precede input consumption: consuming that
	// frame and immediately issuing another pulse caused uncontrolled buildup.
	elapsed := time.Since(s.recordedAt)
	if elapsed < 40*time.Millisecond {
		return
	}
	// No second SendInput until this specific pulse has been accounted for.
	// A dead camera never receives a stream of accumulated commands.
	if elapsed > 350*time.Millisecond {
		s.stop("a câmera não confirmou o movimento no prazo")
		return
	}
	s.pending = false
	oldX, oldY, okBefore := worldToScreen(s.before, s.head, w, h)
	newX, newY, okAfter := worldToScreen(view, s.head, w, h)
	if !okBefore || !okAfter || (s.sentY == 0 && s.sentX == 0) {
		// A head that disappears from view during a camera step is NOT a
		// valid feedback sample. Do not keep steering toward its last point.
		s.ignored++
		if s.ignored >= 2 {
			s.stop("posição da cabeça ou matriz ficou fora da tela")
		}
		return
	}
	dx, dy := newX-oldX, newY-oldY
	if math.Abs(dy) > 70 || math.Abs(dx) > 110 {
		s.stop("a câmera mudou demais após um único passo")
		return
	}
	// Aiming left/right also requires feedback. Previously, a horizontal-only
	// mouse move wasn't recorded, so the camera could run away sideways.
	// Compare the SAME world-space head against consecutive view matrices.
	if s.sentX != 0 {
		if math.Abs(dx) < 0.35 {
			s.stop("sem resposta horizontal confirmada ao movimento do mouse")
			return
		}
		oldErrorX := math.Abs(oldX - float64(w)/2)
		newErrorX := math.Abs(newX - float64(w)/2)
		if newErrorX > oldErrorX+0.75 {
			s.stop(fmt.Sprintf("câmera se afastou da cabeça no eixo X (%.0f→%.0f px)", oldErrorX, newErrorX))
			return
		}
	}
	// A pure horizontal movement must not be counted as an unsuccessful
	// vertical calibration attempt.
	if s.sentY == 0 {
		return
	}
	if math.Abs(dy) < .7 {
		// No way to tell whether FiveM ignored SendInput or whether the view
		// matrix belongs to an older frame. Both must stop further movement.
		s.stop("sem resposta mensurável da câmera a um único comando")
		return
	}
	s.noResponse = 0
	s.ignored = 0
	s.lastShiftY = dy

	// Calibrate ONLY from observed improvement. An inverted first probe may
	// worsen the aim by one mouse unit; allow exactly one opposite probe.
	// A second worsening or a reversal after calibration halts this key hold.
	beforeError := math.Abs(oldY - float64(h)/2)
	afterError := math.Abs(newY - float64(h)/2)
	response := -dy / float64(s.sentY)
	if math.Abs(response) < .25 || math.Abs(response) > 70 {
		s.stop("resposta vertical fora do intervalo confiável")
		return
	}
	orientation := 1
	if response < 0 {
		orientation = -1
	}
	if afterError > beforeError+0.75 {
		if s.wasReadyWhenSent || s.wrongProbe > 0 {
			s.stop(fmt.Sprintf("câmera se afastou da cabeça (erro %.0f→%.0f px)", beforeError, afterError))
			return
		}
		// Before any calibration, learn that the first probe went the wrong
		// way; change direction ONCE and verify that direction on next frame.
		s.wrongProbe++
		s.candidateSign = orientation
		s.votes = 1
		s.samples++
		return
	}
	if s.ready() && s.sign != orientation {
		s.stop("sentido vertical mudou durante o acompanhamento")
		return
	}
	if orientation != s.candidateSign {
		if s.votes != 0 {
			s.stop("amostras contraditórias: calibração rejeitada")
			return
		}
		s.candidateSign = orientation
		s.votes = 1
	} else if s.votes < 5 {
		s.votes++
	}
	if s.votes >= 2 {
		if s.sign != orientation {
			s.gain = math.Abs(response)
		} else {
			s.gain = .75*s.gain + .25*math.Abs(response)
		}
		s.sign = orientation
	}
	s.samples++
}

// command returns a bounded mouse movement for the newest valid projection.
// Uncalibrated Y uses just one mouse unit per frame; a bad camera response
// disables subsequent movements until the user releases the activation key.
func (s *cameraHeadServo) command(aim AimCandidate, w, h int32, smooth float64, invertHint bool) (dx, dy int32, reason string) {
	if !aim.RealBone || !plausibleFiveMPosition(aim.HeadWorld) {
		return 0, 0, "cabeça real indisponível"
	}
	if w < 320 || h < 240 || aim.X < 0 || aim.Y < 0 || aim.X >= w || aim.Y >= h {
		return 0, 0, "viewport ou projeção da cabeça inválidos"
	}
	if s.fault {
		return 0, 0, s.status()
	}
	if s.pending {
		return 0, 0, "aguardando confirmação da câmera antes de outro movimento"
	}
	errX := float64(aim.X) - float64(w)/2
	errY := float64(aim.Y) - float64(h)/2
	if math.Abs(errX) <= 2 && math.Abs(errY) <= 2 {
		return 0, 0, "cabeça centralizada"
	}
	if !s.ready() {
		// Never infer orientation just because Y is already close to center.
		// Calibrate with one-pixel pulses, and leave Y stationary when already
		// aligned. Small probes prevent an inverted game setting from pulling
		// the camera far down before we know which direction is correct.
		if math.Abs(errY) <= 6 {
			return boundedMouseStep(errX/math.Max(4, smooth), 1), 0, "cabeça na altura do centro; Y ainda sem calibração"
		}
		probeSign := 1
		if s.votes > 0 {
			probeSign = s.candidateSign // the measured Y response, not a guess
		} else if invertHint {
			probeSign = -1
		}
		dy = int32(probeSign)
		if errY < 0 {
			dy = -dy
		}
		return 0, dy, s.status()
	}
	if smooth < 1 {
		smooth = 1
	}
	if smooth > 20 {
		smooth = 20
	}
	fraction := math.Max(.14, math.Min(.80, 4.0/smooth))
	dx = boundedMouseStep(errX/smooth, 5)
	// response=-ΔheadScreenY/mouseY; invert response when the camera is inverted.
	dy = boundedMouseStep(errY*fraction/(float64(s.sign)*s.gain), 4)
	return dx, dy, s.status()
}

func boundedMouseStep(v float64, limit int32) int32 {
	if math.IsNaN(v) || math.IsInf(v, 0) {
		return 0
	}
	if v > float64(limit) {
		return limit
	}
	if v < -float64(limit) {
		return -limit
	}
	if math.Abs(v) < .4 {
		return 0
	}
	return int32(math.Round(v))
}

// record is kept for compatibility with the camera feedback tests.
func (s *cameraHeadServo) record(ped uint64, world vec3, before matrix44, dy int32) {
	s.recordXY(ped, world, before, 0, dy)
}

func (s *cameraHeadServo) recordXY(ped uint64, world vec3, before matrix44, dx, dy int32) {
	s.pending = ped != 0 && (dx != 0 || dy != 0)
	s.ped = ped
	s.head = world
	s.before = before
	s.sentX = dx
	s.sentY = dy
	s.wasReadyWhenSent = s.ready()
	s.recordedAt = time.Now()
}
