package main

import "testing"

func TestVehicleKeyMappingV68(t *testing.T) {
	cases := map[string]uint16{"L": 0x4C, "u": 0x55, "f1": 0x70, "F12": 0x7B, "NUM1": 0x61, "0": 0x30}
	for key, expected := range cases {
		got, ok := vehicleVK(key)
		if !ok || got != expected {
			t.Fatalf("key %q got %x, %v; want %x", key, got, ok, expected)
		}
	}
	for _, invalid := range []string{"", "CTRL+L", "ALT", "NUM10", "F13", "F0", "ENTER", "/LOCK", "ñ"} {
		if _, ok := vehicleVK(invalid); ok {
			t.Fatalf("invalid key accepted: %q", invalid)
		}
	}
}
