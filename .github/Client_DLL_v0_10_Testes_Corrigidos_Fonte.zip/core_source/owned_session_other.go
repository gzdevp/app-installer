//go:build !windows

package main

import (
	"os"
	"syscall"
)

func isUnsafeSessionReparsePoint(_ string, fi os.FileInfo) bool {
	return fi.Mode()&os.ModeSymlink != 0
}

func ownedProcessStillActive(pid int) bool {
	if pid <= 0 {
		return true
	}
	err := syscall.Kill(pid, 0)
	return err == nil || err == syscall.EPERM
}
