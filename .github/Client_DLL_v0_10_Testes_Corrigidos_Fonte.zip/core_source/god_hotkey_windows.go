//go:build windows

package main

import (
	"encoding/json"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type GodHotkeySettings struct {
	Enabled bool   `json:"enabled"`
	Key     string `json:"key"`
}

var godHotkeyState = struct {
	sync.RWMutex
	settings   GodHotkeySettings
	lastToggle string
}{settings: GodHotkeySettings{Enabled: false, Key: "f9"}}

func godHotkeySet(s GodHotkeySettings) {
	s.Key = strings.ToLower(strings.TrimSpace(s.Key))
	if !validBindingKey(s.Key) {
		s.Key = "f9"
	}
	godHotkeyState.Lock()
	godHotkeyState.settings = s
	godHotkeyState.Unlock()
}
func godHotkeyGet() map[string]any {
	godHotkeyState.RLock()
	defer godHotkeyState.RUnlock()
	return map[string]any{"enabled": godHotkeyState.settings.Enabled, "key": godHotkeyState.settings.Key, "lastToggle": godHotkeyState.lastToggle, "gameEffect": "not validated"}
}

// Key toggles the same preference stored by the UI and persists the setting.
// The v13.9.7 codebase does not contain a native God Mode effect; this routine
// deliberately does not claim to make the ped invulnerable.
func (s *service) toggleGodPreference() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	nextRaw, _, err := flipGodConfig(s.config)
	if err != nil {
		return err
	}
	if err = writeAtomic(filepath.Join(s.dir, "config.json"), nextRaw); err != nil {
		return err
	}
	s.config = json.RawMessage(nextRaw)
	applyNativeSettings(nextRaw)
	godHotkeyState.Lock()
	godHotkeyState.lastToggle = time.Now().Format("15:04:05")
	godHotkeyState.Unlock()
	return nil
}
func startGodHotkey(s *service) {
	go func() {
        defer recoverServiceWorker("god_hotkey_windows.go")
		ticker := time.NewTicker(35 * time.Millisecond)
		defer ticker.Stop()
		down := false
		for range ticker.C {
			if s.stopping.Load() {
				return
			}
			g := godHotkeyGet()
			key, _ := g["key"].(string)
			v, _, _ := getAsyncKeyState.Call(genericKeyVK(key, 0x78)) // F9 fallback
			pressed := v&0x8000 != 0
			// Transition from up to down only; held keys never repeat-toggle.
			if pressed && !down && !menuWanted.Load() {
				hwnd, _, _ := getForeground.Call()
				if activeFiveMWindow(hwnd) {
					_ = s.toggleGodPreference()
				}
			}
			down = pressed
		}
	}()
}
