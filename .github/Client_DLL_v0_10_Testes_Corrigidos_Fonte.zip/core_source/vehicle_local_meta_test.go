package main

import (
	"strings"
	"testing"
)

func TestLocalMetaHashMatchesGTAV(t *testing.T) {
	if got := joaatModelName("adder"); got != 3078201489 {
		t.Fatalf("adder hash: got %d", got)
	}
}
func TestLocalMetaReadsOnlyActualModels(t *testing.T) {
	xml := `<CVehicleModelInfo__InitDataList><InitDatas><Item><modelName>customr35</modelName><gameName>R35CUSTOM</gameName></Item><Item><modelName>adder</modelName></Item><Item><gameName>no_model</gameName></Item><Item><modelName>../../unsafe</modelName></Item></InitDatas></CVehicleModelInfo__InitDataList>`
	out := parseLocalVehicleMeta(strings.NewReader(xml))
	if out[joaatModelName("customr35")] != "customr35" {
		t.Fatal("custom model missing")
	}
	if out[joaatModelName("adder")] != "adder" {
		t.Fatal("stock model missing")
	}
	if len(out) != 2 {
		t.Fatalf("expected exactly 2 models, got %d", len(out))
	}
}
func TestCustomModelResolutionOnlyAfterLocalMeta(t *testing.T) {
	hash := joaatModelName("testaddonunique7")
	if _, ok := resolvedVehicleName(hash, nil); ok {
		t.Fatal("unexpected preexisting model")
	}
	inserted := rememberLocalVehicleMeta(strings.NewReader(`<Item><modelName>testaddonunique7</modelName></Item>`))
	if inserted != 1 {
		t.Fatalf("inserted %d", inserted)
	}
	name, ok := resolvedVehicleName(hash, nil)
	if !ok || name != "testaddonunique7" {
		t.Fatalf("got %q ok=%v", name, ok)
	}
}
