# sete7 v14 — leitura revisada para testes

Base: v14.1 externa com correções de veículos (29/10/2026).

## Alterações testáveis
- Vehicle ESP: o campo de hash do modelo é escolhido por concordância entre vários veículos reconhecidos, e não pela primeira coincidência. Leituras agrupadas em 16 bytes por modelo, sem escrever na memória. Se não houver evidência, conserva o deslocamento tradicional e não inventa o nome.
- Player ESP: suporte de leitura estrita ao campo legado 0xA4 nas builds b2699 e b2802. Os nomes continuam indisponíveis quando o FiveM não os expõe nesse formato; nenhum ID é anunciado como nome real.
- Preservados: interface, Friends, unlock por tecla, funções de arma. Nenhuma alteração nos mecanismos experimentais de FIX ou Through Wall.

## Limitações REAIS
- Nome Steam/FiveM verdadeiro: não garantido sem fonte de sessão autenticada e correspondência segura ao ped.
- Veículos adicionados por servidores: não é possível recuperar nome comercial apenas de um hash desconhecido. Exigem dados/metadados do veículo customizado.
- FIX/Unlock universal e colisão real do Through Wall NÃO estão implementados nem testados. Through Wall atual apenas muda o campo Penetration, que não equivale a balas atravessarem obstáculos.
- Sem verificação dentro do FiveM. Esta compilação é experimental e não deve ser apresentada como correção final das três funções.
