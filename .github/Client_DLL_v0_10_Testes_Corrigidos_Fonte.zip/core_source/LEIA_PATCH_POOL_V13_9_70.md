# sete7 v13.9.70 — melhoria de varredura dos veículos (não é correção universal)

Base: `sete7_v13_9_70_CORRECAO_FECHAMENTO_FONTE.zip` (callback fix estável).

Mudanças realizadas:
- A varredura do pool de veículos agora usa a **capacidade verificada**, e não somente a quantidade de veículos ativos. Os pools do jogo podem ser esparsos (slots vazios antes dos ocupados).
- A detecção inicial de um pool válido considera candidatos em qualquer posição dentro da capacidade, sem depender de os primeiros 64 slots conterem carros.
- Leitura de ponteiros em blocos, para evitar milhares de chamadas `ReadProcessMemory` por quadro quando há slots vazios.
- Checagem de vínculo com o pool, identificação de ocupantes e busca do carro próximo para a trava local usam a mesma varredura por capacidade.
- O limite de resultados foi elevado de 256 para 512 veículos, respeitando o teto já validado de carros ativos.

Validação executada:
- Compilação Windows amd64 do EXE GUI com `CGO_ENABLED=0`.
- Compilação do binário de testes Windows (não executado sem Windows).
- Testes puros no Linux de capacidade de pool esparso, incluindo contadores inválidos.

Limites importantes — **não foram resolvidos**:
- Obter nomes reais Steam/FiveM de todos os jogadores sem acesso autorizado às funções nativas da sessão.
- Resolver automaticamente modelos customizados que não estão no catálogo local ou não têm mapeamento.
- FIX CAR, trancar/destrancar qualquer carro em qualquer servidor; alterações locais podem ser anuladas pelo servidor.
- Atravessar realmente paredes, janelas e veículos com projéteis: código de Through Wall atual só altera um valor de penetração experimental e não modifica colisão nem valida o dano.
- Testes com FiveM aberto e todas as builds/cidades.

Esta é uma melhoria **pontual** da lista de veículos, não uma versão final das três funcionalidades. Preserve o backup da v13.9.70.
