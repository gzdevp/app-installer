//go:build windows

package main

import "time"

// A failed snapshot must not make every overlay box blink off for one refresh.
// A strictly bounded per-entity hold smooths occasional sparse/partial reads.
// Coordinates are never guessed or extrapolated; the same original box and
// skeleton segments are retained as one coherent unit for at most 90ms.
const espHoldTime = 90 * time.Millisecond

type stablePed struct {
	target   targetESP
	seen     time.Time // last fresh body projection
	realSeen time.Time // last authentic joint read, never extended by fallback
}

type espStabilizer struct {
	viewport espViewport
	entities map[uint64]stablePed
}

func (s *espStabilizer) reset() {
	s.viewport = espViewport{}
	s.entities = nil
}

func (s *espStabilizer) sameViewport(v espViewport) bool {
	return s.viewport == v && v.PID != 0 && v.W > 0 && v.H > 0
}

func (s *espStabilizer) merge(now time.Time, vp espViewport, fresh []targetESP) []targetESP {
	if !s.sameViewport(vp) {
		s.reset()
		s.viewport = vp
	}
	if s.entities == nil {
		s.entities = make(map[uint64]stablePed, len(fresh)+8)
	}
	output := make([]targetESP, 0, len(fresh)+len(s.entities))
	for _, t := range fresh {
		if t.PedID == 0 { // unknown id cannot be safely held
			output = append(output, t)
			continue
		}
		// Preserve a briefly missing real pose without extending its lifetime.
		// A failed joint read must not swap back and forth between a guessed
		// skeleton and authentic joints on successive frames.
		realSeen := time.Time{}
		if t.AimFromBone {
			realSeen = now
		} else if prev, ok := s.entities[t.PedID]; ok && prev.target.AimFromBone &&
			!prev.realSeen.IsZero() && !now.Before(prev.realSeen) &&
			now.Sub(prev.realSeen) <= espHoldTime {
			dx, dy := t.X-prev.target.X, t.Y-prev.target.Y
			if dx < 120 && dx > -120 && dy < 120 && dy > -120 {
				if len(t.Bones) > 0 && len(prev.target.Bones) > 0 {
					t.Bones = make([][4]int32, len(prev.target.Bones))
					for i, line := range prev.target.Bones {
						t.Bones[i] = [4]int32{line[0] + dx, line[1] + dy, line[2] + dx, line[3] + dy}
					}
				}
				t.AimX, t.AimY = prev.target.AimX+dx, prev.target.AimY+dy
				t.AimFromBone = true
				realSeen = prev.realSeen
			}
		}
		s.entities[t.PedID] = stablePed{target: t, seen: now, realSeen: realSeen}
		output = append(output, t)
	}
	for id, prev := range s.entities {
		if now.Sub(prev.seen) > espHoldTime || now.Before(prev.seen) {
			delete(s.entities, id)
			continue
		}
		if prev.seen != now {
			output = append(output, prev.target)
		}
	}
	return output
}

// A hard read failure can reuse a recent snapshot briefly without extending
// its age. Never keep an old frame when the viewport or game PID has changed.
func (s *espStabilizer) hold(now time.Time, vp espViewport) []targetESP {
	if !s.sameViewport(vp) {
		s.reset()
		return nil
	}
	return s.merge(now, vp, nil)
}
