//go:build windows

package main

import (
	"math"
	"strings"
	"testing"
	"time"
)

// Projection matrix: depth remains 1, vertical camera response is represented
// by a tiny translation. This tests the feedback logic, not the real FiveM API.
func syntheticCam(yOffset float32) matrix44 {
	var m matrix44
	m[15] = 1
	m[14] = .38 + yOffset // baseline projects the stationary head at about Y=335 (1080p)
	return m
}

func TestCameraServoLearnsNormalYDirection(t *testing.T) {
	s := cameraHeadServo{pid: 42}
	aim := AimCandidate{ID: 3, X: 1000, Y: 335, RealBone: true, HeadWorld: vec3{X: 15, Y: 10, Z: 25}}
	for i := 0; i < 2; i++ {
		dx, dy, _ := s.command(aim, 1920, 1080, 10, false)
		if dx != 0 || dy != -1 {
			t.Fatalf("probe=(%d,%d)", dx, dy)
		}
		s.record(aim.ID, aim.HeadWorld, syntheticCam(0), dy)
		s.recordedAt = time.Now().Add(-70 * time.Millisecond)
		s.seeFrame(syntheticCam(-.0074), 1920, 1080) // Y=-1 -> head moves DOWN (normal response)
	}
	if !s.ready() || s.sign != 1 || math.Abs(s.gain-4.0) > 0.15 {
		t.Fatalf("normal response: %+v", s)
	}
	dx, dy, _ := s.command(aim, 1920, 1080, 10, false)
	if dx <= 0 || dy >= 0 || math.Abs(float64(dy)) > 12 {
		t.Fatalf("unexpected command %d %d", dx, dy)
	}
}

func TestCameraServoLearnsInvertedYDirection(t *testing.T) {
	s := cameraHeadServo{pid: 42}
	aim := AimCandidate{ID: 3, X: 960, Y: 335, RealBone: true, HeadWorld: vec3{X: 15, Y: 10, Z: 25}}
	for i := 0; i < 2; i++ {
		_, dy, _ := s.command(aim, 1920, 1080, 10, false)
		s.record(aim.ID, aim.HeadWorld, syntheticCam(0), dy)
		s.recordedAt = time.Now().Add(-70 * time.Millisecond)
		if dy == -1 {
			s.seeFrame(syntheticCam(.0074), 1920, 1080) // first negative probe is wrong
		} else {
			s.seeFrame(syntheticCam(-.0074), 1920, 1080) // second positive probe improves aim
		}
	}
	if !s.ready() || s.sign != -1 {
		t.Fatalf("failed to learn inversion: %+v", s)
	}
	_, dy, _ := s.command(aim, 1920, 1080, 10, false)
	if dy <= 0 {
		t.Fatalf("should counteract inverted axis, dy=%d", dy)
	}
}

func TestCameraServoStopsOnUnresponsiveCamera(t *testing.T) {
	s := cameraHeadServo{pid: 42}
	aim := AimCandidate{ID: 3, X: 960, Y: 335, RealBone: true, HeadWorld: vec3{X: 15, Y: 10, Z: 25}}
	_, dy, _ := s.command(aim, 1920, 1080, 10, false)
	if dy == 0 {
		t.Fatal("expected single calibration probe")
	}
	s.record(aim.ID, aim.HeadWorld, syntheticCam(0), dy)
	s.recordedAt = time.Now().Add(-70 * time.Millisecond)
	s.seeFrame(syntheticCam(0), 1920, 1080)
	dx, dy, status := s.command(aim, 1920, 1080, 1, false)
	if dx != 0 || dy != 0 || !s.fault || !strings.Contains(status, "sem resposta") {
		t.Fatalf("didn't stop after a missing camera response: %+v %d %d %s", s, dx, dy, status)
	}
}

func TestCameraServoRejectsInvalidTargetWithoutMouse(t *testing.T) {
	s := cameraHeadServo{pid: 42}
	aim := AimCandidate{ID: 3, X: 960, Y: 335, RealBone: false}
	dx, dy, _ := s.command(aim, 1920, 1080, 1, false)
	if dx != 0 || dy != 0 {
		t.Fatalf("invalid head moved cursor %d %d", dx, dy)
	}
}

func TestCameraServoBlocksWhenCameraMovesAwayFromHead(t *testing.T) {
	s := cameraHeadServo{pid: 42}
	aim := AimCandidate{ID: 3, X: 960, Y: 335, RealBone: true, HeadWorld: vec3{X: 15, Y: 10, Z: 25}}
	// 2 successful tiny probes calibrate a normal Y axis.
	for i := 0; i < 2; i++ {
		_, dy, _ := s.command(aim, 1920, 1080, 10, false)
		s.record(aim.ID, aim.HeadWorld, syntheticCam(0), dy)
		s.recordedAt = time.Now().Add(-70 * time.Millisecond)
		s.seeFrame(syntheticCam(-.0074), 1920, 1080)
	}
	if !s.ready() {
		t.Fatal("should calibrate")
	}
	// First full correction sent. Next observed camera matrix sends the head
	// UP and AWAY from the center, as reported by the user.
	_, dy, _ := s.command(aim, 1920, 1080, 10, false)
	if dy >= 0 {
		t.Fatalf("expected upward command got %d", dy)
	}
	s.record(aim.ID, aim.HeadWorld, syntheticCam(0), dy)
	s.recordedAt = time.Now().Add(-70 * time.Millisecond)
	s.seeFrame(syntheticCam(.0074), 1920, 1080)
	if !s.fault {
		t.Fatal("must block as soon as correction worsens vertical error")
	}
	dx, dy, _ := s.command(aim, 1920, 1080, 1, false)
	if dx != 0 || dy != 0 {
		t.Fatal("blocked servo moved the camera")
	}
}

func TestCameraServoRejectsLargeOneStepMotion(t *testing.T) {
	s := cameraHeadServo{pid: 42}
	aim := AimCandidate{ID: 3, X: 960, Y: 335, RealBone: true, HeadWorld: vec3{X: 15, Y: 10, Z: 25}}
	_, dy, _ := s.command(aim, 1920, 1080, 10, false)
	s.record(aim.ID, aim.HeadWorld, syntheticCam(0), dy)
	s.recordedAt = time.Now().Add(-70 * time.Millisecond)
	s.seeFrame(syntheticCam(.2), 1920, 1080)
	if !s.fault {
		t.Fatal("must block large untrusted view shifts")
	}
}

func TestCameraServoNeverAssumesNormalYWithoutProbe(t *testing.T) {
	s := cameraHeadServo{pid: 42}
	aim := AimCandidate{ID: 3, X: 1030, Y: 540, RealBone: true, HeadWorld: vec3{X: 15, Y: 10, Z: 25}}
	_, dy, _ := s.command(aim, 1920, 1080, 10, false)
	if dy != 0 || s.ready() {
		t.Fatal("a centered head must not silently assume a vertical orientation")
	}
}
