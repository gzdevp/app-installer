# 77 v13.9.63 — Correção de atraso e travamento visual do ESP

- Corrigido o intervalo efetivo de desenho: o controle anterior de 33ms consultado por ticker de 16ms podia renderizar apenas a cada ~48ms.
- Agora a camada é redesenhada somente quando o leitor publica um novo quadro ESP/radar, com teto de 60Hz para evitar BitBlt desnecessário.
- Verificação de novas posições a cada 8ms (não significa 125 desenhos/segundo), diminuindo a espera entre leitura e apresentação.
- FOV e mira fixa permanecem orientados a mudanças, sem redesenhar continuamente.
- Quadros vazios também invalidam a tela para apagar boxes de entidades que desapareceram.
- Não alterados leitura das posições, projeção, ossos, Silent Aim, Aimbot, login, Cleaner nem encerramento do painel.

## Verificação
- Testes unitários de cadência/limite, teste do build Windows (compilação), análise de sintaxe.
- Sem ambiente FiveM para medir FPS/latência in-game. O ganho depende também do custo de scan do processo.
