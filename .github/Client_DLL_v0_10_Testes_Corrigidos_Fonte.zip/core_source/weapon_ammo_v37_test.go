package main

import "testing"

func TestWeaponNoReloadAmmoRanges(t *testing.T) {
	for _, v := range []uint32{1, 6, 30, 100, 300} {
		if !weaponClipCapacityPlausible(v) {
			t.Fatal(v)
		}
	}
	for _, v := range []uint32{0, 301, 9999} {
		if weaponClipCapacityPlausible(v) {
			t.Fatal(v)
		}
	}
	if !weaponReservePlausible(9999) || weaponReservePlausible(30001) {
		t.Fatal("reserve range")
	}
	if !weaponReloadTimerPlausible(-1) || !weaponReloadTimerPlausible(0.001) || weaponReloadTimerPlausible(-2) {
		t.Fatal("reload timers")
	}
	if weaponClipSizeOffset != 0x70 || weaponAmmoInfoOffset != 0x60 {
		t.Fatal("layout")
	}
}
