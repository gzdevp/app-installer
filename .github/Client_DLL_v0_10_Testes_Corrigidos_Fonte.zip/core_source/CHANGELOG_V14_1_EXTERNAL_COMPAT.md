# sete7 v14.1 External — correções reais de compatibilidade e estabilidade

Base: v14 externa acionada por tecla (sem recursos FiveM).

## Corrigido
- A varredura de personagens percorre **todos os slots validados** do pool antes de limitar a lista a 256 candidatos, em vez de parar nos 256 primeiros encontrados. Prioriza jogadores de rede e indivíduos mais próximos.
- A identificação do pool de veículos agora compara os candidatos e prioriza evidências de modelos GTA V conhecidos e hashes legíveis, não a primeira posição plausível. Rejeita pools somente com coordenadas sem hash de modelo.
- A conexão ignora processos FiveM inacessíveis/sem módulo encontrado e continua procurando outra instância suportada, em vez de desistir prematuramente.
- Toda leitura de memória verifica também o **fim do intervalo**, para reduzir erros em endereços inválidos.
- Nenhuma mudança em DLLs, hook de renderização, interface principal, comandos ou formato de EXE único. Nenhuma alteração experimental em offsets de escrita.

## Validação realizada
- Compilação Windows x64 sem janela de console (`-H windowsgui`).
- `go vet` com GOOS=windows e GOARCH=amd64.
- Compilação de todo o conjunto de testes para Windows.
- Cinco testes isolados executados em Linux para seleção dos peds, pool de veículos e limites de endereços; incluem pool de 320 personagens.

## Limites expressos
- Perfis **experimentais** de leitura disponíveis: b2699, b2802, b2944, b3095, b3258, b3323, b3407.
- b3570, b3751, b3889 e outras builds sem layout validado são reconhecidas como não suportadas; não foram copiados offsets entre builds.
- Nomes Steam/FiveM em todas as cidades, FIX CAR/Unlock em qualquer veículo e Through Wall com atravessamento real de obstáculos **não estão demonstrados** pelo executável externo.
- FIX/Lock/Unlock local permanece experimental na b3258; Through Wall é alteração local de penetração da arma, sem garantia de atravessamento nem dano reconhecido pelo servidor.
- **Não testado no FiveM real** neste ambiente. Mantenha backup da v14 anterior.
