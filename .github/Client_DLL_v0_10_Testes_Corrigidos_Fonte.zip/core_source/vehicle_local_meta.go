package main

import (
	"bufio"
	"bytes"
	"encoding/xml"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// A read-only fallback for unpacked FiveM vehicles.meta resources installed
// locally. It never inspects process memory and does not guess custom models
// from a numeric hash. Server-owned/encrypted cache resources are not readable.
var localMetaScanMu sync.Mutex
var localMetaLastScan atomic.Int64

// Resource downloads may finish after the overlay has started. Avoid polling
// the disk each ESP frame; retry at most once every three minutes, only if an
// as-yet unidentified vehicle was actually observed.
func maybeRefreshLocalVehicleMetas() {
	last := localMetaLastScan.Load()
	if last != 0 && time.Since(time.Unix(0, last)) < 3*time.Minute {
		return
	}
	if localMetaScanMu.TryLock() {
		localMetaLastScan.Store(time.Now().UnixNano())
		localMetaScanMu.Unlock()
		go scanReadableLocalVehicleMetas()
	}
}

var localVehicleNames = struct {
	sync.RWMutex
	names map[uint32]string
}{names: make(map[uint32]string)}

// GTA's GET_HASH_KEY uses the case-insensitive Jenkins one-at-a-time hash.
func joaatModelName(name string) uint32 {
	var h uint32
	for _, b := range []byte(strings.ToLower(strings.TrimSpace(name))) {
		h += uint32(b)
		h += h << 10
		h ^= h >> 6
	}
	h += h << 3
	h ^= h >> 11
	h += h << 15
	return h
}

func validMetaModelName(s string) bool {
	if len(s) < 2 || len(s) > 64 {
		return false
	}
	for _, r := range s {
		if !((r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r == '_' || r == '-') {
			return false
		}
	}
	return true
}

// A vehicles.meta gameName can be an untranslated GXT label. Prefer the
// verified spawn/modelName rather than presenting the GXT key as a brand.
func parseLocalVehicleMetaRows(reader io.Reader) map[uint32]localMetaModel {
	d := xml.NewDecoder(io.LimitReader(reader, 4<<20))
	result := map[uint32]localMetaModel{}
	for {
		token, err := d.Token()
		if err != nil {
			break
		}
		el, ok := token.(xml.StartElement)
		if !ok || el.Name.Local != "Item" {
			continue
		}
		var item struct {
			Model    string `xml:"modelName"`
			GameName string `xml:"gameName"`
		}
		if d.DecodeElement(&item, &el) != nil {
			continue
		}
		model := strings.TrimSpace(item.Model)
		if !validMetaModelName(model) {
			continue
		}
		if len(result) < 4096 {
			result[joaatModelName(model)] = localMetaModel{Model: model, GameName: item.GameName}
		}
	}
	return result
}

func parseLocalVehicleMeta(reader io.Reader) map[uint32]string {
	rows := parseLocalVehicleMetaRows(reader)
	result := make(map[uint32]string, len(rows))
	for key, row := range rows {
		result[key] = localModelDisplayName(row, nil)
	}
	return result
}

func rememberLocalVehicleMeta(reader io.Reader) int {
	fresh := parseLocalVehicleMeta(reader)
	localVehicleNames.Lock()
	defer localVehicleNames.Unlock()
	if localVehicleNames.names == nil {
		localVehicleNames.names = map[uint32]string{}
	}
	inserted := 0
	for key, name := range fresh {
		if _, exists := localVehicleNames.names[key]; !exists {
			inserted++
		}
		localVehicleNames.names[key] = name
	}
	return inserted
}

func storedLocalVehicleName(hash uint32) (string, bool) {
	localVehicleNames.RLock()
	n, ok := localVehicleNames.names[hash]
	localVehicleNames.RUnlock()
	return n, ok
}

// This optional scan only touches files in FiveM's own local resource areas.
// Caps avoid blocking the overlay in installations with very large caches.
// FiveM downloads server resources under data/server-cache and
// data/server-cache-priv, NOT only data/cache. Both locations may contain
// packaged files, which deliberately remain unsupported by this read-only
// scanner. Prefer actual resource caches before generic browser cache.
func localVehicleMetaRoots(local string) []string {
	if strings.TrimSpace(local) == "" {
		return nil
	}
	base := filepath.Join(local, "FiveM", "FiveM.app")
	return []string{
		filepath.Join(base, "mods"),
		filepath.Join(base, "data", "server-cache"),
		filepath.Join(base, "data", "server-cache-priv"),
		filepath.Join(base, "data", "cache"),
	}
}

func scanReadableLocalVehicleMetas() {
	if !localMetaScanMu.TryLock() {
		return
	}
	defer localMetaScanMu.Unlock()
	localMetaLastScan.Store(time.Now().UnixNano())
	roots := localVehicleMetaRoots(os.Getenv("LOCALAPPDATA"))
	type namedRow struct {
		source string
		model  localMetaModel
	}
	models := make(map[uint32][]namedRow)
	translations := make(map[string]map[string]string)
	total, metaFiles, scriptFiles := 0, 0, 0
	for _, root := range roots {
		if _, err := os.Stat(root); err != nil {
			continue
		}
		_ = filepath.WalkDir(root, func(path string, info os.DirEntry, err error) error {
			if err != nil || info == nil {
				return nil
			}
			total++
			if total > 25000 {
				return filepath.SkipAll
			}
			if info.IsDir() {
				return nil
			}
			ext := strings.ToLower(filepath.Ext(info.Name()))
			if ext != ".meta" && ext != ".lua" {
				return nil
			}
			stat, err := info.Info()
			if err != nil || stat.Size() > 4<<20 {
				return nil
			}
			rel, err := filepath.Rel(root, path)
			if err != nil {
				return nil
			}
			parts := strings.Split(rel, string(filepath.Separator))
			// Isolate the labels to the same downloaded resource to avoid
			// mapping a model to a different city's unrelated GXT key.
			source := filepath.Join(root, parts[0])
			if ext == ".lua" {
				if scriptFiles >= 2000 || stat.Size() > 512<<10 {
					return nil
				}
				scriptFiles++
				f, err := os.Open(path)
				if err != nil {
					return nil
				}
				found := parseLocalTextEntries(f)
				_ = f.Close()
				if len(found) > 0 {
					if translations[source] == nil {
						translations[source] = make(map[string]string)
					}
					for k, v := range found {
						translations[source][k] = v
					}
				}
				return nil
			}
			if metaFiles >= 3000 {
				return nil
			}
			metaFiles++
			f, err := os.Open(path)
			if err != nil {
				return nil
			}
			reader := bufio.NewReaderSize(f, 4096)
			prefix, _ := reader.Peek(4096)
			if bytes.Contains(prefix, []byte("<CVehicleModelInfo__InitDataList")) {
				for hash, model := range parseLocalVehicleMetaRows(reader) {
					if len(models) < 4096 && len(models[hash]) < 16 {
						models[hash] = append(models[hash], namedRow{source: source, model: model})
					}
				}
			}
			_ = f.Close()
			return nil
		})
		if total > 25000 {
			break
		}
	}
	localVehicleNames.Lock()
	if localVehicleNames.names == nil {
		localVehicleNames.names = map[uint32]string{}
	}
	for hash, rows := range models {
		if len(rows) == 0 {
			continue
		}
		label := localModelDisplayName(rows[0].model, translations[rows[0].source])
		// FiveM can cache multiple cities at once. The same spawn model may
		// have different AddTextEntry descriptions in different cities; never
		// show a randomly chosen name from an unrelated server cache.
		for _, row := range rows[1:] {
			if localModelDisplayName(row.model, translations[row.source]) != label {
				label = rows[0].model.Model // unambiguous spawn name only
				break
			}
		}
		localVehicleNames.names[hash] = label
	}
	localVehicleNames.Unlock()
}
