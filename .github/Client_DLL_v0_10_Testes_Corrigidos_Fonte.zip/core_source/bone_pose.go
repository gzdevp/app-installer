package main

import (
	"encoding/binary"
	"math"
)

// bonePoseFromLocal transforms the 9 joints supplied in the C++ Ped base.
// The data layout is 9 Vector3 fields with four bytes of alignment padding
// between joints. Positions are local to the ped matrix (row-vector layout).
// No joints are fabricated. This pure function is unit-tested separately.
func bonePoseFromLocal(raw []byte, transform matrix44, origin vec3, view matrix44, w, h int32) ([][4]int32, [2]int32, bool) {
	segments, screen, _, ok := bonePoseFromLocalWorld(raw, transform, origin, view, w, h)
	return segments, screen, ok
}

func bonePoseFromLocalWorld(raw []byte, transform matrix44, origin vec3, view matrix44, w, h int32) ([][4]int32, [2]int32, vec3, bool) {
	if len(raw) < 9*16-4 {
		return nil, [2]int32{}, vec3{}, false
	}
	var projected [9][2]int32
	var valid [9]bool
	var world [9]vec3
	for i := 0; i < 9; i++ {
		off := i * 16
		v := vec3{
			X: math.Float32frombits(binary.LittleEndian.Uint32(raw[off : off+4])),
			Y: math.Float32frombits(binary.LittleEndian.Uint32(raw[off+4 : off+8])),
			Z: math.Float32frombits(binary.LittleEndian.Uint32(raw[off+8 : off+12])),
		}
		if !poseFinite(v.X) || !poseFinite(v.Y) || !poseFinite(v.Z) {
			continue
		}
		point := vec3{
			X: v.X*transform[0] + v.Y*transform[4] + v.Z*transform[8] + transform[12],
			Y: v.X*transform[1] + v.Y*transform[5] + v.Z*transform[9] + transform[13],
			Z: v.X*transform[2] + v.Y*transform[6] + v.Z*transform[10] + transform[14],
		}
		if !plausibleFiveMPosition(point) || poseDist(point, origin) > 3.5 {
			continue
		}
		sx, sy, ok := worldToScreen(view, point, w, h)
		if !ok {
			continue
		}
		projected[i] = [2]int32{int32(math.Round(sx)), int32(math.Round(sy))}
		valid[i], world[i] = true, point
	}
	// Reject wrong bone-layout guesses; one plausible coordinate is not a pose.
	if !valid[0] || !valid[7] || !valid[8] ||
		world[0].Z <= world[8].Z+0.20 ||
		poseDist(world[0], world[8]) < 0.35 || poseDist(world[0], world[8]) > 2.6 ||
		poseDist(world[0], world[7]) > 1.0 {
		return nil, [2]int32{}, vec3{}, false
	}
	connections := [...][2]int{
		{0, 7}, {7, 8}, {7, 5}, {7, 6}, {8, 3}, {3, 1}, {8, 4}, {4, 2},
	}
	segments := make([][4]int32, 0, len(connections))
	for _, edge := range connections {
		a, b := edge[0], edge[1]
		if !valid[a] || !valid[b] {
			continue
		}
		aa, bb := projected[a], projected[b]
		length := math.Hypot(float64(aa[0]-bb[0]), float64(aa[1]-bb[1]))
		if length < 1 || length > float64(h)*.40 {
			continue
		}
		segments = append(segments, [4]int32{aa[0], aa[1], bb[0], bb[1]})
	}
	if len(segments) < 3 {
		return nil, [2]int32{}, vec3{}, false
	}
	return segments, projected[0], world[0], true
}

func poseFinite(x float32) bool {
	return !math.IsNaN(float64(x)) && !math.IsInf(float64(x), 0) && math.Abs(float64(x)) < 1000000
}
func poseDist(a, b vec3) float64 {
	x, y, z := float64(a.X-b.X), float64(a.Y-b.Y), float64(a.Z-b.Z)
	return math.Sqrt(x*x + y*y + z*z)
}
