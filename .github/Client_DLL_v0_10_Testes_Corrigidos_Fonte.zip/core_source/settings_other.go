//go:build !windows

package main

import "encoding/json"

func applyNativeSettings(_ json.RawMessage) {}
func nativeStatus() any                     { return map[string]any{"engineConnected": false} }
