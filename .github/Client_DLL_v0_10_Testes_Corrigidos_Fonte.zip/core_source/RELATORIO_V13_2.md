# sete7 v13.2 — revisão do Aimbot (compilação experimental)
Data: 2026-10-27

## Comparação com as bases fornecidas
- O trecho C/C++ colado no chat (`gta_util.h`, `SetGameplayCamRot`, `GetPlayerHeadPosition`) é pseudocódigo incompleto. Ele mistura orientação angular, vetor unitário e posição e não pode ser vinculado ao EXE externo.
- Na base FivemSDK/C++ fornecida, `ProcessCameraMovement` obtém o follow-camera via `CamGameplayDirector + 0x3C0`, usa `+0x60` como referência da mira, lê `+0x40` e `+0x3D0` como vetores e grava ambos. A v13.1 já usava esse caminho, com interpolação e limite de passo adicionais.
- Não há evidência de que a implementação do executável Liphezin esteja presente integralmente e de modo reconstituível nas fontes fornecidas aqui; não declaramos que ela foi copiada.

## Erros corrigidos a partir da v13.1
1. `FrameGate` comparava cada amostra nova apenas à posição anterior ao comando: a sequência 100 → 80 → 98 px era **falsamente aprovada**. Agora compara amostras novas de maneira monotônica e bloqueia regressão (teste específico).
2. O código confiava apenas na direção de um vetor da memória para associar uma câmera ao viewport. `RayCentered` também compara a origem/direção com a matriz da projeção real em dois pontos sobre o eixo óptico; leituras contraditórias bloqueiam a escrita (testes específicos).
3. Identificação do painel atualizada para v13.2, sem alterar configuração existente, layout ou hotkeys.

## Resultado e limites
- Testes nativos de matemática e validação de feedback no pacote `aimv13` executados no Linux.
- EXE Windows x64 compilado; testes Windows podem ser apenas cross-compilados, não executados aqui.
- A precisão de offsets em um FiveM real, os ponteiros retornados e a resposta real da câmera NÃO foram comprovados neste ambiente.
- `silent_windows.go`, `silent_patch.go`, `silent_other.go`, `noclip_windows.go`, `esp_windows.go`, `cpp_bones.go` preservados byte a byte.
- Esta versão NÃO está HOMOLOGADA nem tem garantia de não mirar para o chão em FiveM. Quando os dados não concordarem, o comportamento esperado é bloquear o movimento e reportar o motivo, não corrigir às cegas.
