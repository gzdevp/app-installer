//go:build windows

package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
)

type ownedBrowser struct {
	process *os.Process
	job     syscall.Handle
}

var sessionBrowsersMu sync.Mutex
var sessionBrowsers []ownedBrowser

// After our app exits, terminate only the browser instances that this
// process started with its private temporary profile.
func stopSessionBrowsers() {
	sessionBrowsersMu.Lock()
	browsers := sessionBrowsers
	sessionBrowsers = nil
	sessionBrowsersMu.Unlock()
	for _, browser := range browsers {
		// Closing a successfully assigned job also stops Chromium children.
		closeOwnedBrowserJob(browser.job)
		if browser.process == nil {
			continue
		}
		// Root-process kill remains the fallback where job assignment failed.
		_ = browser.process.Kill()
		_, _ = browser.process.Wait()
		_ = browser.process.Release()
	}
}

// Chromium changes its top-level caption during app startup. A window
// belonging to the exact Edge/Chrome process we launched is a stronger
// identifier than its title and avoids attaching personal browser windows.
func isSessionBrowserPID(pid uint32) bool {
	if pid == 0 {
		return false
	}
	sessionBrowsersMu.Lock()
	defer sessionBrowsersMu.Unlock()
	for _, browser := range sessionBrowsers {
		if browser.process != nil && browser.process.Pid == int(pid) {
			return true
		}
	}
	return false
}

// The browser UI is deliberately launched only on an INSERT request while
// FiveM is foreground. STARTF_USESHOWWINDOW (SW_HIDE) and offscreen placement
// provide defense in depth while its window is reparented into our hidden host.
func openAppWindow(url string) error {
	return openAppWindowMode(url, true)
}

func openAppWindowMode(url string, incognito bool) error {
	roots := []string{os.Getenv("PROGRAMFILES(X86)"), os.Getenv("PROGRAMFILES"), os.Getenv("LOCALAPPDATA")}
	var candidates []string
	for _, r := range roots {
		if r != "" {
			// Prefer Chrome's dedicated Incognito app window when available.
			// Edge's --inprivate + --app combination fails on some releases,
			// so its fallback uses the already isolated disposable profile.
			candidates = append(candidates, filepath.Join(r, "Google", "Chrome", "Application", "chrome.exe"), filepath.Join(r, "Microsoft", "Edge", "Application", "msedge.exe"))
		}
	}
	for _, name := range []string{"chrome.exe", "msedge.exe"} {
		if bin, e := exec.LookPath(name); e == nil {
			candidates = append(candidates, bin)
		}
	}
	for _, bin := range candidates {
		if st, e := os.Stat(bin); e != nil || st.IsDir() {
			continue
		}
		// Isolated profile prevents an already-running personal Edge/Chrome
		// instance from swallowing startup window flags for this app.
		profile := filepath.Join(dataFolder(), "browser-profile")
		args := browserAppArguments(bin, profile, url, incognito)
		cmd := exec.Command(bin, args...)
		// No shell window/console. This is a standard hidden-window startup,
		// not process concealment or anti-cheat manipulation.
		cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
		if err := cmd.Start(); err != nil {
			return err
		}
		job := attachOwnedBrowserJob(cmd.Process)
		sessionBrowsersMu.Lock()
		sessionBrowsers = append(sessionBrowsers, ownedBrowser{process: cmd.Process, job: job})
		sessionBrowsersMu.Unlock()
		return nil
	}
	return fmt.Errorf("Edge ou Chrome nao encontrado")
}

// privateAppArguments starts a one-session browser with no shared personal
// profile. Chrome supports Incognito for this isolated app launch; Edge stays
// in the disposable profile because --inprivate + --app can prevent startup.
// Both paths have their entire temporary browser profile removed on exit.
func privateAppArguments(binary, profile, url string) []string {
	return browserAppArguments(binary, profile, url, true)
}

func browserAppArguments(binary, profile, url string, private bool) []string {
	args := []string{"--user-data-dir=" + profile}
	if private && strings.EqualFold(filepath.Base(binary), "chrome.exe") {
		args = append(args, "--incognito")
	}
	return append(args, "--app="+url,
		"--window-size=1120,740",
		"--window-position=-32000,-32000",
		"--start-minimized", "--no-first-run", "--no-default-browser-check")
}
