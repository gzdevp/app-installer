//go:build !windows

package main

func triggerSet(s TriggerSettings) {}
func triggerEnabled() bool         { return false }
func triggerGet() map[string]any   { return map[string]any{"status": "Somente Windows"} }
func startTriggerbot()             {}
