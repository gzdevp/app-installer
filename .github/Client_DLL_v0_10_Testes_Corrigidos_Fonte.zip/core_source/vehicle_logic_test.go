package main

import "testing"

func TestVehicleHealthGuard(t *testing.T) {
	for _, v := range []vehicleHealthValues{{500, 700, 800}, {-150, 1, 1000}} {
		if !vehicleHealthPlausible(v) {
			t.Fatalf("should allow %v", v)
		}
	}
	for _, v := range []vehicleHealthValues{{0, 0, 0}, {20000, 200, 500}, {-150, 3000, 500}} {
		if vehicleHealthPlausible(v) {
			t.Fatalf("should reject %v", v)
		}
	}
	if !vehicleCloseEnough(3) || vehicleCloseEnough(9) || vehicleCloseEnough(-1) {
		t.Fatal("proximity gate")
	}
}
func TestPenetrationGuard(t *testing.T) {
	if !penetrationPlausible(1) || penetrationPlausible(-1) || penetrationPlausible(1000) {
		t.Fatal("penetration gate")
	}
}
