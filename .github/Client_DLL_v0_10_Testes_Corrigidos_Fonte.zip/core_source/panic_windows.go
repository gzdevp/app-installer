//go:build windows

package main

// Legacy Panic API is retained for settings backward compatibility only.
// There is deliberately no background key listener: the application may be
// terminated by the user exclusively through Settings > Unload or Cleaner.
type PanicSettings struct {
	Enabled bool   `json:"enabled"`
	Key     string `json:"key"`
}

func panicSet(PanicSettings)    {}
func panicGet() PanicSettings   { return PanicSettings{Enabled: false, Key: ""} }
func startPanicHotkey(*service) {}
