//go:build windows

package main

import (
	"sync"
	"time"
)

// frameCache keeps a viewport and the positions projected into it together.
// Publishing either half separately can place last frame's projected objects
// into the current game's moved/resized window.
// Only immutable snapshots escape; callers cannot mutate shared slices.
type frameCache[Target any, Viewport any] struct {
	mu       sync.RWMutex
	viewport Viewport
	targets  []Target
	sequence uint64
	updated  time.Time
}

func (c *frameCache[Target, Viewport]) publish(viewport Viewport, targets []Target) {
	c.mu.Lock()
	c.viewport = viewport
	c.targets = append([]Target(nil), targets...)
	c.sequence++
	c.updated = time.Now()
	c.mu.Unlock()
}

// revision reads only the sequence counter: unlike snapshot it does not copy
// the potentially large per-entity skeleton slice at every overlay poll.
func (c *frameCache[Target, Viewport]) revision() uint64 {
	c.mu.RLock()
	seq := c.sequence
	c.mu.RUnlock()
	return seq
}

func (c *frameCache[Target, Viewport]) snapshot(maxAge time.Duration) (Viewport, []Target, uint64) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	if maxAge > 0 && (c.updated.IsZero() || time.Since(c.updated) > maxAge) {
		var blank Viewport
		return blank, nil, c.sequence
	}
	return c.viewport, append([]Target(nil), c.targets...), c.sequence
}
