# sete7 v13.7 · Black Edition — teclado e conflito do Through Wall

## Corrigido

- A tela Through Wall possui um seletor de teclas explícito. Letras A-Z, algarismos 0-9, F1-F12 (exceto F6), Shift, Ctrl, Alt, Espaço e Mouse 1-5. A configuração continua persistida por `magic.key` na mesma API e é lida pelo worker Windows existente.
- Evita que uma tecla já vinculada a Aimbot, Silent ou No Clip seja atribuída ao Through Wall, com mensagem e restauração do valor anterior.
- Mostra um botão 'Desligar Silent' quando o Silent está habilitado, sem alterar o algoritmo do Silent nem desativá-lo automaticamente.
- O texto do cabeçalho foi corrigido para v13.7; as funções-base continuam as da v13.3.
- Tecla ainda funciona em modo segurado; ao soltar desativa. Isso já estava implementado no worker e não foi reescrito.

## Importante: disparo atravessando paredes

- NÃO foi adicionada função universal para atravessar paredes. A rotina de destino da bala da v13.6 foi mantida inalterada, e ainda NÃO há comprovação que ela elimina colisão com obstáculos ou resulte em dano aceito pelo servidor.
- O print do usuário mostrava `Conflito seguro: desligue Silent ...`, ou seja, o redirecionamento do Through Wall estava bloqueado pelo Silent. Não é uma evidência de que o redirecionamento propriamente dito falhou.
- Este binário foi compilado para Windows; ainda não foi executado nem homologado em FiveM.

## Verificações

- `node --check validation/_script_v13.js` passou.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-s -w -H=windowsgui'` passou.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet ./...` passou.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test -c` compilou testes Windows, mas não os executou.
- A árvore de arquivos do projeto é a v13.6, com modificações apenas no `web/index.html`, cópia para `validation/_script_v13.js` e este relatório. A v13.3 NÃO foi alterada.
