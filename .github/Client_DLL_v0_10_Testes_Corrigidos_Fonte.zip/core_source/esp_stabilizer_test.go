//go:build windows

package main

import (
	"testing"
	"time"
)

func TestESPStabilizerHoldAndExpiry(t *testing.T) {
	var s espStabilizer
	now := time.Unix(100, 0)
	vp := espViewport{PID: 1, W: 1920, H: 1080}
	a := targetESP{PedID: 11, X: 111, Bones: [][4]int32{{1, 2, 3, 4}}}
	if out := s.merge(now, vp, []targetESP{a}); len(out) != 1 {
		t.Fatal(out)
	}
	if out := s.hold(now.Add(60*time.Millisecond), vp); len(out) != 1 || out[0].X != 111 || len(out[0].Bones) != 1 {
		t.Fatalf("lost coherent frame: %+v", out)
	}
	if out := s.hold(now.Add(92*time.Millisecond), vp); len(out) != 0 {
		t.Fatal("stale ghost", out)
	}
}
func TestESPStabilizerNoDuplicateAndResetsOnViewportChange(t *testing.T) {
	var s espStabilizer
	now := time.Unix(100, 0)
	vp := espViewport{PID: 1, W: 1920, H: 1080}
	s.merge(now, vp, []targetESP{{PedID: 1, X: 1}, {PedID: 2, X: 2}})
	out := s.merge(now.Add(25*time.Millisecond), vp, []targetESP{{PedID: 1, X: 15}})
	if len(out) != 2 || out[0].X != 15 {
		t.Fatal(out)
	}
	vp.PID = 2
	if out = s.hold(now.Add(30*time.Millisecond), vp); len(out) > 0 {
		t.Fatal("held old PID", out)
	}
	if out = s.merge(now.Add(35*time.Millisecond), vp, []targetESP{{PedID: 3, X: 3}}); len(out) != 1 {
		t.Fatal("old game entities leaked", out)
	}
}

func TestESPStabilizerBriefRealBonePreservation(t *testing.T) {
	var s espStabilizer
	now := time.Unix(200, 0)
	vp := espViewport{PID: 9, W: 1920, H: 1080}
	real := targetESP{PedID: 88, X: 400, Y: 300, W: 70, H: 180,
		AimX: 435, AimY: 320, AimFromBone: true, Bones: [][4]int32{{435, 320, 435, 340}, {435, 340, 435, 370}}}
	s.merge(now, vp, []targetESP{real})
	estimated := targetESP{PedID: 88, X: 406, Y: 304, W: 70, H: 180, Bones: estimatedSkeleton(406, 304, 70, 180)}
	out := s.merge(now.Add(25*time.Millisecond), vp, []targetESP{estimated})
	if len(out) != 1 || !out[0].AimFromBone || out[0].AimX != 441 || out[0].AimY != 324 || out[0].Bones[0] != [4]int32{441, 324, 441, 344} {
		t.Fatalf("real joint flickered rather than following body displacement: %+v", out)
	}
	// Past the maximum lifetime, no synthesized pose is retained.
	estimated.AimFromBone = false
	out = s.merge(now.Add(200*time.Millisecond), vp, []targetESP{estimated})
	if out[0].AimFromBone {
		t.Fatal("real bone held after deadline")
	}
}
