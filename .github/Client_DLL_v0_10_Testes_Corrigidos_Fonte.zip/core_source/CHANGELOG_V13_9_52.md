# 77 Black Edition v13.9.52 — Cleaner responsável

- Cleaner em um clique: fecha janelas e processos do navegador iniciados pela sessão antes de apagar o perfil temporário isolado.
- Exclusão do EXE após saída: o auxiliar verifica `if not exist` antes de considerar a operação concluída; tenta novamente se o Windows ainda mantém o arquivo bloqueado.
- Remoção temporária limitada a uma pasta `Sete7-session-*` filha direta do diretório temporário do usuário; nunca apaga pastas de outros programas.
- Pasta mãe com nome exato `77`/`Sete7` só é removida se estiver vazia.
- Sem alteração em Prefetch, Event Logs, auditoria do Windows, registry ou dados do FiveM.
- Sem mudanças de jogabilidade, aparência ou hotkeys.
- Testes de escopo de exclusão e comando de verificação incluídos.
