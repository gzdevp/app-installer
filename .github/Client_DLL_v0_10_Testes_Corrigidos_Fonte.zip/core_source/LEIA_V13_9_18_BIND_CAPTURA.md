# v13.9.18 — captura de teclas e mouse

- Atalhos de Aim, Silent, Through Wall, Triggerbot, No Clip e God Mode são agora botões compactos (sem checkbox).
- Clicar abre captura. Próximo keydown ou mousedown físico na janela do painel define o atalho, Esc cancela.
- Teclado suportado: letras, números, F1-F12 exceto F6, modificadores, espaço, navegação, Enter, Tab, Backspace, Delete, setas, numpad, etc.; Mouse 1–5.
- Insert (painel), F6 (veículos), Escape/tecla Windows são reservadas. Mouse 1 não é permitido no Triggerbot para não conflitar com o próprio disparo.
- Teclas duplicadas entre recursos são rejeitadas; nova configuração persiste via /api/config e é lida pela rotina nativa.
- Captura ocorre enquanto o painel tem foco. Não instala hooks globais de teclado ou mouse.
- God Mode mantém limitação anterior: preferência com toggle, sem garantia de invulnerabilidade real.
- Nenhuma garantia de compatibilidade com todas as cidades ou builds. Teste real no Windows/FiveM ainda necessário.
