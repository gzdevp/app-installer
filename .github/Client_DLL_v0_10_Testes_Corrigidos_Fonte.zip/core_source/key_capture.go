package main

import (
	"sync"
	"time"
)

// Only the user's explicit click on a key-binding control can arm this
// short-lived, in-memory capture session. No keys are logged or persisted.
type keyCaptureCandidate struct {
	name string
	vk   uintptr
}

func keyCaptureKeys() []keyCaptureCandidate {
	result := make([]keyCaptureCandidate, 0, 95)
	for c := 'a'; c <= 'z'; c++ {
		result = append(result, keyCaptureCandidate{string(c), uintptr(c - 'a' + 'A')})
	}
	for c := '0'; c <= '9'; c++ {
		result = append(result, keyCaptureCandidate{string(c), uintptr(c)})
	}
	for i := 1; i <= 12; i++ {
		if i == 6 {
			continue
		} // F6 is reserved
		result = append(result, keyCaptureCandidate{fmtKeyFunction(i), uintptr(0x6F + i)})
	}
	for _, key := range []string{"enter", "tab", "backspace", "space", "delete",
		"home", "end", "pageup", "pagedown", "up", "down", "left", "right",
		"capslock", "numlock", "scrolllock", "pause",
		"num0", "num1", "num2", "num3", "num4", "num5", "num6", "num7", "num8", "num9",
		"numadd", "numsub", "nummul", "numdiv", "numdecimal",
		"shift", "ctrl", "alt",
		"mouse2", "mouse3", "mouse4", "mouse5", "mouse1"} {
		result = append(result, keyCaptureCandidate{key, genericKeyVK(key, 0)})
	}
	return result
}

// fmtKeyFunction doesn't introduce a formatting dependency in the scanner.
func fmtKeyFunction(i int) string {
	if i < 10 {
		return "f" + string(rune('0'+i))
	}
	return "f1" + string(rune('0'+i-10))
}

var captureCandidates = keyCaptureKeys()

type keyCaptureScanner struct {
	mu       sync.Mutex
	active   bool
	deadline time.Time
	last     map[uintptr]bool
}

func (c *keyCaptureScanner) begin(now time.Time, pressed func(uintptr) bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.last = make(map[uintptr]bool, len(captureCandidates))
	for _, item := range captureCandidates {
		c.last[item.vk] = pressed(item.vk)
	}
	c.active = true
	c.deadline = now.Add(12 * time.Second)
}
func (c *keyCaptureScanner) cancel() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.active = false
	c.last = nil
}
func (c *keyCaptureScanner) poll(now time.Time, pressed func(uintptr) bool) (status, key string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if !c.active {
		return "idle", ""
	}
	if !now.Before(c.deadline) {
		c.active = false
		return "expired", ""
	}
	// Observe all keys before returning; this ensures unrelated held keys
	// cannot be mistaken for subsequent down-edges.
	found := ""
	for _, item := range captureCandidates {
		down := pressed(item.vk)
		if down && !c.last[item.vk] && found == "" {
			found = item.name
		}
		c.last[item.vk] = down
	}
	if found != "" {
		c.active = false
		return "captured", found
	}
	return "waiting", ""
}
