//go:build windows

package main

import "testing"

func TestAimSelectRangeFovAndVehicles(t *testing.T) {
	s := AimSettings{Enabled: true, FOV: 140, Range: 100, Smooth: 5}
	targets := []targetESP{{PedID: 1, X: 960, Y: 500, W: 40, H: 180, Distance: 30, AimX: 980, AimY: 520},
		{PedID: 2, X: 800, Y: 300, W: 40, H: 180, Distance: 30, AimX: 820, AimY: 320},
		{PedID: 3, X: 961, Y: 500, W: 40, H: 180, Distance: 150, AimX: 980, AimY: 520},
		{PedID: 4, Vehicle: true, X: 961, Y: 500, W: 40, H: 180, Distance: 20, AimX: 980, AimY: 520}}
	a, ok := selectAimTarget(targets, 1920, 1080, s, 0)
	if !ok || a.ID != 1 {
		t.Fatalf("wrong target: %+v %v", a, ok)
	}
	dx, dy := aimDelta(a, 1920, 1080, s.Smooth)
	if dx != 4 || dy != -4 {
		t.Fatalf("wrong movement %d %d", dx, dy)
	}
}
func TestAimRejectStaleViewport(t *testing.T) {
	if _, ok := selectAimTarget([]targetESP{{PedID: 1, W: 40, H: 180}}, 0, 0, AimSettings{FOV: 200}, 0); ok {
		t.Fatal("accepted invalid")
	}
}

func TestAimHeadRequiresValidatedJoint(t *testing.T) {
	settings := AimSettings{Enabled: true, Bone: "head", FOV: 140, Range: 100}
	target := targetESP{PedID: 1, X: 940, Y: 480, W: 60, H: 180, Distance: 15, AimX: 970, AimY: 520}
	if _, ok := selectAimTarget([]targetESP{target}, 1920, 1080, settings, 0); ok {
		t.Fatal("selected estimated head rather than validated joint")
	}
	target.AimFromBone = true
	target.HeadVerified = true
	target.HeadWorld = vec3{X: 100, Y: 100, Z: 33}
	target.World = vec3{X: 100, Y: 100, Z: 32}
	if v, ok := selectAimTarget([]targetESP{target}, 1920, 1080, settings, 0); !ok || v.ID != 1 || !v.RealBone {
		t.Fatalf("missed authenticated head: %+v %v", v, ok)
	}
}

// A mislabeled hip/leg bone must not produce a downward mouse movement.
func TestAimHeadRejectsLowerBodyAndOffscreenJoint(t *testing.T) {
	settings := AimSettings{Enabled: true, Bone: "head", FOV: 500, Range: 100}
	target := targetESP{PedID: 22, X: 940, Y: 400, W: 40, H: 160, Distance: 20,
		AimFromBone: true, HeadVerified: true, HeadWorld: vec3{X: 100, Y: 100, Z: 33}, World: vec3{X: 100, Y: 100, Z: 32}, AimX: 960, AimY: 525}
	if _, ok := selectAimTarget([]targetESP{target}, 1920, 1080, settings, 0); ok {
		t.Fatal("selected a lower-body point as the head")
	}
	target.AimY = 420
	if _, ok := selectAimTarget([]targetESP{target}, 1920, 1080, settings, 0); !ok {
		t.Fatal("rejected a verified head near top of player box")
	}
	target.AimX = 1020
	if _, ok := selectAimTarget([]targetESP{target}, 1920, 1080, settings, 0); ok {
		t.Fatal("selected head outside player width")
	}
}
