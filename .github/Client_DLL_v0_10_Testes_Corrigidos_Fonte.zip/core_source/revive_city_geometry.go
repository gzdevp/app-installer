package main

// reviveCityButtonTarget returns the location of the existing "REVIVER"
// option observed in the provided 1919x1073 FiveM screenshot. It scales with
// the actual client area and never targets outside it. This is UI automation,
// not a resurrection native or a memory patch.
func reviveCityButtonTarget(x, y, width, height int32) (int32, int32, bool) {
	if width < 800 || height < 600 || width > 16384 || height > 16384 || float64(width)/float64(height) < 1.65 || float64(width)/float64(height) > 1.95 {
		return 0, 0, false
	}
	// The observed label is centered around (1517, 401) in 1919x1073.
	px := x + int32(float64(width)*1517.0/1919.0)
	py := y + int32(float64(height)*401.0/1073.0)
	if px < x || py < y || px >= x+width || py >= y+height {
		return 0, 0, false
	}
	return px, py, true
}
