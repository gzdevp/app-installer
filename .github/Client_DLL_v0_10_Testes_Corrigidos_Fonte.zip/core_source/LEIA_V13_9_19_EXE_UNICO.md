# Sete7 v13.9.19 — arquivo EXE único

- Não cria mais nenhuma pasta `sete7-v*-data` ao lado do EXE.
- A execução precisa de um perfil temporário do Edge/Chrome. O perfil, configurações, logs e perfis ficam numa pasta isolada `Sete7-session-*` dentro do TEMP do Windows **enquanto o aplicativo roda**.
- Ao encerrar normalmente via Unload, a sessão é fechada e a pasta temporária é removida com tentativas de repetição. Uma queda do Windows, encerramento forçado ou arquivos travados pelo navegador podem deixar restos no TEMP.
- **Configurações e perfis não persistem após encerrar o programa**, conforme pedido de não salvar arquivos extras.
- Não remove automaticamente as pastas antigas `sete7-v*-data` do usuário; elas podem conter configurações importantes de versões anteriores. Feche as versões antigas e exclua as pastas manualmente se não precisar delas.
- O Cleaner permanece um comando separado que tenta apagar o próprio EXE somente após confirmação, mas essa remoção pode falhar no Windows enquanto está em execução.
- Não modifica código de mira, ESP, Silent, radar, veículos ou outros módulos de jogo.
- Compilação e testes locais não substituem teste no Windows com FiveM.
