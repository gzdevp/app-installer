package main

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"strings"
	"unicode"
	"unicode/utf16"
	"unicode/utf8"
)

// memoryNameReader reads one exact region in the process. This separation makes
// string layouts testable without attaching to any process.
type memoryNameReader func(uintptr, []byte) bool

// sanitizeSessionName is intentionally strict: arbitrary bytes must not turn
// into an ESP label or accidentally designate a player as a friend.
func sanitizeSessionName(s string) string {
	s = strings.TrimSpace(s)
	if !utf8.ValidString(s) || len(s) < 2 || len(s) > 128 || utf8.RuneCountInString(s) > 45 {
		return ""
	}
	meaningful := false
	for _, r := range s {
		if unicode.IsControl(r) || r == utf8.RuneError {
			return ""
		}
		if unicode.IsLetter(r) || unicode.IsNumber(r) {
			meaningful = true
		}
	}
	if !meaningful {
		return ""
	}
	return s
}

// decodeUTF16Candidate accepts UTF-16LE only when a complete terminator is
// present. This matters for names using Cyrillic, Han or Hangul characters:
// their first UTF-16 byte pair does not necessarily have a zero high byte.
func decodeUTF16Candidate(data []byte) string {
	units := make([]uint16, 0, len(data)/2)
	foundTerminator := false
	for i := 0; i+1 < len(data); i += 2 {
		v := binary.LittleEndian.Uint16(data[i : i+2])
		if v == 0 {
			foundTerminator = true
			break
		}
		units = append(units, v)
		if len(units) > 45 {
			return ""
		}
	}
	if !foundTerminator || len(units) < 2 {
		return ""
	}
	return sanitizeSessionName(string(utf16.Decode(units)))
}

func decodeInlineName(data []byte) string {
	if len(data) < 4 {
		return ""
	}
	// Clear UTF-16LE Latin strings contain a NUL high byte. Never interpret
	// those as one-letter ANSI labels.
	if data[1] == 0 {
		if name := decodeUTF16Candidate(data); name != "" {
			return name
		}
	}
	// Prefer UTF-8 when it forms a valid, NUL-terminated string. Otherwise
	// retry UTF-16LE for non-Latin nicknames with no alternating zero bytes.
	if n := bytes.IndexByte(data, 0); n > 1 {
		if name := sanitizeSessionName(string(data[:n])); name != "" {
			return name
		}
	}
	return decodeUTF16Candidate(data)
}

func readNameAt(address uintptr, read memoryNameReader) string {
	if address < 0x10000 || address > 0x7FFFFFFFFFFF || read == nil {
		return ""
	}
	// Prefer a full string view; a smaller read handles structs near a page
	// boundary without silently rejecting a valid first 32-byte name.
	for _, sz := range [...]int{80, 64, 48, 32, 24, 16} {
		buf := make([]byte, sz)
		if !read(address, buf) {
			continue
		}
		// A char* stored inline may have printable low bytes and therefore
		// resemble a valid short name. Follow a plausible pointer BEFORE
		// interpreting its bytes as text, so the label is read from the
		// pointed-to name, not invented from the address itself.
		// 64-bit std::string and char* fields commonly begin with a pointer.
		ptr := uintptr(binary.LittleEndian.Uint64(buf[:8]))
		if ptr >= 0x10000 && ptr <= 0x7FFFFFFFFFFF && ptr != address {
			for _, psz := range [...]int{80, 64, 48, 32, 24, 16} {
				target := make([]byte, psz)
				if read(ptr, target) {
					if name := decodeInlineName(target); name != "" {
						return name
					}
				}
			}
		}
		if name := decodeInlineName(buf); name != "" {
			return name
		}
		break
	}
	return ""
}

// Do not scan arbitrary memory looking for nicknames: use only documented,
// build-specific CPlayerInfo fields and reject undecodable values.
func readFiveMPlayerName(info uintptr, build string, read memoryNameReader) string {
	if info == 0 {
		return "Jogador"
	}
	// Do not let a coincidental printable value in a modern field override
	// the legacy CPlayerInfo name on older builds.
	offsets := []uintptr{0x100} // 2944+ CPlayerInfo name field.
	if build == "b2699" || build == "b2802" {
		offsets = []uintptr{0xA4, 0x84, 0x100}
	}
	for _, offset := range offsets {
		if name := readNameAt(info+offset, read); name != "" {
			return name
		}
	}
	return "Jogador"
}

// This is NOT the server's RP name or server slot ID. Some builds expose
// a small session-network identifier; display it only as a diagnostic fallback.
// It must never participate in Friends or target-name matching.
func readFiveMPlayerLabel(info uintptr, build string, read memoryNameReader) string {
	name := readFiveMPlayerName(info, build, read)
	if name != "Jogador" {
		return name
	}
	if info == 0 || read == nil || build != "b3258" {
		return "Jogador"
	}
	var b [4]byte
	if !read(info+0x88, b[:]) {
		return "Jogador"
	}
	id := binary.LittleEndian.Uint32(b[:])
	if id == 0 || id > 1023 {
		return "Jogador"
	}
	return fmt.Sprintf("Jogador (ID interno %d)", id)
}
