# 77 v13.9.50 — Cleaner self-uninstall
- Cleaner one-click schedules removal of exactly the currently running 77 executable after it exits, using a short-lived hidden Windows system helper.
- The existing shutdown already closes the menu/browser and deletes the ephemeral private session directory.
- Nothing outside the current executable and its own session is deleted. Windows event logs, GTA/FiveM files, other programs, other copies of 77 and system traces remain untouched.
- No additional permanent files created. No prompts added. Unload still closes without deleting the EXE.
- Windows release built for amd64; actual Windows Cleaner completion requires an in-system test.
