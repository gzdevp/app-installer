//go:build windows

package main

import "testing"

func TestHeadlockPrioritizesLiveStickyTarget(t *testing.T) {
	s := AimSettings{Enabled: true, Bone: "head", FOV: 180, Range: 180, Sticky: true}
	targets := []targetESP{
		{PedID: 1, X: 915, Y: 480, W: 65, H: 200, Distance: 20, AimX: 945, AimY: 495, AimFromBone: true, HeadVerified: true, HeadWorld: vec3{X: 100, Y: 100, Z: 33}, World: vec3{X: 100, Y: 100, Z: 32}},
		{PedID: 2, X: 1000, Y: 485, W: 65, H: 200, Distance: 20, AimX: 1015, AimY: 499, AimFromBone: true, HeadVerified: true, HeadWorld: vec3{X: 100, Y: 100, Z: 33}, World: vec3{X: 100, Y: 100, Z: 32}},
	}
	got, found := selectAimTarget(targets, 1920, 1080, s, 2)
	if !found || got.ID != 2 {
		t.Fatalf("sticky target lost: %v %+v", found, got)
	}
	// A disappeared target must never be selected from the previous frame.
	got, found = selectAimTarget(targets[:1], 1920, 1080, s, 2)
	if !found || got.ID != 1 {
		t.Fatalf("stale sticky target used: %v %+v", found, got)
	}
}
