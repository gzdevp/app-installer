package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func writeTestOwner(t *testing.T, folder string, pid int, created time.Time) {
	t.Helper()
	if err := os.MkdirAll(folder, 0700); err != nil {
		t.Fatal(err)
	}
	b, err := json.Marshal(sessionOwnership{Signature: sessionOwnerSignature, PID: pid, Created: created.Unix()})
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(folder, sessionOwnerFile), b, 0600); err != nil {
		t.Fatal(err)
	}
}

func TestCleanerScopeAndRecoveredSessions(t *testing.T) {
	root := t.TempDir()
	now := time.Now()
	old := now.Add(-48 * time.Hour)
	missingPID := int(2000000000)
	abandoned := filepath.Join(root, "Sete7-session-old-1")
	active := filepath.Join(root, "Sete7-session-active-1")
	fresh := filepath.Join(root, "Sete7-session-fresh-1")
	noOwner := filepath.Join(root, "Sete7-session-unknown-1")
	other := filepath.Join(root, "other-app")
	writeTestOwner(t, abandoned, missingPID, old)
	writeTestOwner(t, active, os.Getpid(), old)
	writeTestOwner(t, fresh, missingPID, now)
	for _, dir := range []string{noOwner, other} {
		if err := os.Mkdir(dir, 0700); err != nil {
			t.Fatal(err)
		}
	}
	for _, dir := range []string{abandoned, active, fresh, noOwner, other} {
		if err := os.WriteFile(filepath.Join(dir, "important.txt"), []byte("keep"), 0600); err != nil {
			t.Fatal(err)
		}
	}
	if err := cleanAbandonedOwnedSessions(root, "", now); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(abandoned); !os.IsNotExist(err) {
		t.Fatalf("old inactive owned session must be deleted: %v", err)
	}
	for _, dir := range []string{active, fresh, noOwner, other} {
		if _, err := os.Stat(filepath.Join(dir, "important.txt")); err != nil {
			t.Fatalf("must keep %s: %v", dir, err)
		}
	}
}

func TestCleanerRefusesSymlinkAndFolderWithoutOwnedName(t *testing.T) {
	root := t.TempDir()
	important := filepath.Join(root, "private-data")
	if err := os.Mkdir(important, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(important, "protected"), []byte("keep"), 0600); err != nil {
		t.Fatal(err)
	}
	link := filepath.Join(root, "Sete7-session-link")
	if err := os.Symlink(important, link); err == nil {
		if err := cleanOwnedSessionPath(link, root); err == nil {
			t.Fatal("must reject symlink session")
		}
	}
	fake := filepath.Join(root, "Sete7-session-valid")
	if err := os.Mkdir(fake, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(important, filepath.Join(fake, "external-link")); err == nil {
		if err := cleanOwnedSessionPath(fake, root); err == nil {
			t.Fatal("must refuse symlinks in session content")
		}
	}
	if err := cleanOwnedSessionPath(important, root); err == nil {
		t.Fatal("must reject unrelated folder")
	}
	if _, err := os.Stat(filepath.Join(important, "protected")); err != nil {
		t.Fatal(err)
	}
}
