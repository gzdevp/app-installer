package main

import "testing"

func TestSilentRequiresPhysicalHold(t *testing.T) {
	tests := []struct {
		name  string
		state uintptr
		want  bool
	}{
		{"released", 0x0000, false},
		{"pressed-in-past-not-held", 0x0001, false},
		{"currently-held", 0x8000, true},
		{"currently-held-new-press", 0x8001, true},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			if got := silentKeyHeld(tc.state); got != tc.want {
				t.Fatalf("silentKeyHeld(%#x) = %t, want %t", tc.state, got, tc.want)
			}
		})
	}
}
