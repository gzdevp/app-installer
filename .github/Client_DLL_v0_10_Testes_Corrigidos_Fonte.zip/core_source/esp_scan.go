//go:build windows

package main

import (
	"fmt"
	"math"
)

// espScanReader makes entity filtering unit-testable without attaching to a game.
type espScanReader interface {
	ptr(uintptr) uintptr
	vec3(uintptr) (vec3, bool)
	f32(uintptr) float32
}

// The ped collection can be sparse: occupied items need not be packed into
// the first N slots. ActiveCount is not a safe scan bound when the pool is
// sparse. Prefer the pool capacity, subject to strict upper bounds.
func pedScanCapacity(active, capacity uint32) (uint32, bool) {
	const maxSlots = 2048
	if capacity >= active && capacity > 0 && capacity <= maxSlots {
		return capacity, true
	}
	if active > 0 && active <= maxSlots {
		return active, true // diagnostic fallback if capacity has changed
	}
	return 0, false
}

// Optional optimized reader: one coherent snapshot of ped pointers reduces
// both process-memory calls and inconsistent frames on sparse lists.
type espPedSlotsReader interface {
	pedSlots(list uintptr, count uint32) []uintptr
}

func espDistance(a, b vec3) float64 {
	x, y, z := float64(a.X-b.X), float64(a.Y-b.Y), float64(a.Z-b.Z)
	return math.Sqrt(x*x + y*y + z*z)
}

type ESPDiagnostics struct {
	Slots                   int    `json:"slots"`
	Pointers                int    `json:"pointers"`
	DuplicatePointers       int    `json:"duplicatePointers"`
	NamesResolved           int    `json:"namesResolved"`
	NamesMissing            int    `json:"namesMissing"`
	Players                 int    `json:"players"`
	NPCs                    int    `json:"npcs"`
	Positions               int    `json:"positions"`
	InvalidPositions        int    `json:"invalidPositions"`
	NavigationMismatch      int    `json:"navigationMismatch"`
	InRange                 int    `json:"inRange"`
	Healthy                 int    `json:"healthy"`
	UnusualVitals           int    `json:"unusualVitals"`
	OnScreen                int    `json:"onScreen"`
	ProjectionRejected      int    `json:"projectionRejected"`
	Boxes                   int    `json:"boxes"`
	Skeletons               int    `json:"skeletons"`
	BonePointerMissing      int    `json:"bonePointerMissing"`
	BoneCPPVerified         int    `json:"boneCppVerified"`
	BoneCPPNoFragment       int    `json:"boneCppNoFragment"`
	BoneCPPNoSkeleton       int    `json:"boneCppNoSkeleton"`
	BoneCPPNoHead           int    `json:"boneCppNoHead"`
	BoneCPPBadPose          int    `json:"boneCppBadPose"`
	BonePointerReadable     int    `json:"bonePointerReadable"`
	BoneReadFailed          int    `json:"boneReadFailed"`
	BonePoseVerified        int    `json:"bonePoseVerified"`
	BonePoseRejected        int    `json:"bonePoseRejected"`
	BoneFallbackVerified    int    `json:"boneFallbackVerified"`
	HeadHeightRejected      int    `json:"headHeightRejected"`
	HeadCPPRelativeAccepted int    `json:"headCppRelativeAccepted"`
	HeadAnchorRejected      int    `json:"headAnchorRejected"`
	HeadVerified            int    `json:"headVerified"`
	SkeletonEstimated       int    `json:"skeletonEstimated"`
	MatrixOffset            string `json:"matrixOffset"`
	MatrixScores            string `json:"matrixScores"`
	Reason                  string `json:"reason"`
}

// candidatePed is a single validated snapshot of a possible player.  The
// candidate is not assumed to be real merely because one pointer can be read.
type candidatePed struct {
	ptr           uintptr
	position      vec3
	distance      float64
	info          uintptr
	health, armor int
	isNPC         bool
}

// scanPlayers validates the entity list before any camera projection occurs.
// This preserves meaningful counters when the camera cannot be read, and avoids
// reading the same peds twice with inconsistent values in a live game.
func scanPlayers(reader espScanReader, list uintptr, count uint32, me uintptr, origin vec3, limit float64, d *ESPDiagnostics) []candidatePed {
	return scanPlayersWithOffsets(reader, list, count, me, origin, limit, d, 0x10A8, 0x150C)
}

// Version-specific offsets are passed explicitly rather than silently reusing
// a modern build's PlayerInfo and Armor positions on an older executable.
func scanPlayersWithOffsets(reader espScanReader, list uintptr, count uint32, me uintptr, origin vec3, limit float64, d *ESPDiagnostics, playerInfo, armor uintptr) []candidatePed {
	return scanPedsWithOffsets(reader, list, count, me, origin, limit, d, playerInfo, armor, false)
}

// Scan NPCs only when a visual/aim/silent consumer explicitly enables them.
// A missing PlayerInfo differentiates ordinary NPC peds from network players.
func scanPedsWithOffsets(reader espScanReader, list uintptr, count uint32, me uintptr, origin vec3, limit float64, d *ESPDiagnostics, playerInfo, armor uintptr, includeNPC bool) []candidatePed {
	candidates := make([]candidatePed, 0, 64)
	d.Slots = int(count)
	seen := make(map[uintptr]struct{}, 256)
	var snapshot []uintptr
	if source, ok := reader.(espPedSlotsReader); ok {
		snapshot = source.pedSlots(list, count)
	}
	// Inspect the entire validated pool. Stopping after the first 256 valid
	// slots lets distant entities crowd out nearby players on busy servers.
	for i := uint32(0); i < count; i++ {
		var ped uintptr
		if uint32(len(snapshot)) == count {
			ped = snapshot[i]
		} else {
			ped = reader.ptr(list + uintptr(i)*0x10)
		}
		if ped == 0 || ped == me {
			continue
		}
		if _, duplicate := seen[ped]; duplicate {
			d.DuplicatePointers++
			continue
		}
		seen[ped] = struct{}{}
		d.Pointers++
		pos, ok := reader.vec3(ped + 0x90)
		if !ok || !plausibleFiveMPosition(pos) {
			d.InvalidPositions++
			continue
		}
		nav := reader.ptr(ped + 0x30)
		if nav != 0 {
			if navPos, valid := reader.vec3(nav + 0x50); valid && plausibleFiveMPosition(navPos) && espDistance(navPos, pos) > 25 {
				d.NavigationMismatch++
				continue
			}
		}
		d.Positions++
		distance := espDistance(origin, pos)
		if distance < 0.1 || distance > limit {
			continue
		}
		d.InRange++
		info := reader.ptr(ped + playerInfo)
		isNPC := info == 0
		if isNPC && !includeNPC {
			continue
		}
		if !isNPC {
			d.Players++
		}
		healthRaw, armorRaw := reader.f32(ped+0x280), reader.f32(ped+armor)
		if isNPC {
			// Some ped layouts have no player armor field.
			armorRaw = 0
		}
		// Some FiveM servers use custom health/armor values. The old v8
		// rejected valid PlayerInfo peds above 500 HP or 200 armor.
		// Reject dead or corrupt readings, not merely customized vitals.
		if math.IsNaN(float64(healthRaw)) || math.IsInf(float64(healthRaw), 0) ||
			math.IsNaN(float64(armorRaw)) || math.IsInf(float64(armorRaw), 0) ||
			healthRaw <= 0 || healthRaw > 10000 || armorRaw < 0 || armorRaw > 10000 {
			continue
		}
		health, armor := int(healthRaw), int(armorRaw)
		if health > 500 || armor > 200 {
			d.UnusualVitals++
		}
		d.Healthy++
		candidates = retainBestPeds(candidates, candidatePed{ptr: ped, position: pos, distance: distance, info: info, health: health, armor: armor, isNPC: isNPC}, 256)
		if isNPC {
			d.NPCs++
		}
	}
	return candidates
}

// reportStage returns the first stage where no valid players survived. It is
// diagnostic, not evidence that an ESP is working in a real game session.
func reportStage(d ESPDiagnostics) string {
	switch {
	case d.Pointers == 0:
		return "Nenhum ped encontrado na lista"
	case d.Positions == 0 && d.NavigationMismatch > 0:
		return "Inconsistência entre posições de ped e navegação"
	case d.Positions == 0:
		return "Todas as coordenadas de ped foram rejeitadas"
	case d.InRange == 0:
		return "Nenhum ped dentro do alcance configurado"
	case d.Players == 0 && d.NPCs == 0:
		return "Nenhum ped possui PlayerInfo legível (offset possivelmente incompatível)"
	case d.Healthy == 0:
		return "Vida ou colete fora dos limites (offset possivelmente incompatível)"
	case d.OnScreen == 0:
		return fmt.Sprintf("Nenhum jogador projetado na tela (%d projeções rejeitadas)", d.ProjectionRejected)
	case d.Boxes == 0:
		return "Projeção produziu caixas geometricamente inválidas"
	default:
		return "Sem alvos válidos"
	}
}

// Prefer network players over NPCs, then the closest individuals. This is
// bounded to 256 objects, but checks all pool slots, including sparse pools.
// Stable ped-pointer tie-breaking prevents arbitrary selection order flicker.
func pedMoreRelevant(a, b candidatePed) bool {
	if a.isNPC != b.isNPC {
		return !a.isNPC
	}
	if a.distance != b.distance {
		return a.distance < b.distance
	}
	return a.ptr < b.ptr
}

func retainBestPeds(items []candidatePed, incoming candidatePed, limit int) []candidatePed {
	if limit <= 0 {
		return items[:0]
	}
	if len(items) < limit {
		return append(items, incoming)
	}
	worst := 0
	for i := 1; i < len(items); i++ {
		if pedMoreRelevant(items[worst], items[i]) {
			worst = i
		}
	}
	if pedMoreRelevant(incoming, items[worst]) {
		items[worst] = incoming
	}
	return items
}
