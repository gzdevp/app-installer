package main

import "bytes"

// findBulletSignatures returns byte offsets of every exact 17-byte sequence.
// A region with no matches or ambiguous matches must never be modified.
func findBulletSignatures(region []byte) []int {
	if len(region) < len(bulletOriginal) {
		return nil
	}
	var positions []int
	for pos := 0; pos <= len(region)-len(bulletOriginal); pos++ {
		if bytes.Equal(region[pos:pos+len(bulletOriginal)], bulletOriginal) {
			positions = append(positions, pos)
		}
	}
	return positions
}
