package main

import "time"

// Drawing a full-screen GDI backbuffer for the same ESP frame twice costs FPS
// and does not make boxes fresher.  Paint only when the scanner publishes a new
// coherent frame, with a 60Hz ceiling for exceptional high-frequency sources.
const overlayMinDynamicPaintDelay = 16 * time.Millisecond
const overlaySafetyRefresh = time.Second

type overlayPaintScheduler struct {
	lastPaint    time.Time
	lastESPSeq   uint64
	lastRadarSeq uint64
}

// A forced paint reacts to viewport/settings changes immediately.  Dynamic
// frames wait for new data, rather than being quantized by a slower 33ms timer.
// The safety repaint repairs unexpected DWM invalidation without flooding GDI.
func (s *overlayPaintScheduler) shouldPaint(now time.Time, dynamic bool, force bool, espSeq, radarSeq uint64) bool {
	elapsed := now.Sub(s.lastPaint)
	changed := espSeq != s.lastESPSeq || radarSeq != s.lastRadarSeq
	paint := force || s.lastPaint.IsZero() || elapsed >= overlaySafetyRefresh ||
		(dynamic && changed && elapsed >= overlayMinDynamicPaintDelay)
	if paint {
		s.lastPaint = now
		s.lastESPSeq = espSeq
		s.lastRadarSeq = radarSeq
	}
	return paint
}
