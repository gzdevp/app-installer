package main

import "testing"

func TestCPPAnatomyOverridesVariablePedOriginHeight(t *testing.T) {
	// The supplied b3258 screenshot had 4 anatomically valid heads but all
	// failed the old absolute +0.75 m test. This is valid ONLY after the
	// C++ reader has verified head > neck > pelvis and bone proximity.
	if !headWorldHeightCompatible(101.4, 101.0, true) {
		t.Fatal("verified C++ head rejected due to variable ped origin")
	}
	if headWorldHeightCompatible(101.4, 101.0, false) {
		t.Fatal("unverified reader bypassed legacy height check")
	}
}
func TestHeadHeightStillRejectsNonsense(t *testing.T) {
	if headWorldHeightCompatible(0, 20, false) {
		t.Fatal("accepted low head")
	}
	if headWorldHeightCompatible(float32(1e10), 20, true) {
		t.Fatal("accepted corrupt world position")
	}
}
func TestCPPReferenceProducesAnatomicallyOrderedJoints(t *testing.T) {
	r := setupCPPFake()
	points, valid, stage := cppReadPose(r, 0x100000, vec3{10, 10, 20})
	if stage != cppBoneVerified || !valid[0] || !valid[7] || !valid[8] {
		t.Fatal("C++ pose missing anatomical joints")
	}
	if !(points[0].Z > points[7].Z && points[7].Z > points[8].Z) {
		t.Fatal("anatomical height ordering is inconsistent")
	}
}
