//go:build windows

package main

import (
	"fmt"
	"time"
)

// Low-rate diagnostics let us distinguish a vanished UI from a stopped EXE.
// This deliberately does not record credentials, player data or local URLs.
func monitorServiceLiveness(s *service) {
	ticker := time.NewTicker(20 * time.Second)
	defer ticker.Stop()
	for range ticker.C {
		if s.stopping.Load() {
			return
		}
		writeCrashRecord("heartbeat", fmt.Sprintf(
			"service_alive insert_registered=%t menu_requested=%t browser_attached=%t",
			insertHotkeyRegistered.Load(), menuWanted.Load(), menuWindow() != 0))
	}
}
