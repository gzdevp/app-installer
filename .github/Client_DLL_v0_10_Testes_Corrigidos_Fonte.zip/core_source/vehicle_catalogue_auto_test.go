package main

import (
	"testing"
)

func TestStockModelNamesAvailableAfterBackgroundRefresh(t *testing.T) {
	publicVehicleNames.Lock()
	prior := publicVehicleNames.names
	publicVehicleNames.Unlock()
	defer func() { publicVehicleNames.Lock(); publicVehicleNames.names = prior; publicVehicleNames.Unlock() }()
	publicVehicleNames.Lock()
	publicVehicleNames.names = map[string]string{"3078201489": "Truffade Adder"}
	publicVehicleNames.Unlock()
	name, ok := resolvedVehicleName(3078201489, nil)
	if !ok || name != "Truffade Adder" {
		t.Fatalf("stock name = %q, %v", name, ok)
	}
	name, ok = resolvedVehicleName(3078201489, map[string]string{"3078201489": "Bugatti customizado"})
	if !ok || name != "Bugatti customizado" {
		t.Fatalf("city alias lost priority: %q, %v", name, ok)
	}
	name, ok = resolvedVehicleName(3253274834, nil)
	if !ok || name == "" {
		t.Fatalf("offline stock names disappeared")
	}
}
