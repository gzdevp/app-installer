# sete7 v13.9.5 — Clean Edition

Esta versão é uma revisão **visual e de nomenclatura**, baseada na v13.9.4 Motion Edition.

## Alterações
- Padronização dos nomes das funções, campos e cartões em todas as abas.
- Remoção dos rótulos técnicos como "experimental", nomes internos de builds e descrições extensas da visão principal.
- Status e avisos de compatibilidade continuam acessíveis no painel recolhível **Informações e status**, sem induzir o usuário a acreditar que uma função não validada passou a funcionar.
- Mantida a aba `World > Vehicles | Radar` e a identidade visual sete7.
- `Trigger` agora aparece como `Triggerbot`; `Exploits` como `Protection`; `Configs` como `Profiles`.
- Removida a subaba sem funcionalidade independente `Weapons > Effects`.
- Perfil de navegador separado em `sete7-v13.9.5-data` para não conflitar com a versão anterior.

## Integridade
Somente `web/index.html`, `main.go` (diretório de dados do navegador), `window_title.go` (título da janela) e este documento são diferentes em relação ao pacote v13.9.4. Nenhuma rotina de jogo foi alterada.

## Limites
Este update não adiciona novas funcionalidades, nem comprova funcionamento de ações ainda sem integração, como trancar ou destrancar veículos e Through Wall atravessando paredes. Os controles correspondentes permanecem indisponíveis ou informados na seção de detalhes. A alteração não foi testada dentro do FiveM.

## Verificações
- JavaScript: `node --check`: OK
- Build: `GOOS=windows GOARCH=amd64 go build` (sem CMD): OK
- `GOOS=windows GOARCH=amd64 go vet ./...`: OK
- Testes do Windows cross-compilados: OK (não executados)
- Comparação SHA-256 de fontes do jogo com v13.9.4: idênticos

Ao testar, feche a v13.9.4 antes de executar a v13.9.5.
