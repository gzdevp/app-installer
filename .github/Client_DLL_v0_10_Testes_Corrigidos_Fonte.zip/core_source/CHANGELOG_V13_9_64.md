# 77 v13.9.64 — Resiliência e diagnóstico de encerramentos inesperados

- Mantido INSERT como alternância de visibilidade; Unload e Cleaner são os únicos comandos da UI para encerrar.
- Removido o alias legado /api/quit; permanece /api/unload apenas.
- Erros inesperados do servidor local agora são registrados.
- Panics recuperáveis em goroutines e callbacks de UI são capturados em vez de derrubarem imediatamente todo o processo.
- Monitor da janela e listener de INSERT reiniciam após panics recuperáveis, com limite de tentativas.
- Janela nativa destruída inesperadamente pode ser recriada com tentativas limitadas, sem executar Unload.
- ESP fecha o handle do processo após erro inesperado; outras rotinas interrompidas por panic são registradas.
- Diagnósticos técnicos acessíveis em %TEMP%\77-diagnostics.log; sem senha, URL local, dados de jogadores ou dados de memória no log.
- Não garante recuperação de falha fatal nativa, encerramento pelo Windows/anticheat, desligamento do PC ou OOM.
- Precisa validação real no Windows para confirmar causa original.
