package main

import "testing"

func TestFriendColorDistinctAndCustomizable(t *testing.T) {
	friend := normalizedHex("#42E5A0", "#42E5A0")
	if rgbToColorRef(friend, 0) == rgbToColorRef("#FFFFFF", 0) {
		t.Fatal("friend color must differ from standard white ESP")
	}
	if rgbToColorRef("#59E0FF", 0) != 0x00FFE059 {
		t.Fatal("custom cyan friend color must convert to Win32 COLORREF")
	}
	if normalizedHex("invalid", "#42E5A0") != "#42E5A0" {
		t.Fatal("invalid friend color must fall back to green")
	}
}
