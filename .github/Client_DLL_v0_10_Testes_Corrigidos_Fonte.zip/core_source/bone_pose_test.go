package main

import (
	"encoding/binary"
	"math"
	"testing"
)

func TestBonePoseActualJointsAndRejectsGarbage(t *testing.T) {
	input := [9]vec3{
		{0, 0, 1.8}, {-0.2, 0, 0.05}, {0.2, 0, 0.05},
		{-0.2, 0, 0.15}, {0.2, 0, 0.15},
		{-0.5, 0, 1.1}, {0.5, 0, 1.1}, {0, 0, 1.4}, {0, 0, 0.7},
	}
	raw := make([]byte, 9*16-4)
	for i, v := range input {
		for k, x := range [...]float32{v.X, v.Y, v.Z} {
			binary.LittleEndian.PutUint32(raw[i*16+k*4:], math.Float32bits(x))
		}
	}
	model := matrix44{1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}
	camera := matrix44{}
	camera[1] = 0.16
	camera[10] = 0.20
	camera[15] = 1
	segments, head, ok := bonePoseFromLocal(raw, model, vec3{}, camera, 1200, 800)
	if !ok || len(segments) < 5 {
		t.Fatalf("expected authentic pose from 9 joints, ok=%t count=%d", ok, len(segments))
	}
	if head[0] != 600 || head[1] >= 400 {
		t.Fatalf("invalid projected head: %v", head)
	}
	for i := range raw {
		raw[i] = 0
	}
	_, _, ok = bonePoseFromLocal(raw, model, vec3{}, camera, 1200, 800)
	if ok {
		t.Fatal("invalid bone data accepted")
	}
	_, _, ok = bonePoseFromLocal(raw[:5], model, vec3{}, camera, 1200, 800)
	if ok {
		t.Fatal("truncated bone data accepted")
	}
}
