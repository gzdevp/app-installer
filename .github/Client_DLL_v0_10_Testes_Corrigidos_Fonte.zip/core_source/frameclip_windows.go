//go:build windows

package main

import (
	"syscall"
	"unsafe"
)

var (
	getWindowRectFrame = user32Hotkey.NewProc("GetWindowRect")
	setWindowRgnFrame  = user32Hotkey.NewProc("SetWindowRgn")
	createRectRgnFrame = syscall.NewLazyDLL("gdi32.dll").NewProc("CreateRectRgn")
	deleteObjectFrame  = syscall.NewLazyDLL("gdi32.dll").NewProc("DeleteObject")
)

func clipBrowserWindowToClient(hwnd uintptr) bool {
	if hwnd == 0 {
		return false
	}
	var outer, client rect
	var origin point
	if r, _, _ := getWindowRectFrame.Call(hwnd, uintptr(unsafe.Pointer(&outer))); r == 0 {
		return false
	}
	if r, _, _ := getClientRect.Call(hwnd, uintptr(unsafe.Pointer(&client))); r == 0 {
		return false
	}
	if r, _, _ := toScreen.Call(hwnd, uintptr(unsafe.Pointer(&origin))); r == 0 {
		return false
	}
	// Region rectangles are relative to the OS window rectangle, not desktop.
	left := origin.X - outer.Left
	top := origin.Y - outer.Top
	width := client.Right - client.Left
	height := client.Bottom - client.Top
	if width < 300 || height < 200 || left < 0 || top < 0 || left > 100 || top > 150 {
		return false
	}
	rgn, _, _ := createRectRgnFrame.Call(uintptr(left), uintptr(top), uintptr(left+width), uintptr(top+height))
	if rgn == 0 {
		return false
	}
	ok, _, _ := setWindowRgnFrame.Call(hwnd, rgn, 1)
	if ok == 0 {
		// On success, Windows owns the region and deletes it automatically.
		deleteObjectFrame.Call(rgn)
		return false
	}
	return true
}
