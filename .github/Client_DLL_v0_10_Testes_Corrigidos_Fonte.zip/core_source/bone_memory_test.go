package main

import "testing"

func TestBoneSnapshotDereferencesOffsetPointer(t *testing.T) {
	const ped uintptr = 0x200000
	const ptrAddress uintptr = 0x410
	const boneData uintptr = 0x300000
	var lookedUp, readAt uintptr
	data, status := readPedBoneSnapshot(ped, ptrAddress,
		func(addr uintptr) uintptr { lookedUp = addr; return boneData },
		func(addr uintptr, dst []byte) bool {
			readAt = addr
			if len(dst) != boneSnapshotBytes {
				t.Fatalf("len=%d", len(dst))
			}
			dst[0] = 0xA5
			return true
		})
	if status != boneReadOK || lookedUp != ped+ptrAddress || readAt != boneData || data[0] != 0xA5 {
		t.Fatalf("pointer dereference failed: stage=%d ptr=%x read=%x", status, lookedUp, readAt)
	}
}
func TestBoneSnapshotRejectsNullOrUnreadablePointer(t *testing.T) {
	_, status := readPedBoneSnapshot(0x200000, 0x410, func(uintptr) uintptr { return 0 }, func(uintptr, []byte) bool { t.Fatal("should not read"); return true })
	if status != boneReadNoPointer {
		t.Fatalf("null pointer: %d", status)
	}
	_, status = readPedBoneSnapshot(0x200000, 0x410, func(uintptr) uintptr { return 0x300000 }, func(uintptr, []byte) bool { return false })
	if status != boneReadFailed {
		t.Fatalf("unreadable pointer: %d", status)
	}
}
