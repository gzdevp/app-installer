//go:build windows

package main

import (
	"os"
	"syscall"
)

func isUnsafeSessionReparsePoint(_ string, fi os.FileInfo) bool {
	if info, ok := fi.Sys().(*syscall.Win32FileAttributeData); ok {
		return info.FileAttributes&0x400 != 0 // FILE_ATTRIBUTE_REPARSE_POINT
	}
	return fi.Mode()&os.ModeSymlink != 0
}

// If the process cannot be examined (e.g. access denied), treat it as active.
// A PID reused by another application also makes us skip, never delete more.
func ownedProcessStillActive(pid int) bool {
	if pid <= 0 {
		return true
	}
	handle, err := syscall.OpenProcess(0x1000, false, uint32(pid)) // QUERY_LIMITED_INFORMATION
	if err != nil {
		return err != syscall.Errno(87)
	} // INVALID_PARAMETER means no PID
	defer syscall.CloseHandle(handle)
	var code uint32
	if err := syscall.GetExitCodeProcess(handle, &code); err != nil {
		return true
	}
	return code == 259 // STILL_ACTIVE
}
