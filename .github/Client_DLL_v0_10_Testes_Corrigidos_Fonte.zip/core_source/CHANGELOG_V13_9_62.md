# 77 v13.9.62 — Painel persistente

- Sem encerramento inesperado por perda temporária do foco do FiveM/Chromium.
- INSERT continua alternando visibilidade, sem fechar processos.
- Trocar de aplicativo oculta a janela fora do jogo, mas mantém estado e volta ao contexto do FiveM.
- Reaparecimento de uma janela Chromium pode ser recuperado enquanto o serviço permanece ativo.
- WM_CLOSE incidental do host é interceptado; Unload e Cleaner autorizam a destruição.
- Removido o listener legado de tecla de pânico que poderia acionar encerramento.
- Login compacto, teclado, overlays e Cleaner anteriores preservados.

Limitações: não impede término pelo Gerenciador de Tarefas, desligamento do Windows, falha fatal ou bloqueio externo. Testes Windows no jogo ainda necessários.
