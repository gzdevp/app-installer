package main

import "testing"

func TestNoclipBasisAndDiagonalNormalization(t *testing.T) {
	m := matrix44{}
	m[3], m[7] = 0, 1 // forward +Y
	m[1], m[5] = 1, 0 // right +X
	f, r, ok := noclipBasis(m)
	if !ok || f.Y != 1 || r.X != 1 {
		t.Fatalf("basis wrong: %+v %+v %v", f, r, ok)
	}
	start := vec3{X: 1, Y: 2, Z: 3}
	p, ok := noclipStep(start, f, r, 1, 1, 0, 10, .05)
	if !ok || p.X < 1.34 || p.X > 1.36 || p.Y < 2.34 || p.Y > 2.36 {
		t.Fatalf("diagonal speed not normalized: %+v", p)
	}
}
func TestNoclipFailsClosedOnInvalidMatrixAndSpeed(t *testing.T) {
	if _, _, ok := noclipBasis(matrix44{}); ok {
		t.Fatal("zero matrix accepted")
	}
	p := vec3{Z: 1}
	if _, ok := noclipStep(p, vec3{X: 1}, vec3{Y: 1}, 0, 1, 0, 99999, .02); ok {
		t.Fatal("invalid speed accepted")
	}
	if _, ok := noclipStep(p, vec3{X: 1}, vec3{Y: 1}, 0, 1, 0, 2, 1.2); ok {
		t.Fatal("invalid delta accepted")
	}
}
