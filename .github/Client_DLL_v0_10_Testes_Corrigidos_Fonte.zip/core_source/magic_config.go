package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
)

// The resource provided by the user uses a client-side Lua native or a DLL.
// This external Go process does not have those handlers or an internal-native
// invoker. Report that limitation truthfully; never advertise a working hook.
type magicConfig struct {
	ShootHandler     uint64  `json:"shootHandler"`
	PlayerPedHandler uint64  `json:"playerPedHandler"`
	Damage           int     `json:"damage"`
	Speed            float64 `json:"speed"`
}

func inspectMagicJSON(b []byte) string {
	var cfg magicConfig
	if err := json.Unmarshal(b, &cfg); err != nil {
		return fmt.Sprintf("magic.json inválido (%s); números 0x0 não são JSON", err.Error())
	}
	if cfg.ShootHandler == 0 || cfg.PlayerPedHandler == 0 {
		return "Magic inativo: handlers zerados; DLL e integração interna não fornecidas"
	}
	return "Configuração presente, porém Magic não instalado neste EXE externo (DLL ausente)"
}

func magicStatus(folder string) map[string]any {
	paths := []string{filepath.Join(folder, "magic.json"), filepath.Join(filepath.Dir(folder), "magic.json")}
	for _, path := range paths {
		data, err := os.ReadFile(path)
		if err != nil {
			continue
		}
		return map[string]any{"available": false, "status": inspectMagicJSON(data)}
	}
	return map[string]any{"available": false, "status": "Magic requer resource Lua no servidor autorizado ou DLL interna; arquivos-fonte ausentes"}
}
