//go:build windows

package main

import "testing"

func TestSparsePedPoolUsesCapacityNotActiveCount(t *testing.T) {
	slots, ok := pedScanCapacity(1, 128)
	if !ok || slots != 128 {
		t.Fatalf("wanted full capacity, got %d %v", slots, ok)
	}
	r := fakeESPReader{
		pointers:  map[uintptr]uintptr{0x1000 + 99*0x10: 0x5000, 0x5000 + 0x10A8: 0xA000},
		positions: map[uintptr]vec3{0x5000 + 0x90: {X: 40, Z: 20}},
		floats:    map[uintptr]float32{0x5000 + 0x280: 150, 0x5000 + 0x150C: 25},
	}
	d := ESPDiagnostics{}
	out := scanPlayers(r, 0x1000, slots, 0, vec3{Z: 20}, 500, &d)
	if len(out) != 1 || d.Slots != 128 || d.Pointers != 1 {
		t.Fatalf("must find ped in a sparse, late slot: %+v %+v", out, d)
	}
}

func TestPedScanBounds(t *testing.T) {
	tests := []struct {
		active, cap, want uint32
		ok                bool
	}{
		{0, 0, 0, false}, {0, 256, 256, true}, {5, 256, 256, true},
		{10, 5, 10, true}, {5000, 6000, 0, false},
		{30, 300000, 30, true}, {0, 300000, 0, false},
	}
	for _, tc := range tests {
		got, ok := pedScanCapacity(tc.active, tc.cap)
		if got != tc.want || ok != tc.ok {
			t.Fatalf("active=%d cap=%d: got %d,%v want %d,%v", tc.active, tc.cap, got, ok, tc.want, tc.ok)
		}
	}
}

// Ensure an optional bulk snapshot and the ordinary pointer reader agree.
type fakeBulkESPReader struct {
	fakeESPReader
	slots []uintptr
}

func (r fakeBulkESPReader) pedSlots(_ uintptr, _ uint32) []uintptr { return r.slots }
func TestBulkScanMatchesScalar(t *testing.T) {
	r := baseReader()
	a := ESPDiagnostics{}
	b := ESPDiagnostics{}
	one := scanPlayers(r, 0x1000, 2, 0xDEAD, vec3{Z: 20}, 500, &a)
	two := scanPlayers(fakeBulkESPReader{r, []uintptr{0x5000, 0x6000}}, 0x1000, 2, 0xDEAD, vec3{Z: 20}, 500, &b)
	if len(one) != len(two) || a != b {
		t.Fatalf("bulk mismatch: %v,%+v vs %v,%+v", one, a, two, b)
	}
}
