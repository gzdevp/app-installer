# sete7 v13.2 — Correção da leitura de HP e ação de armadura

## Erro reproduzido na captura

O EXE anterior acusava `Vida: campos de HP incompatíveis com personagem local` porque a leitura de vida máxima era feita em `CPed+0x2A0`. A implementação atual do FiveM/CitizenFX usa `CPed+0x280` para vida atual e `CPed+0x284` para `MaxHealthFloat` (veja `Entity.cs` no repositório citizenfx/fivem: `MemoryAddress + 640` e `+ 644`).

## Alterações

- `player_vitals_logic.go`: passa a obter vida máxima em `+0x284` e aceita valores de HP maiores do que máximo lido quando ambos são plausíveis, para permitir servidores com vida personalizada.
- `player_vitals_windows.go`: mantém leituras/limites e verificação de escrita do ped local; rejeita valores inesperados; ação Set armor implementada com o campo de armadura da build b3258 já lido pelo ESP em `+0x150C`.
- `main.go`: adiciona rota autenticada `/api/player/armor`.
- `web/index.html`: conecta botão Set armor ao backend e adiciona slider Armadura desejada (0 a 100) em Actions.
- `player_vitals_logic_test.go`: regressão para offset, boost 415 HP, armadura, e campos de servidor customizado.
- `player_vitals_other.go`: stub do botão em ambientes não-Windows.

## Validação disponível

- 9/9 testes isolados de HP/armadura passando, incluindo `TestHealthBoostMatchesScreenshot`.
- Build Windows x64 com `-H=windowsgui`: concluída e PE GUI verificado.
- `go test -c` para Windows: compilação dos testes concluída.
- `go vet` direcionado ao Windows: passou.
- `node --check` no JavaScript do painel: passou.
- Testes do pacote inteiro no Linux não executam devido a dependências do Windows.
- **Não executado dentro do FiveM.** É possível que o servidor reverta valores escritos.

## Limite de revive

`Tentar reviver` restaura apenas a vida local numérica. **Não é ressurreição comprovada:** não limpa flags server-side nem chama `NETWORK_RESURRECT_LOCAL_PLAYER`. O programa sempre informa que reanimação real não foi confirmada.

## Módulos preservados

A lógica de TP Waypoint, Aimbot, Silent, ESP, Noclip, FIX CAR e o host gráfico do painel não foi modificada. O painel continua a abrir por INSERT, sem janela de CMD.
