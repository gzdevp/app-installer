//go:build !windows

package main

func startNativeMenuHost()       {}
func attachBrowserToNativeHost() {}
