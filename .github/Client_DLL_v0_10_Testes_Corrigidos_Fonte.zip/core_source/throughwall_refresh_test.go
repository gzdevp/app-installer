package main

import "testing"

func TestPenetrationRefreshStateMachine(t *testing.T) {
	for _, tt := range []struct {
		current, original, installed float32
		want                         penetrationRefreshDecision
	}{
		{10, 0.2, 10, penetrationKeep},
		{0.2, 0.2, 10, penetrationReapply},
		{0.4, 0.2, 10, penetrationStop},
		{0, 0, 10, penetrationReapply},
		{10, 10, 10, penetrationKeep},
	} {
		if got := classifyPenetrationRefresh(tt.current, tt.original, tt.installed); got != tt.want {
			t.Fatalf("classifyPenetrationRefresh(%v,%v,%v)=%d, want %d", tt.current, tt.original, tt.installed, got, tt.want)
		}
	}
}
