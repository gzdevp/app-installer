package main

import (
	"encoding/binary"
	"errors"
	"math"
)

const (
	tpWaypointSprite uint32 = 8
	tpWaypointColor  uint32 = 84
	tpBlipSlots             = 2000
	tpBlipBatch             = 64
)

// waypointReader is a read-only memory primitive: it is injectable in tests.
type waypointReader func(uintptr, []byte) bool

func tpReadU32(read waypointReader, address uintptr) (uint32, bool) {
	var b [4]byte
	if !read(address, b[:]) {
		return 0, false
	}
	return binary.LittleEndian.Uint32(b[:]), true
}
func tpReadPosition(read waypointReader, address uintptr) (vec3, bool) {
	var b [12]byte
	if !read(address, b[:]) {
		return vec3{}, false
	}
	v := vec3{
		X: math.Float32frombits(binary.LittleEndian.Uint32(b[0:4])),
		Y: math.Float32frombits(binary.LittleEndian.Uint32(b[4:8])),
		Z: math.Float32frombits(binary.LittleEndian.Uint32(b[8:12])),
	}
	return v, tpIsWaypointPosition(v)
}
func tpIsWaypointPosition(pos vec3) bool {
	return plausibleFiveMPosition(pos) &&
		math.Abs(float64(pos.X)) <= 10000 && math.Abs(float64(pos.Y)) <= 10000 &&
		(math.Abs(float64(pos.X)) >= 0.1 || math.Abs(float64(pos.Y)) >= 0.1)
}
func tpCandidateWaypoint(read waypointReader, address uintptr) (vec3, bool) {
	icon, ok := tpReadU32(read, address+0x40)
	if !ok || icon != tpWaypointSprite {
		return vec3{}, false
	}
	color, ok := tpReadU32(read, address+0x48)
	if !ok || color != tpWaypointColor {
		return vec3{}, false
	}
	return tpReadPosition(read, address+0x10)
}

// BlipList in the supported build is a contiguous table of 64-bit pointers.
// Read in bounded batches, with a per-pointer fallback for partially readable pages.
func tpFindWaypoint(read waypointReader, list uintptr) (vec3, error) {
	if list < 0x10000 || list > 0x7FFFFFFFFFFF {
		return vec3{}, errors.New("endereço da lista de marcadores inválido")
	}
	seen := make(map[uintptr]struct{}, 8)
	for first := 0; first < tpBlipSlots; first += tpBlipBatch {
		n := tpBlipBatch
		if tpBlipSlots-first < n {
			n = tpBlipSlots - first
		}
		buffer := make([]byte, 8*n)
		batched := read(list+uintptr(first*8), buffer)
		for i := 0; i < n; i++ {
			var address uintptr
			if batched {
				address = uintptr(binary.LittleEndian.Uint64(buffer[i*8 : i*8+8]))
			} else {
				var single [8]byte
				if !read(list+uintptr((first+i)*8), single[:]) {
					continue
				}
				address = uintptr(binary.LittleEndian.Uint64(single[:]))
			}
			if address < 0x10000 || address > 0x7FFFFFFFFFFF {
				continue
			}
			if _, exists := seen[address]; exists {
				continue
			}
			seen[address] = struct{}{}
			if waypoint, valid := tpCandidateWaypoint(read, address); valid {
				return waypoint, nil
			}
		}
	}
	return vec3{}, errors.New("marcador roxo do mapa não encontrado")
}

// The blip Z often contains 0, not the terrain height. Allow an explicit Z
// selected on the panel instead of claiming to resolve ground collision.
func tpDestination(waypoint vec3, requestedZ float32) (vec3, error) {
	if !tpIsWaypointPosition(waypoint) {
		return vec3{}, errors.New("coordenadas do waypoint inválidas")
	}
	if math.IsNaN(float64(requestedZ)) || math.IsInf(float64(requestedZ), 0) || requestedZ < -100 || requestedZ > 1500 {
		return vec3{}, errors.New("altura Z fora do intervalo permitido")
	}
	return vec3{X: waypoint.X, Y: waypoint.Y, Z: requestedZ}, nil
}
