# 77 Black Edition v13.9.58 — Tela de Login

- Primeiro INSERT mostra uma tela para USERNAME e KEY.
- Login validado no servidor local; protegido por comparação constante de hash SHA-256 com salt.
- Sessão HTTP `HttpOnly; SameSite=Strict` necessária para todas as rotas de API.
- Rate-limit: após 5 tentativas incorretas, bloquear por 30 segundos.
- Sessão restrita ao processo atual: ao fechar o EXE a autorização expira.
- INSERT continua alternando visibilidade após login, sem pedir novamente até reiniciar.
- Visual do painel e lógica dos recursos preexistentes mantidos.
- NOTA: licença offline local não substitui ativação online contra engenharia reversa.
