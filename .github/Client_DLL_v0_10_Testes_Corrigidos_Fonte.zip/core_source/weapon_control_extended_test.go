package main

import "testing"

func TestWeaponExtendedOffsetsAndPellets(t *testing.T) {
	if weaponAccuracySpreadOffset != 0x74 || weaponSpreadOffset != 0x84 || weaponBatchSpreadOffset != 0x124 || weaponReloadRateOffset != 0x134 {
		t.Fatal("unexpected weapon layout")
	}
	for _, v := range []uint32{2, 8, 32, 64} {
		if !weaponHasPellets(v) {
			t.Fatalf("batch %d", v)
		}
	}
	for _, v := range []uint32{0, 1, 65, 0xffffffff} {
		if weaponHasPellets(v) {
			t.Fatalf("bad batch %d", v)
		}
	}
}
func TestReloadValidation(t *testing.T) {
	if weaponReloadRatePlausible(0) || !weaponReloadRatePlausible(1) || weaponReloadRatePlausible(1000) {
		t.Fatal("reload range")
	}
	if !weaponValueMatches(1000, 1000) || weaponValueMatches(1, 1000) {
		t.Fatal("target readback")
	}
}
