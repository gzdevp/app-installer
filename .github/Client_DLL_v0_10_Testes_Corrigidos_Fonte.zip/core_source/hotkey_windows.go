//go:build windows

package main

import (
	"path/filepath"
	"runtime"
	"strings"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

// Global hotkey used ONLY to show/hide our own browser app window.
// It does not inject into FiveM or other processes, mask this process,
// install any hooks, or bypass any protection.
const (
	wmHotkey                       = 0x0312
	vkInsert                       = 0x2D
	modNoRepeat                    = 0x4000
	swHide                         = 0
	swShow                         = 5
	processQueryLimitedInformation = 0x1000
)

var (
	user32Hotkey         = syscall.NewLazyDLL("user32.dll")
	regHotkey            = user32Hotkey.NewProc("RegisterHotKey")
	unregHotkey          = user32Hotkey.NewProc("UnregisterHotKey")
	getMessageW          = user32Hotkey.NewProc("GetMessageW")
	getForeground        = user32Hotkey.NewProc("GetForegroundWindow")
	getWindowPid         = user32Hotkey.NewProc("GetWindowThreadProcessId")
	enumWindows          = user32Hotkey.NewProc("EnumWindows")
	getWindowLen         = user32Hotkey.NewProc("GetWindowTextLengthW")
	getWindowText        = user32Hotkey.NewProc("GetWindowTextW")
	showWindow           = user32Hotkey.NewProc("ShowWindow")
	setForeground        = user32Hotkey.NewProc("SetForegroundWindow")
	isWindowVisible      = user32Hotkey.NewProc("IsWindowVisible")
	winIsChild           = user32Hotkey.NewProc("IsChild")
	openProcessHotkey    = kernel32Process.NewProc("OpenProcess")
	queryProcessFilename = kernel32Process.NewProc("QueryFullProcessImageNameW")
	getWindowLongPtr     = user32Hotkey.NewProc("GetWindowLongPtrW")
	setWindowLongPtr     = user32Hotkey.NewProc("SetWindowLongPtrW")
	setWindowPos         = user32Hotkey.NewProc("SetWindowPos")
	postMessage          = user32Hotkey.NewProc("PostMessageW")
)

type winMessage struct {
	Hwnd    uintptr
	Message uint32
	_       uint32 // padding before WParam on Windows amd64
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	PtX     int32
	PtY     int32
	Private uint32
}

func activeFiveMWindow(hwnd uintptr) bool {
	if hwnd == 0 {
		return false
	}
	var pid uint32
	getWindowPid.Call(hwnd, uintptr(unsafe.Pointer(&pid)))
	if pid == 0 {
		return false
	}
	handle, _, _ := openProcessHotkey.Call(processQueryLimitedInformation, 0, uintptr(pid))
	if handle == 0 {
		return false
	}
	defer closeKernelHandle.Call(handle)
	name := make([]uint16, 2048)
	length := uint32(len(name))
	ok, _, _ := queryProcessFilename.Call(handle, 0, uintptr(unsafe.Pointer(&name[0])), uintptr(unsafe.Pointer(&length)))
	if ok == 0 {
		return false
	}
	return isFiveMProcess(filepath.Base(syscall.UTF16ToString(name[:length])))
}

var menuWanted atomic.Bool
var insertHotkeyRegistered atomic.Bool

// A Windows syscall callback is registered for the lifetime of the process.
// Never allocate one inside a polling function: Go's callback table is finite,
// and filling it ends the whole process with a runtime throw (not recoverable).
type browserWindowScan struct {
	found    uintptr
	bestArea int64
}

var browserWindowEnumCallback = syscall.NewCallback(func(hwnd, param uintptr) uintptr {
	entry, ok := windowEnumContexts.Load(param)
	if !ok {
		return 1
	}
	state, ok := entry.(*browserWindowScan)
	if !ok {
		return 1
	}
	length, _, _ := getWindowLen.Call(hwnd)
	if length > 512 {
		return 1
	}
	title := make([]uint16, length+1)
	getWindowText.Call(hwnd, uintptr(unsafe.Pointer(&title[0])), uintptr(len(title)))
	name := strings.ToLower(syscall.UTF16ToString(title))
	var pid uint32
	getWindowPid.Call(hwnd, uintptr(unsafe.Pointer(&pid)))
	if !isCurrentBrowserTitle(name) && !isSessionBrowserPID(pid) {
		return 1
	}
	var bounds rect
	if ok, _, _ := getWindowRectFrame.Call(hwnd, uintptr(unsafe.Pointer(&bounds))); ok == 0 {
		return 1
	}
	w, h := int64(bounds.Right-bounds.Left), int64(bounds.Bottom-bounds.Top)
	if w < 380 || h < 250 {
		return 1
	}
	area := w * h
	if v, _, _ := isWindowVisible.Call(hwnd); v == 0 {
		area /= 4
	}
	if area > state.bestArea {
		state.found, state.bestArea = hwnd, area
	}
	return 1
})

func browserTopWindow() uintptr {
	state := &browserWindowScan{bestArea: -1}
	enumWindowsWithContext(browserWindowEnumCallback, state)
	return state.found
}

// The browser-hosted UI is presented as a frameless tool window. This is
// a normal Windows UI style, not process hiding or an anti-cheat workaround.
// WS_EX_TOOLWINDOW keeps it off the taskbar and normal Alt+Tab switcher.
func customizeOwnWindow(hwnd uintptr) {
	if nativeHostHWND.Load() != 0 && hwnd == nativeHostHWND.Load() {
		// Do not rewrite Chromium's non-client area while it is about to be
		// reparented; racing SetWindowLong changes its measured titlebar.
		return
	}
	const (
		gwlStyle        = ^uintptr(15) // -16
		gwlExStyle      = ^uintptr(19) // -20
		wsPopup         = uintptr(0x80000000)
		wsCaption       = uintptr(0x00C00000)
		wsThickFrame    = uintptr(0x00040000)
		wsSysMenu       = uintptr(0x00080000)
		wsMinimizeBox   = uintptr(0x00020000)
		wsMaximizeBox   = uintptr(0x00010000)
		wsExAppWindow   = uintptr(0x00040000)
		wsExToolWindow  = uintptr(0x00000080)
		swpNoMove       = uintptr(0x0002)
		swpNoSize       = uintptr(0x0001)
		swpNoActivate   = uintptr(0x0010)
		swpFrameChanged = uintptr(0x0020)
		hwndTopmost     = ^uintptr(0) // HWND_TOPMOST -1
	)
	style, _, _ := getWindowLongPtr.Call(hwnd, gwlStyle)
	wanted := (style &^ (wsCaption | wsThickFrame | wsSysMenu | wsMinimizeBox | wsMaximizeBox)) | wsPopup
	changed := false
	if wanted != style {
		setWindowLongPtr.Call(hwnd, gwlStyle, wanted)
		changed = true
	}
	exStyle, _, _ := getWindowLongPtr.Call(hwnd, gwlExStyle)
	wantedEx := (exStyle &^ wsExAppWindow) | wsExToolWindow
	if wantedEx != exStyle {
		setWindowLongPtr.Call(hwnd, gwlExStyle, wantedEx)
		changed = true
	}
	if changed {
		// Taskbar grouping notices style changes reliably after hide/show.
		// A panel deliberately hidden with INSERT must remain hidden.
		wasVisible, _, _ := isWindowVisible.Call(hwnd)
		if wasVisible != 0 {
			showWindow.Call(hwnd, swHide)
		}
		setWindowPos.Call(hwnd, hwndTopmost, 0, 0, 0, 0, swpNoMove|swpNoSize|swpNoActivate|swpFrameChanged)
		if wasVisible != 0 && menuWanted.Load() {
			showWindow.Call(hwnd, swShowNA)
		}
	}
	// Fallback for Chromium app windows: Windows/Chromium may re-create its
	// non-client caption after a cross-process style update. A window region
	// restricted to the browser client physically clips the OS title buttons.
	// It never modifies a game process or conceals this executable from Windows.
	clipBrowserWindowToClient(hwnd)
}

// Use the exact game client bounds, not desktop coordinates or window borders.
// Even when the native menu gains focus, it stays physically over FiveM.
func placeMenuWithinViewport(hwnd uintptr, vp espViewport) {
	if hwnd != 0 && hwnd == nativeHostHWND.Load() {
		positionNativeHost(hwnd, vp)
		return
	}
	const hwndTopmost = ^uintptr(0)
	const swpNoActivate = uintptr(0x0010)
	if vp.W < 320 || vp.H < 240 {
		return
	}
	w, h := menuDimensions()
	if w > vp.W {
		w = vp.W
	}
	if h > vp.H {
		h = vp.H
	}
	x := vp.X + (vp.W-w)/2
	y := vp.Y + (vp.H-h)/2
	setWindowPos.Call(hwnd, hwndTopmost, uintptr(x), uintptr(y), uintptr(w), uintptr(h), swpNoActivate)
	// Rebuild the region after moves/resizes because the browser may recalc
	// its non-client frame when the viewport changes.
	clipBrowserWindowToClient(hwnd)
}

func closeOwnWindow() {
	// Only an explicit Unload/Cleaner (or final process teardown) is allowed
	// to destroy the native host. INSERT and lost focus only hide the menu.
	nativeHostCloseAuthorized.Store(true)
	const wmClose = 0x0010
	if browser := standaloneBrowserHWND.Load(); browser != 0 {
		postMessage.Call(browser, wmClose, 0, 0)
	}
	if child := nativeChildHWND.Load(); child != 0 {
		postMessage.Call(child, wmClose, 0, 0)
	}
	if hwnd := nativeHostHWND.Load(); hwnd != 0 {
		postMessage.Call(hwnd, wmClose, 0, 0)
	} else if hwnd := browserTopWindow(); hwnd != 0 {
		postMessage.Call(hwnd, wmClose, 0, 0)
	}
}

// Last browser start throttles recovery when Chromium takes time to initialize.
var uiBrowserLastStart atomic.Int64
var uiBrowserAttachRunning atomic.Bool

// INSERT must not be canceled while our own Chromium starts up or briefly
// takes focus. This fixes the "Edge taskbar icon, no panel" race.
var uiOpeningDeadline atomic.Int64

func openingPending() bool {
	deadline := uiOpeningDeadline.Load()
	return menuWanted.Load() && deadline > 0 && time.Now().UnixNano() < deadline
}

func viewportForAnyFiveM() (espViewport, bool) {
	game, ok := locateAnyFiveMWindow()
	if !ok {
		return espViewport{}, false
	}
	var r rect
	var origin point
	got, _, _ := getClientRect.Call(game, uintptr(unsafe.Pointer(&r)))
	moved, _, _ := toScreen.Call(game, uintptr(unsafe.Pointer(&origin)))
	if got == 0 || moved == 0 || r.Right-r.Left < 320 || r.Bottom-r.Top < 240 {
		return espViewport{}, false
	}
	return espViewport{X: origin.X, Y: origin.Y, W: r.Right - r.Left, H: r.Bottom - r.Top}, true
}

func isPanelForeground(fg, hwnd uintptr) bool {
	if fg == hwnd && hwnd != 0 {
		return true
	}
	if fg == 0 || hwnd == 0 {
		return false
	}
	if isChild, _, _ := winIsChild.Call(hwnd, fg); isChild != 0 {
		return true
	}
	// On some Chromium builds the renderer/owned popup temporarily becomes
	// foreground instead of the native host. It still belongs to our private
	// browser instance, so don't treat that transition as lost FiveM focus.
	var pid uint32
	getWindowPid.Call(fg, uintptr(unsafe.Pointer(&pid)))
	return isSessionBrowserPID(pid)
}

func presentMenuAfterLaunch() {
	if !menuWanted.Load() {
		return
	}
	hwnd := menuWindow()
	if hwnd == 0 {
		return
	}
	customizeOwnWindow(hwnd)
	if vp, ok := viewportForAnyFiveM(); ok {
		placeMenuWithinViewport(hwnd, vp)
	}
	if hwnd == standaloneBrowserHWND.Load() {
		// --start-minimized and offscreen placement must be undone on fallback.
		showWindow.Call(hwnd, 9) // SW_RESTORE
		if vp, ok := viewportForAnyFiveM(); ok {
			placeMenuWithinViewport(hwnd, vp)
		}
	}
	showWindow.Call(hwnd, swShow)
	setForeground.Call(hwnd)
	requestNativeBrowserFocus(hwnd)
	// Chromium may briefly have focus even after attachment. Keep a small
	// post-show grace period so the watchdog does not immediately hide it.
	uiOpeningDeadline.Store(time.Now().Add(5 * time.Second).UnixNano())
}

func requestMenuBrowser(s *service) {
	if menuWindow() != 0 {
		return
	}
	if !uiBrowserAttachRunning.CompareAndSwap(false, true) {
		return
	}
	// If Chromium is already running without a parent, attach that window.
	// Otherwise launch it *only* in direct response to an in-game INSERT.
	existing := browserTopWindow()
	if existing == 0 {
		now := time.Now().UnixNano()
		last := uiBrowserLastStart.Load()
		if last > 0 && now-last < int64(8*time.Second) {
			uiBrowserAttachRunning.Store(false)
			return
		}
		uiBrowserLastStart.Store(now)
	}
	go func() {
		defer recoverServiceWorker("hotkey_windows.go")
		defer uiBrowserAttachRunning.Store(false)
		if existing != 0 {
			showWindow.Call(existing, swHide)
		} else {
			s.diagnosticEvent("ui_browser_start_requested_by_insert")
			if err := openAppWindow(s.uiURL); err != nil {
				s.diagnosticEvent("ui_browser_start_failed_" + err.Error())
				return
			}
			// If Chrome's Incognito+app combination fails to create a
			// window, retry with the same isolated disposable profile in
			// standard app mode. Do not leave INSERT stuck indefinitely.
			appeared := false
			for i := 0; i < 65; i++ {
				if browserTopWindow() != 0 {
					appeared = true
					break
				}
				if s.stopping.Load() {
					return
				}
				time.Sleep(100 * time.Millisecond)
			}
			if !appeared {
				s.diagnosticEvent("ui_private_launch_unavailable_retry_app")
				stopSessionBrowsers()
				if err := openAppWindowMode(s.uiURL, false); err != nil {
					s.diagnosticEvent("ui_isolated_app_fallback_failed_" + err.Error())
					return
				}
			}
		}
		attached := attachBrowserToNativeHost()
		if attached {
			s.diagnosticEvent("ui_browser_attached")
		} else {
			// Some Windows/Chromium combinations reject cross-process
			// SetParent (DPI contexts, renderer recreation). Never leave the
			// browser stranded/minimized on the taskbar in that case.
			if browser := browserTopWindow(); browser != 0 {
				standaloneBrowserHWND.Store(browser)
				s.diagnosticEvent("ui_native_attach_failed_standalone_browser")
			} else {
				s.diagnosticEvent("ui_browser_attach_failed_no_browser_window")
			}
		}
		presentMenuAfterLaunch()
	}()
}

func runWindowShortcut(s *service) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	const id = 711
	// RegisterHotKey may fail when another still-running 77 or a different
	// application already owns INSERT. Never strand the service permanently:
	// try again when the key becomes free. Do not steal another app's hotkey.
	registrationFailed := false
	for !s.stopping.Load() {
		ok, _, _ := regHotkey.Call(0, id, modNoRepeat, vkInsert)
		if ok == 0 {
			if !registrationFailed {
				s.diagnosticEvent("insert_hotkey_registration_failed_retrying")
				registrationFailed = true
			}
			time.Sleep(2 * time.Second)
			continue
		}
		insertHotkeyRegistered.Store(true)
		if registrationFailed {
			s.diagnosticEvent("insert_hotkey_registration_recovered")
			registrationFailed = false
		} else {
			s.diagnosticEvent("insert_hotkey_registered")
		}
		var msg winMessage
		for !s.stopping.Load() {
			res, _, _ := getMessageW.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
			if int32(res) <= 0 {
				break
			}
			if msg.Message != wmHotkey || msg.WParam != id {
				continue
			}
			foreground, _, _ := getForeground.Call()
			hwnd := menuWindow()
			if !isPanelForeground(foreground, hwnd) && !activeFiveMWindow(foreground) {
				continue
			}
			if menuWanted.Load() {
				uiOpeningDeadline.Store(0)
				menuWanted.Store(false)
				if hwnd != 0 {
					showWindow.Call(hwnd, swHide)
				}
				if hwnd != 0 && foreground == hwnd {
					if fg, ok := locateAnyFiveMWindow(); ok {
						setForeground.Call(fg)
					}
				}
				continue
			}
			menuWanted.Store(true)
			uiOpeningDeadline.Store(time.Now().Add(40 * time.Second).UnixNano())
			if hwnd == 0 {
				requestMenuBrowser(s)
				continue
			}
			customizeOwnWindow(hwnd)
			if vp, ok := foregroundFiveMViewport(); ok {
				placeMenuWithinViewport(hwnd, vp)
			}
			showWindow.Call(hwnd, swShow)
			setForeground.Call(hwnd)
			requestNativeBrowserFocus(hwnd)
		}
		insertHotkeyRegistered.Store(false)
		unregHotkey.Call(0, id)
		if !s.stopping.Load() {
			s.diagnosticEvent("insert_hotkey_message_loop_ended_retrying")
			time.Sleep(time.Second)
		}
	}
}

// The menu remains a normal tool window but is visible only in the FiveM
// context; switching to another application hides it automatically.
func monitorOwnWindow(s *service) {
	tick := time.NewTicker(150 * time.Millisecond)
	defer tick.Stop()
	missing := 0
	var lastView espViewport
	var lastPlaced espViewport
	var lastWindow uintptr
	var lastAuthenticated bool
	// Windows can temporarily change the foreground handle when Chromium
	// gets keyboard focus, creates a child window or when the game changes
	// display mode. Do not interpret these short gaps as a request to close.
	var lastContextAt time.Time
	var lastHostAttempt time.Time
	hostRestarts := 0
	const focusGrace = 3 * time.Second
	const browserRecoveryGrace = 12 * time.Second
	for range tick.C {
		if s.stopping.Load() {
			return
		}
		// An unexpected WM_DESTROY used to leave the UI permanently absent.
		// Re-create the normal, visible-on-INSERT host without restarting the
		// application; bound retries prevent a failing window from looping.
		// A destroyed host may leave a nonzero but invalid HWND. Without this
		// check the previous watchdog never attempted to replace it.
		if stale := nativeHostHWND.Load(); stale != 0 {
			if valid, _, _ := nativeIsWindow.Call(stale); valid == 0 {
				nativeHostHWND.CompareAndSwap(stale, 0)
				nativeHostPrepared.Store(false)
				nativeChildHWND.Store(0)
			}
		}
		if nativeHostHWND.Load() == 0 && !nativeHostCloseAuthorized.Load() {
			if hostRestarts < 5 && time.Since(lastHostAttempt) > 2*time.Second {
				lastHostAttempt = time.Now()
				hostRestarts++
				writeCrashRecord("native-host", "native window missing; attempting bounded recovery")
				startNativeMenuHost()
			}
		} else if nativeHostHWND.Load() != 0 {
			hostRestarts = 0
		}
		fg, _, _ := getForeground.Call()
		gameFront := activeFiveMWindow(fg)
		hwnd := menuWindow()
		if hwnd == 0 {
			// Chromium can recreate its window after a GPU reset, focus
			// transition, or user closing the browser surface. Never turn a
			// transient missing window into an implicit Unload or INSERT off.
			// Recovery is throttled by requestMenuBrowser itself.
			if gameFront {
				lastContextAt = time.Now()
			}
			// The last browser window can vanish while IT has focus, before the
			// game regains foreground. Use recent trusted in-game focus to repair
			// the menu without requiring another INSERT from the user.
			recentContext := !lastContextAt.IsZero() && time.Since(lastContextAt) < browserRecoveryGrace
			if menuWanted.Load() && (gameFront || recentContext) && !uiBrowserAttachRunning.Load() {
				requestMenuBrowser(s)
			}
			if menuWanted.Load() {
				missing++
				if missing == 1 && lastWindow != 0 {
					s.diagnosticEvent("ui_window_lost_service_stays_running")
					writeCrashRecord("browser", "embedded browser window vanished; recovery will be attempted")
					lastWindow = 0
					lastPlaced = espViewport{}
				}
			}
			continue
		}
		if missing > 0 {
			s.diagnosticEvent("ui_window_restored")
			missing = 0
		}
		if hwnd != lastWindow {
			lastWindow = hwnd
			lastPlaced = espViewport{}
		}
		customizeOwnWindow(hwnd)
		if gameFront {
			if view, ok := foregroundFiveMViewport(); ok {
				lastView = view
			}
		} else if lastView.W == 0 && (isPanelForeground(fg, hwnd) || openingPending()) {
			if view, ok := viewportForAnyFiveM(); ok {
				lastView = view
			}
		} else if fg == hwnd && lastView.W == 0 {
			if gameHwnd, ok := locateAnyFiveMWindow(); ok {
				var r rect
				var origin point
				got, _, _ := getClientRect.Call(gameHwnd, uintptr(unsafe.Pointer(&r)))
				moved, _, _ := toScreen.Call(gameHwnd, uintptr(unsafe.Pointer(&origin)))
				if got != 0 && moved != 0 && r.Right-r.Left >= 320 && r.Bottom-r.Top >= 240 {
					lastView = espViewport{X: origin.X, Y: origin.Y, W: r.Right - r.Left, H: r.Bottom - r.Top}
				}
			}
		}
		contextActive := gameFront || isPanelForeground(fg, hwnd) || openingPending()
		if contextActive {
			lastContextAt = time.Now()
		}
		allowed := lastView.W >= 320 && lastView.H >= 240 &&
			(contextActive || (!lastContextAt.IsZero() && time.Since(lastContextAt) < focusGrace))
		if !allowed {
			// Keep the session and user's INSERT state intact on Alt+Tab,
			// lost focus or temporarily unavailable FiveM. Hide the surface
			// outside the game, but show it again if the user returns.
			showWindow.Call(hwnd, swHide)
			continue
		}
		if !menuWanted.Load() {
			showWindow.Call(hwnd, swHide)
			continue
		}
		// On successful authentication the same native window expands to
		// full size even if the game's viewport has not moved.
		authenticated := menuAuthenticated.Load()
		if lastView != lastPlaced || lastAuthenticated != authenticated {
			placeMenuWithinViewport(hwnd, lastView)
			lastPlaced = lastView
			lastAuthenticated = authenticated
		}
		visible, _, _ := isWindowVisible.Call(hwnd)
		if visible == 0 {
			// First show follows the explicit INSERT, never service startup.
			showWindow.Call(hwnd, swShow)
			setForeground.Call(hwnd)
			requestNativeBrowserFocus(hwnd)
		}
	}
}

// When INSERT hides the panel, return focus to the game, not to an arbitrary app.
type fiveMWindowScan struct {
	selected uintptr
	biggest  int64
}

var fiveMWindowEnumCallback = syscall.NewCallback(func(hwnd, param uintptr) uintptr {
	entry, ok := windowEnumContexts.Load(param)
	if !ok {
		return 1
	}
	state, ok := entry.(*fiveMWindowScan)
	if !ok {
		return 1
	}
	if !activeFiveMWindow(hwnd) {
		return 1
	}
	visible, _, _ := isWindowVisible.Call(hwnd)
	if visible == 0 {
		return 1
	}
	var r rect
	if ok, _, _ := getClientRect.Call(hwnd, uintptr(unsafe.Pointer(&r))); ok == 0 {
		return 1
	}
	w, h := r.Right-r.Left, r.Bottom-r.Top
	if w < 320 || h < 240 {
		return 1
	}
	area := int64(w) * int64(h)
	if area > state.biggest {
		state.biggest = area
		state.selected = hwnd
	}
	return 1
})

func locateAnyFiveMWindow() (uintptr, bool) {
	state := &fiveMWindowScan{}
	enumWindowsWithContext(fiveMWindowEnumCallback, state)
	return state.selected, state.selected != 0
}

var messageBox = user32Hotkey.NewProc("MessageBoxW")

func showStartupError(message string) {
	content, _ := syscall.UTF16PtrFromString(message)
	caption, _ := syscall.UTF16PtrFromString("sete7 - Erro ao iniciar")
	messageBox.Call(0, uintptr(unsafe.Pointer(content)), uintptr(unsafe.Pointer(caption)), 0x10)
}
