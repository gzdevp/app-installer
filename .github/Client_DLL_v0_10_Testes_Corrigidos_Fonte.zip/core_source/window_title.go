package main

import "strings"

// Legacy titles and the short "77 | v..." label identify the
// sete7 Chromium window. Keep this in sync with web/index.html; otherwise
// the browser starts but the native menu host never attaches it.
func isSete7BrowserTitle(title string) bool {
	name := strings.ToLower(strings.TrimSpace(title))
	return strings.HasPrefix(name, "sete7 | external v") ||
		strings.HasPrefix(name, "sete7 | black edition v") ||
		strings.HasPrefix(name, "77 | black edition v") ||
		strings.HasPrefix(name, "77 | v")
}

// During startup, never attach a browser window left by an older version.
// The UI title is checked by TestEmbeddedPageTitleRecognized to prevent a
// repeat of the 13.9 invisible-window regression.
// Read the title from the HTML embedded in THIS executable. No manual version
// number to update and no chance of silently breaking Insert after a rebrand.
var thisVersionTitle = func() string {
	b, err := files.ReadFile("web/index.html")
	if err != nil {
		return ""
	}
	s := string(b)
	a := strings.Index(strings.ToLower(s), "<title>")
	if a < 0 {
		return ""
	}
	a += len("<title>")
	bpos := strings.Index(strings.ToLower(s[a:]), "</title>")
	if bpos < 0 {
		return ""
	}
	return strings.ToLower(strings.TrimSpace(s[a : a+bpos]))
}()

func isCurrentBrowserTitle(title string) bool {
	name := strings.ToLower(strings.TrimSpace(title))
	return thisVersionTitle != "" && (name == thisVersionTitle ||
		strings.HasPrefix(name, thisVersionTitle+" - ") ||
		strings.HasPrefix(name, thisVersionTitle+" – ") ||
		strings.HasPrefix(name, thisVersionTitle+" — ") ||
		strings.HasPrefix(name, thisVersionTitle+" | "))
}
