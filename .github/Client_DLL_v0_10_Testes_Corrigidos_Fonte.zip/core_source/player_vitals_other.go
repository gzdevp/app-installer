//go:build !windows

package main

func playerHealthAction(requested float32, reviveMode bool) (string, bool) {
	return "Ação disponível somente no Windows", false
}
func playerVitalsGet() map[string]any {
	return map[string]any{"status": "Disponível somente no Windows", "ok": false}
}

func playerArmorAction(requested float32) (string, bool) {
	return "Ação disponível somente no Windows", false
}
