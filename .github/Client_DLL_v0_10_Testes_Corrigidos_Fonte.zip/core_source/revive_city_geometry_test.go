package main

import "testing"

func TestReviveCityButtonCoordinates(t *testing.T) {
	cases := []struct{ x, y, w, h, wantX, wantY int32 }{
		{0, 0, 1919, 1073, 1517, 401},
		{200, 100, 1919, 1073, 1717, 501},
		{0, 0, 1280, 720, 1011, 269},
	}
	for _, c := range cases {
		x, y, ok := reviveCityButtonTarget(c.x, c.y, c.w, c.h)
		if !ok || x != c.wantX || y != c.wantY {
			t.Errorf("got (%d,%d,%v), want (%d,%d)", x, y, ok, c.wantX, c.wantY)
		}
	}
}
func TestReviveCityButtonRejectsInvalidViewport(t *testing.T) {
	for _, dims := range [][2]int32{{0, 0}, {640, 480}, {1919, 0}, {50000, 1080}, {2560, 1080}} {
		_, _, ok := reviveCityButtonTarget(0, 0, dims[0], dims[1])
		if ok {
			t.Fatalf("accepted invalid %v", dims)
		}
	}
}
