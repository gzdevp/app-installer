//go:build windows

package main

import "testing"

func TestNearbyPlayersSortedByDistanceAndFriend(t *testing.T) {
	players := []candidatePed{
		{ptr: 0x1111, distance: 90.6, health: 200},
		{ptr: 0x2222, distance: 8.2, health: 200},
		{ptr: 0x3333, distance: 4.8, health: 200},
		{ptr: 0x4444, distance: 600.0, health: 200},
		{ptr: 0x5555, distance: 2.3, isNPC: true},
	}
	names := map[uintptr]string{0x1111: "Bruno", 0x2222: "Ana", 0x3333: "Jogador", 0x4444: "MuitoLonge"}
	counts := map[string]int{"bruno": 1, "ana": 1}
	got := buildNearbyPlayerList(players, names, counts, []string{"Ana"}, 500)
	if len(got) != 3 {
		t.Fatalf("expected 3 humans in range, got %+v", got)
	}
	if got[0].Distance != 5 || got[0].Identified || got[0].Friend || !got[0].Ambiguous {
		t.Errorf("unknown name %+v", got[0])
	}
	if got[1].Name != "Ana" || got[1].Distance != 8 || !got[1].Friend {
		t.Errorf("friend %+v", got[1])
	}
	if got[2].Name != "Bruno" || got[2].Distance != 91 || got[2].Friend {
		t.Errorf("other %+v", got[2])
	}
}
func TestNearbyPlayersRefuseDuplicateNameAsFriend(t *testing.T) {
	players := []candidatePed{{ptr: 1, distance: 30}, {ptr: 2, distance: 31}}
	names := map[uintptr]string{1: "MesmoNome", 2: "MesmoNome"}
	got := buildNearbyPlayerList(players, names, map[string]int{"mesmonome": 2}, []string{"MesmoNome"}, 500)
	if len(got) != 2 || got[0].Friend || got[1].Friend || !got[0].Ambiguous || !got[1].Ambiguous {
		t.Fatalf("collision: %+v", got)
	}
}
