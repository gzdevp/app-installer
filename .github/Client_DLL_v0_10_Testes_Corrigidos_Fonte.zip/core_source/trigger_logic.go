package main

import "math"

type TriggerSettings struct {
	Enabled   bool   `json:"enabled"`
	Key       string `json:"key"`
	Delay     int    `json:"delay"`
	Range     int    `json:"range"`
	Radius    int    `json:"radius"`
	TargetNPC bool   `json:"targetNpc"`
	Bone      string `json:"bone"`
}

func normalizeTrigger(s TriggerSettings) TriggerSettings {
	if !validBindingKey(s.Key) || s.Key == "mouse1" {
		s.Key = "mouse5"
	}
	if s.Delay < 0 {
		s.Delay = 0
	}
	if s.Delay > 300 {
		s.Delay = 300
	}
	if s.Range < 20 {
		s.Range = 20
	}
	if s.Range > 500 {
		s.Range = 500
	}
	if s.Radius < 3 {
		s.Radius = 3
	}
	if s.Radius > 30 {
		s.Radius = 30
	}
	if s.Bone != "body" {
		s.Bone = "head"
	}
	return s
}
func triggerCandidate(cx, cy int32, t targetESP, s TriggerSettings) bool {
	if t.Vehicle || t.Friend || (t.Downed && espGet().Settings.IgnoreDowned) || (!s.TargetNPC && t.IsNPC) || t.Health <= 0 || t.Distance <= 0 || t.Distance > s.Range {
		return false
	}
	if t.W <= 0 || t.H <= 0 {
		return false
	}
	if s.Bone == "head" {
		if !t.HeadVerified || !t.AimFromBone {
			return false
		}
		return math.Hypot(float64(t.AimX-cx), float64(t.AimY-cy)) <= float64(s.Radius)
	}
	// Body mode requires crosshair to be physically inside a fresh target box.
	return cx >= t.X && cx <= t.X+t.W && cy >= t.Y && cy <= t.Y+t.H
}

// triggerScanScope ensures the ESP reader sees the targets requested by
// Triggerbot even when all visual ESP/Aimbot/Silent settings are disabled.
func triggerScanScope(rangeMeters int, includeNPC bool, s TriggerSettings) (int, bool) {
	if !s.Enabled {
		return rangeMeters, includeNPC
	}
	if s.Range > rangeMeters {
		rangeMeters = s.Range
	}
	return rangeMeters, includeNPC || s.TargetNPC
}
