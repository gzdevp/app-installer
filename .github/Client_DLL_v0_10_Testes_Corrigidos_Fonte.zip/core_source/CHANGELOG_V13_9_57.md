# 77 Black Edition v13.9.57 — ESP 360° e detalhes de veículos

## Implementado

- Setas Off-Screen 360°: projeção somente visual para entidades fora do viewport, inclusive com profundidade negativa (atrás da câmera). Em posição exatamente atrás o indicador fica embaixo, pois não existe direção lateral única. Alvos na tela não geram marcador. As setas não são candidatos de mira.
- Reutilização da orientação de câmera previamente validada quando todos os jogadores saem da tela. Fallback limitado estritamente a marcadores; não é usado para Aimbot, caixas ou skeleton. Requer ao menos uma calibração visual prévia na sessão. Recusa matrizes degeneradas.
- Vehicle ESP: nova identificação experimental de motorista para b3258, com três verificações (ponteiro do motorista, vínculo ped↔veículo e posição) e confirmação no pool de peds; passageiros só são assim identificados quando o motorista estiver confirmado, senão nomes ficam como ocupantes sem assento confirmado.
- Classificação informativa da condição do motor a partir da leitura de saúde já existente (normal, desgastado, crítico). Sem inventar dados onde leitura não existir.
- Detalhes dos veículos exibem motorista, passageiros identificados, ocupantes sem assento confirmado, condição do motor e o estado indisponível da placa. Lista mostra o motorista somente quando efetivamente identificado.
- Controles existentes preservados; Off-Screen, Vehicle ESP e detalhes novos começam desligados conforme a configuração atual. Cleaner preservado.

## Não implementado

- **Indicador real de espectadores:** o programa externo não recebe quem está acompanhando a câmera de outra pessoa; nenhuma fonte confiável de telemetria de espectadores está disponível. Contadores hipotéticos seriam enganadores. Requer integração autorizada com servidor que exponha eventos reais.
- **Placa do veículo:** ainda não há leitura validada de texto da placa nesse leitor. Mostrada como indisponível.
- **Motorista / nomes de passageiros em builds diferentes de b3258:** sem layout validado.

## Validação

- Compilação nativa Windows AMD64 GUI concluída.
- `go vet` Windows concluído; `go test -c` Windows (compila testes, não executa) concluído.
- Testes unitários portáveis da geometria 360° e classificação da condição do motor passaram; sintaxe JavaScript validada.
- Não foi testado em um jogo FiveM rodando no Windows. Leituras de memória são experimentais e podem ser recusadas quando os perfis não batem.
- Não alterados Cleaner, logs, Prefetch ou proteção do Windows.
