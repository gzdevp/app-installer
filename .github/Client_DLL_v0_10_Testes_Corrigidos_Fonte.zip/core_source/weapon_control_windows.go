//go:build windows

package main

import (
	"encoding/binary"
	"fmt"
	"strings"
	"sync"
	"sync/atomic"
	"time"
	"unsafe"
)

type WeaponControlSettings struct {
	NoRecoil     bool `json:"noRecoil"`
	NoSpread     bool `json:"noSpread"`
	NoReload     bool `json:"noReload"`
	InfiniteAmmo bool `json:"infiniteAmmo"`
}
type weaponPatch struct {
	Addr     uintptr
	Original float32
	Modified bool
	Target   float32
}

var weaponController = struct {
	sync.RWMutex
	settings WeaponControlSettings
	status   string
	pid      uint32
	recoil   bool
	spread   bool
	reload   bool
	ammo     bool
}{status: "Desativado"}
var weaponStopping atomic.Bool
var weaponDone = make(chan struct{})

func weaponSet(s WeaponControlSettings) {
	weaponController.Lock()
	weaponController.settings = s
	weaponController.Unlock()
}
func weaponGet() map[string]any {
	weaponController.RLock()
	defer weaponController.RUnlock()
	return map[string]any{"status": weaponController.status, "pid": weaponController.pid, "noRecoil": weaponController.recoil, "noSpread": weaponController.spread, "noReload": weaponController.reload, "infiniteAmmo": weaponController.ammo, "requestedRecoil": weaponController.settings.NoRecoil, "requestedSpread": weaponController.settings.NoSpread, "requestedReload": weaponController.settings.NoReload, "requestedAmmo": weaponController.settings.InfiniteAmmo}
}
func weaponReport(status string, pid uint32, recoil, spread, reload, ammo bool) {
	weaponController.Lock()
	weaponController.status = status
	weaponController.pid = pid
	weaponController.recoil = recoil
	weaponController.spread = spread
	weaponController.reload = reload
	weaponController.ammo = ammo
	weaponController.Unlock()
}
func weaponSettings() WeaponControlSettings {
	weaponController.RLock()
	defer weaponController.RUnlock()
	return weaponController.settings
}

func patchWeaponTarget(a *noclipAttachment, addr uintptr, target float32, p *weaponPatch, valid func(float32) bool) error {
	if !validGamePointer(addr) {
		return fmt.Errorf("endereço inválido")
	}
	if p.Modified && (p.Addr != addr || !weaponValueMatches(p.Target, target)) {
		return fmt.Errorf("troca de campo sem restauração")
	}
	current, ok := readFloat32Game(a.read, addr)
	if !ok {
		return fmt.Errorf("campo indisponível")
	}
	if p.Modified {
		if weaponValueMatches(current, target) {
			return nil
		}
		// The engine may have restored its original value. Only rewrite when
		// still plausible; never overwrite a stale or unrelated field.
		if !valid(current) {
			return fmt.Errorf("valor incompatível")
		}
	} else {
		if !valid(current) {
			return fmt.Errorf("valor original incompatível")
		}
		p.Addr, p.Original, p.Target = addr, current, target
	}
	if !writeFloat32Game(a.writer, addr, target) {
		return fmt.Errorf("escrita recusada")
	}
	p.Modified = true
	if check, ok := readFloat32Game(a.read, addr); !ok || !weaponValueMatches(check, target) {
		return fmt.Errorf("verificação após escrita falhou")
	}
	return nil
}
func restoreWeaponFloat(a *noclipAttachment, p *weaponPatch) error {
	if !p.Modified {
		return nil
	}
	value, ok := readFloat32Game(a.read, p.Addr)
	if !ok {
		return fmt.Errorf("leitura indisponível para restauração")
	}
	// Restore only when the original patch is still installed. Respect game
	// changes and do not overwrite a value already replaced by the engine.
	if weaponValueMatches(value, p.Target) {
		if !writeFloat32Game(a.writer, p.Addr, p.Original) {
			return fmt.Errorf("escrita de restauração recusada")
		}
	}
	*p = weaponPatch{}
	return nil
}

type weaponUintPatch struct {
	Addr             uintptr
	Original, Target uint32
	Modified         bool
}

func readWeaponUint(p *attachedESP, addr uintptr) (uint32, bool) {
	var b [4]byte
	if !validGamePointer(addr) || !p.read(addr, b[:]) {
		return 0, false
	}
	return binary.LittleEndian.Uint32(b[:]), true
}
func writeWeaponUint(a *noclipAttachment, addr uintptr, v uint32) bool {
	var b [4]byte
	binary.LittleEndian.PutUint32(b[:], v)
	var n uintptr
	ok, _, _ := noclipWriteProcessMemory.Call(a.writer, addr, uintptr(unsafe.Pointer(&b[0])), 4, uintptr(unsafe.Pointer(&n)))
	return ok != 0 && n == 4
}
func patchWeaponUint(a *noclipAttachment, addr uintptr, value uint32, patch *weaponUintPatch, valid func(uint32) bool) error {
	if !validGamePointer(addr) {
		return fmt.Errorf("endereço de munição inválido")
	}
	if patch.Modified && (patch.Addr != addr || patch.Target != value) {
		return fmt.Errorf("ponteiro mudou antes da restauração")
	}
	current, ok := readWeaponUint(a.read, addr)
	if !ok {
		return fmt.Errorf("leitura de munição falhou")
	}
	if !patch.Modified {
		if !valid(current) {
			return fmt.Errorf("valor de munição incompatível")
		}
		patch.Addr, patch.Original, patch.Target = addr, current, value
	} else if current != value && !valid(current) {
		return fmt.Errorf("munição substituída pelo jogo")
	}
	if current != value && !writeWeaponUint(a, addr, value) {
		return fmt.Errorf("escrita de munição recusada")
	}
	check, ok := readWeaponUint(a.read, addr)
	if !ok || check != value {
		return fmt.Errorf("confirmação de munição falhou")
	}
	patch.Modified = true
	return nil
}
func restoreWeaponUint(a *noclipAttachment, p *weaponUintPatch) error {
	if !p.Modified {
		return nil
	}
	cur, ok := readWeaponUint(a.read, p.Addr)
	if !ok {
		return fmt.Errorf("não foi possível conferir o valor original")
	}
	if cur == p.Target {
		if !writeWeaponUint(a, p.Addr, p.Original) {
			return fmt.Errorf("restauração recusada")
		}
	}
	*p = weaponUintPatch{}
	return nil
}

// Resolve only the selected ped's ammo counter. All intermediate pointers
// must be readable and remain stable before a write; no global ammo flag is touched.
func resolveWeaponReserve(p *attachedESP, info uintptr) (uintptr, bool) {
	if !validGamePointer(info) {
		return 0, false
	}
	ammoInfo := p.ptr(info + weaponAmmoInfoOffset)
	if !validGamePointer(ammoInfo) {
		return 0, false
	}
	node := p.ptr(ammoInfo + weaponAmmoCountNodeOffset)
	if !validGamePointer(node) {
		return 0, false
	}
	entry := p.ptr(node)
	if !validGamePointer(entry) {
		return 0, false
	}
	address := entry + weaponAmmoCountValueOffset
	current, ok := readWeaponUint(p, address)
	if !ok || !weaponReservePlausible(current) {
		return 0, false
	}
	return address, true
}

// Isolated worker. A pointer chain must resolve from local ped->weapon manager
// on EVERY update. No process names/offsets are extrapolated beyond b3258.
func startWeaponControl() {
	go func() {
        defer recoverServiceWorker("weapon_control_windows.go")
		defer close(weaponDone)
		ticker := time.NewTicker(25 * time.Millisecond)
		defer ticker.Stop()
		var a *noclipAttachment
		var oldChain weaponChain
		var recoil, spread, baseSpread, batchSpread, reload, reloadMP, reloadSP weaponPatch
		var clip, ammo weaponUintPatch
		var lastAttach time.Time
		drop := func() {
			if a != nil {
				a.close()
				a = nil
			}
			oldChain = weaponChain{}
			recoil, spread, baseSpread, batchSpread, reload, reloadMP, reloadSP = weaponPatch{}, weaponPatch{}, weaponPatch{}, weaponPatch{}, weaponPatch{}, weaponPatch{}, weaponPatch{}
			clip, ammo = weaponUintPatch{}, weaponUintPatch{}
		}
		restore := func() error {
			if a == nil {
				return nil
			}
			var first error
			for _, p := range []*weaponPatch{&recoil, &spread, &baseSpread, &batchSpread, &reload, &reloadMP, &reloadSP} {
				if e := restoreWeaponFloat(a, p); e != nil && first == nil {
					first = e
				}
			}
			for _, p := range []*weaponUintPatch{&clip, &ammo} {
				if e := restoreWeaponUint(a, p); e != nil && first == nil {
					first = e
				}
			}
			return first
		}
		defer func() { _ = restore(); drop() }()
		for range ticker.C {
			cfg := weaponSettings()
			if weaponStopping.Load() {
				return
			}
			if !cfg.NoRecoil && !cfg.NoSpread && !cfg.NoReload && !cfg.InfiniteAmmo {
				if err := restore(); err != nil {
					weaponReport("Restauração pendente: "+err.Error(), 0, recoil.Modified, baseSpread.Modified, reload.Modified, ammo.Modified)
				} else {
					drop()
					weaponReport("Desativado", 0, false, false, false, false)
				}
				continue
			}
			if overlayPaused.Load() {
				_ = restore()
				drop()
				weaponReport("Aguardando foco do FiveM", 0, false, false, false, false)
				continue
			}
			if a == nil {
				if time.Since(lastAttach) < 800*time.Millisecond {
					continue
				}
				lastAttach = time.Now()
				next, err := attachWritableGame()
				if err != nil {
					weaponReport("FiveM indisponível: "+err.Error(), 0, false, false, false, false)
					continue
				}
				if next.read.build != "b3258" {
					weaponReport("Armas não validadas na build "+next.read.build, next.read.pid, false, false, false, false)
					next.close()
					continue
				}
				a = next
			}
			if espProcessExited(a.read.handle) || !fiveMIsForeground(a.read.pid) {
				_ = restore()
				drop()
				weaponReport("Aguardando FiveM em foco", 0, false, false, false, false)
				continue
			}
			l := espLayouts[a.read.build]
			world := a.read.ptr(a.read.base + l.world)
			chain, ok := resolveWeaponChain(world, a.read.ptr)
			if !ok {
				_ = restore()
				drop()
				weaponReport("Arma equipada indisponível", 0, false, false, false, false)
				continue
			}
			pos, posOK := a.read.vec3(chain.ped + 0x90)
			if !posOK || !plausibleFiveMPosition(pos) {
				_ = restore()
				drop()
				weaponReport("Personagem inválido", 0, false, false, false, false)
				continue
			}
			if oldChain.info != 0 && oldChain.info != chain.info {
				// Crucial fix: restoring on swap must NOT close the writable
				// connection and force a 0.8–1.5 s cooldown on each weapon.
				if err := restore(); err != nil {
					weaponReport("Troca de arma: restauração pendente", a.read.pid, recoil.Modified, baseSpread.Modified, reload.Modified, ammo.Modified)
					continue
				}
				oldChain = weaponChain{}
			}
			if !chain.stillCurrent(world, a.read.ptr) {
				continue
			}
			oldChain = chain
			var errors []string
			do := func(enable bool, off uintptr, patch *weaponPatch, target float32, check func(float32) bool, name string) {
				var err error
				if enable {
					err = patchWeaponTarget(a, chain.info+off, target, patch, check)
				} else {
					err = restoreWeaponFloat(a, patch)
				}
				if err != nil {
					errors = append(errors, name+": "+err.Error())
				}
			}
			do(cfg.NoRecoil, weaponRecoilOffset, &recoil, 0, weaponValuePlausible, "recoil")
			// The old source only wrote 0x84 (RecoilAccuracyMax). Also patch
			// 0x74 (AccuracySpread), the base scatter of many other weapons.
			do(cfg.NoSpread, weaponAccuracySpreadOffset, &baseSpread, 0, weaponValuePlausible, "spread base")
			do(cfg.NoSpread, weaponSpreadOffset, &spread, 0, weaponValuePlausible, "spread extra")
			pellets := a.read.uint32(chain.info + weaponBatchCountOffset)
			do(cfg.NoSpread && weaponHasPellets(pellets), weaponBatchSpreadOffset, &batchSpread, 0, weaponValuePlausible, "spread múltiplos projéteis")
			// No Reload is a large-capacity magazine + fast reload timings.
			// Live bullets in a partially used magazine are not reset by ClipSize.
			do(cfg.NoReload, weaponReloadRateOffset, &reload, 1000, weaponReloadRatePlausible, "animação")
			do(cfg.NoReload, weaponReloadTimeMPOffset, &reloadMP, 0.001, weaponReloadTimerPlausible, "tempo MP")
			do(cfg.NoReload, weaponReloadTimeSPOffset, &reloadSP, 0.001, weaponReloadTimerPlausible, "tempo SP")
			if cfg.NoReload {
				if e := patchWeaponUint(a, chain.info+weaponClipSizeOffset, weaponLargeClip, &clip, weaponClipCapacityPlausible); e != nil {
					errors = append(errors, "capacidade: "+e.Error())
				}
			} else if e := restoreWeaponUint(a, &clip); e != nil {
				errors = append(errors, "capacidade: "+e.Error())
			}
			if cfg.InfiniteAmmo {
				addr, ok := resolveWeaponReserve(a.read, chain.info)
				if !ok {
					errors = append(errors, "reserva: ponteiros não confirmados")
				} else if !chain.stillCurrent(world, a.read.ptr) {
					errors = append(errors, "reserva: arma mudou")
				} else if e := patchWeaponUint(a, addr, weaponLargeReserve, &ammo, weaponReservePlausible); e != nil {
					errors = append(errors, "reserva: "+e.Error())
				}
			} else if e := restoreWeaponUint(a, &ammo); e != nil {
				errors = append(errors, "reserva: "+e.Error())
			}
			status := "Arma atual: alterações verificadas na memória; efeito em jogo não validado"
			if len(errors) > 0 {
				status = "Ajuste parcial: " + strings.Join(errors, "; ")
			}
			weaponReport(status, a.read.pid, recoil.Modified, baseSpread.Modified && spread.Modified, reload.Modified && clip.Modified, ammo.Modified)
		}
	}()
}
func weaponShutdown() {
	weaponStopping.Store(true)
	select {
	case <-weaponDone:
	case <-time.After(900 * time.Millisecond):
	}
}
