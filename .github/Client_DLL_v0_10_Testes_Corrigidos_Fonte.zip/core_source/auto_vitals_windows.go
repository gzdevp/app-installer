//go:build windows

package main

import (
	"fmt"
	"sync"
	"time"
)

type autoVitalsConfig struct {
	AutoHealth   bool `json:"autoHealth"`
	AutoArmor    bool `json:"autoArmor"`
	MinHealth    int  `json:"minHealth"`
	MinArmor     int  `json:"minArmor"`
	TargetHealth int  `json:"targetHealth"`
	TargetArmor  int  `json:"targetArmor"`
}

var autoVitalsState = struct {
	sync.RWMutex
	cfg    autoVitalsConfig
	status string
}{status: "Desativado"}

func autoVitalsSet(c autoVitalsConfig) {
	if c.MinHealth < 101 {
		c.MinHealth = 101
	}
	if c.MinHealth > 450 {
		c.MinHealth = 450
	}
	if c.MinArmor < 0 {
		c.MinArmor = 0
	}
	if c.MinArmor > 95 {
		c.MinArmor = 95
	}
	if c.TargetHealth < 101 {
		c.TargetHealth = 200
	}
	if c.TargetHealth > 500 {
		c.TargetHealth = 500
	}
	if c.TargetArmor < 0 {
		c.TargetArmor = 0
	}
	if c.TargetArmor > 100 {
		c.TargetArmor = 100
	}
	autoVitalsState.Lock()
	autoVitalsState.cfg = c
	if !c.AutoHealth && !c.AutoArmor {
		autoVitalsState.status = "Desativado"
	}
	autoVitalsState.Unlock()
}
func autoVitalsGet() map[string]any {
	autoVitalsState.RLock()
	defer autoVitalsState.RUnlock()
	return map[string]any{"status": autoVitalsState.status, "enabled": autoVitalsState.cfg.AutoHealth || autoVitalsState.cfg.AutoArmor}
}
func autoVitalsReport(s string) {
	autoVitalsState.Lock()
	autoVitalsState.status = s
	autoVitalsState.Unlock()
}
func readLocalVitals() (int, int, uint32, bool) {
	p, _, _, err := findESP()
	if err != nil {
		return 0, 0, 0, false
	}
	defer closeESP(p.handle)
	if p.build != "b3258" || !fiveMIsForeground(p.pid) {
		return 0, 0, 0, false
	}
	layout := espLayouts[p.build]
	world := p.ptr(p.base + layout.world)
	if world == 0 {
		return 0, 0, 0, false
	}
	ped := p.ptr(world + 0x8)
	if ped < 0x10000 {
		return 0, 0, 0, false
	}
	pos, valid := p.vec3(ped + 0x90)
	if !valid || !plausibleFiveMPosition(pos) {
		return 0, 0, 0, false
	}
	h, okH := readFloat32Game(p, ped+pedHealthField)
	a, okA := readFloat32Game(p, ped+layout.armor)
	if !okH || !okA || h <= 100 || h > 10000 || a < 0 || a > 1000 {
		return 0, 0, 0, false
	}
	return int(h), int(a), p.pid, true
}
func startAutoVitals() {
	go func() {
        defer recoverServiceWorker("auto_vitals_windows.go")
		ticker := time.NewTicker(2200 * time.Millisecond)
		defer ticker.Stop()
		var lastHP, lastArmor time.Time
		for range ticker.C {
			autoVitalsState.RLock()
			cfg := autoVitalsState.cfg
			autoVitalsState.RUnlock()
			if (!cfg.AutoHealth && !cfg.AutoArmor) || overlayPaused.Load() || menuWanted.Load() {
				continue
			}
			hp, armor, pid, ok := readLocalVitals()
			if !ok {
				autoVitalsReport("Aguardando leitura válida do personagem (b3258)")
				continue
			}
			if !fiveMIsForeground(pid) {
				continue
			}
			if cfg.AutoHealth && hp < cfg.MinHealth && cfg.TargetHealth > hp && time.Since(lastHP) > 10*time.Second {
				lastHP = time.Now()
				result, ok := playerHealthAction(float32(cfg.TargetHealth), false)
				if !ok {
					autoVitalsReport(result)
				} else {
					autoVitalsReport(fmt.Sprintf("Vida %d → %d (confirmação local)", hp, cfg.TargetHealth))
				}
			}
			if cfg.AutoArmor && armor < cfg.MinArmor && cfg.TargetArmor > armor && time.Since(lastArmor) > 10*time.Second {
				lastArmor = time.Now()
				result, ok := playerArmorAction(float32(cfg.TargetArmor))
				if !ok {
					autoVitalsReport(result)
				} else {
					autoVitalsReport(fmt.Sprintf("Armadura %d → %d (confirmação local)", armor, cfg.TargetArmor))
				}
			}
		}
	}()
}
