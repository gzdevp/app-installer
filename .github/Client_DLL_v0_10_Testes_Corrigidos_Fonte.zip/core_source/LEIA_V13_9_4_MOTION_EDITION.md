# sete7 v13.9.4 · MOTION EDITION

Interface reconstruída a partir do vídeo fornecido pelo usuário, usando exclusivamente o logo já pertencente ao sete7. Não há código, assets ou marca copiados do software mostrado no vídeo.

## Alterações feitas
- A navegação lateral agora possui estilo grafite compacto, acento laranja e animações suaves.
- Abas, switches, botões, sliders, seleção de perfis, cartões, hover e alertas visuais redesenhados.
- Configuração de tema escuro, claro e sistema, com cores de destaque predefinidas e cor personalizada.
- Suporte a densidade compacta, redução de movimento, redução de transparência, efeitos decorativos e desfoque de superfícies (não desfoca o jogo fora da janela).
- Busca rápida em todos os grupos e abas, incluindo World → Vehicles / Radar.
- Dados da interface salvos localmente em `sete7_ui_1394`; perfil de jogo e endpoints originais preservados.
- Título do navegador atualizado para v13.9.4; perfil de navegador próprio `sete7-v13.9.4-data`.
- Nenhum arquivo nativo de funcionalidades de jogo foi modificado; exceções: `main.go` (apenas pasta de perfil da janela) e `window_title.go` (apenas identificação do título).

## Validação
- EXE Windows amd64 compilado via Go 1.23.2, CGO=0; `go vet` Windows passou.
- Testes Windows cross-compilados e testes nativos da biblioteca `aimv13` passaram.
- `node --check` do JavaScript e testes de navegação/tema/busca em Chromium headless passaram.
- Não houve execução desta versão dentro do FiveM ou Windows; toda validação do jogo depende de teste do usuário.

## Importante
A reconstituição é baseada em frames e interações visíveis do vídeo, não é cópia bit a bit do software original. O comportamento das funções nativas segue igual à base v13.9.3. A v13.3 e a v13.8 continuam intocadas.
