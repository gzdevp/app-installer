# sete7 v13.9 BLACK EDITION — Vehicle ESP + Triggerbot + Panic/Unload
Data: 2026-10-27

## Base e isolamento
- Fonte da v13.8 copiada para diretorio novo antes de editar.
- EXE v13.3, ZIP v13.3 e fonte v13.8 originais não foram modificados.
- Configuracoes novas em `sete7-v13.9-data` ao lado do EXE; não regrava `sete7-data`.
- Arquivos de logica validados por SHA-256 como byte a byte IDENTICOS aos da v13.8: `silent_windows.go`, `silent_patch.go`, `silent_other.go`, `aim_windows.go`, `aim_logic.go`, `aim_v13_bridge_windows.go`, `esp_stabilizer.go`, `esp_scan.go`, `weapon_control_windows.go`, `radar_windows.go`, `throughwall_windows.go`, `noclip_windows.go`, `tpway_windows.go`, `player_vitals_windows.go`.

## Vehicle ESP
- `Visuals > Vehicles`: opcao separada, alcance 50–500 m, rotulo e lista de proximidade.
- Leitura baseada na interface de veiculos do replay da build suportada; valida ponteiros, quantidades e distancias; calcula posicoes por 3D; lista ordenada.
- Projeta veiculos no overlay quando a matriz da camera e validada. Pode usar veiculos como referencias se nao houver jogadores para validar a matriz.
- O rotulo mostrado e um IDENTIFICADOR (`Veiculo #...`), nao nome comercial: leitura de hash/nome do modelo nao esta validada. Nao inventa nomes de carros.
- Fora da tela, veiculos aparecem na lista, quando detectados.

## Triggerbot
- `Aim > Trigger` habilita de forma independente do Aimbot/Silent.
- Tecla selecionavel de teclado/mouse (padrao Mouse 5), ativa SOMENTE enquanto segura.
- Exige FiveM em primeiro plano, menu oculto, camera/frame recentes, alvo valido sob centro da tela, distancia limite, nao NPC por padrao.
- Cabeça validada como padrao (tol 3–30 px), ou corpo dentro da caixa; atraso inicial 0–300 ms, limite de no minimo 110 ms entre disparos, evita intervir se o clique esquerdo estiver manualmente segurado.
- Envia o clique por SendInput. NAO confirma dano/acerto, line-of-sight, ou permissao de disparar segundo o servidor. Nao e funcao no-Wall.

## Panic / Unload
- `Settings > Interface`: atalho configuravel (padrao F10) e botao Unload.
- Detecta borda do pressionamento, com FiveM focado ou menu aberto; aciona encerramento ja existente e restauracoes previstas pelo codigo.
- O encerramento faz melhor esforço para restaurar arma, ThroughWall e Silent. Nao promete limpar memoria do jogo ou garantir restauracao de todos os efeitos de servidor.
- `finish()` agora impede dupla execucao concorrente.

## Verificacoes
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-H=windowsgui'`: PASSOU.
- `GOOS=windows GOARCH=amd64 go vet ./...`: PASSOU.
- `GOOS=windows GOARCH=amd64 go test -c`: PASSOU (compilacao dos testes; nao executados no Windows).
- `node --check` para JS embutido: PASSOU.
- Quatro testes unitarios puros Linux: PASSOU.
- NAO TESTADO DENTRO DO FIVEM, NEM EM TODAS AS CIDADES; desempenho e compatibilidade em jogo dependem da build e do servidor.

## Arquivos principais
- `main.go`, `settings_windows.go`, `web/index.html`, `esp_windows.go`, `overlay_windows.go`
- `vehicle_esp_windows.go`, `vehicle_esp_other.go`, `vehicle_esp_logic.go`
- `trigger_windows.go`, `trigger_other.go`, `trigger_logic.go`
- `panic_windows.go`, `panic_other.go`, `v139_test.go`

## Uso
1. Execute apenas um sete7 por vez. Mantenha os executaveis v13.3/v13.8 arquivados.
2. Abra painel com INSERT dentro do FiveM.
3. Em `Visuals > Vehicles`, ligue ESP para veiculos e consulte lista.
4. Em `Aim > Trigger`, selecione tecla, ative o recurso e segure durante o jogo para disparar quando o alvo validado coincidir com a mira.
5. Em `Settings > Interface`, configure o Panic (F10 padrao). O botao Unload permanece acessivel.
