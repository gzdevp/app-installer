//go:build windows

package main

import "fmt"

// Retrieve only local ped position, no other player's coordinates.
func tpCurrentPosition() (vec3, error) {
	p, _, _, err := findESP()
	if err != nil {
		return vec3{}, err
	}
	defer closeESP(p.handle)
	if p.build != "b3258" {
		return vec3{}, fmt.Errorf("posição local sem perfil confirmado para %s", p.build)
	}
	world := p.ptr(p.base + espLayouts[p.build].world)
	if world == 0 {
		return vec3{}, fmt.Errorf("mundo indisponível")
	}
	ped := p.ptr(world + 0x8)
	if ped == 0 {
		return vec3{}, fmt.Errorf("personagem indisponível")
	}
	pos, ok := p.vec3(ped + 0x90)
	if !ok || !plausibleFiveMPosition(pos) {
		return vec3{}, fmt.Errorf("posição inválida")
	}
	return pos, nil
}
func tpFavoriteAction(dest vec3) (string, bool) {
	tpWayMutex.Lock()
	defer tpWayMutex.Unlock()
	if !plausibleFiveMPosition(dest) {
		return tpWayReport("Destino inválido", false)
	}
	noclipController.RLock()
	moving := noclipController.active && noclipController.settings.Enabled
	noclipController.RUnlock()
	if moving {
		return tpWayReport("Desative o Noclip", false)
	}
	a, err := attachWritableGame()
	if err != nil {
		return tpWayReport("Destino: "+err.Error(), false)
	}
	defer a.close()
	p := a.read
	if p.build != "b3258" {
		return tpWayReport("TP favorito não confirmado para "+p.build, false)
	}
	world := p.ptr(p.base + espLayouts[p.build].world)
	if world == 0 {
		return tpWayReport("Mundo indisponível", false)
	}
	ped := p.ptr(world + 0x8)
	if ped < 0x10000 {
		return tpWayReport("Personagem indisponível", false)
	}
	before, ok := p.vec3(ped + 0x90)
	if !ok || !plausibleFiveMPosition(before) {
		return tpWayReport("Posição original inválida", false)
	}
	nav := p.ptr(ped + 0x30)
	if nav < 0x10000 {
		return tpWayReport("Navegação indisponível", false)
	}
	navBefore, ok := p.vec3(nav + 0x50)
	if !ok || !plausibleFiveMPosition(navBefore) || dist(navBefore, before) > 25 {
		return tpWayReport("Navegação incoerente", false)
	}
	vehicle := p.ptr(ped + vehicleWriteProfiles[p.build].PedVehicle)
	if vehicle >= 0x10000 {
		if vehPos, vok := p.vec3(vehicle + 0x90); vok && plausibleFiveMPosition(vehPos) && dist(before, vehPos) < 8 {
			return tpWayReport("Saia do veículo antes do TP", false)
		}
	}
	if p.ptr(world+0x8) != ped {
		return tpWayReport("Personagem mudou, cancelado", false)
	}
	if !tpWriteVector(a.writer, nav+0x50, dest) {
		return tpWayReport("Falha ao atualizar navegação", false)
	}
	if !tpWriteVector(a.writer, ped+0x90, dest) {
		_ = tpWriteVector(a.writer, nav+0x50, navBefore)
		return tpWayReport("Falha ao mover personagem", false)
	}
	after, ok1 := p.vec3(ped + 0x90)
	navAfter, ok2 := p.vec3(nav + 0x50)
	if !ok1 || !ok2 || dist(after, dest) > 3 || dist(navAfter, dest) > 3 {
		return tpWayReport("Destino enviado, mas não confirmado localmente", false)
	}
	return tpWayReport(fmt.Sprintf("TP enviado para %.0f, %.0f, %.0f; servidor não verificado", dest.X, dest.Y, dest.Z), true)
}
