package main

import "testing"

func TestTriggerNPCRequiresConsentAndCanTargetBody(t *testing.T) {
	npc := targetESP{X: 200, Y: 150, W: 90, H: 180, IsNPC: true, Health: 200, Distance: 45}
	cfg := normalizeTrigger(TriggerSettings{Key: "f5", Range: 100, Radius: 9, Bone: "body", TargetNPC: false})
	if triggerCandidate(240, 200, npc, cfg) {
		t.Fatal("NPC accepted while disabled")
	}
	cfg.TargetNPC = true
	if !triggerCandidate(240, 200, npc, cfg) {
		t.Fatal("body target must accept valid NPC")
	}
	if triggerCandidate(30, 20, npc, cfg) {
		t.Fatal("body outside box accepted")
	}
	cfg.Range = 20
	if triggerCandidate(240, 200, npc, cfg) {
		t.Fatal("outside trigger range accepted")
	}
}

func TestTriggerHeadRequiresRealVerifiedBone(t *testing.T) {
	npc := targetESP{X: 200, Y: 150, W: 90, H: 180, IsNPC: true, Health: 200, Distance: 45, AimX: 240, AimY: 200}
	cfg := normalizeTrigger(TriggerSettings{Key: "f5", Range: 100, Radius: 9, Bone: "head", TargetNPC: true})
	if triggerCandidate(240, 200, npc, cfg) {
		t.Fatal("unverified head accepted")
	}
	npc.HeadVerified, npc.AimFromBone = true, true
	if !triggerCandidate(240, 200, npc, cfg) {
		t.Fatal("verified head should be accepted")
	}
}

func TestTriggerScannerRequestsNPCsAndRangeIndependently(t *testing.T) {
	cfg := TriggerSettings{Enabled: true, TargetNPC: true, Range: 425}
	meters, npcs := triggerScanScope(190, false, cfg)
	if meters != 425 || !npcs {
		t.Fatalf("scanner must request 425m + NPCs; got %dm, NPC=%v", meters, npcs)
	}
	cfg.Enabled = false
	meters, npcs = triggerScanScope(190, false, cfg)
	if meters != 190 || npcs {
		t.Fatalf("disabled trigger must not expand scanner scope")
	}
	cfg.Enabled, cfg.TargetNPC = true, false
	meters, npcs = triggerScanScope(190, false, cfg)
	if meters != 425 || npcs {
		t.Fatal("player-only trigger must not include NPCs")
	}
}
