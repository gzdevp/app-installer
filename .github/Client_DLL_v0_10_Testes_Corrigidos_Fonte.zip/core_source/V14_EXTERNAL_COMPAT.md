# sete7 v14 — atualização externa de compatibilidade

Base: `SETE7_V14_REVISAO_CODIGO_FONTE.zip`, sem a integração com recurso no servidor.

## Mudanças implementadas
- Leitura de nomes com decodificação UTF-16LE não latina, incluindo nomes russos, coreanos e chineses, preservando preferência por UTF-8 quando válido. Não identifica nomes reais indisponíveis na memória do cliente.
- Identificação do pool de veículos prioriza candidatos que tenham posição válida **e** hash de modelo legível; mantém retorno anterior somente quando esse campo não é conhecido. Esse controle evita selecionar acidentalmente um pool de ped/objetos quando várias estruturas têm coordenadas plausíveis.
- Through Wall: restauração do campo experimental de penetração agora exige que o hash da arma continue igual ao capturado na ativação, para não sobrescrever outra arma após troca/reciclagem de memória. Isso **não** faz as balas atravessarem obstáculos.

## Limitações
- O EXE é 100% externo, mas não lê os nomes oficiais de sessão universalmente nem opera com todos os servidores sem permissão.
- FIX CAR e Unlock All continuam experimentais e só usam perfis já existentes; nenhuma alteração de permissões/chaves de servidor foi implementada.
- A atualização não altera a lógica de disparos, redireciona tiros nem finge penetração real.
- É necessário testar em jogo. Compilação Windows e testes isolados não garantem funcionamento no servidor.
