-- Simulacao isolada de natives FiveM. Nao executa o jogo nem prova dano multiplayer.
local function vec(x,y,z)
  local mt={}
  mt.__add=function(a,b) return vec(a.x+b.x,a.y+b.y,a.z+b.z) end
  mt.__sub=function(a,b) return vec(a.x-b.x,a.y-b.y,a.z-b.z) end
  mt.__mul=function(a,b)
    if type(a)=='number' then return vec(a*b.x,a*b.y,a*b.z) end
    return vec(a.x*b,a.y*b,a.z*b)
  end
  return setmetatable({x=x,y=y,z=z},mt)
end
vector3=vec
local threads,events,callbacks,requests,bullets={},{},{},{},{}
RegisterNUICallback=function(name,fn) callbacks[name]=fn end
CreateThread=function(fn) threads[#threads+1]=fn end
RegisterNetEvent=function(name,fn) events[name]=fn end
RegisterCommand=function() end
NetworkIsSessionStarted=function() return false end
TriggerServerEvent=function(name,...) requests[#requests+1]={name,...} end
GetGameTimer=function() return 2000 end
Wait=function() _G.waitCalls=(_G.waitCalls or 0)+1; if waitCalls>7 then error('simulated stop') end end
IsPedArmed=function() return true end
IsPedShooting=function() return true end
IsEntityDead=function() return false end
PlayerPedId=function() return 99 end
GetSelectedPedWeapon=function() return 500 end
GetHashKey=function() return 0 end
GetGameplayCamRot=function() return {x=0,z=0} end
GetGameplayCamCoord=function() return vec(0,0,1) end
StartShapeTestRay=function(_,y0,_,_,y1) return y1>y0 and 1 or 2 end
GetShapeTestResult=function(h)
  if h==1 then return 2,true,vec(0,2,1) end
  return 2,true,vec(0,5,1)
end
ShootSingleBulletBetweenCoords=function(...)
  bullets[#bullets+1]={...}
end
local path=assert(arg and arg[1], 'Passe client.lua como argumento')
dofile(path)
assert(#threads>=3,'threads registration failed')
callbacks.wallMode({held=true},function() end)
local ok,err=pcall(threads[#threads]);assert(not ok and tostring(err):find('simulated stop'),'loop should stop via mock')
assert(#requests==1 and requests[1][1]=='sete7:requestCoordinateShot', 'requires target-free shot request')
assert(#requests[1]==8, 'shot request must contain ID + camera and direction only')
events['sete7:coordinateShotApproved'](requests[1][2]);assert(#bullets==1,'shot must be emitted when approved')
assert(math.abs(bullets[1][2]-5.22)<0.001 and math.abs(bullets[1][5]-115)<0.001,'straight-line bullet after wall exit')
assert(bullets[1][1]==bullets[1][4] and bullets[1][3]==bullets[1][6], 'bullet deviated from camera direction')
-- If user released the key before server permission, no shot can be created.
requests={};bullets={};_G.waitCalls=0
callbacks.wallMode({held=false},function() end)
events['sete7:coordinateShotApproved'](1)
assert(#bullets==0, 'released key should cancel pending shot')
print('SIMULACAO LUA APROVADA: tiro sem alvo, mesma direcao, tecla solta cancela')
