local handlers,acks={},{}
RegisterNetEvent=function(name,fn) handlers[name]=fn end
AddEventHandler=function(name,fn) handlers[name]=fn end
TriggerClientEvent=function(...) acks[#acks+1]={...} end
GetGameTimer=function() return 123456 end
GetPlayerPed=function() return 101 end
DoesEntityExist=function() return true end
GetEntityHealth=function() return 200 end
GetEntityCoords=function() return {x=0,y=0,z=0} end
source=77
local allowed=false
IsPlayerAceAllowed=function(_,perm) assert(perm=='sete7.throughwall');return allowed end
dofile(assert(arg[1]))
local req=assert(handlers['sete7:requestCoordinateShot'])
req(5,0,0,1,0,1,0)
assert(#acks==0,'ACE denied yet approved')
allowed=true
req(6,0,0,1,0,1,0)
assert(#acks==1 and acks[1][1]=='sete7:coordinateShotApproved' and acks[1][2]==77 and acks[1][3]==6,'ACE valid approval failed')
req(7,0,0,1,0,20,0)
assert(#acks==1,'invalid ray approved')
print('SIMULACAO SERVIDOR APROVADA: ACE exigido, vetor validado, nenhum alvo necessario')
