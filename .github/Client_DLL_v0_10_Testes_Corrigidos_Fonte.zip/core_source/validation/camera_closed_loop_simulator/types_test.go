package main

import "math"

type vec3 struct{ X, Y, Z float32 }
type matrix44 [16]float32
type AimCandidate struct {
	ID        uint64
	X, Y      int32
	RealBone  bool
	HeadWorld vec3
	Distance  float64
}

func plausibleFiveMPosition(v vec3) bool {
	return !math.IsNaN(float64(v.X)) && !math.IsNaN(float64(v.Y)) && !math.IsNaN(float64(v.Z))
}
func worldToScreen(m matrix44, v vec3, width, height int32) (float64, float64, bool) {
	x := float64(m[1]*v.X + m[5]*v.Y + m[9]*v.Z + m[13])
	y := float64(m[2]*v.X + m[6]*v.Y + m[10]*v.Z + m[14])
	z := float64(m[3]*v.X + m[7]*v.Y + m[11]*v.Z + m[15])
	if z <= 0.1 {
		return 0, 0, false
	}
	sx := float64(width) * (.5 + x/z*.5)
	sy := float64(height) * (.5 - y/z*.5)
	return sx, sy, sx >= 0 && sy >= 0 && sx < float64(width) && sy < float64(height)
}
