module servo_sim

go 1.23
