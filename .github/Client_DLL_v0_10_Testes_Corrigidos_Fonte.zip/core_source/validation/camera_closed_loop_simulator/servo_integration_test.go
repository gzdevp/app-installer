package main

import (
	"math"
	"strings"
	"testing"
	"time"
)

func sceneCam() matrix44 { var m matrix44; m[15] = 1; m[13] = .16; m[14] = .36; return m }
func candidate(m matrix44) AimCandidate {
	h := vec3{X: 100, Y: 100, Z: 100}
	x, y, ok := worldToScreen(m, h, 1920, 1080)
	if !ok {
		panic("out of view")
	}
	return AimCandidate{ID: 21, X: int32(math.Round(x)), Y: int32(math.Round(y)), RealBone: true, HeadWorld: h}
}
func advance(m *matrix44, dx, dy int32, vertGain, horizGain float64) {
	m[13] -= float32(float64(dx) * horizGain / 960.0)
	m[14] += float32(float64(dy) * vertGain / 540.0)
}
func exercise(t *testing.T, yGain float64) {
	t.Helper()
	s := cameraHeadServo{pid: 42}
	cam := sceneCam()
	first := candidate(cam)
	initial := math.Abs(float64(first.Y) - 540)
	worst := initial
	steps := 0
	for i := 0; i < 130; i++ {
		a := candidate(cam)
		dx, dy, status := s.command(a, 1920, 1080, 10, false)
		if s.fault {
			t.Fatalf("unexpected fault frame %d: %s", i, status)
		}
		if dx == 0 && dy == 0 && i > 10 && math.Abs(float64(a.Y)-540) <= 6 {
			break
		}
		if dx == 0 && dy == 0 && math.Abs(float64(a.Y)-540) > 6 {
			t.Fatalf("stalled at frame %d %s / %+v", i, status, s)
		}
		s.recordXY(a.ID, a.HeadWorld, cam, dx, dy)
		// No unacknowledged second command can be emitted, even while the ESP
		// would otherwise publish another head before FiveM consumes input.
		nextX, nextY, _ := s.command(a, 1920, 1080, 10, false)
		if nextX != 0 || nextY != 0 {
			t.Fatalf("two commands before observation frame=%d", i)
		}
		advance(&cam, dx, dy, yGain, 3)
		s.recordedAt = time.Now().Add(-70 * time.Millisecond) // simulated real frame delay
		s.seeFrame(cam, 1920, 1080)
		err := math.Abs(float64(candidate(cam).Y) - 540)
		if err > worst {
			worst = err
		}
		if err > initial+5 {
			t.Fatalf("unbounded departure toward floor (%f > %f)", err, initial)
		}
		steps++
	}
	last := candidate(cam)
	if math.Abs(float64(last.Y)-540) > 6 {
		t.Fatalf("didn't converge: initial %.1f final %.1f after %d frames %+v", initial, math.Abs(float64(last.Y)-540), steps, s)
	}
	if !s.ready() {
		t.Fatalf("didn't validate sign: %+v", s)
	}
}
func TestClosesLoopNormalGame(t *testing.T)           { exercise(t, 4) }
func TestClosesLoopInvertedVerticalGame(t *testing.T) { exercise(t, -4) }
func TestRejectsUnresponsiveGame(t *testing.T) {
	s := cameraHeadServo{pid: 1}
	cam := sceneCam()
	a := candidate(cam)
	dx, dy, _ := s.command(a, 1920, 1080, 10, false)
	if dy == 0 || dx != 0 {
		t.Fatal("expected only one bounded probe")
	}
	s.recordXY(a.ID, a.HeadWorld, cam, dx, dy)
	s.recordedAt = time.Now().Add(-70 * time.Millisecond)
	s.seeFrame(cam, 1920, 1080)
	if !s.fault {
		t.Fatalf("no response failed to stop: %+v", s)
	}
	nx, ny, _ := s.command(a, 1920, 1080, 10, false)
	if nx != 0 || ny != 0 {
		t.Fatal("sent input after fault")
	}
}
func TestBlockedWrongReadyDirection(t *testing.T) {
	s := cameraHeadServo{pid: 1}
	cam := sceneCam()
	for i := 0; i < 2; i++ {
		a := candidate(cam)
		dx, dy, _ := s.command(a, 1920, 1080, 10, false)
		s.recordXY(a.ID, a.HeadWorld, cam, dx, dy)
		advance(&cam, dx, dy, 4, 3)
		s.recordedAt = time.Now().Add(-70 * time.Millisecond)
		s.seeFrame(cam, 1920, 1080)
	}
	if !s.ready() {
		t.Fatal("no calibration")
	}
	a := candidate(cam)
	dx, dy, _ := s.command(a, 1920, 1080, 10, false)
	s.recordXY(a.ID, a.HeadWorld, cam, dx, dy)
	advance(&cam, dx, dy, -4, 3)
	s.recordedAt = time.Now().Add(-70 * time.Millisecond)
	s.seeFrame(cam, 1920, 1080)
	if !s.fault || !strings.Contains(s.status(), "se afastou") {
		t.Fatalf("failed to stop opposite movement: %s", s.status())
	}
}

func TestNeverIssuesSecondInputUntilCameraResponds(t *testing.T) {
	s := cameraHeadServo{pid: 3}
	cam := sceneCam()
	a := candidate(cam)
	dx, dy, _ := s.command(a, 1920, 1080, 10, false)
	s.recordXY(a.ID, a.HeadWorld, cam, dx, dy)
	s.recordedAt = time.Now().Add(-10 * time.Millisecond)
	advance(&cam, dx, dy, 4, 3)
	s.seeFrame(cam, 1920, 1080)
	if !s.pending {
		t.Fatal("consumed a camera frame before the mouse could be processed")
	}
	for i := 0; i < 100; i++ {
		x, y, _ := s.command(candidate(cam), 1920, 1080, 10, false)
		if x != 0 || y != 0 {
			t.Fatal("queued a second command while first remained unconfirmed")
		}
	}
	s.recordedAt = time.Now().Add(-70 * time.Millisecond)
	s.seeFrame(cam, 1920, 1080)
	if s.pending || s.fault {
		t.Fatalf("failed to resolve pending after actual camera update: %+v", s)
	}
}
func TestStopsAfterVeryLargeOneUnitCameraReaction(t *testing.T) {
	s := cameraHeadServo{pid: 3}
	cam := sceneCam()
	a := candidate(cam)
	dx, dy, _ := s.command(a, 1920, 1080, 10, false)
	s.recordXY(a.ID, a.HeadWorld, cam, dx, dy)
	advance(&cam, dx, dy, 100, 3)
	s.recordedAt = time.Now().Add(-70 * time.Millisecond)
	s.seeFrame(cam, 1920, 1080)
	if !s.fault {
		t.Fatal("large one-unit reaction was not blocked")
	}
}
func TestNeverSendsInputWithInvalidTarget(t *testing.T) {
	s := cameraHeadServo{pid: 3}
	a := candidate(sceneCam())
	a.RealBone = false
	dx, dy, _ := s.command(a, 1920, 1080, 10, false)
	if dx != 0 || dy != 0 {
		t.Fatal("invalid skull caused input")
	}
}
