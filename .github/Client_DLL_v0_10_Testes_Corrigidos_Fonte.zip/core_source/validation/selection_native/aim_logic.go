
package main

import "math"

// The external aim-assist uses the same, already-projected frame as the ESP.
// No game memory is written. Selection is nearest to screen center, with
// optional slight preference for the previous target to prevent jumping.
type AimSettings struct {
	Enabled        bool    `json:"enabled"`
	Key            string  `json:"key"`
	FOV            int     `json:"fov"`
	Range          int     `json:"range"`
	Smooth         float64 `json:"smooth"`
	InvertY        bool    `json:"invertY"`
	AutoY          bool    `json:"autoY"`
	VisualFallback bool    `json:"visualFallback"`
	Bone           string  `json:"bone"`
	Sticky         bool    `json:"sticky"`
}

type AimCandidate struct {
	ID        uint64
	X, Y      int32
	RealBone  bool
	HeadWorld vec3 // same authenticated 3D head already consumed by Silent
	Distance  float64
}

// AimSelectionStats explains precisely why an apparently visible player is
// unavailable to mouse aim. The existing Silent reader/hook is unchanged.
type AimSelectionStats struct {
	Players   int
	Heads     int
	InRange   int
	InFOV     int
	NearestPx float64
}

func selectAimTarget(targets []targetESP, w, h int32, settings AimSettings, previous uint64) (AimCandidate, bool) {
	chosen, ok, _ := selectAimTargetWithStats(targets, w, h, settings, previous)
	return chosen, ok
}

func selectAimTargetWithStats(targets []targetESP, w, h int32, settings AimSettings, previous uint64) (AimCandidate, bool, AimSelectionStats) {
	return selectAimTargetCore(targets, w, h, settings, previous, nil)
}

// The actual v13 camera controller must select using the exact world point it
// will aim at, projected through the same matrix as the ESP frame.
func selectAimTargetInFrame(targets []targetESP, viewport espViewport, settings AimSettings, previous uint64) (AimCandidate, bool, AimSelectionStats) {
	if !viewport.CameraValid {
		return AimCandidate{}, false, AimSelectionStats{NearestPx: -1}
	}
	return selectAimTargetCore(targets, viewport.W, viewport.H, settings, previous, &viewport.Camera)
}

func targetWorldPoint(head vec3, bone string) vec3 {
	point := head
	switch bone {
	case "neck":
		point.Z -= 0.18
	case "chest":
		point.Z -= 0.45
	case "pelvis":
		point.Z -= 0.8
	}
	return point
}

func selectAimTargetCore(targets []targetESP, w, h int32, settings AimSettings, previous uint64, camera *matrix44) (AimCandidate, bool, AimSelectionStats) {
	stats := AimSelectionStats{NearestPx: -1}
	if w < 320 || h < 240 {
		return AimCandidate{}, false, stats
	}
	fov := settings.FOV
	if fov < 5 {
		fov = 5
	}
	if fov > 500 {
		fov = 500
	}
	rangeMeters := settings.Range
	if rangeMeters <= 0 || rangeMeters > 500 {
		rangeMeters = 500
	}
	cx, cy := float64(w)/2, float64(h)/2
	bestScore := math.Inf(1)
	var best, sticky AimCandidate
	stickyFound := false
	for _, t := range targets {
		if t.Vehicle || t.PedID == 0 || t.W < 2 || t.H < 5 {
			continue
		}
		stats.Players++
		// Both the screenshot bone anchor and the world head are checked by the
		// reader. A prior head pose accepted by the reader is never downgraded to
		// an estimated box center in Head mode.
		// Match the *working* Silent module's verified head contract.
		// Never chase a projected box/neck/pelvis anchor as a "head".
		// Reuse precisely the proven Silent head contract. The ESP reader
		// already validates head/box geometry while setting HeadVerified.
		// Duplicating that check here rejected valid joints when stabilized
		// boxes shifted slightly (Silent accepted them, Aimbot reported 0).
		verifiedHead := t.AimFromBone && t.HeadVerified && validBulletWorld(t.HeadWorld) &&
			poseDist(t.HeadWorld, t.World) >= 0.2 && poseDist(t.HeadWorld, t.World) <= 3.4 &&
			t.AimX >= 0 && t.AimY >= 0 && t.AimX < w && t.AimY < h

		if verifiedHead {
			stats.Heads++
		}
		// Optional compatibility mode for a build where the replay list is
		// valid but the joint reader cannot locate the skull. This is only
		// the top of the visible box, never labelled an authentic head.
		if settings.Bone == "head" && !verifiedHead && !settings.VisualFallback {
			continue
		}
		if t.Distance > rangeMeters {
			continue
		}
		stats.InRange++
		x, y := t.AimX, t.AimY
		if camera != nil {
			// Never feed a visual-box fallback into direct camera memory writes.
			if !verifiedHead {
				continue
			}
			px, py, visible := worldToScreen(*camera, targetWorldPoint(t.HeadWorld, settings.Bone), w, h)
			if !visible {
				continue
			}
			x, y = int32(math.Round(px)), int32(math.Round(py))
		} else if settings.Bone == "head" && !verifiedHead && settings.VisualFallback {
			// Compatibility mode: prefer the visible skeleton's upper center
			// to a fixed 1.9m box guess, but never call it a verified skull.
			x, y = visualHeadAnchor(t)
		} else if x == 0 && y == 0 {
			x, y = t.X+t.W/2, t.Y+t.H*12/100
		}
		if camera == nil && !t.AimFromBone {
			switch settings.Bone {
			case "neck":
				y = t.Y + t.H*24/100
			case "chest":
				y = t.Y + t.H*40/100
			case "pelvis":
				y = t.Y + t.H*60/100
			}
		}
		if x < 0 || y < 0 || x >= w || y >= h {
			continue
		}
		d := math.Hypot(float64(x)-cx, float64(y)-cy)
		if stats.NearestPx < 0 || d < stats.NearestPx {
			stats.NearestPx = d
		}
		if d > float64(fov) {
			continue
		}
		stats.InFOV++
		c := AimCandidate{ID: t.PedID, X: x, Y: y, RealBone: verifiedHead, HeadWorld: t.HeadWorld, Distance: d}
		if settings.Sticky && previous != 0 && t.PedID == previous {
			sticky, stickyFound = c, true
		}
		if d < bestScore {
			bestScore, best = d, c
		}
	}
	if stickyFound {
		return sticky, true, stats
	}
	return best, !math.IsInf(bestScore, 1), stats
}

// aimDelta calculates the original screen-space displacement. Keep it neutral:
// the actual device-axis orientation is selected separately, per game.
func aimDelta(candidate AimCandidate, w, h int32, smooth float64) (int32, int32) {
	if smooth < 1 {
		smooth = 1
	}
	if smooth > 20 {
		smooth = 20
	}
	dx := float64(candidate.X-w/2) / smooth
	dy := float64(candidate.Y-h/2) / smooth
	// Match the supplied headlock's relative SendInput movement. The FOV
	// gate already bounds the maximum delta; smoothing is the divisor.
	return int32(math.Round(dx)), int32(math.Round(dy))
}

// aimOutputDelta maps the desired screen-space displacement to the FiveM mouse
// input axis. Some setups interpret vertical input in the opposite direction.
// Switching this option is intentionally independent of the Silent module.
func aimOutputDelta(candidate AimCandidate, w, h int32, smooth float64, invertY bool) (int32, int32) {
	dx, dy := aimDelta(candidate, w, h, smooth)
	if invertY {
		dy = -dy
	}
	return dx, dy
}

// visualHeadAnchor uses the upper center of a coherent projected skeleton
// when head bone metadata was rejected on this build. The result is still
// approximate and only allowed with explicit VisualFallback consent.
func visualHeadAnchor(t targetESP) (int32, int32) {
	fallbackX, fallbackY := t.X+t.W/2, t.Y+t.H*12/100
	if len(t.Bones) < 3 || t.W < 2 || t.H < 5 {
		return fallbackX, fallbackY
	}
	midX := t.X + t.W/2
	xTolerance := int32(math.Max(6, float64(t.W)*0.40))
	highY := t.Y + t.H*36/100
	lowY := t.Y - int32(math.Max(6, float64(t.H)*0.22))
	var count int
	seen := make(map[[2]int32]bool, len(t.Bones)*2)
	for _, seg := range t.Bones {
		for _, p := range [][2]int32{{seg[0], seg[1]}, {seg[2], seg[3]}} {
			if seen[p] || p[1] < lowY || p[1] > highY || p[0] < midX-xTolerance || p[0] > midX+xTolerance {
				continue
			}
			seen[p] = true
			count++
		}
	}
	if count == 0 {
		return fallbackX, fallbackY
	}
	// The uppermost center point is the safer skull estimate; averaging
	// all upper-body joints tends toward the neck/shoulders.
	bestX, bestY := fallbackX, int32(math.MaxInt32)
	for p := range seen {
		if p[1] < bestY || p[1] == bestY && aimAbs(p[0]-midX) < aimAbs(bestX-midX) {
			bestX, bestY = p[0], p[1]
		}
	}
	if bestY == math.MaxInt32 {
		return fallbackX, fallbackY
	}
	return bestX, bestY
}
