package main
import "testing"

func TestSelectionUsesBoneProjectedWithinFOV(t *testing.T){
  cam:=matrix44{}
  cam[5]=1
  cam[10]=1
  cam[14]=-1.3
  cam[3]=1
  view:=espViewport{W:1920,H:1080, Camera:cam, CameraValid:true}
  player:=targetESP{PedID:1,X:925,Y:475,W:70,H:180, Distance:20, World:vec3{10,0,1},HeadWorld:vec3{10,0,2},AimX:960,AimY:500,AimFromBone:true,HeadVerified:true}
  cfg:=AimSettings{FOV:25,Range:150,Bone:"head"}
  if cand,ok,_:=selectAimTargetInFrame([]targetESP{player},view,cfg,0); ok {t.Fatalf("head should be out FOV: %+v",cand)}
  cfg.Bone="chest"
  if cand,ok,_:=selectAimTargetInFrame([]targetESP{player},view,cfg,0); !ok || cand.ID!=1 {t.Fatalf("chest should be within FOV: %+v %v",cand,ok)}
  view.CameraValid=false
  if _,ok,_:=selectAimTargetInFrame([]targetESP{player},view,cfg,0); ok {t.Fatal("invalid matrix flag accepted")}
}
