package main

import "math"

type targetESP struct {
 X, Y, W, H int32
 Distance int
 Vehicle bool
 Bones [][4]int32
 World vec3
 PedID uint64
 AimX, AimY int32
 AimFromBone bool
 HeadWorld vec3
 HeadVerified bool
}
type espViewport struct { W,H int32; Camera matrix44; CameraValid bool }
func validBulletWorld(v vec3) bool { return plausibleFiveMPosition(v) }
func poseDist(a,b vec3) float64 { return math.Sqrt(math.Pow(float64(a.X-b.X),2)+math.Pow(float64(a.Y-b.Y),2)+math.Pow(float64(a.Z-b.Z),2)) }
func poseFinite(v float32) bool {return !math.IsNaN(float64(v))&&!math.IsInf(float64(v),0)}
func aimAbs(n int32) int32 { if n<0 {return -n};return n }
