package main

import (
	"strings"
	"testing"
)

type fakeESPReader struct {
	pointers  map[uintptr]uintptr
	positions map[uintptr]vec3
	floats    map[uintptr]float32
}

func (f fakeESPReader) ptr(a uintptr) uintptr       { return f.pointers[a] }
func (f fakeESPReader) vec3(a uintptr) (vec3, bool) { v, ok := f.positions[a]; return v, ok }
func (f fakeESPReader) f32(a uintptr) float32       { return f.floats[a] }

func baseReader() fakeESPReader {
	return fakeESPReader{
		pointers:  map[uintptr]uintptr{0x1000: 0x5000, 0x1010: 0x6000, 0x5000 + 0x10A8: 0xA000, 0x6000 + 0x10A8: 0xB000},
		positions: map[uintptr]vec3{0x5000 + 0x90: {X: 150, Y: 0, Z: 20}, 0x6000 + 0x90: {X: 550, Y: 0, Z: 20}},
		floats:    map[uintptr]float32{0x5000 + 0x280: 200, 0x5000 + 0x150C: 50, 0x6000 + 0x280: 200, 0x6000 + 0x150C: 50},
	}
}
func TestScanPlayersValidNearFar(t *testing.T) {
	reader := baseReader()
	d := ESPDiagnostics{}
	out := scanPlayers(reader, 0x1000, 2, 0xDEAD, vec3{X: 0, Y: 0, Z: 20}, 500, &d)
	if len(out) != 1 || out[0].ptr != 0x5000 || d.Slots != 2 || d.Pointers != 2 || d.Positions != 2 || d.InRange != 1 || d.Players != 1 || d.Healthy != 1 {
		t.Fatalf("unexpected scan %+v %+v", out, d)
	}
}
func TestScanPlayersNoPlayerInfoDistinctFromNoPed(t *testing.T) {
	reader := baseReader()
	delete(reader.pointers, 0x5000+0x10A8)
	d := ESPDiagnostics{}
	out := scanPlayers(reader, 0x1000, 2, 0xDEAD, vec3{Z: 20}, 500, &d)
	if len(out) != 0 || d.Pointers != 2 || d.Positions != 2 || d.InRange != 1 || d.Players != 0 || !strings.Contains(reportStage(d), "PlayerInfo") {
		t.Fatalf("stage should report missing PlayerInfo: %+v", d)
	}
}
func TestScanPlayersHealthFilter(t *testing.T) {
	reader := baseReader()
	reader.floats[0x5000+0x280] = 0
	d := ESPDiagnostics{}
	out := scanPlayers(reader, 0x1000, 2, 0, vec3{Z: 20}, 500, &d)
	if len(out) != 0 || d.Players != 1 || d.Healthy != 0 || !strings.Contains(reportStage(d), "Vida") {
		t.Fatalf("bad health stage %+v", d)
	}
}
func TestScanPlayersNavigationMismatch(t *testing.T) {
	reader := baseReader()
	reader.pointers[0x5000+0x30] = 0xE000
	reader.positions[0xE000+0x50] = vec3{X: 800, Y: 800, Z: 20}
	d := ESPDiagnostics{}
	out := scanPlayers(reader, 0x1000, 2, 0, vec3{Z: 20}, 500, &d)
	if len(out) != 0 || d.NavigationMismatch != 1 || d.InRange != 0 || d.Positions != 1 {
		t.Fatalf("bad nav mismatch %+v", d)
	}
}
func TestScanPlayersRejectsCorruptPosition(t *testing.T) {
	reader := baseReader()
	reader.positions[0x5000+0x90] = vec3{X: 35000, Y: 0, Z: 0}
	d := ESPDiagnostics{}
	out := scanPlayers(reader, 0x1000, 2, 0, vec3{Z: 20}, 500, &d)
	if len(out) != 0 || d.InvalidPositions != 1 || d.Positions != 1 {
		t.Fatalf("failed to reject position %+v", d)
	}
}
func TestReportStageCameraCannotHideEarlierEvidence(t *testing.T) {
	d := ESPDiagnostics{Pointers: 7, Positions: 6, InRange: 3, Players: 2, Healthy: 1, ProjectionRejected: 1}
	if msg := reportStage(d); !strings.Contains(msg, "projetado") {
		t.Fatal(msg)
	}
}

func TestScanPlayersDeduplicatesRepeatedPedPointers(t *testing.T) {
	reader := baseReader()
	// Two pool slots point to the exact same character: it must not draw twice.
	reader.pointers[0x1010] = reader.pointers[0x1000]
	diag := ESPDiagnostics{}
	out := scanPlayers(reader, 0x1000, 2, 0xDEAD, vec3{Z: 20}, 500, &diag)
	if len(out) != 1 || diag.DuplicatePointers != 1 || diag.Pointers != 1 {
		t.Fatalf("duplicate pointer produced overlapping entities: out=%+v diagnostics=%+v", out, diag)
	}
}

func TestESPPlayersWithCustomServerHealthAndArmor(t *testing.T) {
	reader := baseReader()
	reader.floats[0x5000+0x280] = 750
	reader.floats[0x5000+0x150C] = 250
	var diagnostics ESPDiagnostics
	selected := scanPlayers(reader, 0x1000, 2, 0xDEAD, vec3{Z: 20}, 500, &diagnostics)
	if len(selected) != 1 || selected[0].health != 750 || diagnostics.UnusualVitals != 1 {
		t.Fatalf("valid custom vitals rejected: %+v %+v", selected, diagnostics)
	}
}
func TestESPRejectsClearlyCorruptVitals(t *testing.T) {
	reader := baseReader()
	reader.floats[0x5000+0x280] = 50000
	var diagnostics ESPDiagnostics
	selected := scanPlayers(reader, 0x1000, 2, 0xDEAD, vec3{Z: 20}, 500, &diagnostics)
	if len(selected) != 0 || diagnostics.Healthy != 0 {
		t.Fatalf("corrupt vitals accepted: %+v %+v", selected, diagnostics)
	}
}
