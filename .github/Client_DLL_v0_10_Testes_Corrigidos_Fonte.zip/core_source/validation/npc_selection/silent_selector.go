package main

import "math"

type silentSelectionStats struct {
	Verified  int
	Eligible  int
	InFOV     int
	NearestPx float64
}

func selectSilentHeadWithStats(targets []targetESP, view espViewport, s SilentSettings) (vec3, uint64, bool, silentSelectionStats) {
	stats := silentSelectionStats{NearestPx: -1}

	if view.W < 320 || view.H < 240 {
		return vec3{}, 0, false, stats
	}
	cx, cy := float64(view.W)/2, float64(view.H)/2
	nearest := math.Inf(1)
	var chosen vec3
	var ped uint64
	for _, t := range targets {
		if t.Vehicle || (t.IsNPC && s.IgnoreNPC) || t.PedID == 0 || !t.HeadVerified || !t.AimFromBone || !validBulletWorld(t.HeadWorld) {
			continue
		}
		stats.Verified++
		if t.Distance < 1 || t.Distance > s.Range {
			continue
		}
		distFromPed := poseDist(t.HeadWorld, t.World)
		if distFromPed > 3.4 || distFromPed < 0.2 {
			continue
		}
		x, y := float64(t.AimX), float64(t.AimY)
		if x < 0 || y < 0 || x >= float64(view.W) || y >= float64(view.H) {
			continue
		}
		stats.Eligible++
		delta := math.Hypot(x-cx, y-cy)
		if stats.NearestPx < 0 || delta < stats.NearestPx {
			stats.NearestPx = delta
		}
		if delta > float64(s.FOV) {
			continue
		}
		stats.InFOV++
		if delta < nearest {
			nearest = delta
			chosen = t.HeadWorld
			ped = t.PedID
		}
	}
	return chosen, ped, ped != 0, stats
}

func selectSilentHead(targets []targetESP, view espViewport, s SilentSettings) (vec3, uint64, bool) {
	head, id, found, _ := selectSilentHeadWithStats(targets, view, s)
	return head, id, found
}

// Runs independently from the Aimbot and the display. If the game loses focus
// or a fresh, verified head is not present, restore original code promptly.
