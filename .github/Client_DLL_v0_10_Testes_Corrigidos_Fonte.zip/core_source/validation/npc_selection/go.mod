module sete7/validation/selection_native

go 1.23
