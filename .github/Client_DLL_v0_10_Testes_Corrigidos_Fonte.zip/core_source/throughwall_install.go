package main

import (
	"bytes"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
)

const installedMaterialPack = "zz_sete7_shootthru.rpf"

func fiveMModFile() (string, error) {
	if runtime.GOOS != "windows" {
		return "", errors.New("instalação disponível somente no Windows")
	}
	local := os.Getenv("LOCALAPPDATA")
	if local == "" {
		return "", errors.New("LOCALAPPDATA indisponível")
	}
	root := filepath.Join(local, "FiveM", "FiveM.app")
	// Never create a fake FiveM installation on arbitrary paths.
	for _, file := range []string{"CitizenFX.ini", "citizen"} {
		if _, err := os.Stat(filepath.Join(root, file)); err != nil {
			return "", fmt.Errorf("instalação padrão do FiveM não encontrada: %s", root)
		}
	}
	return filepath.Join(root, "mods", installedMaterialPack), nil
}

func installMaterialPack(input []byte) (string, error) {
	if detectFiveMProcess() {
		return "", errors.New("feche completamente o FiveM antes de instalar")
	}
	target, err := fiveMModFile()
	if err != nil {
		return "", err
	}
	if _, err = os.Stat(target); err == nil {
		return "", errors.New("pacote sete7 já existe: remova-o antes de reinstalar")
	}
	if !os.IsNotExist(err) {
		return "", err
	}
	patched, count, err := patchShootThru(input)
	if err != nil {
		return "", err
	}
	rpf, err := buildMaterialsModRPF(patched)
	if err != nil {
		return "", err
	}
	if err = os.MkdirAll(filepath.Dir(target), 0755); err != nil {
		return "", err
	}
	// Atomic creation: never overwrite an existing pack or original game file.
	file, err := os.OpenFile(target, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if err != nil {
		return "", err
	}
	_, writeErr := file.Write(rpf)
	closeErr := file.Close()
	if writeErr != nil || closeErr != nil {
		_ = os.Remove(target)
		return "", errors.New("falha ao gravar pacote RPF")
	}
	return fmt.Sprintf("Pacote RPF instalado (%d materiais). Reinicie o FiveM; pure mode pode impedir seu carregamento.", count), nil
}

func removeMaterialPack() (string, error) {
	if detectFiveMProcess() {
		return "", errors.New("feche completamente o FiveM antes de remover")
	}
	target, err := fiveMModFile()
	if err != nil {
		return "", err
	}
	b, err := os.ReadFile(target)
	if os.IsNotExist(err) {
		return "Nenhum pacote sete7 instalado", nil
	}
	if err != nil {
		return "", err
	}
	// Do not delete other user files, even if they were placed at our path.
	if len(b) < 1024 || string(b[:4]) != "RPF7" || !bytes.Contains(b[512:1024], []byte("sete7 materials")) {
		return "", errors.New("arquivo alterado ou desconhecido; remoção recusada")
	}
	if err = os.Remove(target); err != nil {
		return "", err
	}
	return "Pacote sete7 removido. Reinicie o FiveM.", nil
}
