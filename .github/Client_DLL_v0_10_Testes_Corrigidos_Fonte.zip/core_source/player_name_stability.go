package main

import (
	"sync"
	"time"
)

// A name temporarily lost to an incomplete memory read may be reused only
// for the SAME ped and PlayerInfo pointer, in the SAME game process, and at
// nearly the same world position. This does not discover a FiveM/Steam name;
// it only prevents a previously verified readable value from flickering.
// It deliberately does not infer identity from distance or player list order.
type stablePedNameKey struct {
	pid  uint32
	ped  uintptr
	info uintptr
}

type stablePedNameEntry struct {
	name     string
	position vec3
	at       time.Time
}

type stablePedNameStore struct {
	mu    sync.Mutex
	items map[stablePedNameKey]stablePedNameEntry
}

const stablePedNameLife = 900 * time.Millisecond

func (s *stablePedNameStore) resolve(pid uint32, ped, info uintptr, pos vec3, readName string, now time.Time) string {
	if pid == 0 || ped < 0x10000 || info < 0x10000 {
		return readName
	}
	key := stablePedNameKey{pid: pid, ped: ped, info: info}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.items == nil {
		s.items = make(map[stablePedNameKey]stablePedNameEntry)
	}
	if validFriendName(readName) {
		s.items[key] = stablePedNameEntry{name: readName, position: pos, at: now}
		s.prune(now)
		return readName
	}
	if existing, ok := s.items[key]; ok && now.Sub(existing.at) >= 0 && now.Sub(existing.at) <= stablePedNameLife && closeStableNamePosition(existing.position, pos) {
		return existing.name
	}
	delete(s.items, key)
	s.prune(now)
	return readName
}

func (s *stablePedNameStore) prune(now time.Time) {
	if len(s.items) <= 512 {
		return
	}
	for key, entry := range s.items {
		if now.Sub(entry.at) > stablePedNameLife || now.Before(entry.at) {
			delete(s.items, key)
		}
	}
	// Fail closed rather than retaining unbounded stale identity data.
	if len(s.items) > 2048 {
		s.items = make(map[stablePedNameKey]stablePedNameEntry)
	}
}

func closeStableNamePosition(a, b vec3) bool {
	x, y, z := float64(a.X-b.X), float64(a.Y-b.Y), float64(a.Z-b.Z)
	return x*x+y*y+z*z <= 20.25
}

var stablePlayerNames stablePedNameStore
