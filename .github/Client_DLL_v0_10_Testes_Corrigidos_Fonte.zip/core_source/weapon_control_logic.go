package main

import "math"

// Validated fields from CWeaponInfo parStructure. Exact layout is specific
// to the supported b3258 process, and is not assumed on other builds.
const (
	weaponAccuracySpreadOffset uintptr = 0x74
	weaponSpreadOffset         uintptr = 0x84 // recoil accuracy accumulation, legacy field
	weaponRecoilOffset         uintptr = 0x2F4
	weaponBatchCountOffset     uintptr = 0x120
	weaponBatchSpreadOffset    uintptr = 0x124
	weaponReloadRateOffset     uintptr = 0x134
	weaponReloadTimeMPOffset   uintptr = 0x128
	weaponReloadTimeSPOffset   uintptr = 0x12C
	weaponClipSizeOffset       uintptr = 0x70
	weaponAmmoInfoOffset       uintptr = 0x60
	weaponAmmoCountNodeOffset  uintptr = 0x08
	weaponAmmoCountValueOffset uintptr = 0x18
)

func weaponValuePlausible(v float32) bool {
	return !math.IsNaN(float64(v)) && !math.IsInf(float64(v), 0) && v >= 0 && v <= 100
}
func weaponZeroConfirmed(v float32) bool       { return weaponValuePlausible(v) && v <= 0.0001 }
func weaponReloadRatePlausible(v float32) bool { return weaponValuePlausible(v) && v > 0 }
func weaponValueMatches(v, target float32) bool {
	return !math.IsNaN(float64(v)) && !math.IsInf(float64(v), 0) && math.Abs(float64(v-target)) < 0.0001
}
func weaponHasPellets(count uint32) bool { return count > 1 && count <= 64 }

// The clip capacity is a per-weapon definition, not the currently loaded clip.
// Reserve is read from the currently selected ped's weapon/ammo pointer chain.
const weaponLargeClip uint32 = 9999
const weaponLargeReserve uint32 = 9999

func weaponClipCapacityPlausible(v uint32) bool { return v >= 1 && v <= 300 }
func weaponReservePlausible(v uint32) bool      { return v <= 30000 }
func weaponReloadTimerPlausible(v float32) bool {
	return !math.IsNaN(float64(v)) && !math.IsInf(float64(v), 0) && v >= -1 && v <= 100
}
