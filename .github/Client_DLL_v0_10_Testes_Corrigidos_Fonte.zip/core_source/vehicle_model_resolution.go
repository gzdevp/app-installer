package main

// Model info fields can move across builds. Only accept an alternate offset
// if its hash is in a verified name table (or an explicit user-defined alias).
// Unknown primary hashes remain unknown; no invented car name or make is shown.
func resolveModelHashCandidates(primary uint32, alternates []uint32, aliases map[string]string) (uint32, string, bool) {
	if name, ok := resolvedVehicleName(primary, aliases); ok {
		return primary, name, true
	}
	var resolved uint32
	var name string
	for _, candidate := range alternates {
		if candidate == 0 || candidate == 0xffffffff {
			continue
		}
		title, ok := resolvedVehicleName(candidate, aliases)
		if !ok {
			continue
		}
		if resolved != 0 && resolved != candidate {
			// Distinct matching hashes would make the model ambiguous.
			return primary, "", false
		}
		resolved, name = candidate, title
	}
	if resolved != 0 {
		return resolved, name, true
	}
	return primary, "", false
}

// candidateVehicleHashOffset selects a model-info field on the basis of
// multiple independently recognised vehicles, rather than using one random
// uint32 as a model hash. Indexes correspond to offsets 0x14..0x20.
// A weak/ambiguous frame preserves the normal 0x18 layout (index 1).
type vehicleModelHashSample [4]uint32

func candidateVehicleHashOffset(samples []vehicleModelHashSample, aliases map[string]string) int {
	var evidence [4]int
	// Each vehicle contributes at most one vote to each candidate field.
	for _, sample := range samples {
		for i, hash := range sample {
			if hash == 0 || hash == ^uint32(0) {
				continue
			}
			if _, ok := resolvedVehicleName(hash, aliases); ok {
				evidence[i]++
			}
		}
	}
	best, runner, bestIdx := 0, 0, 1
	for i, n := range evidence {
		if n > best || (n == best && i == 1) {
			runner = best
			best, bestIdx = n, i
		} else if n > runner {
			runner = n
		}
	}
	// Require multiple independent positives and a clear lead. Otherwise
	// do not extrapolate a new field layout from one coincidental number.
	if best < 2 || best <= runner {
		return 1
	}
	return bestIdx
}

// Evidence from a vehicle-model record can live in any of the known candidate
// fields. Pool selection previously checked only +0x18, which caused correct
// pools on layouts using +0x1c to lose against unrelated entity pools.
// Do not use arbitrary nonzero values as proof of a model identity.
func vehiclePoolModelEvidence(hashes vehicleModelHashSample, aliases map[string]string) (plausible, named bool) {
	for _, value := range hashes {
		if value != 0 && value != ^uint32(0) {
			plausible = true
			if _, ok := resolvedVehicleName(value, aliases); ok {
				named = true
			}
		}
	}
	return
}
