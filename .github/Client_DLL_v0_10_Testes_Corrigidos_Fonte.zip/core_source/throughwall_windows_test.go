//go:build windows

package main

import "testing"

func TestThroughWallArmingAndRelease(t *testing.T) {
	throughWallSet(true)
	throughWallPressed(true)
	state := throughWallGet()
	if state["enabled"] != true || state["held"] != true || state["operational"] != false || state["patched"] != false {
		t.Fatalf("unexpected state: %#v", state)
	}
	if state["mode"] != "native-weapon-penetration" {
		t.Fatal("unexpected mode")
	}
	throughWallPressed(false)
	if throughWallGet()["held"] != false {
		t.Fatal("release should disarm")
	}
	throughWallShutdown()
	if throughWallGet()["enabled"] != false {
		t.Fatal("shutdown should disarm")
	}
}
func TestThroughWallBuildAllowance(t *testing.T) {
	for _, build := range []string{"b3095", "b3258", "b3323", "b3407"} {
		if !throughWallSupportedBuild(build) {
			t.Fatal(build)
		}
	}
	for _, build := range []string{"b2699", "b2802", "", "b9999"} {
		if throughWallSupportedBuild(build) {
			t.Fatal(build)
		}
	}
}
