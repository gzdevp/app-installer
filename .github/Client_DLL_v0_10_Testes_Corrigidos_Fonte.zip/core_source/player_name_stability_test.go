package main

import (
	"testing"
	"time"
)

func TestStableNameOnlyOnVerifiedIdentity(t *testing.T) {
	var c stablePedNameStore
	now := time.Unix(123, 0)
	a := vec3{X: 10, Y: 20, Z: 30}
	if got := c.resolve(12, 0x20000, 0x50000, a, "Session_Renata", now); got != "Session_Renata" {
		t.Fatal(got)
	}
	if got := c.resolve(12, 0x20000, 0x50000, vec3{X: 11, Y: 20, Z: 30}, "Jogador", now.Add(250*time.Millisecond)); got != "Session_Renata" {
		t.Fatal("temporary read error erased a verified label:", got)
	}
	for _, tt := range []struct {
		pid       uint32
		ped, info uintptr
		position  vec3
		at        time.Time
	}{
		{13, 0x20000, 0x50000, a, now.Add(100 * time.Millisecond)},
		{12, 0x22000, 0x50000, a, now.Add(100 * time.Millisecond)},
		{12, 0x20000, 0x60000, a, now.Add(100 * time.Millisecond)},
		{12, 0x20000, 0x50000, vec3{X: 50, Y: 20, Z: 30}, now.Add(100 * time.Millisecond)},
		{12, 0x20000, 0x50000, a, now.Add(1000 * time.Millisecond)},
	} {
		other := stablePedNameStore{items: map[stablePedNameKey]stablePedNameEntry{{pid: 12, ped: 0x20000, info: 0x50000}: {name: "Session_Renata", position: a, at: now}}}
		if got := other.resolve(tt.pid, tt.ped, tt.info, tt.position, "Jogador", tt.at); got != "Jogador" {
			t.Fatal("name should not cross identities, teleport, or time window:", got)
		}
	}
}

func TestStableNameChangesWhenSessionLabelChanges(t *testing.T) {
	var c stablePedNameStore
	now := time.Unix(123, 0)
	p := vec3{X: 1}
	c.resolve(7, 0x20000, 0x50000, p, "Old", now)
	if got := c.resolve(7, 0x20000, 0x50000, p, "New", now.Add(time.Millisecond)); got != "New" {
		t.Fatal(got)
	}
}
