//go:build !windows

package main

func startNativeKeyCapture() bool            { return false }
func pollNativeKeyCapture() (string, string) { return "unavailable", "" }
func cancelNativeKeyCapture()                {}
