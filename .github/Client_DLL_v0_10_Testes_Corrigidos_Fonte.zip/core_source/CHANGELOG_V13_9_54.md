# 77 Black Edition v13.9.54 — Inicialização suave

- Browser pré-inicializado em segundo plano **somente depois que FiveM for detectado**; a interface permanece invisível até INSERT.
- Evita aguardar a inicialização fria do Chrome/Edge ao pressionar INSERT pela primeira vez, na maioria das execuções.
- Mantém um único navegador por sessão mesmo com INSERT durante pré-inicialização, usando a proteção de concorrência existente.
- Preserva Cleaner, Unload, preferências desligadas na abertura e os outros recursos da versão anterior.
- Sem desativar ou contornar SmartScreen, Defender, UAC, logs ou Prefetch do Windows. Aviso do SmartScreen acontece antes de o app ser executado e não pode ser corrigido por uma otimização interna.
- Compilação e testes automatizados não substituem teste visual em Windows 10/11.
