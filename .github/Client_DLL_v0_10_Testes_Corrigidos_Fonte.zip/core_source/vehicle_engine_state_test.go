package main

import "testing"

func TestVehicleEngineStateDoesNotInferUnknownHealth(t *testing.T) {
	for _, tc := range []struct {
		hp    int
		state string
	}{{-1, ""}, {0, "Crítico"}, {249, "Crítico"}, {250, "Desgastado"}, {649, "Desgastado"}, {650, "Normal"}, {1000, "Normal"}, {1001, ""}} {
		if got := vehicleEngineState(tc.hp); got != tc.state {
			t.Fatalf("health %d: got %q, want %q", tc.hp, got, tc.state)
		}
	}
}
