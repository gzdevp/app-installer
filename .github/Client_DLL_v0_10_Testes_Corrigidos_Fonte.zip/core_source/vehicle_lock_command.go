package main

import (
	"regexp"
	"strconv"
	"strings"
)

var lockCommandPattern = regexp.MustCompile(`^[A-Za-z][A-Za-z0-9_-]{0,30}$`)

// Only a single ordinary key is supported. Never accept modifier combinations
// or arbitrary input sequences from localhost HTTP requests.
func vehicleVK(key string) (uint16, bool) {
	k := strings.ToUpper(strings.TrimSpace(key))
	if len(k) == 1 {
		ch := k[0]
		if (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') {
			return uint16(ch), true
		}
	}
	if strings.HasPrefix(k, "F") {
		n, err := strconv.Atoi(strings.TrimPrefix(k, "F"))
		if err == nil && n >= 1 && n <= 12 {
			return uint16(0x70 + n - 1), true
		}
	}
	if strings.HasPrefix(k, "NUM") && len(k) == 4 && k[3] >= '0' && k[3] <= '9' {
		return uint16(0x60 + int(k[3]-'0')), true
	}
	return 0, false
}
