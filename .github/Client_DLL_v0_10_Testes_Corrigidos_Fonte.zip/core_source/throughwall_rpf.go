package main

import (
	"encoding/binary"
	"errors"
	"fmt"
)

// buildMaterialsModRPF builds an unencrypted RPF7 mod package, as required by
// FiveM's client mods loader. A loose materials.dat is not a valid mod pack.
// It does not change game memory, nor bypass server pure-mode checks.
func buildMaterialsModRPF(materials []byte) ([]byte, error) {
	if len(materials) == 0 || len(materials) > 1<<20 {
		return nil, errors.New("materials.dat vazio ou maior que 1 MiB")
	}
	const xml = `<?xml version="1.0" encoding="UTF-8"?>
<package version="2.1" id="{A6F77483-B477-484A-852D-B2AF33AB8730}" target="Five">
 <metadata><name>sete7 materials</name><version><major>1</major><minor>0</minor></version><author><displayName>sete7</displayName></author><description>Local materials override</description></metadata>
 <content><archive path="update\update.rpf" createIfNotExist="false" type="RPF7"><add source="materials.dat">common\data\materials\materials.dat</add></archive></content>
</package>`
	if len(xml) > 512 {
		return nil, fmt.Errorf("assembly.xml grande demais: %d", len(xml))
	}
	// RPF7 header (16 bytes), 4 x 16-byte TOC, name heap to 512,
	// assembly.xml at block 1 and materials.dat at block 2.
	// Root children [1,2], content children [3].
	names := []string{"", "assembly.xml", "content", "materials.dat"}
	offsets := make([]uint16, len(names))
	namebuf := make([]byte, 0)
	for i, n := range names {
		offsets[i] = uint16(len(namebuf))
		namebuf = append(namebuf, []byte(n)...)
		namebuf = append(namebuf, 0)
	}
	if 16+4*16+len(namebuf) > 512 {
		return nil, errors.New("name table too large")
	}
	total := 1024 + len(materials)
	p := make([]byte, total)
	binary.LittleEndian.PutUint32(p[0:4], 0x52504637)
	binary.LittleEndian.PutUint32(p[4:8], 4)
	binary.LittleEndian.PutUint32(p[8:12], 512-16-4*16)
	binary.LittleEndian.PutUint32(p[12:16], 0x4E45504F) // OPEN
	directory := func(i int, nameoff uint16, first, count uint32) {
		q := p[16+i*16 : 16+(i+1)*16]
		binary.LittleEndian.PutUint32(q[0:4], uint32(nameoff))
		binary.LittleEndian.PutUint32(q[4:8], 0x7fffff00)
		binary.LittleEndian.PutUint32(q[8:12], first)
		binary.LittleEndian.PutUint32(q[12:16], count)
	}
	file := func(i int, nameoff uint16, block uint32, size int) {
		q := p[16+i*16 : 16+(i+1)*16]
		binary.LittleEndian.PutUint16(q[0:2], nameoff)
		q[2] = 0
		q[3] = 0
		q[4] = 0
		q[5] = byte(block)
		q[6] = byte(block >> 8)
		q[7] = byte(block >> 16)
		binary.LittleEndian.PutUint32(q[8:12], uint32(size))
		binary.LittleEndian.PutUint32(q[12:16], 0)
	}
	directory(0, offsets[0], 1, 2)
	file(1, offsets[1], 1, len(xml))
	directory(2, offsets[2], 3, 1)
	file(3, offsets[3], 2, len(materials))
	copy(p[80:], namebuf)
	copy(p[512:], xml)
	copy(p[1024:], materials)
	return p, nil
}
