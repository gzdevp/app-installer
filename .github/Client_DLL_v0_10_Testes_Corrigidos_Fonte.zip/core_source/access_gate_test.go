package main

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestAccessRejectsInvalidCredentials(t *testing.T) {
	if validCredentials("", "") || validCredentials("77owner", "wrong-key") || validCredentials("not-owner", "wrong-key") {
		t.Fatal("invalid credentials accepted")
	}
}

func TestAccessCookieRequiredForAPI(t *testing.T) {
	s := &service{key: "local-service-key", accessToken: strings.Repeat("a", 64)}
	r := httptest.NewRequest(http.MethodGet, "http://127.0.0.1:2026/api/config", nil)
	r.Header.Set("X-Nexo-Key", "local-service-key")
	w := httptest.NewRecorder()
	s.handler().ServeHTTP(w, r)
	if w.Code != http.StatusUnauthorized {
		t.Fatalf("unauthed request: got HTTP %d", w.Code)
	}
	r.AddCookie(&http.Cookie{Name: sessionCookieName, Value: strings.Repeat("a", 64)})
	if !s.sessionAllowed(r) {
		t.Fatal("correct session cookie rejected")
	}
}

func TestLoginFailuresAreRateLimited(t *testing.T) {
	s := &service{key: "local-service-key"}
	for i := 0; i < 5; i++ {
		r := httptest.NewRequest(http.MethodPost, "http://127.0.0.1:2026/api/auth/login", strings.NewReader(`{"username":"77owner","key":"invalid"}`))
		r.Header.Set("X-Nexo-Key", "local-service-key")
		w := httptest.NewRecorder()
		s.handler().ServeHTTP(w, r)
		if w.Code != http.StatusUnauthorized {
			t.Fatalf("attempt %d: got HTTP %d", i+1, w.Code)
		}
	}
	r := httptest.NewRequest(http.MethodPost, "http://127.0.0.1:2026/api/auth/login", strings.NewReader(`{"username":"77owner","key":"invalid"}`))
	r.Header.Set("X-Nexo-Key", "local-service-key")
	w := httptest.NewRecorder()
	s.handler().ServeHTTP(w, r)
	if w.Code != http.StatusTooManyRequests {
		t.Fatalf("expected HTTP 429 after 5 failures, got %d", w.Code)
	}
}
