//go:build !windows

package main

// Windows-only external input; non-Windows builds provide a no-op.
func startAimAssist() {}
