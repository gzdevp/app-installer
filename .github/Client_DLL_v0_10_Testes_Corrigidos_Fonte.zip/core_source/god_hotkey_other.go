//go:build !windows

package main

func startGodHotkey(s *service) {}
