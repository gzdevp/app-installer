SETE7 v13.0 — reconstrução FollowPedCamera (NÃO TESTADO NO FIVEM)

CORREÇÃO DE ARQUITETURA
v12.37 usava a instância do viewport como se fosse FollowPedCamera.
A base C++ enviada pelo usuário (FivemSDK/Classes.hpp, FivemSDK/Fivem.cpp)
mostra estrutura diferente:
  module+offset Camera -> CamGameplayDirector
  CamGameplayDirector+0x3C0 -> FollowPedCamera
  FollowPedCamera+0x40 -> ViewAngles
  FollowPedCamera+0x60 -> CrosshairPosition
  FollowPedCamera+0x3D0 -> ThirdpersonViewAngles
ProcessCameraMovement grava os DOIS vetores e preserva delta Z.

REFERÊNCIA DE ENDEREÇOS
b3258: Camera=0x201E7D0 (FiveM-B3258-Offset-main/Offsets.txt enviado)
b3095: Camera=0x2002888 (C++ fornecido)
b2944: Camera=0x1FEB968 (C++ fornecido)
b2802: Camera=0x1FBCFA8 (C++ fornecido)
b2699: Camera=0x20D9B38 (C++ fornecido)
b3323 e b3407: sem endereço de câmera confirmado; este Aimbot NÃO escreverá nelas.

SEGURANÇA DE CONTROLE
- Obtém jogador local via world->ped, não por targets[0].
- Exige cabeça 3D verificada, alvo no FOV, posição local coerente.
- Nunca usa SendInput ou sondas Y para Aimbot.
- Executa movimento angular pequeno de no máximo ~4° por ciclo.
- Escreve ambos os vetores; relê memória e tenta rollback quando falha.
- Não manda novo comando antes de observar no viewport melhora real.
- Se a projeção piora, bloqueia movimentos até soltar a tecla.
- Preserva Silent Aim v12.20 e outros módulos sem alterações.

TESTES REALIZADOS
- Go nativo: aimv13 TestHeadAnglesAllDirections OK
- Go nativo: aimv13 TestConverges OK
- Go nativo: aimv13 TestRejectBadValues OK
- Go nativo: aimv13 TestIndependentVerticalHorizontal OK
- Go nativo: aimv13 TestFeedbackPreventsRepeatedWrongMoves OK
- Go race / go vet OK.
- Windows 64 bit compilado, inclusive testes Windows crosscompilados.
- JS node --check OK.
- Hash dos três arquivos principais Silent idêntico v12.20.

TESTE REAL NO FIVEM
NÃO EXECUTADO. Não há como certificar funcionamento no jogo sem rodá-lo.
Esta build NÃO deve ser anunciada como garantida ou perfeita.
