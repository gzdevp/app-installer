# sete7 v13.2 — Reviver pela opção da cidade

Esta revisão substitui a ação ineficaz que fazia somente `HP=200` no botão Reviver por uma automação restrita da interface da própria cidade. Ela NÃO implementa uma ressurreição autônoma no FiveM, nem contorna o estado médico do servidor.

## Como utilizar

1. Somente quando a tela `Você morreu` estiver visível e apresentar a opção `REVIVER` (como na captura fornecida).
2. Abra o sete7 com INSERT.
3. Clique em `Player > Actions > Reviver (cidade)`.
4. Confirme. O sete7 oculta o painel, coloca o FiveM em primeiro plano e clica na posição da opção REVIVER mostrada na captura.
5. O servidor decide se e quando a reanimação é aceita. O status "clique enviado" NÃO equivale a revive bem-sucedido.

## Limites

- O botão foi posicionado conforme a captura de 1919x1073 px, normalizado para janelas 16:9. Se o menu da cidade mudar de posição, a automação pode não funcionar.
- NÃO use o botão quando outra tela estiver aberta: há possibilidade de clicar em outro controle.
- Monitores ultra-wide ou resoluções fora de 16:9 são recusados para evitar cliques no lugar errado.
- Não é uma função de revive independente do servidor. O projeto atual é um EXE externo que não tem acesso aos flags/rotinas médicos internos da cidade.
- Suspensões, privilégios VIP, cooldowns e demais regras impostas pela cidade não são ignorados.

## Preservação

Os arquivos `player_vitals_windows.go`, `tpway_windows.go`, `aim_windows.go`, `silent_windows.go`, `esp_windows.go`, `noclip_windows.go`, `hotkey_windows.go` são idênticos à versão base de HP e armadura. O endpoint `/api/player/revive` agora chama `reviveCityMenuAction()`.

## Testes executados

- `go test revive_city_geometry.go revive_city_geometry_test.go`: OK.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-s -w -H=windowsgui'`: OK.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test -c .`: OK (compilação dos testes; execução não feita).
- `node --check` no JavaScript extraído de `web/index.html`: OK.
- Comportamento dentro do FiveM: NÃO TESTADO; servidor não acessível neste ambiente.

Não confundir 'clique enviado' com reanimação confirmada pelo jogo.
