# Sete7 13.9.37 — WEAPONS

- No Reload: altera ClipSize da arma equipada e acelera os parâmetros de recarga MP/SP e animação; não é um hook comprovado do contador vivo de munição do pente. Ao ativar com um pente parcialmente usado, pode precisar recarregar uma vez para carregar a nova capacidade.
- Infinite Ammo: tenta resolver o contador da reserva pela cadeia da arma equipada e repô-lo; nunca modifica flags globais de AmmoInfo.
- Valida ponteiros, arma equipada, valores, read-back e tenta restaurar valores anteriores ao desligar/trocar arma.
- Só habilitado para perfil b3258; outros builds não foram validados.
- Sem execução real de FiveM neste ambiente: funcionalidade em jogo não homologada e servidores/inventários podem substituir valores.
