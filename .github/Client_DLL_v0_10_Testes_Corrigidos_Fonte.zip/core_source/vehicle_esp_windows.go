//go:build windows

package main

import (
	"encoding/binary"
	"math"
	"sync"
	"time"
)

type vehicleFrame struct {
	PID    uint32          `json:"pid"`
	Status string          `json:"status"`
	Count  int             `json:"count"`
	Cars   []vehicleNearby `json:"cars"`
	When   time.Time       `json:"-"`
}

var vehicleEspData = struct {
	sync.RWMutex
	frame vehicleFrame
}{}

func vehicleEspPublish(f vehicleFrame) {
	f.When = time.Now()
	vehicleEspData.Lock()
	vehicleEspData.frame = f
	vehicleEspData.Unlock()
}
func vehicleEspGet() vehicleFrame {
	vehicleEspData.RLock()
	f := vehicleEspData.frame
	vehicleEspData.RUnlock()
	if time.Since(f.When) > 600*time.Millisecond {
		return vehicleFrame{Status: "Aguardando leitura do FiveM"}
	}
	return f
}

// Only the scan goroutine owns the sampling cadence. Entries are purged when
// a vehicle vanishes, preventing pointer reuse from creating fake speeds.
type vehicleSample struct {
	pos   vec3
	when  time.Time
	speed *int
}

var vehicleMotion = struct {
	sync.Mutex
	seen map[uint64]vehicleSample
}{seen: map[uint64]vehicleSample{}}

// Names are looked up only for peds whose current-vehicle pointer and world
// position both match an observed vehicle. A driver is considered identified
// only when the b3258 driver slot ALSO agrees with the ped's vehicle pointer.
// No seat, player or license-plate identity is inferred from proximity alone.
type vehicleOccupantDetail struct {
	count       int
	driverKnown bool
	driver      string
	passengers  []string
	unassigned  []string
}

func (p *attachedESP) verifiedVehicleDriverPed(vehicle uintptr, carPosition vec3) uintptr {
	if p.build != "b3258" || vehicle < 0x10000 {
		return 0
	}
	// Experimental b3258 CVehicle::driver candidate. All independent
	// consistency checks must pass before presenting its information.
	ped := p.ptr(vehicle + 0xC98)
	if ped < 0x10000 || ped > 0x7FFFFFFFFFFF {
		return 0
	}
	if p.ptr(ped+0xD10) != vehicle {
		return 0
	}
	pos, ok := p.vec3(ped + 0x90)
	if !ok || !plausibleFiveMPosition(pos) || dist(pos, carPosition) > 8 {
		return 0
	}
	return ped
}

func (p *attachedESP) vehicleOccupantDetails(replay uintptr, cars []vehicleNearby) map[uint64]vehicleOccupantDetail {
	if p.build != "b3258" || len(cars) == 0 {
		return nil
	}
	iface := p.ptr(replay + 0x18)
	if iface < 0x10000 {
		return nil
	}
	list := p.ptr(iface + 0x100)
	active, capacity := p.uint32(iface+0x110), p.uint32(iface+0x108)
	n, ok := pedScanCapacity(active, capacity)
	if !ok || list < 0x10000 {
		return nil
	}

	type occupant struct {
		ped  uintptr
		name string
	}
	known := make(map[uint64]vec3, len(cars))
	members := make(map[uint64][]occupant, len(cars))
	details := make(map[uint64]vehicleOccupantDetail, len(cars))
	for _, car := range cars {
		known[car.ID] = car.Position
		details[car.ID] = vehicleOccupantDetail{}
	}
	layout := espLayouts[p.build]
	seenPeds := make(map[uintptr]bool, 32)
	for _, ped := range p.pedSlots(list, n) {
		if ped < 0x10000 || seenPeds[ped] {
			continue
		}
		seenPeds[ped] = true
		veh := uint64(p.ptr(ped + 0xD10))
		pos, interested := known[veh]
		if !interested || len(members[veh]) >= 16 {
			continue
		}
		at, valid := p.vec3(ped + 0x90)
		if !valid || !plausibleFiveMPosition(at) || dist(at, pos) >= 8 {
			continue
		}
		// Only player-info names are shown; NPCs remain counted, unnamed.
		name := ""
		info := p.ptr(ped + layout.playerInfo)
		if info >= 0x10000 && info <= 0x7FFFFFFFFFFF {
			candidate := p.playerName(info)
			if validFriendName(candidate) {
				name = candidate
			}
		}
		members[veh] = append(members[veh], occupant{ped, name})
	}
	// Probe the experimental driver slot ONLY when an occupied vehicle has
	// passed the independent ped-pool, vehicle pointer and position checks.
	for _, car := range cars {
		people := members[car.ID]
		detail := vehicleOccupantDetail{count: len(people)}
		if len(people) == 0 {
			details[car.ID] = detail
			continue
		}
		candidate := p.verifiedVehicleDriverPed(uintptr(car.ID), car.Position)
		// Presence of the driver in the verified ped pool is mandatory.
		for _, person := range people {
			if candidate != 0 && person.ped == candidate {
				detail.driverKnown = true
				detail.driver = person.name
				break
			}
		}
		for _, person := range people {
			if person.name == "" || (detail.driverKnown && person.ped == candidate) {
				continue
			}
			if detail.driverKnown {
				if len(detail.passengers) < 8 {
					detail.passengers = append(detail.passengers, person.name)
				}
			} else if len(detail.unassigned) < 8 {
				detail.unassigned = append(detail.unassigned, person.name)
			}
		}
		details[car.ID] = detail
	}
	return details
}

// A vehicle interface has changed its placement and pool field layout between
// GTA/FiveM builds. Try only known, read-only candidates, validating sampled
// vehicle entity positions before trusting any pointer chain.
type vehiclePoolCandidate struct {
	replayOffset, listOffset, maxOffset, countOffset uintptr
}

var vehiclePoolCandidates = []vehiclePoolCandidate{
	{0xD10, 0x100, 0x108, 0x110},
	{0x10, 0x180, 0x188, 0x190},
	{0x10, 0x100, 0x108, 0x110},
	{0xD10, 0x180, 0x188, 0x190},
}

func validVehiclePoolCounts(active, capacity uint32) bool {
	_, ok := vehiclePoolScanSlots(active, capacity)
	return ok
}

// Different builds place vehicle pools at different locations. Prefer the
// candidate with the strongest vehicle-model evidence, never the first pool
// containing an arbitrary entity with a plausible position. Custom vehicles
// with unknown hashes still count as candidate vehicles.
func (p *attachedESP) findVehiclePool(replay uintptr) (uintptr, uint32, bool) {
	var bestList, emptyList uintptr
	var bestSlots uint32
	bestScore := 0
	for _, candidate := range vehiclePoolCandidates {
		iface := p.ptr(replay + candidate.replayOffset)
		if iface < 0x10000 || iface > 0x7FFFFFFFFFFF {
			continue
		}
		list := p.ptr(iface + candidate.listOffset)
		active := p.uint32(iface + candidate.countOffset)
		capacity := p.uint32(iface + candidate.maxOffset)
		slots, countsOK := vehiclePoolScanSlots(active, capacity)
		if list < 0x10000 || list > 0x7FFFFFFFFFFF || !countsOK {
			continue
		}
		if active == 0 {
			if emptyList == 0 {
				emptyList = list
			}
			continue
		}
		// Limit per-candidate reads so a malformed pool cannot cause a full
		// frame stall. Slots are already read in bounded contiguous chunks.
		validPositions, validHashes, namedModels := 0, 0, 0
		for _, entity := range p.pedSlots(list, slots) {
			if entity < 0x10000 || entity > 0x7FFFFFFFFFFF {
				continue
			}
			pos, ok := p.vec3(entity + 0x90)
			if !ok || !plausibleFiveMPosition(pos) {
				continue
			}
			validPositions++
			info := p.ptr(entity + 0x20)
			if info >= 0x10000 && info <= 0x7FFFFFFFFFFF {
				var raw [16]byte
				if p.read(info+0x14, raw[:]) {
					var hashes vehicleModelHashSample
					for i := range hashes {
						hashes[i] = binary.LittleEndian.Uint32(raw[i*4 : i*4+4])
					}
					if plausible, named := vehiclePoolModelEvidence(hashes, nil); plausible {
						validHashes++
						if named {
							namedModels++
						}
					}
				}
			}
			if validPositions >= 24 {
				break
			}
		}
		// Refuse coordinate-only false positives (e.g. ped/object pool).
		if validHashes == 0 {
			continue
		}
		score := vehiclePoolEvidenceScore(validPositions, validHashes, namedModels)
		if score > bestScore {
			bestScore, bestList, bestSlots = score, list, slots
		}
	}
	if bestList != 0 {
		return bestList, bestSlots, true
	}
	if emptyList != 0 {
		return emptyList, 0, true
	}
	return 0, 0, false
}

func (p *attachedESP) vehicleIsActiveInPool(vehicle uintptr) bool {
	if vehicle < 0x10000 {
		return false
	}
	layout, known := espLayouts[p.build]
	if !known {
		return false
	}
	replay := p.ptr(p.base + layout.replay)
	if replay < 0x10000 {
		return false
	}
	list, slots, valid := p.findVehiclePool(replay)
	if !valid || slots == 0 {
		return false
	}
	for _, ptr := range p.pedSlots(list, slots) {
		if ptr == vehicle {
			return true
		}
	}
	return false
}

func (p *attachedESP) scanNearbyVehicles(replay uintptr, origin vec3, maxDistance int, aliases map[string]string) []vehicleNearby {
	vehicles := make([]vehicleNearby, 0, 64)
	unknownModels := false
	list, slots, validPool := p.findVehiclePool(replay)
	if !validPool {
		return vehicles
	}
	// Local vehicle is checked via the current player's ped. Only b3258
	// has a candidate PedVehicle offset; other builds remain read-only.
	var localVehicle uintptr
	if p.build == "b3258" {
		layout, ok := espLayouts[p.build]
		if ok {
			world := p.ptr(p.base + layout.world)
			if world >= 0x10000 {
				ped := p.ptr(world + 0x8)
				if ped >= 0x10000 {
					// This hot scan stays O(1): full pool validation is reserved for
					// the explicit Fix Car action, not every ESP frame.
					localVehicle = p.ptr(ped + vehicleWriteProfiles[p.build].PedVehicle)
				}
			}
		}
	}
	// Infer the *read-only* model-hash field from several recognised vehicles.
	// A single candidate resembling a model is not enough to change layouts.
	var hashSamples []vehicleModelHashSample
	poolEntries := p.pedSlots(list, slots)
	for _, entity := range poolEntries {
		if len(hashSamples) >= 48 {
			break
		}
		if entity < 0x10000 || entity > 0x7FFFFFFFFFFF {
			continue
		}
		pos, ok := p.vec3(entity + 0x90)
		if !ok || !plausibleFiveMPosition(pos) {
			continue
		}
		info := p.ptr(entity + 0x20)
		if info < 0x10000 || info > 0x7FFFFFFFFFFF {
			continue
		}
		var buf [16]byte
		if !p.read(info+0x14, buf[:]) {
			continue
		}
		var sample vehicleModelHashSample
		for i := range sample {
			sample[i] = binary.LittleEndian.Uint32(buf[i*4 : i*4+4])
		}
		hashSamples = append(hashSamples, sample)
	}
	modelIndex := candidateVehicleHashOffset(hashSamples, aliases)
	seen := make(map[uintptr]bool)
	for _, veh := range poolEntries {
		// Scan every validated pool slot within range. A 512-entry early exit
		// dropped legitimate nearby vehicles in busy servers, depending on
		// unrelated entity allocation order.
		if veh < 0x10000 || seen[veh] {
			continue
		}
		seen[veh] = true
		pos, ok := p.vec3(veh + 0x90)
		if !ok || !plausibleFiveMPosition(pos) {
			continue
		}
		distance := dist(origin, pos)
		if !validVehicleDistance(distance, maxDistance) && !(veh == localVehicle && distance >= 0 && distance <= float64(clampVehicleESPRange(maxDistance))) {
			continue
		}
		// Model-name memory layouts vary. Never invent vehicle models from an
		// unverified pointer: show an explicit ID until a model hash is validated.
		car := vehicleNearby{ID: uint64(veh), IsLocal: localVehicle != 0 && veh == localVehicle, Name: "Veículo não identificado", Distance: int(distance + 0.5), Position: pos}
		// Entity -> model info is common to the supported GTA V builds.
		// Read-only identification; hash must pass plausibility checks.
		// A hash is not a brand name: custom models display their hexadecimal
		// identifier until mapped, never a fabricated vehicle make/model.
		info := p.ptr(veh + 0x20)
		if info > 0x10000 && info < 0x7FFFFFFFFFFF {
			var raw [16]byte
			if p.read(info+0x14, raw[:]) {
				var hashes vehicleModelHashSample
				for i := range hashes {
					hashes[i] = binary.LittleEndian.Uint32(raw[i*4 : i*4+4])
				}
				primary := hashes[modelIndex]
				if primary == 0 || primary == ^uint32(0) {
					primary = hashes[1]
				}
				if primary != 0 && primary != ^uint32(0) {
					car.ModelHash = primary
					alternates := make([]uint32, 0, 3)
					for i, hash := range hashes {
						if i != modelIndex {
							alternates = append(alternates, hash)
						}
					}
					if resolved, title, valid := resolveModelHashCandidates(primary, alternates, aliases); valid {
						car.ModelHash, car.Name = resolved, title
					} else {
						car.Name = "Modelo não identificado"
						unknownModels = true
					}
				}
			}
		}
		if p.build == "b3258" {
			engine, eok := readFloat32Game(p, veh+vehicleWriteProfiles["b3258"].Engine)
			body, bok := readFloat32Game(p, veh+vehicleWriteProfiles["b3258"].Body)
			tank, tok := readFloat32Game(p, veh+vehicleWriteProfiles["b3258"].Tank)
			if eok && bok && tok && vehicleHealthPlausible(vehicleHealthValues{Engine: engine, Body: body, Tank: tank}) {
				hp := int(math.Round(float64(engine)))
				car.EngineHealth = &hp
				car.EngineState = vehicleEngineState(hp)
			}
		}
		vehicles = append(vehicles, car)
	}
	// Optional estimates, never fake a measurement on the first frame.
	people := p.vehicleOccupantDetails(replay, vehicles)
	now := time.Now()
	vehicleMotion.Lock()
	next := make(map[uint64]vehicleSample, len(vehicles))
	for i := range vehicles {
		car := &vehicles[i]
		if details, ok := people[car.ID]; ok {
			n := details.count
			car.Occupants = &n
			car.DriverKnown = details.driverKnown
			if details.driverKnown {
				car.Driver = details.driver
			}
			// Passenger classification requires a verified driver in the ped pool.
			if details.driverKnown {
				car.Passengers = details.passengers
			} else {
				car.NamedOccupants = append(car.NamedOccupants, details.unassigned...)
				car.NamedOccupants = append(car.NamedOccupants, details.passengers...)
			}
		}
		if prior, found := vehicleMotion.seen[car.ID]; found {
			if kph, ok := vehicleSpeedKMH(prior.pos, car.Position, now.Sub(prior.when)); ok {
				car.SpeedKMH = &kph
			}
			if now.Sub(prior.when) < 150*time.Millisecond {
				next[car.ID] = prior
				continue
			}
		}
		next[car.ID] = vehicleSample{pos: car.Position, when: now, speed: car.SpeedKMH}
	}
	vehicleMotion.seen = next
	vehicleMotion.Unlock()
	sortNearbyVehicles(vehicles)
	if unknownModels {
		maybeRefreshLocalVehicleMetas()
	}
	return vehicles
}
