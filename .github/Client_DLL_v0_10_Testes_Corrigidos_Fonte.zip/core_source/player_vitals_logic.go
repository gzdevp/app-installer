package main

import (
	"errors"
	"math"
)

// CitizenFX Entity.MaxHealthFloat reads MemoryAddress + 644 (0x284),
// immediately after current health + 640 (0x280).
// This layout does not expose an authoritative multiplayer revive operation.
const (
	pedHealthField    uintptr = 0x280
	pedMaxHealthField uintptr = 0x284
)

type pedVitals struct{ Current, Maximum float32 }

type healthWritePlan struct {
	Target, NewMaximum float32
	RaiseMaximum       bool
}

func finiteHealth(v float32) bool { return !math.IsNaN(float64(v)) && !math.IsInf(float64(v), 0) }

func planHealthWrite(v pedVitals, target float32) (healthWritePlan, error) {
	if !finiteHealth(v.Current) || !finiteHealth(v.Maximum) || !finiteHealth(target) {
		return healthWritePlan{}, errors.New("vida inválida (NaN/Infinito)")
	}
	if v.Current < 0 || v.Current > 10000 || v.Maximum < 100 || v.Maximum > 10000 {
		return healthWritePlan{}, errors.New("campos de HP incompatíveis com personagem local")
	}
	if target < 101 || target > 500 {
		return healthWritePlan{}, errors.New("vida solicitada fora do intervalo 101–500")
	}
	plan := healthWritePlan{Target: target, NewMaximum: v.Maximum}
	if target > v.Maximum {
		plan.RaiseMaximum = true
		plan.NewMaximum = target
	}
	return plan, nil
}

func confirmedHealthValue(actual, expected float32) bool {
	return finiteHealth(actual) && math.Abs(float64(actual-expected)) <= 0.5
}

// Armor is independent of health, but shares the same local-ped checks.
func validArmorTarget(target float32) bool {
	return finiteHealth(target) && target >= 0 && target <= 100
}
func plausibleArmorValue(current float32) bool {
	return finiteHealth(current) && current >= 0 && current <= 500
}
