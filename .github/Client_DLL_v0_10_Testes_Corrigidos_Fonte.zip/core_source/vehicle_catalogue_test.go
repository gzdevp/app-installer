package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strconv"
	"testing"
)

func TestPublicVehicleCatalogue(t *testing.T) {
	rows := make([]map[string]any, 0, 602)
	for i := 1; i <= 600; i++ {
		rows = append(rows, map[string]any{"hash_unsigned": i, "display_name": fmt.Sprintf("Vehicle %d", i), "manufacturer": "Test"})
	}
	rows = append(rows, map[string]any{"hash_unsigned": 601, "display_name": "<script>alert(1)</script>", "manufacturer": "Test"})
	rows = append(rows, map[string]any{"hash_unsigned": 602, "display_name": "Adder", "manufacturer": "Truffade"})
	raw, err := json.Marshal(map[string]any{"count": 602, "rows": rows})
	if err != nil {
		t.Fatal(err)
	}
	names, err := parsePublicVehicleCatalogue(bytes.NewReader(raw))
	if err != nil {
		t.Fatal(err)
	}
	if len(names) != 601 {
		t.Fatalf("want 601 safe names, got %d", len(names))
	}
	if names[strconv.Itoa(602)] != "Truffade Adder" {
		t.Fatalf("unexpected real label: %q", names["602"])
	}
	if _, ok := names[strconv.Itoa(601)]; ok {
		t.Fatal("unsafe name should be rejected")
	}
}
func TestPublicVehicleCatalogueRejectsShortData(t *testing.T) {
	if _, err := parsePublicVehicleCatalogue(bytes.NewReader([]byte(`{"rows":[]}`))); err == nil {
		t.Fatal("empty feed accepted")
	}
}
