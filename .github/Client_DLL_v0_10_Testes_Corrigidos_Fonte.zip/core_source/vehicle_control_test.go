package main

import "testing"

func TestVehicleRepairTargetMatches(t *testing.T) {
	cases := []struct {
		local, selected uint64
		want            bool
	}{
		{0, 0, false}, {0, 10, false}, {10, 0, true}, {10, 10, true}, {10, 11, false},
	}
	for _, c := range cases {
		if got := vehicleRepairTargetMatches(c.local, c.selected); got != c.want {
			t.Fatalf("local=%d selected=%d: got %t, want %t", c.local, c.selected, got, c.want)
		}
	}
}
