package main

import (
	"testing"
	"time"
)

func TestFallbackNameRequiresIndependentObservations(t *testing.T) {
	m := fakeNames{0x2000A4: makeBytes("SessionName")}
	name := readFiveMFallbackPlayerName(0x200000, "b3258", m.read)
	if name != "SessionName" {
		t.Fatalf("unexpected name %q", name)
	}
	store := cautiousNameFallbackStore{}
	at := time.Unix(123, 0)
	if got := store.observe(42, 0x200000, name, at); got != "" {
		t.Fatalf("first observation must not publish: %q", got)
	}
	if got := store.observe(42, 0x200000, name, at.Add(25*time.Millisecond)); got != name {
		t.Fatalf("second observation should publish: %q", got)
	}
	if got := store.observe(99, 0x200000, name, at.Add(50*time.Millisecond)); got != "" {
		t.Fatalf("other process shared identity %q", got)
	}
	if got := store.observe(42, 0x200001, name, at.Add(50*time.Millisecond)); got != "" {
		t.Fatalf("other playerinfo shared identity %q", got)
	}
}
func TestFallbackNameRejectsAmbiguousAndUnknown(t *testing.T) {
	m := fakeNames{0x2000A4: makeBytes("NameOne"), 0x200084: makeBytes("DifferentPerson")}
	if got := readFiveMFallbackPlayerName(0x200000, "b3258", m.read); got != "" {
		t.Fatalf("ambiguous %q", got)
	}
	if got := readFiveMFallbackPlayerName(0x200000, "b9999", m.read); got != "" {
		t.Fatalf("unknown build %q", got)
	}
	if got := readFiveMFallbackPlayerName(0x200000, "b2699", m.read); got != "" {
		t.Fatalf("old build must use original reader %q", got)
	}
}
func TestFallbackClearsChangedNamesAndExpired(t *testing.T) {
	s := cautiousNameFallbackStore{}
	at := time.Unix(10, 0)
	s.observe(1, 0x300000, "FirstName", at)
	s.observe(1, 0x300000, "FirstName", at.Add(30*time.Millisecond))
	if got := s.observe(1, 0x300000, "SecondName", at.Add(60*time.Millisecond)); got != "" {
		t.Fatalf("changed name accepted without confirmation %q", got)
	}
	if got := s.observe(1, 0x300000, "SecondName", at.Add(90*time.Millisecond)); got != "SecondName" {
		t.Fatalf("changed name not accepted %q", got)
	}
	if got := s.observe(1, 0x300000, "SecondName", at.Add(700*time.Millisecond)); got != "" {
		t.Fatalf("expired name %q", got)
	}
}
