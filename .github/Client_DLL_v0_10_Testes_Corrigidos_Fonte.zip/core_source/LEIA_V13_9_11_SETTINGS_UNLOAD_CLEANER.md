# sete7 v13.9.11 — Settings: Unload & Cleaner

Versão separada baseada no código-fonte sete7 v13.9.10. A v13.9.10 e as bases v13.3/v13.8 não foram modificadas.

## Alterações
- Settings > Interface agora tem apenas dois controles: Unload e Cleaner.
- Removidos os switches e seletores Panic do HTML, da busca e dos atalhos do usuário.
- A rotina startPanicHotkey NÃO é iniciada: F10 não é mais hotkey de saída.
- Mantidos sem modificação os módulos nativos de jogo, a interface Appearance e os perfis.
- Pasta de dados própria (`sete7-v13.9.11-data`) e título próprio para o navegador (`sete7 | Black Edition v13.9.11`).

## Semântica dos botões
- Unload: encerra UI/serviço, tentando restaurar ajustes temporários conforme rotinas existentes.
- Cleaner: exige que o usuário digite `REMOVER SETE7`; fecha o painel, exclui apenas a pasta de dados desta versão e TENTA excluir o próprio arquivo EXE, sujeito às restrições do Windows. Pode ser necessário excluir o EXE manualmente.
- Cleaner NÃO apaga registros do Windows, antivírus, logs de segurança, arquivos do FiveM ou qualquer outra aplicação.

## Testes
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build` OK
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet ./...` OK
- Cross-compilação dos testes Windows OK (não executados em FiveM/Windows)
- `node --check` JavaScript OK
- Prévia Chromium: Settings contém os dois botões, sem Panic; Appearance preservado; navegação Player preservada; nenhum erro JS.

Não foi executada no Windows/FiveM.
