# Sete7 v13.9.25 — AIM cleanup

- Removido inteiramente o Silent Auto-Fire da interface, do loop de inicialização, da lógica Windows, do schema de configuração, do retorno de status nativo e do código-fonte.
- Perfis importados com as antigas chaves `silentAim.autoFire` e `silentAim.autoFireRate` perdem tais campos na migração.
- Triggerbot, Aimbot, Silent Aim, ESP, armas e demais módulos de jogo preservados byte a byte.
- Through Wall continua sem implementação funcional de atravessamento físico da colisão; sua aba exibe **Indisponível**, e nenhum redirecionamento de alvo é reinstalado.
- Distribuição em EXE único, arquivos de sessão em TEMP; sem pastas de dados permanentes ao lado do EXE.
- Não é comprovação de compatibilidade no FiveM; somente compilação/testes locais.
