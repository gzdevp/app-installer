package main

import "testing"

func TestVehicleRange(t *testing.T) {
	if clampVehicleESPRange(0) != 50 || clampVehicleESPRange(900) != 500 || !validVehicleDistance(290, 300) || validVehicleDistance(301, 300) {
		t.Fatal("range")
	}
}
func TestVehicleSort(t *testing.T) {
	v := []vehicleNearby{{ID: 3, Distance: 30}, {ID: 1, Distance: 10}, {ID: 2, Distance: 10}}
	sortNearbyVehicles(v)
	if v[0].ID != 1 || v[1].ID != 2 {
		t.Fatal(v)
	}
}
func TestTriggerCandidate(t *testing.T) {
	s := normalizeTrigger(TriggerSettings{Enabled: true, Key: "g", Delay: 30, Range: 150, Radius: 7, Bone: "head"})
	q := targetESP{Health: 200, Distance: 25, X: 95, Y: 95, W: 10, H: 20, HeadVerified: true, AimFromBone: true, AimX: 100, AimY: 100}
	if !triggerCandidate(100, 100, q, s) {
		t.Fatal("head target rejected")
	}
	q.HeadVerified = false
	if triggerCandidate(100, 100, q, s) {
		t.Fatal("unverified head accepted")
	}
	s.Bone = "body"
	if !triggerCandidate(100, 100, q, s) {
		t.Fatal("body target rejected")
	}
	q.Vehicle = true
	if triggerCandidate(100, 100, q, s) {
		t.Fatal("vehicle accepted")
	}
}
func TestTriggerNormalize(t *testing.T) {
	s := normalizeTrigger(TriggerSettings{Key: "mouse1", Delay: 1000, Range: 999, Radius: 999})
	if s.Key != "mouse5" || s.Delay != 300 || s.Range != 500 || s.Radius != 30 {
		t.Fatal(s)
	}
}
