//go:build windows

package main

import "testing"

func TestB3258CameraDirectorIsNotCameraGlobal(t *testing.T) {
	if got := cameraDirectorOffsets["b3258"]; got != 0x201ED50 {
		t.Fatalf("b3258 CamGameplayDirector = %#x; expected %#x", got, uintptr(0x201ED50))
	}
}
