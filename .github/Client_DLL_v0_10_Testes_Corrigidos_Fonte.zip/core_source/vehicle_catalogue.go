package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode"
)

// Public stock GTA V vehicle model metadata, fetched only when the user
// explicitly requests it in the Vehicles tab. Not a city/custom model API.
const publicVehicleCatalogueURL = "https://fam-tools.com/data/vehicles.json"
const maxPublicCatalogueBytes int64 = 4 << 20

type publicVehicleCatalogue struct {
	Count int `json:"count"`
	Rows  []struct {
		Hash         uint32 `json:"hash_unsigned"`
		DisplayName  string `json:"display_name"`
		Manufacturer string `json:"manufacturer"`
	} `json:"rows"`
}

func cleanedCatalogueTitle(s string) string {
	s = strings.TrimSpace(s)
	if s == "" || len(s) > 80 || len([]rune(s)) > 45 {
		return ""
	}
	for _, r := range s {
		if unicode.IsControl(r) || r == '<' || r == '>' {
			return ""
		}
	}
	return s
}
func parsePublicVehicleCatalogue(r io.Reader) (map[string]string, error) {
	var catalogue publicVehicleCatalogue
	if err := json.NewDecoder(io.LimitReader(r, maxPublicCatalogueBytes)).Decode(&catalogue); err != nil {
		return nil, err
	}
	if len(catalogue.Rows) == 0 || len(catalogue.Rows) > 1800 {
		return nil, errors.New("catálogo sem veículos ou excedendo limite")
	}
	models := make(map[string]string, len(catalogue.Rows))
	for _, car := range catalogue.Rows {
		if car.Hash == 0 {
			continue
		}
		title := cleanedCatalogueTitle(car.DisplayName)
		if title == "" {
			continue
		}
		makeName := cleanedCatalogueTitle(car.Manufacturer)
		if makeName != "" && makeName != "Rockstar" && !strings.HasPrefix(strings.ToLower(title), strings.ToLower(makeName)+" ") {
			// Model name remains grounded in published display_name and manufacturer.
			combined := makeName + " " + title
			if cleanedCatalogueTitle(combined) != "" {
				title = combined
			}
		}
		models[strconv.FormatUint(uint64(car.Hash), 10)] = title
	}
	if len(models) < 500 {
		return nil, fmt.Errorf("catálogo inesperadamente pequeno: %d", len(models))
	}
	return models, nil
}
func getPublicVehicleCatalogue() (map[string]string, error) {
	client := &http.Client{Timeout: 9 * time.Second}
	request, err := http.NewRequest(http.MethodGet, publicVehicleCatalogueURL, nil)
	if err != nil {
		return nil, err
	}
	request.Header.Set("Accept", "application/json")
	response, err := client.Do(request)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("catálogo indisponível: HTTP %d", response.StatusCode)
	}
	return parsePublicVehicleCatalogue(response.Body)
}

// A stock-vehicle catalogue is refreshed without blocking the ESP scanner.
// This is only a model-name dictionary; it cannot identify server-exclusive
// vehicles that do not publish a model mapping.
var publicVehicleNames = struct {
	sync.RWMutex
	names map[string]string
}{names: make(map[string]string)}

func storedPublicVehicleName(hash uint32) (string, bool) {
	if hash == 0 {
		return "", false
	}
	key := strconv.FormatUint(uint64(hash), 10)
	publicVehicleNames.RLock()
	name, ok := publicVehicleNames.names[key]
	publicVehicleNames.RUnlock()
	return name, ok
}

func setPublicVehicleNames(names map[string]string) {
	if len(names) < 500 {
		return
	}
	publicVehicleNames.Lock()
	publicVehicleNames.names = names
	publicVehicleNames.Unlock()
}

func updatePublicVehicleNames() error {
	names, err := getPublicVehicleCatalogue()
	if err != nil {
		return err
	}
	setPublicVehicleNames(names)
	return nil
}
