//go:build !windows

package main

func reviveCityMenuAction() (string, bool) {
	return "Reviver pela cidade disponível somente no Windows", false
}
