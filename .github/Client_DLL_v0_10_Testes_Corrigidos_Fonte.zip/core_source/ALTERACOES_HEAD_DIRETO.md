# sete7 — v13.2, ajuste focado no Aimbot Head (revisão experimental)

Base: código-fonte da v13.2 que já abre o painel corretamente, sem CMD.

Arquivos do aplicativo alterados: `aim_windows.go` e `aim_v13_bridge_windows.go`.

- A rotina de mira usa a seleção validada da cabeça 3D, como antes.
- A cada atualização de 33 ms, lê os vetores do `FollowPedCamera` e aplica um passo de orientação para o alvo, sem `SendInput`.
- Usa `CrosshairPosition` (+0x60) como origem preferida; se inválida, testa a posição de câmera (+0x3F0) documentada na classe C++ fornecida. Ambas exigem proximidade do jogador local.
- Remove os bloqueios adicionais de comparação entre a matriz do ESP e a câmera do SDK que impediam enviar movimentos mesmo com cabeça selecionada. Preserva checagens de ponteiros, vetores, processo e escrita/leitura após movimento.
- Não adiciona abas, recursos nem diagnóstico visual; mantém o painel e suas configurações.

Verificações: GOOS=windows GOARCH=amd64, compilação GUI (`-H=windowsgui`, PE Subsystem=2), compilação dos testes Windows, `go vet`, testes de `aimv13`, comparação byte a byte do Silent, ESP e interface com a base.

**Limitação:** não há execução em FiveM neste ambiente. Portanto, o EXE não é garantido em jogo e não deve ser descrito como Aimbot perfeito ou homologado.
