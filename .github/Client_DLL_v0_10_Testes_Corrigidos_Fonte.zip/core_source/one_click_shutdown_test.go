package main

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestShutdownButtonsNeverPrompt(t *testing.T) {
	ui, err := files.ReadFile("web/index.html")
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Contains(ui, []byte("case 'unload':case 'cleaner':")) {
		t.Fatal("unload and cleaner must share one-click handler")
	}
	if bytes.Contains(ui, []byte("confirm('Encerrar totalmente")) || bytes.Contains(ui, []byte("prompt('Cleaner:")) {
		t.Fatal("shutdown actions must not request confirmation")
	}
}

func TestCleanerOneClickRequiresSessionKey(t *testing.T) {
	s, err := newService(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	req := httptest.NewRequest(http.MethodPost, "http://localhost/api/cleaner", nil)
	rr := httptest.NewRecorder()
	s.handler().ServeHTTP(rr, req)
	if rr.Code != http.StatusUnauthorized {
		t.Fatalf("auth status: %d", rr.Code)
	}
}
