package main

import "testing"

func TestVehiclePoolSparseCapacity(t *testing.T) {
	for _, tc := range []struct {
		active, capacity, want uint32
		ok                     bool
	}{
		{1, 128, 128, true},
		{2, 512, 512, true},
		{100, 128, 128, true},
		{0, 128, 0, true},
		{0, 0, 0, false},
		{513, 2048, 2048, true},
		{3, 2, 0, false},
		{1, 2049, 0, false},
	} {
		got, ok := vehiclePoolScanSlots(tc.active, tc.capacity)
		if got != tc.want || ok != tc.ok {
			t.Fatalf("active=%d capacity=%d got=(%d,%v) want=(%d,%v)", tc.active, tc.capacity, got, ok, tc.want, tc.ok)
		}
	}
}
