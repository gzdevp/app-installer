# 77 v13.9.40 — ESP Names + Friends

- Existing CPlayerInfo name reader (`info + 0x100`) retained. These are **unverified in-game session labels**, not automatically confirmed Steam usernames or RP names. Build-specific layouts may fail.
- `Visuals > Friends`: add an exact displayed nickname manually or by clicking a nearby ESP candidate; remove; persist in profile; import/export.
- Duplicate visible names, anonymous placeholders and NPCs cannot be positively identified as friends.
- Unique matched friends appear with a green `★ (amigo)` label in the ESP.
- AIM, Silent Aim and Trigger selection ignore matched friend targets, if the scanner has successfully resolved the nickname and no duplicate exists.
- The source **does not read other players' private Steam/Cfx identifiers**; a stable cross-server friends registry would require server-provided ID mappings with authorization or a user-shared, verifiable account association.
- Offline compilation and unit tests are not proof of actual FiveM compatibility.
