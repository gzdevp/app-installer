//go:build windows

package main

import "testing"

func TestVehiclePoolCountValidation(t *testing.T) {
	for _, v := range [][2]uint32{{0, 1}, {1, 1}, {256, 512}, {513, 2048}, {2048, 2048}} {
		if !validVehiclePoolCounts(v[0], v[1]) {
			t.Fatalf("valid pool rejected: %v", v)
		}
	}
	for _, v := range [][2]uint32{{0, 0}, {3, 2}, {2049, 2049}, {1, 2049}} {
		if validVehiclePoolCounts(v[0], v[1]) {
			t.Fatalf("invalid pool accepted: %v", v)
		}
	}
}
