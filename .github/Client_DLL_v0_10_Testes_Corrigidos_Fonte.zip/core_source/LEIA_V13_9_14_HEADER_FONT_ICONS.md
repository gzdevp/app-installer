# sete7 v13.9.14 — Header, fonte e ícones

Alterações isoladas na UI sobre v13.9.13:

- Ocultada a pílula de detecção FiveM na barra superior (poll/status continua funcionando).
- Removidos os rótulos de versão/Black Edition abaixo da marca e acima do conteúdo.
- Fonte Inter agora é a primeira opção e se aplica explicitamente aos controles; alternativa Arial quando Inter não estiver disponível. A fonte Inter é carregada por Google Fonts quando há conexão; nenhuma fonte proprietária é distribuída.
- Ícone Aim atualizado para alvo conciso, Weapons para silhueta de pistola; ambos usam currentColor e herdam o destaque configurável.
- Preservados os algoritmos de jogo; somente web/index.html, main.go e window_title.go diferem da versão de base.

Validação: testes de interface em Chromium, JavaScript e cross-compilação Windows. A execução real dentro do FiveM não foi testada.
