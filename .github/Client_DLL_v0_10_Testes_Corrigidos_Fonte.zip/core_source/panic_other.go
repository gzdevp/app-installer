//go:build !windows

package main

type PanicSettings struct {
	Enabled bool   `json:"enabled"`
	Key     string `json:"key"`
}

func panicSet(PanicSettings)    {}
func panicGet() PanicSettings   { return PanicSettings{Enabled: false, Key: ""} }
func startPanicHotkey(*service) {}
