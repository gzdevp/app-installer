//go:build windows

package main

import (
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
)

// deleteOwnExecutableAfterExit schedules deletion of ONLY the running 77 EXE.
// Windows locks executable images while running, so a transient, hidden
// system helper retries once the main process has completely exited.
// No batch files, extra app binaries, startup entries, registry changes,
// cleanup of unrelated folders or event-log modifications are involved.
func deleteOwnExecutableAfterExit() error {
	exe, err := os.Executable()
	if err != nil {
		return err
	}
	exe, err = filepath.Abs(exe)
	if err != nil {
		return err
	}
	if !strings.EqualFold(filepath.Ext(exe), ".exe") {
		return errors.New("not a Windows executable")
	}
	st, err := os.Stat(exe)
	if err != nil {
		return err
	}
	if st.IsDir() {
		return errors.New("executable target is a directory")
	}
	root := os.Getenv("SystemRoot")
	if root == "" {
		root = os.Getenv("WINDIR")
	}
	if root == "" {
		return errors.New("Windows directory unavailable")
	}
	cmdPath := filepath.Join(root, "System32", "cmd.exe")
	if st, e := os.Stat(cmdPath); e != nil || st.IsDir() {
		return errors.New("Windows cleanup helper unavailable")
	}
	// If the executable lives in a dedicated app-named directory, remove
	// that directory ONLY if it becomes empty after deleting the current EXE.
	// Never delete Downloads, Desktop, Temp, or unrelated files recursively.
	appDir := ""
	parent := filepath.Dir(exe)
	if isDedicatedAppFolder(filepath.Base(parent)) {
		appDir = parent
	}
	// The filename is passed via a private environment variable, not
	// interpolated into a shell script. Paths with spaces, &, ^ and % remain
	// a single literal file target. /V:OFF disables delayed expansion.
	// cmd.exe is a transient invisible helper, NOT part of the app UI.
	command := selfDeleteHelperCommand()
	cmd := exec.Command(cmdPath)
	// /C consumes the entire remaining command line. Avoid Go's generic
	// argument-quoting rules, which can interfere with CMD's FOR syntax.
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow: true, CreationFlags: 0x08000000,
		CmdLine: "/D /Q /V:OFF /C " + command,
	}
	cmd.Env = append(os.Environ(), "SETE7_DELETE_ME="+exe, "SETE7_EMPTY_DIR="+appDir)
	if err := cmd.Start(); err != nil {
		return err
	}
	return cmd.Process.Release()
}

// A strictly allowlisted name is not enough to delete a folder recursively:
// the Windows rmdir helper removes it only when it is already EMPTY.
func isDedicatedAppFolder(name string) bool {
	normalized := strings.ToLower(strings.TrimSpace(name))
	switch normalized {
	case "77", "77 black edition", "sete7", "sete7 black edition":
		return true
	default:
		return false
	}
}

// The helper operates solely on the current EXE passed through its own
// environment. It confirms the file no longer exists (del's exit code alone
// does not guarantee this), and rmdir can only remove an EMPTY app-named folder.
func selfDeleteHelperCommand() string {
	return `for /L %i in (1,1,40) do @(del /F /Q "%SETE7_DELETE_ME%" >nul 2>nul & if not exist "%SETE7_DELETE_ME%" (if defined SETE7_EMPTY_DIR rmdir "%SETE7_EMPTY_DIR%" >nul 2>nul & exit /B 0) & ping -n 2 127.0.0.1 >nul)`
}
