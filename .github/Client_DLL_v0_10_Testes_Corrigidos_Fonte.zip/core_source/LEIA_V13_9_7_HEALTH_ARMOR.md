# sete7 v13.9.7 - Health + Armor

Atualização de interface baseada na v13.9.6.

- Player > Health: Set Health e Set Armor, cada um com controle próprio.
- Player > Protection: somente God Mode, Semi God e No Ragdoll.
- Player > Movement: nenhuma alteração.
- Visuals > Players, Labels, Bars, Markers, Friends: nenhuma alteração.
- Ações HTTP de health e armor: idênticas à versão anterior.
- Persistência e perfil do navegador próprios da versão v13.9.7.
- Base v13.9.6 e versões estáveis v13.3/v13.8 não foram editadas.

Aviso: EXE compilado para Windows, mas não testado diretamente em FiveM.
