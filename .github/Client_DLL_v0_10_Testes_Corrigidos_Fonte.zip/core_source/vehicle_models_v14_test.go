package main

import "testing"

func TestV14VehicleNameCatalog(t *testing.T) {
	for _, v := range []struct {
		hash uint32
		name string
	}{
		{1046206681, "Lampadati Michelli GT"},
		{867799010, "Ocelot Pariah"},
		{1909189272, "Vapid GB200"},
	} {
		got, ok := vehicleNameByHash(v.hash)
		if !ok || got != v.name {
			t.Fatalf("hash=%d name=%q ok=%v", v.hash, got, ok)
		}
	}
}
func TestV14SecondaryModelOffsets(t *testing.T) {
	hash, name, found := resolveModelHashCandidates(0xabcdef12, []uint32{0, 1046206681}, nil)
	if hash != 1046206681 || name != "Lampadati Michelli GT" || !found {
		t.Fatalf("unexpected car: %d %q %v", hash, name, found)
	}
	hash, _, found = resolveModelHashCandidates(0xabcdef12, []uint32{867799010, 1046206681}, nil)
	if hash != 0xabcdef12 || found {
		t.Fatal("Ambiguous model hash unexpectedly accepted")
	}
	hash, _, found = resolveModelHashCandidates(0xabcdef12, []uint32{1, 2, 3}, nil)
	if hash != 0xabcdef12 || found {
		t.Fatal("Unrecognized model invented")
	}
}
