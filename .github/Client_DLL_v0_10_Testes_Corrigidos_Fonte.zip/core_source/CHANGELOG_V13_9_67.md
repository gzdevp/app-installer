# 77 v13.9.67 — Identificação e Fix Car experimental

- Fix Car b3258: leitura e escrita de saúde alteradas para offsets do dump b3258 consultado (A48/840/130 em vez de 908/920/924). A execução exige validação de veículo local por lista ativa, posição e ponteiro do personagem. O último veículo (DD0) só pode ser usado quando a posição do motorista é confirmada. Não altera outros veículos selecionados, nem simula reparo completo.
- Confirmamos valores locais após um breve intervalo de atualização (90 ms), sem alegar que a cidade replicou o reparo.
- A identificação do carro no ESP continua com leitura O(1) por quadro; validação completa de pool é reservada ao clique no Fix Car, preservando FPS.
- Catálogo de nomes GTA expandido com 69 modelos oficiais adicionais (total de 530 hashes disponíveis na build).
- Status informa apenas saúde local, pois o servidor e os amassados não podem ser verificados por escrita de memória externa.
- Vehicle ESP indica "Modelo desconhecido" para hash sem mapeamento, em vez de presumir que ele é personalizado.
- Player ESP: usa o nome de sessão legível e, somente no b3258 quando disponível, informa um identificador interno como fallback; não inventa nomes RP nem aplica Friends a identificadores.
- Preservados login, Cleaner, ESP e demais configurações.

Atenção: offsets ainda experimentais e sujeito à confirmação real no FiveM. É possível que o Fix Car continue indisponível quando o layout do servidor diferir; não force escrita de memória não validada.
