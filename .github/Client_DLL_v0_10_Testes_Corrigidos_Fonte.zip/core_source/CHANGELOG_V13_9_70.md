# 77 / sete7 v13.9.70 — Friends e nomes de sessão

Base: v13.9.69; mantém lógica anterior do FIX CAR, Unlock All, ESP e Vehicle ESP sem reivindicar sucesso universal.

## Implementado

- Lista Friends por distância (até 500 m), ordenada pelo jogador mais próximo, sem depender da projeção de personagens na tela.
- Leitura dos nomes por `CPlayerInfo`/sessão FiveM para as builds em que o leitor já possui perfil; sem inventar nome Steam nem associar por ID interno.
- Jogadores cujo nome não foi identificado aparecem como `Nome FiveM indisponível`, com distância, mas sem opção para adicioná-los como amigos.
- Nomes duplicados não são marcados automaticamente como amigos.
- Amigos salvos aparecem com a distância atual ou `Fora do alcance`.
- Lista de próximos independente do toggle de caixas ESP; pode ser desativada, com alcance configurável de 30 a 500 metros.
- Ações FIX CAR e Lock/Unlock permanecem como na v13.9.69. Não foram alteradas para offsets não verificados nem garantidas em todo servidor.

## Validação executada

- Go compilado com `GOOS=windows GOARCH=amd64 CGO_ENABLED=0` (Windows GUI, sem console).
- Testes de unidade compilados para Windows; não executáveis neste ambiente Linux sem Windows/Wine.
- Testes de leitura de nomes/validação Friends executados em Linux em compilação de arquivos isolados.
- JavaScript: sintaxe verificada por Node, e testes de ordenação, distância e escaping HTML da lista Friends concluídos.
- Não foi possível testar dentro do FiveM; compatibilidade por build e efeito real de veículos precisam de validação em jogo.

## Limitações honestas

- Nome Steam verdadeiro e nome RP de outro jogador só podem ser exibidos se uma fonte confiável os fornecer; a memória do FiveM não garante esses nomes.
- Perfis de leitura originais do ESP: b2699, b2802, b2944, b3095, b3258, b3323 e b3407. Os offsets são experimentais e podem não funcionar em instalações diferentes.
- FIX CAR não recria amassados via native; Unlock All local da b3258 é experimental e não contorna autorização/sincronização do servidor.
- O painel externo não consegue garantir ações em todas as builds/cidades sem uma integração compatível autorizada.
