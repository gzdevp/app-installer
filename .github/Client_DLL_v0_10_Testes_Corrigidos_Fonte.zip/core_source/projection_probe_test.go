//go:build windows

package main

import "testing"

func TestProjectionProbeChoosesGeometricallyValidMatrix(t *testing.T) {
	good := matrix44{}
	good[1] = .03  // screen X = world X
	good[10] = .05 // screen Y = world Z
	good[15] = 1   // positive homogeneous w
	wrong := matrix44{}
	wrong[15] = -1 // behind camera
	candidates := []cameraProjectionCandidate{{Offset: 0x250, Matrix: wrong}, {Offset: 0x24C, Matrix: good}}
	sample := []projectedBodySample{{Position: vec3{0, 0, 0}, Height: 1.9}}
	index, scores, ok := chooseProjectionMatrix(1920, 1080, candidates, sample)
	if !ok || index != 1 || scores[1] < 2 || scores[0] != 0 {
		t.Fatalf("unexpected probe: %d %v %v", index, scores, ok)
	}
}
func TestProjectionProbeRejectsAllInvalidCandidates(t *testing.T) {
	matrix := matrix44{} // homogeneous w == 0
	_, scores, ok := chooseProjectionMatrix(1920, 1080, []cameraProjectionCandidate{{Matrix: matrix}}, []projectedBodySample{{Position: vec3{1, 1, 1}, Height: 1.9}})
	if ok || scores[0] != 0 {
		t.Fatalf("must reject all invalid candidates: %v %v", scores, ok)
	}
}
func TestProjectionProbeRejectsInvalidSamples(t *testing.T) {
	good := matrix44{}
	good[10] = .05
	good[15] = 1
	_, scores, ok := chooseProjectionMatrix(1920, 1080, []cameraProjectionCandidate{{Matrix: good}}, []projectedBodySample{{Position: vec3{200000, 0, 0}, Height: 1.9}})
	if ok || scores[0] != 0 {
		t.Fatalf("invalid position was accepted: %v %v", scores, ok)
	}
}

func TestProjectionStableKeepsValidPreviousLayout(t *testing.T) {
	// Both layouts have equally good geometry; prefer the last valid one.
	m := matrix44{}
	m[10] = .05
	m[15] = 1
	candidates := []cameraProjectionCandidate{{Offset: 0x24C, Matrix: m}, {Offset: 0x250, Matrix: m}}
	samples := []projectedBodySample{{Position: vec3{0, 0, 0}, Height: 1.9}}
	idx, scores, valid := chooseProjectionMatrixStable(1920, 1080, candidates, samples, 0x250)
	if !valid || idx != 1 || scores[1] == 0 {
		t.Fatalf("matrix jumped despite equivalent evidence: %d %v %v", idx, scores, valid)
	}
}
func TestProjectionStableSwitchesWhenPreviousFails(t *testing.T) {
	good := matrix44{}
	good[10] = .05
	good[15] = 1
	bad := matrix44{}
	bad[15] = -1
	candidates := []cameraProjectionCandidate{{Offset: 0x24C, Matrix: good}, {Offset: 0x250, Matrix: bad}}
	idx, _, valid := chooseProjectionMatrixStable(1920, 1080, candidates, []projectedBodySample{{Position: vec3{}, Height: 1.9}}, 0x250)
	if !valid || idx != 0 {
		t.Fatal("must switch away from invalid previous matrix")
	}
}
