package main

import (
	"os"
	"strings"
	"testing"
)

// No keyboard-triggered emergency kill should remain; the only user-visible
// termination routes are authenticated Unload and Cleaner.
func TestNoAutomaticPanicUnload(t *testing.T) {
	b, err := os.ReadFile("panic_windows.go")
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(b), ".finish(") {
		t.Fatal("legacy panic hotkey must not terminate service")
	}
}

func TestUIFocusLossDoesNotResetInsertState(t *testing.T) {
	b, err := os.ReadFile("hotkey_windows.go")
	if err != nil {
		t.Fatal(err)
	}
	s := string(b)
	if strings.Contains(s, "ui_launch_expired") {
		t.Fatal("lost browser must not cancel desired UI")
	}
	pos := strings.Index(s, "if !allowed {")
	if pos < 0 {
		t.Fatal("missing context guard")
	}
	end := strings.Index(s[pos:], "continue")
	if end < 0 {
		t.Fatal("incomplete context guard")
	}
	if strings.Contains(s[pos:pos+end], "menuWanted.Store(false)") {
		t.Fatal("focus loss resets INSERT state")
	}
}

func TestNativeCloseRequiresUnload(t *testing.T) {
	b, err := os.ReadFile("native_host_windows.go")
	if err != nil {
		t.Fatal(err)
	}
	s := string(b)
	if !strings.Contains(s, "message == nativeWMClose && !nativeHostCloseAuthorized.Load()") {
		t.Fatal("native close not guarded")
	}
}
