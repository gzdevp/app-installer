# 77 v13.9.61 — Login compacto e painel expandido

- Primeiro Insert: janela nativa exclusiva para login, 480 x 570 px, sem sidebar nem espaço sobrando.
- JACK 77 original com fundo transparente e vermelho como destaque; somente "77" no título.
- Mantém username e key: apenas a apresentação mudou.
- Quando o servidor local valida as credenciais, a mesma janela passa a 1120 x 740 px (ou ao máximo disponível dentro do jogo), exibindo o painel completo.
- O monitor de janelas percebe a transição mesmo com viewport do FiveM inalterado.
- Mantidas as correções de foco do teclado e de cadência de overlays da base v13.9.60.
- Nenhuma alteração no comportamento de Prefetch, logs ou componentes de jogo.

Testar no Windows: Insert inicial, digitar username e key, abrir o painel e alternar Insert depois do login. Confirmar também overlay com FPS no mesmo cenário.
