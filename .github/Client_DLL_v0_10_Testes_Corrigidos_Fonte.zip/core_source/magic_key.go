package main

import (
	"encoding/json"
	"strings"
)

// Magic uses a dedicated, user-selectable hotkey. The external Magic DLL is
// not included; the key now must be HELD to apply the experimental
// penetration field (which does not guarantee wall penetration).
// Bindable keys: letters, digits, function keys, mouse buttons and modifiers.
// INSERT controls the panel; F6 repairs vehicles; Escape cancels capture.
func validMagicKey(key string) bool {
	return validBindingKey(key)
}

func normalizeMagicKey(key string) string {
	key = strings.ToLower(strings.TrimSpace(key))
	if !validMagicKey(key) {
		return "f7"
	}
	return key
}

func magicKeyVK(key string) uintptr {
	return genericKeyVK(normalizeMagicKey(key), 0x76)
}

type magicHotkeySettings struct {
	Magic struct {
		Key string `json:"key"`
	} `json:"magic"`
	Aim struct {
		Key         string `json:"key"`
		ThroughWall bool   `json:"throughWall"`
	} `json:"aim"`
	SilentAim struct {
		Key string `json:"key"`
	} `json:"silentAim"`
	Player struct {
		NoclipKey string `json:"noclipKey"`
	} `json:"player"`
}

func parseMagicHotkeySettings(data []byte) (key string, collision bool, enabled bool) {
	var v magicHotkeySettings
	if json.Unmarshal(data, &v) != nil {
		return "f7", false, false
	}
	key = normalizeMagicKey(v.Magic.Key)
	for _, reserved := range []string{v.Aim.Key, v.SilentAim.Key, v.Player.NoclipKey} {
		if strings.EqualFold(reserved, key) {
			collision = true
		}
	}
	return key, collision, v.Aim.ThroughWall
}

// Only the combination of armed + held + foreground + no key collision
// engages the experimental module. Releasing the hotkey always disengages it.
func shouldEngageThroughWall(armed, keyHeld, gameForeground, collision, paused bool) bool {
	return armed && keyHeld && gameForeground && !collision && !paused
}
