//go:build windows

package main

import (
	"fmt"
	"sync"
	"sync/atomic"
	"time"
)

// Actual native-weapon penetration field experiment; not a collision bypass.
// Does NOT patch raycasts, collision flags, bullet trajectory or damage.
// Must validate the local weapon manager pointer and original float. Restore
// the original EXACT value on toggle-off/unload/focus loss; never force 1.0.
// A bounded experimental value. The previous 1000.0 write was extreme and
// did not guarantee passing through walls or player/server collision.
const experimentalPenetrationValue float32 = 10

var throughWallControl = struct {
	sync.RWMutex
	enabled bool // armamento persistente da interface; so patch quando held = true
	held    bool
	status  string
	pid     uint32
	patched bool
}{status: "Desativado"}

func throughWallSet(enabled bool) {
	throughWallControl.Lock()
	defer throughWallControl.Unlock()
	throughWallControl.enabled = enabled
	if !enabled {
		throughWallControl.held = false
	}
	if !enabled && !throughWallControl.patched {
		throughWallControl.status = "Desativado"
	}
}
func throughWallPressed(held bool) {
	throughWallControl.Lock()
	throughWallControl.held = held && throughWallControl.enabled
	throughWallControl.Unlock()
}
func throughWallGet() map[string]any {
	throughWallControl.RLock()
	enabled, held := throughWallControl.enabled, throughWallControl.held
	status, pid, patched := throughWallControl.status, throughWallControl.pid, throughWallControl.patched
	throughWallControl.RUnlock()
	if !enabled {
		status = "Desativado"
	} else if !held && !patched {
		status = "Penetração nativa experimental; disparo por coordenadas não disponível no EXE externo"
	} else if patched {
		status = "Campo Penetration modificado; atravessamento NÃO confirmado"
	}
	ray := readExternalLineState()
	if enabled && held && ray["valid"] == true {
		status += " | reta da câmera verificada externamente (não efetua disparo)"
	}
	return map[string]any{"enabled": enabled, "held": held,
		"patched": patched, "operational": false, "mode": "native-weapon-penetration",
		"status": status, "pid": pid, "aimLine": ray}
}
func twStatus(s string, pid uint32, patched bool) {
	throughWallControl.Lock()
	throughWallControl.status = s
	throughWallControl.pid = pid
	throughWallControl.patched = patched
	throughWallControl.Unlock()
}

type throughWallPatch struct {
	attachment *noclipAttachment
	chain      weaponChain
	original   float32
	weaponHash uint32
	refreshes  uint32
}

func (a *throughWallPatch) restore() string {
	if a == nil || a.attachment == nil {
		return "Desativado"
	}
	p := a.attachment.read
	current, ok := readFloat32Game(p, a.chain.field)
	status := "Penetração original restaurada"
	if !ok {
		status = "Não foi possível ler valor de penetração na restauração"
	} else if p.uint32(a.chain.info+0x10) != a.weaponHash {
		status = "Arma alterada: restauração não aplicada a um objeto de arma diferente"
	} else if current != experimentalPenetrationValue {
		status = "Valor alterado pelo jogo: restauração não aplicada para evitar sobrescrever dados novos"
	} else if !writeFloat32Game(a.attachment.writer, a.chain.field, a.original) {
		status = "Falha ao restaurar valor original de penetração"
	}
	a.attachment.close()
	a.attachment = nil
	twStatus(status, 0, false)
	return status
}

// These are community-derived GTA V layouts, not validated wall-collision
// signatures. Every actual write still requires pointer, ped, weapon hash,
// field range, and equipped-chain checks at runtime.
func throughWallSupportedBuild(build string) bool {
	switch build {
	case "b3095", "b3258", "b3323", "b3407":
		return true
	default:
		return false
	}
}

var throughWallStopping atomic.Bool
var twWorker = struct {
	sync.Mutex
	patch *throughWallPatch
}{}

func throughWallShutdown() {
	throughWallSet(false)
	throughWallPressed(false)
	throughWallStopping.Store(true)
	twWorker.Lock()
	defer twWorker.Unlock()
	if twWorker.patch != nil {
		twWorker.patch.restore()
		twWorker.patch = nil
	}
}
func twInstall() (*throughWallPatch, error) {
	a, err := attachWritableGame()
	if err != nil {
		return nil, err
	}
	defer func() {
		if err != nil {
			a.close()
		}
	}()
	p := a.read
	// Community layouts are used only when their pointers and field contents pass checks.
	if !throughWallSupportedBuild(p.build) {
		err = fmt.Errorf("Penetração bloqueada: layout de arma não reconhecido para %s", p.build)
		return nil, err
	}
	if !fiveMIsForeground(p.pid) {
		err = fmt.Errorf("Through Wall aguardando foco no FiveM")
		return nil, err
	}
	world := p.ptr(p.base + espLayouts[p.build].world)
	chain, ok := resolveWeaponChain(world, p.ptr)
	if !ok {
		err = fmt.Errorf("Penetração: cadeia de arma não identificada/validada")
		return nil, err
	}
	// CWeaponInfo+0x10 is its weapon hash, not a pointer. Do not patch
	// unarmed/no-weapon layouts even when a stale manager happens to resolve.
	weaponHash := p.uint32(chain.info + 0x10)
	if weaponHash == 0 || weaponHash == 0xA2719263 {
		err = fmt.Errorf("Through Wall: equipe uma arma de fogo antes de ativar")
		return nil, err
	}
	// Reject an unrelated ped pointer or stale CWeaponInfo chain before
	// attempting any write, especially on non-b3258 layouts.
	pos, posOK := p.vec3(chain.ped + 0x90)
	if !posOK || !plausibleFiveMPosition(pos) {
		err = fmt.Errorf("Penetração: CPed não validado; nada escrito")
		return nil, err
	}
	field := chain.field
	current, ok := readFloat32Game(p, field)
	if !ok || !penetrationPlausible(current) {
		err = fmt.Errorf("Through Wall: valor original da penetração inválido; alteração bloqueada")
		return nil, err
	}
	if !chain.stillCurrent(world, p.ptr) || !fiveMIsForeground(p.pid) {
		err = fmt.Errorf("Penetração: personagem/arma/foco mudou, escrita cancelada")
		return nil, err
	}
	if !writeFloat32Game(a.writer, field, experimentalPenetrationValue) {
		err = fmt.Errorf("Through Wall: escrita recusada")
		return nil, err
	}
	after, ok := readFloat32Game(p, field)
	if !ok || after != experimentalPenetrationValue {
		_ = writeFloat32Game(a.writer, field, current)
		err = fmt.Errorf("Through Wall: escrita não confirmada; valor restaurado")
		return nil, err
	}
	if !chain.stillCurrent(world, p.ptr) {
		_ = writeFloat32Game(a.writer, field, current)
		err = fmt.Errorf("Through Wall: arma mudou durante a ativação; valor restaurado")
		return nil, err
	}
	return &throughWallPatch{attachment: a, chain: chain, original: current, weaponHash: weaponHash}, nil
}
func startThroughWall() {
	go func() {
		defer recoverServiceWorker("throughwall_windows.go")
		ticker := time.NewTicker(35 * time.Millisecond)
		defer ticker.Stop()
		lastTry := time.Time{}
		for now := range ticker.C {
			if throughWallStopping.Load() {
				return
			}
			throughWallControl.RLock()
			enabled := throughWallControl.enabled && throughWallControl.held
			throughWallControl.RUnlock()
			twWorker.Lock()
			p := twWorker.patch
			if p != nil {
				if !enabled || espProcessExited(p.attachment.read.handle) || !fiveMIsForeground(p.attachment.read.pid) || overlayPaused.Load() {
					p.restore()
					twWorker.patch = nil
					twWorker.Unlock()
					continue
				}
				// A weapon change replaces manager. Verify the field still
				// belongs to the equipped weapon and restore safely if not.
				attached := p.attachment.read
				world := attached.ptr(attached.base + espLayouts[attached.build].world)
				if !p.chain.stillCurrent(world, attached.ptr) {
					p.restore()
					twWorker.patch = nil
					twWorker.Unlock()
					continue
				}
				// Certain weapon pipelines can reload CWeaponInfo while the key is
				// held. The old worker never checked whether its patch survived.
				// Write again ONLY after the exact original value has returned,
				// and reject unknown values rather than trampling other changes.
				live, ok := readFloat32Game(attached, p.chain.field)
				if !ok || classifyPenetrationRefresh(live, p.original, experimentalPenetrationValue) == penetrationStop {
					p.restore()
					twWorker.patch = nil
					twStatus("Penetração desarmada: valor externo mudou ou leitura falhou", 0, false)
					twWorker.Unlock()
					continue
				}
				if classifyPenetrationRefresh(live, p.original, experimentalPenetrationValue) == penetrationReapply {
					if !writeFloat32Game(p.attachment.writer, p.chain.field, experimentalPenetrationValue) {
						p.restore()
						twWorker.patch = nil
						twStatus("Penetração desarmada: reaplicação recusada", 0, false)
						twWorker.Unlock()
						continue
					}
					verified, readOK := readFloat32Game(attached, p.chain.field)
					if !readOK || verified != experimentalPenetrationValue {
						p.restore()
						twWorker.patch = nil
						twStatus("Penetração desarmada: reaplicação não confirmada", 0, false)
						twWorker.Unlock()
						continue
					}
					p.refreshes++
					twStatus(fmt.Sprintf("Penetração mantida na arma; %d reaplicações (colisão ainda não validada)", p.refreshes), attached.pid, true)
				}
				twWorker.Unlock()
				continue
			}
			if !enabled {
				twWorker.Unlock()
				continue
			}
			if now.Sub(lastTry) < 180*time.Millisecond {
				twWorker.Unlock()
				continue
			}
			lastTry = now
			patched, err := twInstall()
			if err != nil {
				twStatus(err.Error(), 0, false)
			} else {
				twWorker.patch = patched
				twStatus("Campo de penetração aplicado; atravessar paredes NÃO confirmado", patched.attachment.read.pid, true)
			}
			twWorker.Unlock()
		}
	}()
}
