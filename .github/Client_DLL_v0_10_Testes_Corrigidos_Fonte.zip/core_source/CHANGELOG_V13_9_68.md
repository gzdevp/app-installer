# sete7 Black Edition v13.9.68 — Controles de veículos

## Implementado
- Trancar/destrancar pela entrada já autorizada da cidade: comando de chat ou tecla configurada por ação.
- Teclas permitidas: A-Z, 0-9, F1-F12 e NUM0-NUM9; o comando tem prioridade quando ambos são configurados.
- Os controles não dependem de o jogador estar sentado no veículo e não vinculam um endereço local de memória ao alvo do comando. O servidor da cidade escolhe a entidade adequada.
- FIX CAR oferece comando opcional de reparo existente na cidade. Sem ele, conserva a tentativa local experimental b3258, validada para o veículo ocupado.
- Feedback diferencia entrega de entrada (tecla/comando) de confirmação de um reparo ou tranca.
- Preservadas as outras rotinas do código-fonte v13.9.67, além da interface sem janela CMD.

## Limitações
- **Não existe garantia universal para todos os servidores FiveM**: cada cidade valida reparo, chaves e propriedade do carro.
- O método local experimental não é equivalente à native SetVehicleFixed e não restaura deformação visual/estado de rede.
- Um comando enviado não significa que o servidor aceitou a ação. Se a cidade não oferece comando ou bind, estas rotas não funcionam.
- Tecla de reparo não está implementada: a opção servidor do FIX CAR requer comando em chat.
- Testes disponíveis: validação de tecla em Go (Linux), sintaxe JS e compilação Windows amd64. Sem teste em uma cidade FiveM real.

## Usar
1. Abra **World > Vehicles**.
2. Em **Trava da cidade**, coloque um comando que realmente exista, ou a tecla de trava configurada no FiveM. Se a cidade usa a mesma tecla para alternar, repita-a em trancar e destrancar.
3. Em **Controles**, deixe o comando de reparo em branco para tentativa local experimental ou informe o comando de reparo realmente disponível na cidade.
4. Ative a opção de Vehicle ESP para visualizar carros, mas observe que os comandos da cidade agem sobre o carro definido pelo servidor, não sobre o carro selecionado no ESP.
