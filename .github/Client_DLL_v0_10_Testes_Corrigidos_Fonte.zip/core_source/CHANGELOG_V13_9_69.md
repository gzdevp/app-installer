# sete7 / 77 v13.9.69 — Unlock All local experimental

**Não é um desbloqueio universal comprovado.** Não foi testado dentro do FiveM.

## Mudanças
- NOVO: World > Vehicles > Unlock All (experimental), desligado por padrão.
- Sem bind/comando de servidor: no modo ativo, a cada ~400 ms tenta examinar o carro mais próximo dentro de 5,5 m; somente com FiveM em primeiro plano.
- Alterna um candidato de estado local de trava de veículo na build b3258, após validações de pool ativo, coordenadas, modelo válido, distância, foco e faixa do valor antigo.
- Manual Trancar / Destrancar sem comando/tecla passa a tentar alterar a trava local do veículo próximo selecionado, com as mesmas validações.
- Usa operação de memória de apenas 1 byte; continua sendo **offset experimental NÃO VALIDADO em jogo** e pode causar comportamento inesperado ou travamento. O usuário precisa ativá-lo manualmente.
- Mantidos modo anterior de comandos de cidade e outras funcionalidades v13.9.68.
- Tenta apresentar estado de leitura local e distingue explicitamente da confirmação do servidor.

## Limitações reais
- Não consegue conceder chaves ou permissões da cidade, nem desativar as regras servidor.
- O cliente pode ter seu estado sobrescrito pelo servidor mesmo após gravação local.
- Não assegura que a tentativa realmente abre a porta ou permite entrar; a única validação foi recompilação e testes de unidade de estado/distância.
- Só modo experimental b3258; em outras builds o código falha de forma fechada.
- O offset da trava (+0x13C0) veio de fonte pública não validada no jogo e **não foi auditado dinamicamente**.
- Não ativar em sessões importantes; realizar teste controlado com backup em ambiente onde seja permitido.

## Testes executados (ambiente sem FiveM)
- Compilação Windows/amd64 sem janela de console: OK.
- `go test vehicle_unlockall_logic.go vehicle_unlockall_logic_test.go`: OK.
- JavaScript extraído de `web/index.html`: `node --check`: OK.
- `GOOS=windows GOARCH=amd64 go test -c`: OK, gerou testes compilados; execução Windows não testada.
