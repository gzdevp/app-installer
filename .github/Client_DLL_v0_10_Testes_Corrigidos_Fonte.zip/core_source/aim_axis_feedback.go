package main

// aimAxisFeedback checks the effect of a relative Y mouse command against the
// next observed on-screen position of the SAME verified joint. It avoids
// assuming the game camera uses Windows' default vertical sign. Inference is
// deliberately conservative: transient movement/recoil must not flip axes.
type aimAxisFeedback struct {
	pending      bool
	ped          uint64
	oldX, oldY   int32
	sentX, sentY int32
	bad, good    int
	reversed     bool
	flips        int
	samples      int
}

func aimAbs(v int32) int32 {
	if v < 0 {
		return -v
	}
	return v
}

func (a *aimAxisFeedback) clearPending() { a.pending = false }

func (a *aimAxisFeedback) record(ped uint64, x, y, dx, dy int32) {
	a.pending = ped != 0 && aimAbs(dy) >= 3
	a.ped, a.oldX, a.oldY, a.sentX, a.sentY = ped, x, y, dx, dy
}

// observe returns true only after repeated, plausible evidence that the Y
// response is inverted. The reference is actual sent Y, not a configuration.
func (a *aimAxisFeedback) observe(ped uint64, x, y int32) bool {
	if !a.pending {
		return false
	}
	a.pending = false
	if ped == 0 || ped != a.ped {
		a.bad, a.good = 0, 0
		return false
	}
	deltaY := y - a.oldY
	if aimAbs(deltaY) < 2 || aimAbs(deltaY) > 80 ||
		aimAbs(deltaY) > aimAbs(a.sentY)*9+10 {
		return false
	}
	// When a sizeable X movement exists, reject implausible samples where
	// the X response also moved *away* from the expected counter-direction.
	if aimAbs(a.sentX) >= 4 {
		deltaX := x - a.oldX
		if aimAbs(deltaX) >= 3 && aimAbs(deltaX) <= 80 &&
			(deltaX > 0) == (a.sentX > 0) {
			return false
		}
	}
	a.samples++
	bad := (deltaY > 0) == (a.sentY > 0)
	if bad {
		a.bad++
		a.good = 0
	} else {
		a.good++
		a.bad = 0
	}
	if a.bad >= 3 {
		a.reversed = !a.reversed
		a.flips++
		a.bad, a.good = 0, 0
		return true
	}
	return false
}
