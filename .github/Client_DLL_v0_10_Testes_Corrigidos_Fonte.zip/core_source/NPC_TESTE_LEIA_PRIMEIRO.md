# sete7 v13.2 — suporte experimental a NPCs (teste local)

Base: sete7 v13.2 Head Direto (interface GUI/INSERT; sem CMD).

## Como testar
1. Abra o sete7 e o FiveM normalmente.
2. Para ver NPCs: em Visuals, ative **Players ESP** e **Show NPCs**.
3. Para mirar em NPCs: em Aim > Aimbot, ative **Aimbot** e **Mirar em NPCs**. Selecione **Head**, configure sua tecla e segure-a com o FiveM em primeiro plano.
4. Para permitir NPCs no Silent: em Aim > Silent Aim, desligue **Ignore NPCs**. Essa opção é independente das duas anteriores.
5. Para voltar ao comportamento anterior, desligue Show NPCs e Mirar em NPCs e ative Ignore NPCs no Silent.

## Alterações reais
- Scanner de peds: além dos jogadores com PlayerInfo, admite NPCs sem PlayerInfo **somente quando algum módulo solicita NPCs**. Mantém filtros de posição, distância, nav e vida, exclui personagem local e deduplica ponteiros.
- ESP: rotula NPCs com a indicação NPC e desenha apenas se Show NPCs estiver ativado.
- Aimbot: NPCs são elegíveis apenas se Mirar em NPCs estiver ligado. Ainda requer cabeça 3D validada e segue o controlador FollowPedCamera **já existente**; não foi substituído.
- Silent: adicionado somente um filtro de uma linha para respeitar Ignore NPCs na seleção. Rotina de hook/disparo, patch, offsets e cálculo de cabeça preservados.
- Menu: somente duas opções novas e correção do antigo switch Show NPCs que não funcionava; nenhum ajuste no sistema GUI / INSERT.

## Validações
- Testes isolados de seleção de ped/NPC, alvo real, FOV, local player e Ignore NPCs: ver validation/npc_selection (Go Linux, sem FiveM).
- Compilação Windows x64 com -H windowsgui.
- Execução no FiveM **não disponível neste ambiente**: não foi validado que os NPCs desta build exponham os ossos corretamente, nem que o movimento do Aimbot/funcionamento do Silent sejam corretos em jogo.

NPCs com esqueleto não verificável podem aparecer no ESP sem serem alvo de Aimbot/Silent. Isso evita uma falsa mira na cabeça.
