# sete7 v13.9.2 — Vehicles (versão experimental)

Base: sete7 v13.9.1, compilação separada; v13.3 e v13.8 não foram modificadas.

## Organização
- Menu lateral `Vehicles` reúne **todas** as opções novas de veículos.
- Removidos os controles de veículo que estavam duplicados em Visuals, World e Player.
- Mantido o botão FIX CAR, com rotina local existente e status explícito.

## Dados exibidos
- O scanner original de veículos do FiveM fornece a posição 3D, distância e lista ordenada até 500 m, mesmo que o veículo não esteja projetado na câmera.
- Nome real somente se o hash lido via ModelInfo corresponder a um nome da lista de modelos conhecidos; caso contrário aparece explicitamente `modelo não identificado`. Offsets de ModelInfo são experimentais para a build b3258.
- Velocidade em km/h **estimada** por duas posições separadas por no mínimo 120 ms. Teleporte / ruído são descartados; primeiro frame é `—`.
- Vida do motor usa leitura de campos experimentais *somente na b3258*, sujeita a verificação dos três valores de integridade antes de exibir. Se inválida, `—`.
- Ocupantes: contagem estimada de peds associados ao veículo, apenas com layout b3258 e leitura de pool de peds válida. Outras builds exibem `—`.

## Ações
- FIX CAR: botão na aba Vehicles; altera campos locais do veículo em uso (build b3258); a confirmação significa apenas *leitura de memória*, não reparo autoritativo no servidor.
- TRANCAR / DESTRANCAR: **não implementados** no modo externo atual. Botões desabilitados e justificativa explícita, porque em cidades multiplayer as fechaduras podem ser controladas por recursos do servidor. Não existe escrita segura e validada nem integração nativa autorizada no projeto atual. Não simula clicar numa tela nem afirma ter trancado um carro.

## Testes realizados
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build`: passou.
- `GOOS=windows GOARCH=amd64 go vet ./...`: passou.
- Compilação cruzada dos testes Windows `go test -c`: passou.
- Testes isolados de hashes conhecidos/desconhecidos e validação de velocidade: passaram no Linux.
- Teste de parsing do JavaScript do HTML: passou.
- Preview da aba Vehicles aberta em Chromium: verificada.

NÃO testado dentro do FiveM/Windows. Compatibilidade com outras cidades/builds, nomes, motor, ocupantes e sincronização de FIX CAR não homologadas. Preserve as versões antigas.
