//go:build windows

package main

import (
	"fmt"
	"math"
	"sync"
	"sync/atomic"
	"time"
	"unsafe"
)

// b3258 candidate from a public offset dump. The value and field width are
// unverified for any running FiveM build: this mode is EXPERIMENTAL and opt-in.
// The write is limited to one byte and only after several independent checks.
const b3258CandidateDoorLockByteOffset = uintptr(0x13C0)

var localUnlockEnabled atomic.Bool

// Default GTA/FiveM keyboard vehicle-enter control is F. A remapped key can
// be selected in the panel. This is OS input observation, NOT a native game
// control event, so controllers/custom mappings may need a different binding.
var localUnlockEntryKey atomic.Uint32

func localUnlockSetEntryKey(key string) {
	if !validBindingKey(key) {
		key = "f"
	}
	localUnlockEntryKey.Store(uint32(genericKeyVK(key, 0x46)))
}
func localUnlockEnterVK() uintptr {
	vk := localUnlockEntryKey.Load()
	if vk == 0 {
		return 0x46
	}
	return uintptr(vk)
}

var localUnlockStatus = struct {
	sync.RWMutex
	status    string
	at        string
	attempts  uint64
	confirmed uint64
}{status: "Desativado"}
var localUnlockWriteMu sync.Mutex

func localUnlockSet(enabled bool) {
	localUnlockEnabled.Store(enabled)
	if !enabled {
		localUnlockReport("Desativado", false)
	} else {
		localUnlockReport("Aguardando tecla Entrar (F por padrão). Tentativa local experimental b3258", false)
	}
}
func localUnlockReport(s string, confirmed bool) {
	localUnlockStatus.Lock()
	localUnlockStatus.status = s
	localUnlockStatus.at = time.Now().Format("15:04:05")
	if confirmed {
		localUnlockStatus.confirmed++
	}
	localUnlockStatus.Unlock()
}
func localUnlockGet() map[string]any {
	localUnlockStatus.RLock()
	defer localUnlockStatus.RUnlock()
	return map[string]any{"enabled": localUnlockEnabled.Load(), "entryVK": localUnlockEnterVK(), "status": localUnlockStatus.status, "at": localUnlockStatus.at, "attempts": localUnlockStatus.attempts, "localReadsConfirmed": localUnlockStatus.confirmed, "serverConfirmed": false}
}
func writeVehicleLockByte(handle, address uintptr, value byte) bool {
	buf := [1]byte{value}
	var written uintptr
	ok, _, _ := noclipWriteProcessMemory.Call(handle, address, uintptr(unsafe.Pointer(&buf[0])), 1, uintptr(unsafe.Pointer(&written)))
	return ok != 0 && written == 1
}
func readVehicleLockByte(p *attachedESP, address uintptr) (byte, bool) {
	var data [1]byte
	if !p.read(address, data[:]) {
		return 0, false
	}
	return data[0], true
}
func (p *attachedESP) nearbyVehicleForLocalLock(requested uint64) (uintptr, float64, bool) {
	layout, ok := espLayouts[p.build]
	if !ok {
		return 0, 0, false
	}
	world := p.ptr(p.base + layout.world)
	if world < 0x10000 {
		return 0, 0, false
	}
	ped := p.ptr(world + 0x8)
	if ped < 0x10000 {
		return 0, 0, false
	}
	pedPos, ok := p.vec3(ped + 0x90)
	if !ok || !plausibleFiveMPosition(pedPos) {
		return 0, 0, false
	}
	// Do not touch vehicles while the player is already seated.
	if current := p.ptr(ped + 0xD10); current >= 0x10000 && p.vehicleIsActiveInPool(current) {
		return 0, 0, false
	}
	replay := p.ptr(p.base + layout.replay)
	if replay < 0x10000 {
		return 0, 0, false
	}
	list, count, valid := p.findVehiclePool(replay)
	if !valid {
		return 0, 0, false
	}
	var selected uintptr
	distance := math.Inf(1)
	for _, car := range p.pedSlots(list, count) {
		if car < 0x10000 || car > 0x7FFFFFFFFFFF {
			continue
		}
		if requested != 0 && uint64(car) != requested {
			continue
		}
		info := p.ptr(car + 0x20)
		if info < 0x10000 || info > 0x7FFFFFFFFFFF {
			continue
		}
		model := p.uint32(info + 0x18)
		if model == 0 || model == 0xFFFFFFFF {
			continue
		}
		pos, valid := p.vec3(car + 0x90)
		if !valid || !plausibleFiveMPosition(pos) {
			continue
		}
		d := dist(pedPos, pos)
		if !validUnlockTargetDistance(d) {
			continue
		}
		if d < distance {
			selected = car
			distance = d
		}
	}
	return selected, distance, selected != 0
}

// A local change cannot grant a server-side vehicle key or prove a network
// change. Refuse to guess different offsets or unknown values.
func localVehicleLockAttempt(requested uint64, desired byte) (string, bool) {
	a, err := attachWritableGame()
	if err != nil {
		return "Jogo indisponível: " + err.Error(), false
	}
	defer a.close()
	return localVehicleLockAttemptAttached(a, requested, desired)
}

func localVehicleLockAttemptAttached(a *noclipAttachment, requested uint64, desired byte) (string, bool) {
	localUnlockWriteMu.Lock()
	defer localUnlockWriteMu.Unlock()
	if desired != 1 && desired != 2 {
		return "Estado de trava inválido", false
	}
	p := a.read
	if p.build != "b3258" {
		return "Trava local experimental disponível somente na b3258", false
	}
	if !fiveMIsForeground(p.pid) {
		return "Ação cancelada: FiveM não está em foco", false
	}
	car, d, ok := p.nearbyVehicleForLocalLock(requested)
	if !ok {
		return "Nenhum veículo confirmado a até 5,5 m", false
	}
	addr := car + b3258CandidateDoorLockByteOffset
	previous, ok := readVehicleLockByte(p, addr)
	if !ok || !plausibleLocalDoorLockState(previous) {
		return "Layout de trava não reconhecido; nenhuma escrita realizada", false
	}
	if previous == desired || (desired == 1 && previous <= 1) {
		return fmt.Sprintf("Campo local já em estado %d (servidor não verificado)", previous), true
	}
	if !writeVehicleLockByte(a.writer, addr, desired) {
		return "Escrita local recusada", false
	}
	time.Sleep(60 * time.Millisecond)
	observed, readOK := readVehicleLockByte(p, addr)
	if !readOK || observed != desired {
		return "Estado local não permaneceu aplicado; servidor/jogo pode ter revertido", false
	}
	return fmt.Sprintf("Campo local alterado para %d (%.1f m). Entrada e servidor NÃO confirmados", desired, d), true
}

func startLocalAutoUnlock() {
	go func() {
		defer recoverServiceWorker("vehicle_unlockall_windows.go")
		ticker := time.NewTicker(20 * time.Millisecond)
		defer ticker.Stop()
		var keyEdge entryPressDetector
		var previousVK uintptr
		for range ticker.C {
			enabled := localUnlockEnabled.Load()
			vk := localUnlockEnterVK()
			// Use the same foreground check as the other hold-to-activate
			// features: Never trigger from the desktop or while the menu is open.
			foreground, _, _ := getForeground.Call()
			focused := activeFiveMWindow(foreground) && !overlayPaused.Load()
			down := noclipKeyHeld(vk)
			// Key remap while pressed must not create a false "enter" event.
			if vk != previousVK {
				keyEdge.wasDown = down
				previousVK = vk
				continue
			}
			if !keyEdge.update(enabled, focused, down) {
				continue
			}
			// Do not poll memory/write repeatedly merely because a vehicle is
			// nearby: one attempt for each actual Enter Vehicle key press.
			localUnlockStatus.Lock()
			localUnlockStatus.attempts++
			localUnlockStatus.Unlock()
			status, readBackOK := localVehicleLockAttempt(0, 1)
			localUnlockReport(status, readBackOK)
		}
	}()
}
