package main

import "math"

// projectOffscreen360 returns the edge marker for targets outside the viewport,
// including targets behind the camera (negative homogeneous depth).  Front
// targets truly on-screen are never marked. The rear center has no unique
// left/right bearing, so it uses the bottom-center marker deterministically.
// This function only supplies read-only drawing coordinates, never aim targets.
func projectOffscreen360(m matrix44, v vec3, width, height int32) (int32, int32, bool, bool) {
	if width < 320 || height < 240 || !plausibleFiveMPosition(v) {
		return 0, 0, false, false
	}
	x := float64(m[1]*v.X + m[5]*v.Y + m[9]*v.Z + m[13])
	y := float64(m[2]*v.X + m[6]*v.Y + m[10]*v.Z + m[14])
	z := float64(m[3]*v.X + m[7]*v.Y + m[11]*v.Z + m[15])
	if math.IsNaN(x) || math.IsNaN(y) || math.IsNaN(z) || math.IsInf(x, 0) || math.IsInf(y, 0) || math.IsInf(z, 0) {
		return 0, 0, false, false
	}
	behind := z < 0
	rearOrNear := z <= .1
	var dx, dy float64
	if !rearOrNear {
		dx, dy = x/z, -y/z
		// Do not mark an object that is actually in the viewport.
		if math.Abs(dx) <= 1 && math.Abs(dy) <= 1 {
			return 0, 0, false, false
		}
	} else {
		// Use abs(depth) for camera-relative side. Dividing by signed depth
		// would mirror rear targets and point an arrow in the wrong direction.
		divisor := math.Max(math.Abs(z), .1)
		dx, dy = x/divisor, -y/divisor
		if math.Hypot(dx, dy) < .0001 {
			dx, dy = 0, 1
		}
	}
	if math.IsNaN(dx) || math.IsNaN(dy) || math.IsInf(dx, 0) || math.IsInf(dy, 0) {
		return 0, 0, false, behind
	}
	margin := 35.0
	bx, by := float64(width)/2-margin, float64(height)/2-margin
	if bx <= 0 || by <= 0 {
		return 0, 0, false, behind
	}
	// Scale normalized clip direction into the matching screen aspect ratio.
	px, py := dx*float64(width)/2, dy*float64(height)/2
	screenScale := math.Max(math.Abs(px)/bx, math.Abs(py)/by)
	if screenScale <= 0 || math.IsInf(screenScale, 0) {
		return 0, 0, false, behind
	}
	sx := int32(math.Round(float64(width)/2 + px/screenScale))
	sy := int32(math.Round(float64(height)/2 + py/screenScale))
	return sx, sy, true, behind
}

// Compatibility wrapper for the legacy front-only test/API.
func projectOffscreen(m matrix44, v vec3, width, height int32) (int32, int32, bool) {
	x, y, ok, _ := projectOffscreen360(m, v, width, height)
	return x, y, ok
}
