# 77 v13.9.49 — One-click exit
- Unload: single click, no confirm/OK. Authenticated API triggers a graceful shutdown that restores temporary patches, closes the local HTTP server, stops the private Edge/Chrome session and removes the disposable profile. The executable process then exits normally (no Task Manager residue of the 77 process).
- Cleaner: single click with no prompt, no typing, no OK; same controlled shutdown and own-session file cleanup. The existing attempted self-delete of the running EXE cannot be guaranteed on Windows and never touches unrelated files.
- Authentication remains required for both endpoints, including localhost origin validation.
- No other changes to game-facing controls.
