//go:build !windows

package main

func detectFiveMProcess() bool { return false }
