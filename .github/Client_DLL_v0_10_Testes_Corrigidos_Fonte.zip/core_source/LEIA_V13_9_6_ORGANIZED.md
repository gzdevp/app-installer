# sete7 v13.9.6 — Organized Edition

Base: v13.9.5 Clean Edition.

## Alterações de interface
- Visuals: Players, Labels, Bars, Markers e Friends.
- Players: ativação ESP, NPC, alcance e boxes/estilo.
- Labels: nome e distância do alvo.
- Bars: HP e armadura visual.
- Markers: esqueleto, cor e snaplines.
- Friends: apenas aba informativa, integração ainda indisponível.
- Player/Health: Set Health e slider de HP.
- Player/Movement: TP Waypoint e controles do No Clip.
- Player/Protection: God/Semi God, No Ragdoll e Set Armor.
- Removida a antiga aba Actions sem eliminar comandos.
- Mantida World > Vehicles / Radar.

## Preservação
Todos os campos JSON enviados à API são os mesmos da v13.9.5.
Somente web/index.html, main.go e window_title.go tiveram alterações no código existente.
Toda a lógica nativa de jogo permaneceu byte a byte igual à v13.9.5.
A pasta do navegador desta build é sete7-v13.9.6-data.

## Validação
- Go build Windows amd64: OK
- Go vet Windows amd64: OK
- Testes Go compilados Windows amd64: OK
- node --check HTML script: OK
- Testes UI Chromium: navegação e controle de abas: OK

A execução real em FiveM não foi testada neste ambiente.
