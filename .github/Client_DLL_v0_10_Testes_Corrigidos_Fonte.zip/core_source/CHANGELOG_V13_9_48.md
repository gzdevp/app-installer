# v13.9.48 — Identificação de jogadores

- O leitor de nomes agora aceita UTF-8, UTF-16LE e ponteiro para string, com offsets específicos por build.
- Leitura continua estritamente local, somente de CPlayerInfo; sem endpoints externos ou exposição de IDs privados.
- Bytes inválidos continuam com rótulo genérico, sem marcar como amigo.
- Friend logic, ESP, UI, Insert, JACK 77, Weapons e Vehicles preservados.
- Implementação compilada e testada isoladamente; nenhum teste dentro do FiveM foi executado.
