# sete7 v13.8 — Radar 2D + No Recoil / No Spread (EXPERIMENTAL)

## Preservação da base estável
- A v13.3 original não foi modificada. Esta entrega usa v13.7 como base isolada.
- Arquivos de lógica principal Aimbot, Silent, TP, vida/armadura e Through Wall estão mantidos byte a byte em relação à v13.7.
- Os ajustes novos são desativados por padrão.

## Radar
- World > Radar: ativa desenho 2D no canto superior direito do jogo.
- Norte sempre para cima. Jogador no centro, outros jogadores em roxo/rosa; NPCs (opcionais) em laranja.
- Mostra entidades lidas da lista de ped do ESP independentemente de estarem visíveis na câmera; não descobre entidades que não existem no cliente.
- Alcance configurável entre 50 e 500 metros; tamanho entre 50 e 200%.
- O ajuste de intensidade visual não é transparência alfa real: o overlay usa chromakey do Windows.
- Leitura radar expira após 350 ms sem atualizações. A execução depende de um processo/build e de um leitor de entidades válidos.

## No Recoil e No Spread
- Weapons: dois interruptores independentes.
- Perfil de offsets de referência APENAS para b3258: CWeaponInfo + 0x2F4 (recoil) e + 0x84 (spread).
- O código só aceita ponteiros completos validados da arma equipada e valores float finitos/plausíveis; realiza escrita zero e leitura posterior.
- Tenta restaurar os valores antes da troca de arma, ao desativar, ao perder foco ou no Unload. A restauração é de melhor esforço; falhas de leitura e processos encerrados inesperadamente impedem garantia total.
- O status descreve os campos locais; não confirma que o jogo ou servidor aplicaram a dispersão/recuo aos disparos.
- Não há implementação/garantia universal: offsets do GTA/FiveM, valores reais e regras de scripts podem variar entre builds e cidades. Há referências públicas conflitantes para offsets: por isso não foram adicionados perfis indiscriminados.

## Teste prático sugerido
1. Faça backup da v13.3. Execute somente a v13.8 e abra FiveM.
2. Ative World > Radar com ESP de jogadores desligado; veja se aparecem marcadores em torno do seu personagem.
3. Em Weapons, primeiro ative No Recoil com uma arma sem acessório de redução de recuo; compare o padrão antes/depois, desligue e verifique retorno.
4. Repita com No Spread, disparando um carregador em alvo estático na mesma distância; compare agrupamento, desligue e confira restauração.
5. Caso exiba `offset não confirmado`, `campo incompatível` ou `restauração incompleta`, desligue a opção. Não force alterações em builds desconhecidas.

## Testes internos
- go build Windows amd64 concluído.
- go vet Windows amd64 concluído.
- node --check executado sobre JavaScript embutido.
- go test para lógica isolada do radar e validação dos valores das armas passou em Linux.
- NÃO executado no FiveM ou em cidades neste ambiente. Testes de interface e efeito de disparos requerem avaliação prática.
