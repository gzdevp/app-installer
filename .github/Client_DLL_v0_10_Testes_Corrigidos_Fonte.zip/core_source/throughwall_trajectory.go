package main

import (
	"errors"
	"math"
	"sete7/external/ui/aimv13"
)

// An external-only, read-only mathematical description of the camera aim line.
// It is NOT a collision trace, a native shot or proof that a wall can be pierced.
// No ped, target identifier or screen aim assist is involved in this calculation.
type externalAimRay struct {
	Origin    aimv13.Vec3
	Direction aimv13.Vec3
	End       aimv13.Vec3
	Meters    float64
}

func computeExternalAimRay(eye, facing aimv13.Vec3, meters float64) (externalAimRay, error) {
	good := func(n float64) bool { return !math.IsNaN(n) && !math.IsInf(n, 0) }
	if !(good(eye.X) && good(eye.Y) && good(eye.Z)) {
		return externalAimRay{}, errors.New("origem inválida")
	}
	if !aimv13.ValidDirection(facing) {
		return externalAimRay{}, errors.New("direção inválida")
	}
	if !good(meters) || meters < 1 || meters > 500 {
		return externalAimRay{}, errors.New("alcance fora de 1 a 500 metros")
	}
	unit, ok := aimv13.Unit(facing)
	if !ok {
		return externalAimRay{}, errors.New("não foi possível normalizar a direção")
	}
	end := aimv13.Add(eye, aimv13.Mul(unit, meters))
	if !(good(end.X) && good(end.Y) && good(end.Z)) {
		return externalAimRay{}, errors.New("fim da reta inválido")
	}
	return externalAimRay{Origin: eye, Direction: unit, End: end, Meters: meters}, nil
}

// A known obstruction could be placed along this ray, but without real
// collision information the external process MUST NOT fabricate an exit face.
func (r externalAimRay) pointAt(distance float64) (aimv13.Vec3, bool) {
	if math.IsNaN(distance) || math.IsInf(distance, 0) || distance < 0 || distance > r.Meters {
		return aimv13.Vec3{}, false
	}
	return aimv13.Add(r.Origin, aimv13.Mul(r.Direction, distance)), true
}
