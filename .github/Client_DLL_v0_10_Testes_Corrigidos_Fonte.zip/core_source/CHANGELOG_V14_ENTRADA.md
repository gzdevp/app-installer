# sete7 v14 — alteração pontual de acionamento

- Unlock All experimental não é mais acionado automaticamente por proximidade.
- Agora só tenta um destrancamento local por pressão da tecla de entrada (F por padrão; configurável em World > Vehicles), quando FiveM está em foco.
- Não repete enquanto a tecla está pressionada. Não tenta ações na ausência de comando de entrada, nem por perda/retorno de foco.
- O método continua limitado ao offset experimental b3258 e não concede permissões ou chaves válidas no servidor.
- Through Wall permanece acionado por tecla enquanto estiver segurando: o código já acompanha trocas de arma equipada, mas modifica apenas Penetration na arma atual; **não há penetração comprovada de paredes, vidros ou carros em nenhuma arma**. Não declaramos suporte universal falso.
- Demais recursos da base externa v14 preservados.
