package main

import (
	"testing"
	"time"
)

func TestVehicleHashesKnownAndUnknown(t *testing.T) {
	n, ok := vehicleNameByHash(3078201489)
	if !ok || n != "Truffade Adder" {
		t.Fatal(n, ok)
	}
	if _, ok := vehicleNameByHash(0); ok {
		t.Fatal("unverified model accepted")
	}
}
func TestVehicleSpeedGuard(t *testing.T) {
	a, b := vec3{X: 0, Y: 0, Z: 0}, vec3{X: 10, Y: 0, Z: 0}
	n, ok := vehicleSpeedKMH(a, b, time.Second)
	if !ok || n != 36 {
		t.Fatal(n, ok)
	}
	if _, ok := vehicleSpeedKMH(a, b, 1*time.Millisecond); ok {
		t.Fatal("jitter accepted")
	}
	if _, ok := vehicleSpeedKMH(a, vec3{X: 2000}, time.Second); ok {
		t.Fatal("teleport speed accepted")
	}
}
