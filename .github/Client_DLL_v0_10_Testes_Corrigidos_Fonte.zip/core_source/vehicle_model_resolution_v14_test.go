package main

import "testing"

func TestV14ModelFieldSelection(t *testing.T) {
	// Fallback when no evidence (custom-only city).
	if got := candidateVehicleHashOffset(nil, nil); got != 1 {
		t.Fatalf("no evidence: %d", got)
	}
	// 0x1c is supported when multiple vehicles agree on real models.
	samples := []vehicleModelHashSample{{0, 11, 3078201489, 99}, {0, 12, 2922118804, 77}, {0, 13, 1032823388, 88}}
	if got := candidateVehicleHashOffset(samples, nil); got != 2 {
		t.Fatalf("expected +0x1c, got %d", got)
	}
	// A single candidate should not cause a speculative layout switch.
	if got := candidateVehicleHashOffset(samples[:1], nil); got != 1 {
		t.Fatalf("weak evidence: %d", got)
	}
	// Ambiguous layouts must fall back to established +0x18.
	ambiguous := []vehicleModelHashSample{{0, 3078201489, 2922118804, 0}, {0, 1032823388, 3078201489, 0}}
	if got := candidateVehicleHashOffset(ambiguous, nil); got != 1 {
		t.Fatalf("ambiguous: %d", got)
	}
}

func TestVehiclePoolCanRecognizeAlternativeModelField(t *testing.T) {
	known := vehicleModelHashSample{0, 0, 3078201489, 0}
	plausible, named := vehiclePoolModelEvidence(known, nil)
	if !plausible || !named {
		t.Fatal("missed recognized Adder at +0x1c")
	}
	custom := vehicleModelHashSample{0, 0x12345678, 0, 0}
	plausible, named = vehiclePoolModelEvidence(custom, nil)
	if !plausible || named {
		t.Fatal("unknown model must remain an unknown model")
	}
	if plausible, named = vehiclePoolModelEvidence(vehicleModelHashSample{}, nil); plausible || named {
		t.Fatal("empty model info must be rejected")
	}
}
