package main

import (
	"encoding/binary"
	"testing"
)

func TestSessionIDFallback(t *testing.T) {
	b := make([]byte, 4)
	binary.LittleEndian.PutUint32(b, 42)
	m := fakeNames{0x200088: b}
	got := readFiveMPlayerLabel(0x200000, "b3258", m.read)
	if got != "Jogador (ID interno 42)" {
		t.Fatalf("%q", got)
	}
	if validFriendName(got) {
		t.Fatal("internal ID must never be a friend")
	}
	if got := readFiveMPlayerLabel(0x200000, "b3095", m.read); got != "Jogador" {
		t.Fatalf("%q", got)
	}
}
func TestSessionIDOutOfRange(t *testing.T) {
	b := make([]byte, 4)
	binary.LittleEndian.PutUint32(b, 8675309)
	m := fakeNames{0x200088: b}
	if got := readFiveMPlayerLabel(0x200000, "b3258", m.read); got != "Jogador" {
		t.Fatalf("%q", got)
	}
}
