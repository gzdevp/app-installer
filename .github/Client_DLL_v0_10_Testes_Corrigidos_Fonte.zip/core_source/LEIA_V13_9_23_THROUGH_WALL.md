# Sete7 v13.9.23 — correção de semântica do Through Wall

**NÃO IMPLEMENTA penetração de paredes no jogo.** Esta é uma revisão de segurança e fidelidade à especificação do usuário, **não** a versão final da função.

- Through Wall significa somente passagem do tiro em linha reta por obstáculos, sem seleção de alvo, Silent Aim, aimbot ou desvio de trajetória.
- O código anterior (v13.6–v13.9.22) injetava um detour de destino de bala, equivalente ao do Silent Aim, e estava incorreto para este requisito. Foi removido totalmente da funcionalidade Through Wall.
- O toggle de efeito foi retirado da interface para não oferecer um botão que não funciona; o campo de tecla e o status permanecem visíveis como referência.
- Não houve alteração dos módulos que já funcionavam. A configuração legada `aim.throughWall=true` é ignorada por segurança.
- Para tornar esta função operacional num EXE externo, seria necessário identificar e validar no build real do FiveM a etapa de colisão e as condições de aceite de dano no servidor. Não é seguro adivinhar endereços, padrões binários ou prometer compatibilidade universal. Sem o jogo instalado, não há como validar esses efeitos aqui.

Validação de build Windows / go vet e testes automatizados NÃO demonstram funcionamento em jogo.
