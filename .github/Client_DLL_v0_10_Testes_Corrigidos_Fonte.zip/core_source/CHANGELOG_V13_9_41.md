# sete7 v13.9.41 — Friend ESP Colors

- **Visuals > Friends**: "Cor dos amigos no ESP" com paleta de cores e seletor RGB.
- Cor inicial verde menta `#42E5A0`, independente da cor dos outros jogadores.
- A cor exclusiva se aplica a **Boxes, Skeleton, Snaplines, Names, Distance, Health e Armor** quando o alvo é identificado como amigo.
- Outros jogadores continuam usando o branco padrão e a cor configurada para o esqueleto.
- A lista de amigos e o reconhecimento por nome único continuam funcionando da mesma forma; se houver nomes duplicados, nenhuma entidade é identificada automaticamente como amigo.
- Implementação usa apenas canetas GDI criadas uma vez por frame; evita alocação para cada entidade e restaura a cor antes do próximo jogador.
- Não altera Silent Aim, filtro de amigos, Stream Mode, binds, weapons nem o mascote JACK 77.
- Compilação pode ser verificada em Windows; funcionalidade em FiveM não validada neste ambiente.
