//go:build windows

package main

import (
	"encoding/binary"
	"math"
	"time"
	"unsafe"
)

// These camera-vector field offsets are recovered from the supplied Nexo v8.4
// executable's startCameraAimLoop, NOT inferred from SendInput. We validate
// the camera's world position and forward vector against the actual ESP view
// matrix before touching them. Unsupported layouts fail closed.
const (
	legacyCameraEyeOffset     uintptr = 0x60
	legacyCameraForwardOffset uintptr = 0x3D0
)

func finiteVec3(v vec3) bool {
	return !math.IsNaN(float64(v.X)) && !math.IsNaN(float64(v.Y)) && !math.IsNaN(float64(v.Z)) &&
		!math.IsInf(float64(v.X), 0) && !math.IsInf(float64(v.Y), 0) && !math.IsInf(float64(v.Z), 0)
}
func vectorLength(v vec3) float64 {
	return math.Sqrt(float64(v.X)*float64(v.X) + float64(v.Y)*float64(v.Y) + float64(v.Z)*float64(v.Z))
}
func unitVector(v vec3) (vec3, bool) {
	if !finiteVec3(v) {
		return vec3{}, false
	}
	l := vectorLength(v)
	if l < 0.0001 || math.IsNaN(l) || math.IsInf(l, 0) {
		return vec3{}, false
	}
	return vec3{float32(float64(v.X) / l), float32(float64(v.Y) / l), float32(float64(v.Z) / l)}, true
}
func dotVectors(a, b vec3) float64 {
	return float64(a.X)*float64(b.X) + float64(a.Y)*float64(b.Y) + float64(a.Z)*float64(b.Z)
}
func directionToHead(eye, head vec3) (vec3, bool) {
	if !plausibleFiveMPosition(eye) || !plausibleFiveMPosition(head) {
		return vec3{}, false
	}
	delta := vec3{head.X - eye.X, head.Y - eye.Y, head.Z - eye.Z}
	if l := vectorLength(delta); l < 1.0 || l > 600 {
		return vec3{}, false
	}
	return unitVector(delta)
}

// Rotate toward target by at most 4 degrees on a single 33 ms tick, without
// using mouse-axis signs. An invalid camera vector produces NO movement.
func cameraDirectionStep(eye, head, current vec3, smooth float64) (vec3, bool) {
	desired, ok := directionToHead(eye, head)
	if !ok {
		return vec3{}, false
	}
	n := vectorLength(current)
	if !finiteVec3(current) || n < 0.75 || n > 1.25 {
		return vec3{}, false
	}
	cur, _ := unitVector(current)
	dp := dotVectors(cur, desired)
	// Refuse vectors pointing away from the visible target: likely wrong offset.
	if dp < 0.45 {
		return vec3{}, false
	}
	if dp > 0.999995 {
		return vec3{}, false
	}
	if smooth < 1 {
		smooth = 1
	}
	if smooth > 20 {
		smooth = 20
	}
	// Interpolation with an explicit angular bound. No Y-axis inversion or probes.
	alpha := math.Min(0.30, math.Max(0.045, 0.22*10.0/smooth))
	out, ok := unitVector(vec3{
		X: float32(float64(cur.X)*(1-alpha) + float64(desired.X)*alpha),
		Y: float32(float64(cur.Y)*(1-alpha) + float64(desired.Y)*alpha),
		Z: float32(float64(cur.Z)*(1-alpha) + float64(desired.Z)*alpha),
	})
	if !ok {
		return vec3{}, false
	}
	turn := math.Acos(math.Max(-1, math.Min(1, dotVectors(cur, out))))
	if turn > 4*math.Pi/180 {
		fraction := (4 * math.Pi / 180) / turn
		out, ok = unitVector(vec3{
			X: float32(float64(cur.X) + (float64(out.X)-float64(cur.X))*fraction),
			Y: float32(float64(cur.Y) + (float64(out.Y)-float64(cur.Y))*fraction),
			Z: float32(float64(cur.Z) + (float64(out.Z)-float64(cur.Z))*fraction),
		})
		if !ok {
			return vec3{}, false
		}
	}
	if dotVectors(out, desired) <= dp+0.000001 {
		return vec3{}, false
	}
	return out, true
}

func cameraMatchesProjection(direction vec3, projection matrix44) bool {
	forward, ok := unitVector(vec3{projection[3], projection[7], projection[11]})
	if !ok {
		return false
	}
	v, valid := unitVector(direction)
	return valid && dotVectors(v, forward) > 0.72
}

func writeCameraDirection(a *noclipAttachment, addr uintptr, result vec3) bool {
	if a == nil || a.writer == 0 || addr < 0x10000 || !finiteVec3(result) {
		return false
	}
	lenResult := vectorLength(result)
	if lenResult < 0.98 || lenResult > 1.02 {
		return false
	}
	var b [12]byte
	binary.LittleEndian.PutUint32(b[0:4], math.Float32bits(result.X))
	binary.LittleEndian.PutUint32(b[4:8], math.Float32bits(result.Y))
	binary.LittleEndian.PutUint32(b[8:12], math.Float32bits(result.Z))
	var written uintptr
	ok, _, _ := noclipWriteProcessMemory.Call(a.writer, addr, uintptr(unsafe.Pointer(&b[0])), 12, uintptr(unsafe.Pointer(&written)))
	return ok != 0 && written == 12
}

type cameraAimGuard struct {
	pending            bool
	targetID           uint64
	oldError           float64
	previousProjection matrix44
	sentAt             time.Time
	faults             int
}

func (g *cameraAimGuard) reset() { *g = cameraAimGuard{} }
func (g *cameraAimGuard) observe(view espViewport, head vec3, id uint64) (ready bool, reason string) {
	if !g.pending {
		return true, ""
	}
	if g.targetID != id {
		g.pending = false
		return false, "Alvo mudou durante a resposta; aguardando novo quadro"
	}
	if time.Since(g.sentAt) < 45*time.Millisecond {
		return false, "Aguardando resposta real da câmera"
	}
	if time.Since(g.sentAt) > 350*time.Millisecond {
		g.pending = false
		g.faults++
		return false, "Sem resposta da câmera no prazo"
	}
	beforeX, beforeY, bok := worldToScreen(g.previousProjection, head, view.W, view.H)
	afterX, afterY, aok := worldToScreen(view.Camera, head, view.W, view.H)
	if !bok || !aok {
		g.pending = false
		g.faults++
		return false, "Cabeça saiu da projeção válida"
	}
	oldErr := math.Hypot(beforeX-float64(view.W)/2, beforeY-float64(view.H)/2)
	newErr := math.Hypot(afterX-float64(view.W)/2, afterY-float64(view.H)/2)
	g.pending = false
	// A direction-memory write must turn the projected target closer to screen
	// center. If not, refuse any more writes until the key is released.
	if newErr > oldErr+1.0 {
		g.faults++
		return false, "Falha: câmera afastou da cabeça; bloqueada até soltar tecla"
	}
	if math.Abs(newErr-oldErr) < 0.35 {
		g.faults++
		return false, "Câmera não respondeu; bloqueada até soltar tecla"
	}
	return true, ""
}
func (g *cameraAimGuard) mark(view espViewport, id uint64) {
	g.pending = true
	g.targetID = id
	g.previousProjection = view.Camera
	g.sentAt = time.Now()
}
