package main
import "testing"

func TestVehicleOccupiedAtZeroDistanceIsIncluded(t *testing.T) {
    if !validVehicleDistance(0, 500) {
        t.Fatal("occupied vehicle at the player's exact coordinates was dropped")
    }
    if validVehicleDistance(-1, 500) || validVehicleDistance(501, 500) {
        t.Fatal("out of range vehicle included")
    }
}
