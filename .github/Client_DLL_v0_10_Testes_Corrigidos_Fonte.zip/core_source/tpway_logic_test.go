package main

import (
	"encoding/binary"
	"math"
	"testing"
)

type fakeWaypointMemory map[uintptr]byte

func (m fakeWaypointMemory) put(addr uintptr, data []byte) {
	for i, b := range data {
		m[addr+uintptr(i)] = b
	}
}
func (m fakeWaypointMemory) u32(addr uintptr, n uint32) {
	var b [4]byte
	binary.LittleEndian.PutUint32(b[:], n)
	m.put(addr, b[:])
}
func (m fakeWaypointMemory) ptr(addr, target uintptr) {
	var b [8]byte
	binary.LittleEndian.PutUint64(b[:], uint64(target))
	m.put(addr, b[:])
}
func (m fakeWaypointMemory) xyz(addr uintptr, v vec3) {
	m.u32(addr, math.Float32bits(v.X))
	m.u32(addr+4, math.Float32bits(v.Y))
	m.u32(addr+8, math.Float32bits(v.Z))
}
func (m fakeWaypointMemory) read(addr uintptr, dst []byte) bool {
	for i := range dst {
		v, ok := m[addr+uintptr(i)]
		if !ok {
			return false
		}
		dst[i] = v
	}
	return true
}

func TestTPFindWaypointMixedMarkers(t *testing.T) {
	m := make(fakeWaypointMemory)
	list, normal, waypoint := uintptr(0x100000), uintptr(0x200000), uintptr(0x300000)
	m.ptr(list+0*8, normal)
	m.ptr(list+1*8, waypoint)
	m.u32(normal+0x40, 1)
	m.u32(normal+0x48, 84)
	m.xyz(normal+0x10, vec3{1, 2, 3})
	m.u32(waypoint+0x40, 8)
	m.u32(waypoint+0x48, 84)
	m.xyz(waypoint+0x10, vec3{1200, -600, 0})
	actual, err := tpFindWaypoint(m.read, list)
	if err != nil || actual.X != 1200 || actual.Y != -600 {
		t.Fatalf("expected waypoint: %+v / %v", actual, err)
	}
}
func TestTPFindWaypointNoMarker(t *testing.T) {
	m := make(fakeWaypointMemory)
	m.ptr(0x100000, 0x200000)
	m.u32(0x200000+0x40, 1)
	if _, err := tpFindWaypoint(m.read, 0x100000); err == nil {
		t.Fatal("must refuse missing waypoint")
	}
}
func TestTPRejectFalseMarkers(t *testing.T) {
	for _, tc := range []struct {
		icon, color uint32
		pos         vec3
	}{
		{8, 1, vec3{1, 1, 0}}, {1, 84, vec3{1, 1, 0}}, {8, 84, vec3{}},
		{8, 84, vec3{X: float32(math.NaN()), Y: 42}},
	} {
		m := make(fakeWaypointMemory)
		m.u32(0x200000+0x40, tc.icon)
		m.u32(0x200000+0x48, tc.color)
		m.xyz(0x200000+0x10, tc.pos)
		if _, ok := tpCandidateWaypoint(m.read, 0x200000); ok {
			t.Fatalf("false marker accepted: %+v", tc)
		}
	}
}
func TestTPAltitudeIsExplicit(t *testing.T) {
	got, err := tpDestination(vec3{X: 100, Y: 200, Z: 0}, 125)
	if err != nil || got.Z != 125 {
		t.Fatalf("altitude not respected: %+v %v", got, err)
	}
	for _, z := range []float32{float32(math.NaN()), -101, 1501} {
		if _, err = tpDestination(vec3{1, 2, 0}, z); err == nil {
			t.Fatalf("invalid altitude accepted: %v", z)
		}
	}
}
func TestTPWaypointReadFailure(t *testing.T) {
	if _, err := tpFindWaypoint(func(uintptr, []byte) bool { return false }, 0x100000); err == nil {
		t.Fatal("read failures must not look successful")
	}
}
