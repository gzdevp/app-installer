//go:build windows

package main

import (
	"fmt"
	"math"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

type RadarSettings struct {
	Enabled bool `json:"enabled"`
	Range   int  `json:"range"`
	Size    int  `json:"size"`
	Opacity int  `json:"opacity"`
	ShowNPC bool `json:"showNpc"`
}
type radarPed struct {
	Pos vec3
	NPC bool
}
type radarFrame struct {
	Origin vec3
	Peds   []radarPed
	PID    uint32
	At     time.Time
}

var radarSettingsRevision atomic.Uint64
var radarFrameRevision atomic.Uint64

var radarData = struct {
	sync.RWMutex
	Settings RadarSettings
	Frame    radarFrame
}{Settings: RadarSettings{Range: 250, Size: 100, Opacity: 80}}

func radarSet(s RadarSettings) {
	s.Range = clampRadarRange(s.Range)
	s.Size = clampRadarSize(s.Size)
	s.Opacity = clampRadarOpacity(s.Opacity)
	radarData.Lock()
	radarData.Settings = s
	radarData.Unlock()
	radarSettingsRevision.Add(1)
}
func radarGet() RadarSettings {
	radarData.RLock()
	defer radarData.RUnlock()
	return radarData.Settings
}
func radarPublish(pid uint32, origin vec3, players []candidatePed) {
	pts := make([]radarPed, 0, len(players))
	for _, p := range players {
		pts = append(pts, radarPed{Pos: p.position, NPC: p.isNPC})
	}
	radarData.Lock()
	radarData.Frame = radarFrame{Origin: origin, Peds: pts, PID: pid, At: time.Now()}
	radarData.Unlock()
	radarFrameRevision.Add(1)
}
func radarSnapshot(pid uint32) (RadarSettings, radarFrame, bool) {
	radarData.RLock()
	defer radarData.RUnlock()
	r := radarData.Settings
	f := radarData.Frame
	if !r.Enabled || f.PID != pid || time.Since(f.At) > 350*time.Millisecond {
		return r, radarFrame{}, false
	}
	return r, f, true
}
func radarDraw(dc uintptr, width, height int32, pid uint32) {
	s, f, ok := radarSnapshot(pid)
	if !ok || s.Opacity == 0 {
		return
	}
	// 160 px at 100%; keep space from the screen edges and avoid large oversized windows.
	size := int32(math.Round(160 * float64(s.Size) / 100))
	if size > width/3 {
		size = width / 3
	}
	if size > height/2 {
		size = height / 2
	}
	if size < 68 {
		return
	}
	radius := size / 2
	cx, cy := width-radius-24, radius+24
	blend := func(c uint32) uintptr {
		a := float64(s.Opacity) / 100
		rr := uint32(float64(c&0xff) * a)
		gg := uint32(float64((c>>8)&0xff) * a)
		bb := uint32(float64((c>>16)&0xff) * a)
		return uintptr(rr | (gg << 8) | (bb << 16))
	}
	// Dark opaque plate: the layered overlay uses chroma key, not true per-pixel alpha.
	dark, _, _ := solidBrush.Call(blend(0x00202020))
	oldBrush, _, _ := selectObject.Call(dc, dark)
	rim, _, _ := createPen.Call(0, 2, blend(0x00C6C6C6))
	oldPen, _, _ := selectObject.Call(dc, rim)
	ellipse.Call(dc, uintptr(cx-radius), uintptr(cy-radius), uintptr(cx+radius), uintptr(cy+radius))
	selectObject.Call(dc, oldBrush)
	deleteObject.Call(dark)
	cross, _, _ := createPen.Call(0, 1, blend(0x00505050))
	selectObject.Call(dc, cross)
	moveTo.Call(dc, uintptr(cx-radius+6), uintptr(cy), 0)
	lineTo.Call(dc, uintptr(cx+radius-6), uintptr(cy))
	moveTo.Call(dc, uintptr(cx), uintptr(cy-radius+6), 0)
	lineTo.Call(dc, uintptr(cx), uintptr(cy+radius-6))
	selectObject.Call(dc, rim)
	deleteObject.Call(cross)
	// Local character at radar center (small filled marker).
	dot, _, _ := solidBrush.Call(blend(0x00EFC477))
	old, _, _ := selectObject.Call(dc, dot)
	ellipse.Call(dc, uintptr(cx-4), uintptr(cy-4), uintptr(cx+4), uintptr(cy+4))
	selectObject.Call(dc, old)
	deleteObject.Call(dot)
	// All player positions from the unprojected ped scan, including off-camera players.
	var players, npcs int
	for _, p := range f.Peds {
		if p.NPC && !s.ShowNPC {
			continue
		}
		xy, in := radarProject(f.Origin, p.Pos, float64(s.Range), float64(radius-9))
		if !in {
			continue
		}
		x, y := cx+int32(math.Round(xy.X)), cy+int32(math.Round(xy.Y))
		c := uint32(0x00D08AFA)
		if p.NPC {
			c = 0x0048B9F5
			npcs++
		} else {
			players++
		}
		mark, _, _ := solidBrush.Call(blend(c))
		previous, _, _ := selectObject.Call(dc, mark)
		ellipse.Call(dc, uintptr(x-3), uintptr(y-3), uintptr(x+3), uintptr(y+3))
		selectObject.Call(dc, previous)
		deleteObject.Call(mark)
	}
	selectObject.Call(dc, oldPen)
	deleteObject.Call(rim)
	setBkMode.Call(dc, 1)
	setTextColor.Call(dc, blend(0x00FFFFFF))
	label := fmt.Sprintf("N  %dm  %d", s.Range, players)
	if s.ShowNPC {
		label = fmt.Sprintf("N  %dm  %d/%d", s.Range, players, npcs)
	}
	encoded, _ := syscall.UTF16FromString(label)
	if len(encoded) > 1 {
		textOut.Call(dc, uintptr(cx-radius+8), uintptr(cy-radius+6), uintptr(unsafe.Pointer(&encoded[0])), uintptr(len(encoded)-1))
	}
}
