# sete7 v14.2 — correções localizadas (29/10/2026)

Base: sete7 v14.1 externa, pacote 'SETE7_V14_TESTE_LEITURAS_FONTE.zip'.

## O que mudou de verdade

- Nome de sessão: para builds b2699/b2802, campos legados `+0xA4` / `+0x84` têm precedência sobre `+0x100`. A leitura de `char*` é priorizada em relação à interpretação dos bytes do endereço como texto. Evita rótulos inválidos por falso texto de ponteiro.
- O ESP usa diretamente o nome validado pela rotina de leitura, sem apresentação de IDs internos como se fossem nomes pessoais.
- Veículos: escolha do pool considera hashes reconhecidos em quatro campos candidatos de CModelInfo (não apenas `+0x18`), evitando reduzir a confiança de um pool válido com layout alternativo.

## Validação executada

- Windows/amd64 `go build` com `-H=windowsgui`: OK.
- `GOOS=windows go vet ./...`: OK.
- 12 testes isolados da leitura de nomes: OK.
- Testes isolados de layout e candidatos de hash: OK.
- O EXE não foi testado dentro do FiveM.

## Limitações abertas

- Não existe neste EXE externo uma fonte universal garantida de nome real Steam/FiveM para cada ped.
- Hash de carro personalizado não informa automaticamente sua marca e modelo sem dados do servidor/metadados locais.
- FIX/Unlock permanece experimental e sem confirmação universal.
- Through Wall continua sendo teste do campo `CWeaponInfo::Penetration`, não um bypass da colisão física ou confirmação de dano através de obstáculos.

Estes pontos não foram falsamente marcados como corrigidos.
