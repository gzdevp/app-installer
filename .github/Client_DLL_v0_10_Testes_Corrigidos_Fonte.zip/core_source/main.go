package main

import (
	"context"
	"crypto/rand"
	"embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

//go:embed web/index.html web/logo.png
var files embed.FS

const configLimit = 96 << 10

var validProfile = regexp.MustCompile(`^[\pL\pN _-]{1,30}$`)

type service struct {
	mu             sync.Mutex
	key            string
	dir            string
	config         json.RawMessage
	server         *http.Server
	uiURL          string
	stopping       atomic.Bool
	lastScan       time.Time
	lastSeen       bool
	mode           string
	accessToken    string
	accessFailures int
	accessBlocked  time.Time
}

// No sidecar files are created next to the EXE. Edge/Chrome still need a
// writable, isolated profile while the program is open, so all browser data,
// settings and temporary logs live in one disposable system TEMP directory.
// This also means configuration and named profiles are session-only. There is
// intentionally no AppData/registry persistence and no writes beside the EXE.
var sessionDataOnce sync.Once
var sessionDataPath string

func dataFolder() string {
	sessionDataOnce.Do(func() {
		dir, err := os.MkdirTemp(os.TempDir(), "Sete7-session-")
		if err != nil {
			return
		}
		// Write an ownership marker so a future Cleaner can recognize only
		// disposable sessions created by this application.
		if err := writeSessionOwnership(dir); err != nil {
			_ = os.RemoveAll(dir)
			return
		}
		sessionDataPath = dir
	})
	return sessionDataPath
}

func cleanSessionFiles() error {
	if sessionDataPath == "" {
		return nil
	}
	return cleanOwnedSessionPath(sessionDataPath, os.TempDir())
}

func newService(folder string) (*service, error) {
	if folder == "" {
		return nil, errors.New("nao foi possivel criar sessao temporaria")
	}
	if err := os.MkdirAll(folder, 0700); err != nil {
		return nil, err
	}
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return nil, err
	}
	s := &service{dir: folder, key: hex.EncodeToString(b), mode: "external-readonly-experimental", config: json.RawMessage(`{"theme":"dark","accent":"#ff5715","silentAim":{"enabled":false,"key":"mouse4","showFov":false,"fov":120,"fovColor":"#E50000","range":250,"visible":false,"ignoreNpc":false,"miss":0},"aim":{"enabled":false,"bone":"head","target":"players","targetNpc":false,"visible":false,"sticky":false,"multipoint":false,"points":8,"fov":130,"range":250,"fovColor":"#FFFFFF","smooth":10,"invertY":false,"autoY":false,"yCalV2":false,"visualFallback":false,"key":"mouse2","ignoreNpc":false,"trigger":false,"triggerDelay":35,"triggerRange":250,"throughWall":false,"showFov":false},"magic":{"key":"f7"},"trigger":{"enabled":false,"key":"mouse5","delay":45,"range":250,"radius":9,"targetNpc":false,"bone":"body"} ,"crosshair":{"enabled":false,"style":"dot","dotSize":5,"stretchX":0,"stretchY":0,"lengthX":9,"lengthY":9,"thickness":2,"gap":4,"outline":false,"outlineSize":1,"color":"#FFFFFF","outlineColor":"#000000"},"weapon":{"noRecoil":false,"noSpread":false,"noReload":false,"infiniteAmmo":false,"damage":1,"fireRate":1},"visual":{"playerEsp":false,"nearbyPlayers":true,"nearbyRange":500,"showNpc":false,"friends":[],"refreshMS":25,"renderMS":8,"boxes":false,"boxStyle":"corner","names":false,"health":false,"armor":false,"distance":false,"skeleton":false,"skeletonColor":"#FFFFFF","friendColor":"#42E5A0","snaplines":false,"range":250,"ignoreNpc":false,"vehicleEsp":false,"vehicleRange":300,"vehicleName":false},"chams":{"enabled":false,"throughWalls":false,"color":"#ff5858"},"vehicle":{"showSpeed":false,"showEngine":false,"showOccupants":false},"world":{"radar":false,"radarRange":250,"radarScale":100,"radarAlpha":80,"radarNPC":false,"showVehicles":false,"vehicleRange":250,"ignoreOccupied":false},"player":{"god":false,"godKey":"f9","semigod":false,"noclip":false,"noclipKey":"f2","noclipSpeed":15,"tpHeight":35,"health":200,"armor":100,"speed":1,"noRagdoll":false},"settings":{"streamMode":false},"profile":"Default"}`)}
	applyNativeSettings(s.config)
	return s, nil
}
func (s *service) authOrigin(w http.ResponseWriter, r *http.Request) bool {
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	if r.Header.Get("X-Nexo-Key") != s.key || s.key == "" {
		http.Error(w, "Acesso negado", http.StatusUnauthorized)
		return false
	}
	if origin := r.Header.Get("Origin"); origin != "" && origin != "http://"+r.Host {
		http.Error(w, "Origem nao permitida", http.StatusForbidden)
		return false
	}
	return true
}
func (s *service) auth(w http.ResponseWriter, r *http.Request) bool {
	if !s.authOrigin(w, r) {
		return false
	}
	if !s.sessionAllowed(r) {
		http.Error(w, "Login necessario", http.StatusUnauthorized)
		return false
	}
	return true
}
func jsonOut(w http.ResponseWriter, value interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	_ = json.NewEncoder(w).Encode(value)
}
func decodeJSON(r *http.Request) (json.RawMessage, error) {
	defer r.Body.Close()
	data, err := io.ReadAll(io.LimitReader(r.Body, configLimit+1))
	if err != nil {
		return nil, err
	}
	if len(data) > configLimit {
		return nil, errors.New("configuracao grande demais")
	}
	if len(data) == 0 || !json.Valid(data) || data[0] != '{' {
		return nil, errors.New("JSON invalido")
	}
	return data, nil
}
func writeAtomic(file string, data []byte) error {
	f, err := os.CreateTemp(filepath.Dir(file), "sete7-*.tmp")
	if err != nil {
		return err
	}
	tmp := f.Name()
	defer os.Remove(tmp)
	if _, err = f.Write(data); err != nil {
		f.Close()
		return err
	}
	if err = f.Sync(); err != nil {
		f.Close()
		return err
	}
	if err = f.Close(); err != nil {
		return err
	}
	return os.Rename(tmp, file)
}
func (s *service) profiles() []string {
	entries, _ := os.ReadDir(filepath.Join(s.dir, "profiles"))
	names := []string{"Default"}
	for _, e := range entries {
		if !e.IsDir() && strings.HasSuffix(e.Name(), ".json") {
			name := strings.TrimSuffix(e.Name(), ".json")
			if name != "Default" && validProfile.MatchString(name) {
				names = append(names, name)
			}
		}
	}
	sort.Strings(names[1:])
	return names
}
func (s *service) profilePath(name string) (string, error) {
	if !validProfile.MatchString(name) {
		return "", errors.New("nome de perfil invalido")
	}
	return filepath.Join(s.dir, "profiles", name+".json"), nil
}
func (s *service) handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /{$}", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Content-Security-Policy", "default-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'")
		b, _ := files.ReadFile("web/index.html")
		_, _ = w.Write(b)
	})
	mux.HandleFunc("GET /logo.png", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "image/png")
		w.Header().Set("Cache-Control", "public, max-age=86400")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		b, err := files.ReadFile("web/logo.png")
		if err != nil {
			http.NotFound(w, r)
			return
		}
		_, _ = w.Write(b)
	})
	mux.HandleFunc("/api/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/api/auth/status" || r.URL.Path == "/api/auth/login" {
			s.accessLogin(w, r)
			return
		}
		if !s.auth(w, r) {
			return
		}
		switch {
		case r.URL.Path == "/api/config" && r.Method == "GET":
			s.mu.Lock()
			cfg := append(json.RawMessage(nil), s.config...)
			s.mu.Unlock()
			jsonOut(w, map[string]interface{}{"config": cfg, "profiles": s.profiles(), "connected": false})
		case r.URL.Path == "/api/config" && r.Method == "PUT":
			b, err := decodeJSON(r)
			if err != nil {
				http.Error(w, err.Error(), 400)
				return
			}
			s.mu.Lock()
			err = writeAtomic(filepath.Join(s.dir, "config.json"), b)
			if err == nil {
				s.config = b
				applyNativeSettings(b)
			}
			s.mu.Unlock()
			if err != nil {
				http.Error(w, "Falha ao salvar", 500)
				return
			}
			jsonOut(w, map[string]bool{"saved": true})
		case r.URL.Path == "/api/keycapture" && r.Method == "POST":
			var input struct {
				Action string `json:"action"`
			}
			b, err := decodeJSON(r)
			if err != nil || json.Unmarshal(b, &input) != nil {
				http.Error(w, "Comando inválido", 400)
				return
			}
			switch input.Action {
			case "start":
				jsonOut(w, map[string]any{"ok": startNativeKeyCapture()})
			case "cancel":
				cancelNativeKeyCapture()
				jsonOut(w, map[string]any{"ok": true})
			default:
				http.Error(w, "Comando inválido", 400)
			}
		case r.URL.Path == "/api/keycapture" && r.Method == "GET":
			state, key := pollNativeKeyCapture()
			jsonOut(w, map[string]string{"state": state, "key": key})
		case r.URL.Path == "/api/window/drag" && r.Method == "POST":
			var input struct {
				Action string `json:"action"`
				DX     int32  `json:"dx"`
				DY     int32  `json:"dy"`
				Seq    uint64 `json:"seq"`
			}
			body, e := decodeJSON(r)
			if e != nil || json.Unmarshal(body, &input) != nil {
				http.Error(w, "Movimento inválido", http.StatusBadRequest)
				return
			}
			ok := dragOwnPanel(input.Action, input.DX, input.DY, input.Seq)
			jsonOut(w, map[string]bool{"ok": ok})
		case r.URL.Path == "/api/status" && r.Method == "GET":
			jsonOut(w, map[string]interface{}{"fivem": s.findFiveM(), "native": nativeStatus(), "mode": s.mode, "local": true})
		case r.URL.Path == "/api/tpwaypoint" && r.Method == "POST":
			var input struct {
				Z float32 `json:"z"`
			}
			body, e := decodeJSON(r)
			if e != nil || json.Unmarshal(body, &input) != nil {
				http.Error(w, "Altura inválida", http.StatusBadRequest)
				return
			}
			status, ok := tpWayAction(input.Z)
			jsonOut(w, map[string]interface{}{"ok": ok, "status": status})
		case r.URL.Path == "/api/player/position" && r.Method == "GET":
			pos, err := tpCurrentPosition()
			if err != nil {
				jsonOut(w, map[string]any{"ok": false, "status": err.Error()})
				break
			}
			jsonOut(w, map[string]any{"ok": true, "x": pos.X, "y": pos.Y, "z": pos.Z})
		case r.URL.Path == "/api/player/favorite" && r.Method == "POST":
			var input struct{ X, Y, Z float32 }
			body, e := decodeJSON(r)
			if e != nil || json.Unmarshal(body, &input) != nil {
				http.Error(w, "Destino inválido", 400)
				return
			}
			status, ok := tpFavoriteAction(vec3{X: input.X, Y: input.Y, Z: input.Z})
			jsonOut(w, map[string]any{"ok": ok, "status": status})
		case r.URL.Path == "/api/player/health" && r.Method == "POST":
			var input struct {
				HP float32 `json:"hp"`
			}
			body, e := decodeJSON(r)
			if e != nil || json.Unmarshal(body, &input) != nil {
				http.Error(w, "HP inválido", http.StatusBadRequest)
				return
			}
			status, ok := playerHealthAction(input.HP, false)
			jsonOut(w, map[string]any{"ok": ok, "status": status})
		case r.URL.Path == "/api/player/armor" && r.Method == "POST":
			var input struct {
				Armor float32 `json:"armor"`
			}
			body, e := decodeJSON(r)
			if e != nil || json.Unmarshal(body, &input) != nil {
				http.Error(w, "Armadura inválida", http.StatusBadRequest)
				return
			}
			status, ok := playerArmorAction(input.Armor)
			jsonOut(w, map[string]any{"ok": ok, "status": status})
		case r.URL.Path == "/api/player/revive" && r.Method == "POST":
			status, ok := reviveCityMenuAction()
			jsonOut(w, map[string]any{"ok": ok, "status": status})
		case r.URL.Path == "/api/vehicle/catalog" && r.Method == "GET":
			models, err := getPublicVehicleCatalogue()
			if err != nil {
				http.Error(w, "Não foi possível atualizar o catálogo público", http.StatusBadGateway)
				return
			}
			jsonOut(w, map[string]any{"models": models, "count": len(models), "source": "FAM Tools - GTA V vehicles"})
		case r.URL.Path == "/api/vehicle/lock" && r.Method == "POST":
			var input struct {
				VehicleID uint64 `json:"vehicleId"`
				Locked    bool   `json:"locked"`
				Command   string `json:"command"`
				Key       string `json:"key"`
			}
			body, err := decodeJSON(r)
			if err != nil || json.Unmarshal(body, &input) != nil {
				http.Error(w, "Veículo inválido", http.StatusBadRequest)
				return
			}
			var status string
			var ok bool
			if strings.TrimSpace(input.Command) == "" && strings.TrimSpace(input.Key) == "" {
				state := byte(1)
				if input.Locked {
					state = 2
				}
				status, ok = localVehicleLockAttempt(input.VehicleID, state)
			} else {
				status, ok = vehicleLockActionForID(input.VehicleID, input.Locked, input.Command, input.Key)
			}
			jsonOut(w, map[string]any{"ok": ok, "status": status})
		case r.URL.Path == "/api/fixcar" && r.Method == "POST":
			var input struct {
				VehicleID uint64 `json:"vehicleId"`
				Command   string `json:"command"`
			}
			if r.ContentLength > 0 {
				body, err := decodeJSON(r)
				if err != nil || json.Unmarshal(body, &input) != nil {
					http.Error(w, "Veículo inválido", http.StatusBadRequest)
					return
				}
			}
			var status string
			var ok bool
			if strings.TrimSpace(input.Command) != "" {
				status, ok = vehicleRepairViaCityCommand(input.Command)
			} else {
				status, ok = fixVehicleActionForID(input.VehicleID)
			}
			jsonOut(w, map[string]interface{}{"ok": ok, "status": status})
		case r.URL.Path == "/api/profile" && r.Method == "POST":
			var input struct {
				Name   string          `json:"name"`
				Config json.RawMessage `json:"config"`
			}
			b, err := decodeJSON(r)
			if err != nil || json.Unmarshal(b, &input) != nil || !json.Valid(input.Config) {
				http.Error(w, "JSON invalido", 400)
				return
			}
			path, err := s.profilePath(input.Name)
			if err != nil {
				http.Error(w, "Nome invalido", 400)
				return
			}
			if err = os.MkdirAll(filepath.Dir(path), 0700); err == nil {
				err = writeAtomic(path, input.Config)
			}
			if err != nil {
				http.Error(w, "Falha ao salvar", 500)
				return
			}
			jsonOut(w, map[string]bool{"saved": true})
		case r.URL.Path == "/api/profile" && r.Method == "GET":
			path, err := s.profilePath(r.URL.Query().Get("name"))
			if err != nil {
				http.Error(w, "Nome invalido", 400)
				return
			}
			b, err := os.ReadFile(path)
			if err != nil || !json.Valid(b) {
				http.Error(w, "Perfil nao encontrado", 404)
				return
			}
			jsonOut(w, map[string]interface{}{"config": json.RawMessage(b)})
		case r.URL.Path == "/api/unload" && r.Method == "POST":
			jsonOut(w, map[string]interface{}{"closing": true, "mode": "unload"})
			go s.finish(false)
		case r.URL.Path == "/api/cleaner" && r.Method == "POST":
			// The click itself authorizes the clean. Authentication and
			// localhost origin checking still apply to this endpoint.
			jsonOut(w, map[string]interface{}{
				"closing": true, "mode": "cleaner", "scope": "executavel atual e dados temporarios do 77",
			})
			go s.finish(true)
		default:
			http.Error(w, "Rota indisponivel", 404)
		}
	})
	return mux
}

// diagnosticEvent records lifecycle information only. It never logs game memory,
// credentials, the local session key, or external application data.
func (s *service) diagnosticEvent(event string) {
	writeCrashRecord("lifecycle", event)
	f, err := os.OpenFile(filepath.Join(s.dir, "diagnostics.log"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0600)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = fmt.Fprintf(f, "%s %s\n", time.Now().Format(time.RFC3339), event)
}

// finish unloads the local UI server. The disposable profile is cleaned
// after Chromium has exited. Cleaner deletes only the current executable
// and its own temporary session, never unrelated files or Windows logs.
func (s *service) finish(clean bool) {
	if !s.stopping.CompareAndSwap(false, true) {
		return
	}
	s.diagnosticEvent("user_requested_shutdown")
	weaponShutdown()                   // restore local weapon fields on termination
	throughWallShutdown()              // clear unsupported Through Wall request
	silentShutdown()                   // restore patched game instructions before UI exit
	time.Sleep(250 * time.Millisecond) // allow the HTTP response to reach the UI
	closeOwnWindow()
	if clean {
		// Stop only browser processes launched by this session before removing
		// their disposable profile. The deferred cleanup in run() is a second
		// safety pass for errors and ordinary Unload.
		stopSessionBrowsers()
		_ = cleanSessionFiles()
		// Recover only verified, old, inactive 77 sessions from earlier crashes.
		// Never remove generic user Temp files or files belonging to other apps.
		_ = cleanAbandonedOwnedSessions(os.TempDir(), sessionDataPath, time.Now())
		_ = os.Remove(filepath.Join(os.TempDir(), "77-diagnostics.log"))
		// The EXE stays locked until this process exits; a short-lived system
		// helper verifies the specific file is absent before finishing.
		if managedDLLMode() {
			// DLL mode must not remove its own host while code is still loaded.
			// The host receives a special return code and can delegate verified
			// uninstall to its trusted installer after the process exits.
			markManagedCleanup()
		} else {
			_ = deleteOwnExecutableAfterExit()
		}
	}
	// Shutdown LAST; Serve() returns and the process exits after this call.
	if s.server != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		_ = s.server.Shutdown(ctx)
		cancel()
	}
}

func isFiveMProcess(name string) bool {
	name = strings.ToLower(name)
	return strings.Contains(name, "fivem") || strings.HasPrefix(name, "gta5") || strings.Contains(name, "gtaprocess")
}

func (s *service) findFiveM() bool {
	s.mu.Lock()
	if time.Since(s.lastScan) < 2*time.Second {
		r := s.lastSeen
		s.mu.Unlock()
		return r
	}
	s.lastScan = time.Now()
	s.mu.Unlock()
	// Enumerate processes through the Windows API. Do not launch tasklist.exe:
	// a console subprocess would flash on screen every status refresh.
	found := detectFiveMProcess()
	s.mu.Lock()
	s.lastSeen = found
	s.mu.Unlock()
	return found
}
func run() error {
	// Even abnormal HTTP shutdown should not leave a versioned data folder.
	defer func() {
		closeOwnWindow()
		stopSessionBrowsers()
		_ = cleanSessionFiles()
	}()
	s, err := newService(dataFolder())
	if err != nil {
		return err
	}
	listener, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		return err
	}
	url := fmt.Sprintf("http://%s/?key=%s", listener.Addr().String(), s.key)
	s.uiURL = url
	s.diagnosticEvent("service_started_v13.9.66_hidden")
	defer func() {
		if s.stopping.Load() {
			writeCrashRecord("service", "exit_after_unload_or_cleaner")
		} else {
			writeCrashRecord("service", "run_returned_without_explicit_unload")
		}
	}()
	s.server = &http.Server{Handler: s.handler(), ReadHeaderTimeout: 3 * time.Second}
	// GUI binary has no attached console; never print URLs containing session keys.
	// A native tool-window hosts the browser content. Chromium's app-mode
	// chrome is clipped inside it; INSERT toggles only the native host.
	// Never spawn Chromium on the desktop. The native host and overlay are
	// created hidden; the browser starts only after INSERT in foreground FiveM.
	menuWanted.Store(false)
	startNativeMenuHost()
	// Native draw loop and real, read-only experimental entity scanner.
	startOverlay()
	// Refresh GTA V stock model names in the background, without a UI click.
	// The existing built-in names remain available if offline.
	go func() { _ = updatePublicVehicleNames() }()
	go scanReadableLocalVehicleMetas()
	startESPReader()
	startAimAssist()
	startTriggerbot()
	startAutoVitals()
	startGodHotkey(s)
	startNoclip()
	startVehicleFixHotkey()
	// Standalone: no FiveM resource/loopback bridge listener.
	startLocalAutoUnlock()
	startThroughWall()
	startExternalLineReader()
	startWeaponControl()
	startMagicHotkey(s)
	startSilentAim()
	defer weaponShutdown()
	defer throughWallShutdown()
	defer silentShutdown()
	// Shutting the menu window also stops our local process.
	go guardedEssentialWorker("menu-monitor", func() { monitorOwnWindow(s) })
	// The optional INSERT shortcut only changes the window visibility.
	// It never hides this process from Windows or security tools.
	go guardedEssentialWorker("insert-shortcut", func() { runWindowShortcut(s) })
	go guardedEssentialWorker("liveness", func() { monitorServiceLiveness(s) })
	// Warm up the isolated browser only once FiveM is running. The native
	// host remains hidden and INSERT is still required to show the panel.
	// This removes the Chromium cold start from the first INSERT in most cases.
	go prewarmMenuBrowser(s)
	return serveLocalWithRecovery(s, listener)
}

// The menu URL stays unchanged after recovering from an unexpected listener
// closure. A deliberate Unload/Cleaner always stops the service normally.
func serveLocalWithRecovery(s *service, listener net.Listener) error {
	const maxRecoveryAttempts = 4
	address := listener.Addr().String()
	for attempt := 0; ; attempt++ {
		err := s.server.Serve(listener)
		if s.stopping.Load() {
			return nil
		}
		writeCrashRecord("http-server", fmt.Sprintf("unexpected listener stop: %v", err))
		if attempt >= maxRecoveryAttempts {
			return fmt.Errorf("servidor local indisponivel apos %d tentativas: %w", attempt, err)
		}
		// Rebind the *same* random localhost address so the already-running
		// embedded browser continues using the same session and URL.
		time.Sleep(time.Duration(attempt+1) * 250 * time.Millisecond)
		var reopenErr error
		listener, reopenErr = net.Listen("tcp4", address)
		if reopenErr != nil {
			writeCrashRecord("http-server", "retry failed to listen on same localhost address: "+reopenErr.Error())
			return fmt.Errorf("servidor local sem porta disponivel: %w", reopenErr)
		}
		s.server = &http.Server{Handler: s.handler(), ReadHeaderTimeout: 3 * time.Second}
		s.diagnosticEvent("http_listener_restored_without_restarting_panel")
	}
}
func main() {
	if err := run(); err != nil {
		writeCrashRecord("main", fmt.Sprintf("run error: %v", err))
		showStartupError("sete7: " + err.Error())
	}
}
