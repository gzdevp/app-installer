//go:build windows

package main

import (
	"fmt"
	"sync"
	"time"
)

// This worker accesses the FiveM process READ-ONLY through the ESP reader.
// It neither injects Lua/DDL nor loads any FiveM resource. In particular it
// does NOT generate bullets, bypass collision or apply damage.
var throughWallExternalLine = struct {
	sync.RWMutex
	ray     externalAimRay
	pid     uint32
	ready   bool
	status  string
	updated time.Time
}{status: "Sem leitura da câmera"}

func readExternalLineState() map[string]any {
	throughWallExternalLine.RLock()
	defer throughWallExternalLine.RUnlock()
	fresh := throughWallExternalLine.ready && time.Since(throughWallExternalLine.updated) < 600*time.Millisecond
	if !fresh {
		return map[string]any{"valid": false, "status": throughWallExternalLine.status}
	}
	r := throughWallExternalLine.ray
	return map[string]any{
		"valid": true, "status": "Reta da câmera lida externamente; SEM colisão ou disparo",
		"pid": throughWallExternalLine.pid, "range": r.Meters,
		"origin":    [3]float64{r.Origin.X, r.Origin.Y, r.Origin.Z},
		"direction": [3]float64{r.Direction.X, r.Direction.Y, r.Direction.Z},
		"end":       [3]float64{r.End.X, r.End.Y, r.End.Z},
	}
}

func setExternalLineState(status string, pid uint32, ray externalAimRay, ready bool) {
	throughWallExternalLine.Lock()
	throughWallExternalLine.status = status
	throughWallExternalLine.pid = pid
	throughWallExternalLine.ray = ray
	throughWallExternalLine.ready = ready
	throughWallExternalLine.updated = time.Now()
	throughWallExternalLine.Unlock()
}

func readExternalLocalPedPosition(p *attachedESP) (vec3, bool) {
	if p == nil || espProcessExited(p.handle) {
		return vec3{}, false
	}
	layout, ok := espLayouts[p.build]
	if !ok {
		return vec3{}, false
	}
	world := p.ptr(p.base + layout.world)
	if world == 0 {
		return vec3{}, false
	}
	ped := p.ptr(world + 0x8)
	if ped == 0 {
		return vec3{}, false
	}
	pos, ok := p.vec3(ped + 0x90)
	return pos, ok && plausibleFiveMPosition(pos)
}

func startExternalLineReader() {
	go func() {
		defer recoverServiceWorker("throughwall_trajectory_windows.go")
		ticker := time.NewTicker(150 * time.Millisecond)
		defer ticker.Stop()
		var p *attachedESP
		lastTry := time.Time{}
		detach := func() {
			if p != nil {
				closeESP(p.handle)
				p = nil
			}
		}
		defer detach()
		for range ticker.C {
			if throughWallStopping.Load() {
				return
			}
			throughWallControl.RLock()
			active := throughWallControl.enabled && throughWallControl.held
			throughWallControl.RUnlock()
			if !active || overlayPaused.Load() {
				detach()
				setExternalLineState("Aguardando tecla HOLD", 0, externalAimRay{}, false)
				continue
			}
			if p != nil && (espProcessExited(p.handle) || !fiveMIsForeground(p.pid)) {
				detach()
			}
			if p == nil {
				if time.Since(lastTry) < 900*time.Millisecond {
					continue
				}
				lastTry = time.Now()
				var err error
				p, _, _, err = findESP()
				if err != nil {
					setExternalLineState("Leitor externo: "+err.Error(), 0, externalAimRay{}, false)
					continue
				}
			}
			if !fiveMIsForeground(p.pid) {
				detach()
				continue
			}
			local, ok := readExternalLocalPedPosition(p)
			if !ok {
				setExternalLineState("Posição local não validada", p.pid, externalAimRay{}, false)
				continue
			}
			cam, err := readV13Camera(p, local)
			if err != nil {
				setExternalLineState(err.Error(), p.pid, externalAimRay{}, false)
				continue
			}
			ray, err := computeExternalAimRay(v13FromVec(cam.eye), v13FromVec(cam.view), 250)
			if err != nil {
				setExternalLineState("Direção: "+err.Error(), p.pid, externalAimRay{}, false)
				continue
			}
			setExternalLineState(fmt.Sprintf("Reta externa: %.0f m, sem disparo", ray.Meters), p.pid, ray, true)
		}
	}()
}
