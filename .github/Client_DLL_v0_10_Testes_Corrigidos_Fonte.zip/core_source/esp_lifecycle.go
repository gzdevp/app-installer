//go:build windows

package main

import "time"

// espAttachmentTracker keeps a reader attached during short game-window
// transitions, but forces a clean reattach when the game exits or its window
// remains absent. The state machine is process-independent and unit tested.
type espAttachmentTracker struct {
	windowMissingSince time.Time
}

const espWindowGrace = 12 * time.Second

func (t *espAttachmentTracker) reset() {
	t.windowMissingSince = time.Time{}
}

// detach is true when an existing attachment must be closed.  A temporarily
// hidden/minimized FiveM window isn't evidence of a crashed process.
func (t *espAttachmentTracker) detach(now time.Time, processExited, windowFound bool) bool {
	if processExited {
		t.reset()
		return true
	}
	if windowFound {
		t.reset()
		return false
	}
	if t.windowMissingSince.IsZero() {
		t.windowMissingSince = now
		return false
	}
	if now.Sub(t.windowMissingSince) >= espWindowGrace {
		t.reset()
		return true
	}
	return false
}

// Windows WaitForSingleObject result values. Only WAIT_OBJECT_0 proves that
// the process was signalled; WAIT_FAILED must not detach a live game.
const (
	espWaitObject0 = uintptr(0x00000000)
	espWaitTimeout = uintptr(0x00000102)
	espWaitFailed  = uintptr(0xFFFFFFFF)
)

func espWaitReportsExit(result uintptr) bool {
	return result == espWaitObject0
}
