# 77 Black Edition 13.9.42 — Clean UI

- Toda nova execução do EXE começa com os switches desligados, incluindo Stream Mode, ESP, Weapons, Aimbot, Triggerbot e Vehicles.
- A inicialização não restaura config.json antigo, perfis ou configurações guardadas no localStorage do navegador.
- Configurações feitas durante a sessão continuam sendo aplicadas ao backend local; o EXE não recupera a sessão no próximo início.
- Stream Mode em Settings > Interface: somente toggle.
- Friends: apenas cor, nome, lista de amigos e jogadores detectados; informações, textos de diagnóstico e mensagens vazias removidos.
- Weapons: somente as quatro opções, sem relatórios.
- Informações e status técnicos foram retirados da interface, preservando diagnósticos no núcleo.
- Vehicles: UI simplificada; removidos controles de trancar/destrancar sem implementação e avisos; leitura da lista de carros antecipada para não depender do sucesso de leitura da lista de jogadores.
- JACK 77, Insert e binds existentes preservados.
- A execução real das ações de Vehicles no FiveM não foi validada neste ambiente.
