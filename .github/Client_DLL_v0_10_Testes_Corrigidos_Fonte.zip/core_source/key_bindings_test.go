package main

import "testing"

func TestCaptureBindingsVK(t *testing.T) {
	for _, row := range []struct {
		key string
		vk  uintptr
	}{
		{"a", 0x41}, {"z", 0x5a}, {"0", 0x30}, {"9", 0x39},
		{"f1", 0x70}, {"f2", 0x71}, {"f7", 0x76}, {"f12", 0x7b},
		{"mouse1", 1}, {"mouse2", 2}, {"mouse3", 4}, {"mouse4", 5}, {"mouse5", 6},
		{"shift", 0x10}, {"ctrl", 0x11}, {"alt", 0x12}, {"space", 0x20},
		{"enter", 0x0D}, {"tab", 0x09}, {"backspace", 0x08}, {"delete", 0x2E},
		{"up", 0x26}, {"left", 0x25}, {"pageup", 0x21}, {"num0", 0x60}, {"num9", 0x69},
		{"numadd", 0x6B}, {"numdecimal", 0x6E},
	} {
		if !validBindingKey(row.key) || genericKeyVK(row.key, 0) != row.vk {
			t.Errorf("%s: got %d want %d", row.key, genericKeyVK(row.key, 0), row.vk)
		}
	}
	for _, key := range []string{"insert", "escape", "f6", "f13", "", "ctrl+shift", "something"} {
		if validBindingKey(key) {
			t.Errorf("should reject %q", key)
		}
	}
}
