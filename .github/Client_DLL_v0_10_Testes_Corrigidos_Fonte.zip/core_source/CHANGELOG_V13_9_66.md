# 77 v13.9.66 — Veículos e nomes do ESP

- Catálogo expandido com 114 identificadores stock GTA V ausentes das listas anteriores, calculados a partir de nomes de spawn via JOAAT.
- Hash desconhecido não vira um nome inventado. Exibimos "Veículo personalizado" e mantemos seu hash no painel de detalhes.
- Mapeamento manual e temporário de nome por hash na aba **World → Vehicles** para veículos personalizados ou renomeados pelas cidades.
- Aplica o mapeamento tanto à listagem quanto aos rótulos do overlay. O mapeamento faz parte da configuração atual; não é informação descoberta automaticamente do jogo.
- Leitura de nome de CPlayerInfo agora tenta tamanhos de buffer menores (até 16 bytes) em páginas parcialmente legíveis, sem varredura de endereços desconhecidos.
- Contadores de diagnóstico `namesResolved` e `namesMissing` foram adicionados à leitura do ESP.
- Preservados: Insert, login, Cleaner e limites de renderização do ESP.

**Limitações:** nomes de personagens RP definidos apenas pelo servidor não são necessariamente acessíveis por um aplicativo externo; o código não inventa nomes. Hash de veículos customizados também não revela marca/modelo real sem uma tabela do servidor ou apelido fornecido pelo usuário.

**Validação:** `GOOS=windows go build`, `GOOS=windows go vet`, testes unitários Go dos leitores/mapeamentos e sintaxe JavaScript; teste em FiveM real ainda não executado.
