package main

import "math"

type vec3 struct{ X, Y, Z float32 }
type matrix44 [16]float32

// worldToScreen returns false for positions outside the actual game viewport.
// In v6 this returned true for points as far as one entire screen beyond its
// edges, leaving text clipped to the top edge of the desktop overlay.
func worldToScreen(m matrix44, v vec3, width, height int32) (float64, float64, bool) {
	if width <= 0 || height <= 0 || !plausibleFiveMPosition(v) {
		return 0, 0, false
	}
	for _, coefficient := range m {
		if math.IsNaN(float64(coefficient)) || math.IsInf(float64(coefficient), 0) {
			return 0, 0, false
		}
	}
	// Matches transposed D3D viewport matrix (clip x uses row 1, y row 2, depth row 3).
	x := float64(m[1]*v.X + m[5]*v.Y + m[9]*v.Z + m[13])
	y := float64(m[2]*v.X + m[6]*v.Y + m[10]*v.Z + m[14])
	z := float64(m[3]*v.X + m[7]*v.Y + m[11]*v.Z + m[15])
	if z <= 0.1 || math.IsInf(z, 0) || math.IsNaN(z) {
		return 0, 0, false
	}
	sx := float64(width) * (.5 + x/z*.5)
	sy := float64(height) * (.5 - y/z*.5)
	return sx, sy, !math.IsNaN(sx) && !math.IsNaN(sy) && !math.IsInf(sx, 0) && !math.IsInf(sy, 0) && sx >= 0 && sx <= float64(width) && sy >= 0 && sy <= float64(height)
}

// Rejects labels in the sky, reversed head/feet projections, boxes
// partially outside the game window and implausibly small targets.
func espBox(topX, topY, bottomX, bottomY float64, width, height int32, vehicle bool) (int32, int32, int32, int32, bool) {
	if width < 320 || height < 240 || math.IsNaN(topY) || math.IsNaN(bottomY) {
		return 0, 0, 0, 0, false
	}
	h := bottomY - topY
	// Distant people may occupy only 2-7px. A 500m option must not use the previous 8px minimum.
	if h < 2 || h > float64(height)*0.9 || math.Abs(topX-bottomX) > math.Max(h*1.2, 10) {
		return 0, 0, 0, 0, false
	}
	w := math.Max(2, h*.48)
	if vehicle {
		w = math.Max(3, h*1.4)
	}
	x := int32(math.Round((topX + bottomX - w) / 2))
	y := int32(math.Round(topY))
	// No forced labels at the top edge; reject projections that do not fit the client.
	if x < 0 || y < 14 || x+int32(math.Ceil(w)) > width || y+int32(math.Ceil(h)) > height {
		return 0, 0, 0, 0, false
	}
	return x, y, int32(math.Ceil(w)), int32(math.Ceil(h)), true
}

// Broad GTA V playable/world bounds: an anti-corruption sanity filter, not a
// visibility test. In particular, nonsense pointers should not create overlays
// at arbitrary sky coordinates. These boundaries are intentionally generous.
func plausibleFiveMPosition(v vec3) bool {
	for _, n := range [...]float32{v.X, v.Y, v.Z} {
		if math.IsNaN(float64(n)) || math.IsInf(float64(n), 0) {
			return false
		}
	}
	return math.Abs(float64(v.X)) <= 20000 && math.Abs(float64(v.Y)) <= 20000 && v.Z >= -2000 && v.Z <= 10000
}

// headWorldHeightCompatible preserves the historical guard for unverified
// bone readers. The C++ reader independently verifies three anatomically
// ordered joints (head, neck and pelvis), so the ped origin is not a reliable
// foot-height reference and may be above the pelvis on some streamed models.
// The screen-space head/box anchor must STILL pass before selection.
func headWorldHeightCompatible(headZ, pedZ float32, cppAnatomyVerified bool) bool {
	if !poseFinite(headZ) || !poseFinite(pedZ) {
		return false
	}
	return cppAnatomyVerified || headZ > pedZ+0.75
}

// headAnchorInsidePlayer checks the spatial relation between the authentic
// joint projection and the body projection from the very same camera frame.
// A joint offset from an incompatible bone table can otherwise be plausible
// world data while pointing aim assist at a torso or below the player.
// Rejecting an uncertain head is safer than moving the cursor toward it.
func headAnchorInsidePlayer(headX, headY, boxX, boxY, boxW, boxH int32) bool {
	if boxW < 2 || boxH < 5 || headX < 0 || headY < 0 {
		return false
	}
	midX := float64(boxX) + float64(boxW)/2
	xTolerance := math.Max(5, float64(boxW)*0.72)
	upperMargin := math.Max(5, float64(boxH)*0.4)
	lowerMargin := math.Max(3, float64(boxH)*0.32)
	return math.Abs(float64(headX)-midX) <= xTolerance &&
		float64(headY) >= float64(boxY)-upperMargin &&
		float64(headY) <= float64(boxY)+lowerMargin
}

// alignPlayerBoxToBones uses the same projected joint snapshot that paints
// the skeleton. The old fixed 1.9m body projection can be displaced on
// streamed peds (the ped origin is not guaranteed to be at either foot).
// Keep the joint coordinates unchanged; move only the rectangle derived from
// them. All text, bars and snaplines are painted relative to that rectangle.
// If the joint snapshot covers only an upper torso, keep the original height
// but anchor its top on the authentic skull, instead of truncating at the hip.
func alignPlayerBoxToBones(fallback targetESP, bones [][4]int32, skull [2]int32, viewportW, viewportH int32) (targetESP, bool) {
	if len(bones) < 3 || fallback.W < 2 || fallback.H < 5 || viewportW <= 0 || viewportH <= 0 {
		return fallback, false
	}
	minX, minY := int32(math.MaxInt32), int32(math.MaxInt32)
	maxX, maxY := int32(math.MinInt32), int32(math.MinInt32)
	for _, seg := range bones {
		for _, pt := range [][2]int32{{seg[0], seg[1]}, {seg[2], seg[3]}} {
			if pt[0] < 0 || pt[0] > viewportW || pt[1] < 0 || pt[1] > viewportH {
				return fallback, false
			}
			if pt[0] < minX {
				minX = pt[0]
			}
			if pt[0] > maxX {
				maxX = pt[0]
			}
			if pt[1] < minY {
				minY = pt[1]
			}
			if pt[1] > maxY {
				maxY = pt[1]
			}
		}
	}
	if skull[0] < 0 || skull[0] > viewportW || skull[1] < 0 || skull[1] > viewportH {
		return fallback, false
	}
	if minY >= maxY || minX > maxX {
		return fallback, false
	}

	result := fallback
	skeletonHeight := maxY - minY
	// An authentic nine-joint pose produces up to eight segments including
	// both feet. A partial older-build chain has only upper body landmarks.
	complete := len(bones) >= 7 && float64(skeletonHeight) >= 0.63*float64(fallback.H)
	if complete {
		padTop := int32(math.Max(1, math.Round(float64(skeletonHeight)*0.04)))
		padBottom := int32(math.Max(1, math.Round(float64(skeletonHeight)*0.025)))
		top := minY - padTop
		bottom := maxY + padBottom
		bodyHeight := bottom - top
		padSide := int32(math.Max(2, math.Round(float64(bodyHeight)*0.05)))
		naturalW := int32(math.Ceil(float64(bodyHeight) * 0.46))
		// A raised or stretched arm must remain inside the player's box.
		left := minX - padSide
		right := maxX + padSide
		centeredLeft := skull[0] - naturalW/2
		centeredRight := centeredLeft + naturalW
		if centeredLeft < left {
			left = centeredLeft
		}
		if centeredRight > right {
			right = centeredRight
		}
		result.X, result.Y, result.W, result.H = left, top, right-left, bodyHeight
	} else {
		// Use the skull as the vertical anchor when one or both feet did not
		// project in the bone stream; do not substitute a fake skeleton.
		result.X = skull[0] - fallback.W/2
		result.Y = skull[1] - int32(math.Round(float64(fallback.H)*0.10))
	}
	if result.X < 0 || result.Y < 14 || result.W < 2 || result.H < 5 ||
		result.X+result.W > viewportW || result.Y+result.H > viewportH ||
		result.W > viewportW/2 || result.H > viewportH*9/10 {
		return fallback, false
	}
	return result, true
}
