# 77 Black Edition v13.9.53 — Cleaner

- Mantém Cleaner de um clique, encerramento dos processos próprios, perfil isolado e autoexclusão do EXE.
- Também remove arquivos temporários simples (.tmp/.temp) com mais de 14 dias, somente do diretório padrão `%LOCALAPPDATA%\Temp`, sem entrar em subpastas.
- Arquivos recentes, logs, Prefetch, histórico do Windows, arquivos do FiveM, Event Viewer e pastas de outros aplicativos são preservados.
- Sem função de otimização, sem confirmação ou interface adicional.
