# sete7 v13.9.70 — Estabilidade (base preservada)

Somente melhorias de ciclo de vida e recuperação de interface.

- Reconhece janelas recém-criadas do navegador privado mesmo quando ainda não têm título.
- Evita ocultar o painel em transições breves de foco para o Chromium pertencente à própria sessão.
- Se o navegador desaparecer, tenta restabelecer a interface enquanto o FiveM estiver aberto/recente, sem exigir outro INSERT.
- Detecta janelas nativas destruídas que ainda estavam referenciadas por identificadores inválidos.
- Não permite que uma janela antiga apague o identificador da janela de reposição.
- Se o servidor HTTP local parar inesperadamente, tenta reabrir a mesma porta preservando a sessão.
- Ações de tecla/chat do veículo devolvem o menu ao estado anterior após enviar o comando (antes ficava oculto).
- Não modifica as rotinas de ESP, Friends, Aimbot, Silent, FIX CAR ou Unlock All.

**Limites:** Não evita encerramento pelo antivírus/Windows, falta de memória,
queda do jogo ou falhas nativas do Chromium. Estabilidade em jogo não verificada;
compilação e testes automatizados realizados fora do Windows.
