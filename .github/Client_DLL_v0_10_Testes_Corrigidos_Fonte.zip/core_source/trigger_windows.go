//go:build windows

package main

import (
	"sync"
	"time"
)

var triggerController = struct {
	sync.RWMutex
	Settings TriggerSettings
	Status   string
	Shots    uint64
	Active   bool
}{Settings: normalizeTrigger(TriggerSettings{Key: "mouse5", Delay: 45, Range: 250, Radius: 9, Bone: "body", TargetNPC: true}), Status: "Desativado"}

func triggerSet(s TriggerSettings) {
	s = normalizeTrigger(s)
	triggerController.Lock()
	triggerController.Settings = s
	if !s.Enabled {
		triggerController.Status = "Desativado"
		triggerController.Active = false
	}
	triggerController.Unlock()
}

// Snapshot the trigger request atomically for the shared ESP scanner.
// Unlike the visual ESP, the trigger must request its own NPCs and distance.
func triggerScanSettings() TriggerSettings {
	triggerController.RLock()
	defer triggerController.RUnlock()
	return triggerController.Settings
}

func triggerEnabled() bool {
	triggerController.RLock()
	defer triggerController.RUnlock()
	return triggerController.Settings.Enabled
}
func triggerGet() map[string]any {
	triggerController.RLock()
	defer triggerController.RUnlock()
	return map[string]any{"status": triggerController.Status, "shots": triggerController.Shots, "active": triggerController.Active, "settings": triggerController.Settings}
}
func triggerReport(status string, shot bool) {
	triggerController.Lock()
	triggerController.Status = status
	if shot {
		triggerController.Shots++
	}
	triggerController.Unlock()
}
func startTriggerbot() {
	go func() {
        defer recoverServiceWorker("trigger_windows.go")
		ticker := time.NewTicker(12 * time.Millisecond)
		defer ticker.Stop()
		var wasPressed, armed bool
		var armedSince, timeLast time.Time
		for range ticker.C {
			triggerController.RLock()
			setting := triggerController.Settings
			triggerController.RUnlock()
			if !setting.Enabled {
				armed, wasPressed = false, false
				triggerController.Lock()
				triggerController.Active = false
				triggerController.Unlock()
				continue
			}
			if overlayPaused.Load() || menuWanted.Load() {
				wasPressed = false
				continue
			}
			view, targets, _ := espRendered.snapshot(110 * time.Millisecond)
			if view.PID == 0 || view.W < 320 || view.H < 240 || !view.CameraValid || !fiveMIsForeground(view.PID) {
				wasPressed = false
				triggerReport("Aguardando FiveM em foco", false)
				continue
			}
			key := genericKeyVK(setting.Key, 0x06)
			pressed, _, _ := getAsyncKeyState.Call(key)
			down := pressed&0x8000 != 0
			if down && !wasPressed {
				armed = !armed
				armedSince = time.Now()
				triggerController.Lock()
				triggerController.Active = armed
				triggerController.Unlock()
			}
			wasPressed = down
			if !armed {
				triggerReport("Desativado pela bind", false)
				continue
			}
			if time.Since(armedSince) < time.Duration(setting.Delay)*time.Millisecond {
				continue
			}
			if time.Since(timeLast) < 110*time.Millisecond {
				continue
			}
			// Do not interfere with an existing manually held left click.
			left, _, _ := getAsyncKeyState.Call(0x01)
			if left&0x8000 != 0 {
				triggerReport("Mouse 1 em uso", false)
				continue
			}
			selected := false
			for _, t := range targets {
				if triggerCandidate(view.W/2, view.H/2, t, setting) {
					selected = true
					break
				}
			}
			if !selected {
				triggerReport("Sem alvo validado sob a mira", false)
				continue
			}
			// Fail closed if foreground changed while target selection occurred.
			if !fiveMIsForeground(view.PID) {
				continue
			}
			if !reviveCitySendClick(reviveCityMouseDown) {
				triggerReport("Falha ao pressionar mouse", false)
				continue
			}
			time.Sleep(12 * time.Millisecond)
			releaseOK := reviveCitySendClick(reviveCityMouseUp)
			timeLast = time.Now()
			if !releaseOK {
				triggerReport("Falha ao soltar mouse", false)
				continue
			}
			triggerReport("Disparo enviado; acerto depende do jogo/servidor", true)
		}
	}()
}
