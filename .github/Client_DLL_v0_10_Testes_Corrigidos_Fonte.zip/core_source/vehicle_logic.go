package main

import "math"

// Vehicle offsets supplied as experimental examples: never write unless the
// local vehicle, proximity and all three source values are validated.
type vehicleHealthValues struct{ Engine, Body, Tank float32 }

func vehicleHealthPlausible(v vehicleHealthValues) bool {
	okay := func(x float32, lo, hi float64) bool {
		f := float64(x)
		return !math.IsInf(f, 0) && !math.IsNaN(f) && f >= lo && f <= hi
	}
	if !okay(v.Engine, -4000, 1000) || !okay(v.Body, 0, 1000) || !okay(v.Tank, -4000, 1000) {
		return false
	}
	return !(v.Engine == 0 && v.Body == 0 && v.Tank == 0)
}
func vehicleCloseEnough(distance float64) bool {
	return !math.IsNaN(distance) && !math.IsInf(distance, 0) && distance <= 8 && distance >= 0
}
func penetrationPlausible(v float32) bool {
	f := float64(v)
	return !math.IsNaN(f) && !math.IsInf(f, 0) && f >= 0 && f <= 10
}

// A selected vehicle may be repaired only if it is the local player's car.
// Requested ID zero is reserved for the legacy F6 local-only shortcut.
func vehicleRepairTargetMatches(local, requested uint64) bool {
	return local != 0 && (requested == 0 || requested == local)
}
