//go:build windows

package main

import (
	"math"
	"testing"
	"time"
)

func cameraTestView(eye, forward vec3) matrix44 {
	f, _ := unitVector(forward)
	right, _ := unitVector(vec3{-f.Y, f.X, 0})
	up := vec3{f.Y*right.Z - f.Z*right.Y, f.Z*right.X - f.X*right.Z, f.X*right.Y - f.Y*right.X}
	m := matrix44{}
	m[1], m[5], m[9] = right.X, right.Y, right.Z
	m[2], m[6], m[10] = up.X, up.Y, up.Z
	m[3], m[7], m[11] = f.X, f.Y, f.Z
	m[13] = -dotTest(eye, right)
	m[14] = -dotTest(eye, up)
	m[15] = -dotTest(eye, f)
	return m
}
func dotTest(a, b vec3) float32 { return a.X*b.X + a.Y*b.Y + a.Z*b.Z }
func TestCameraVectorSteersTowardHeadIn3D(t *testing.T) {
	eye := vec3{X: 5, Y: 6, Z: 2}
	targets := []vec3{{25, 6, 7}, {25, 6, -3}, {25, 11, 2}, {25, 1, 2}, {25, 12, 7}, {25, 0, -3}}
	for _, head := range targets {
		current := vec3{1, 0, 0}
		direction, want := directionToHead(eye, head)
		if !want {
			t.Fatal("test target invalid", head)
		}
		beforeDot := dotVectors(current, direction)
		next, ok := cameraDirectionStep(eye, head, current, 10)
		if !ok || dotVectors(next, direction) <= beforeDot || math.Abs(vectorLength(next)-1) > .001 {
			t.Fatalf("step did not approach head %+v -> %+v", head, next)
		}
		if math.Acos(math.Max(-1, math.Min(1, dotVectors(current, next)))) > 4.01*math.Pi/180 {
			t.Fatal("max turn exceeded")
		}
		if !cameraMatchesProjection(current, cameraTestView(eye, current)) {
			t.Fatal("projection mismatch")
		}
		if cameraMatchesProjection(vec3{-1, 0, 0}, cameraTestView(eye, current)) {
			t.Fatal("accepted opposite camera")
		}
	}
}
func TestCameraVectorConvergesWithoutFloorRunaway(t *testing.T) {
	eye := vec3{1, 1, 1}
	head := vec3{41, 5, 9}
	current := vec3{1, 0, 0}
	desired, ok := directionToHead(eye, head)
	if !ok {
		t.Fatal("target invalid")
	}
	oldErr := math.Inf(1)
	for i := 0; i < 70; i++ {
		view := cameraTestView(eye, current)
		x, y, valid := worldToScreen(view, head, 1920, 1080)
		if !valid {
			t.Fatalf("invalid projection at step %d", i)
		}
		err := math.Hypot(x-960, y-540)
		if err > oldErr+1.1 {
			t.Fatalf("screen aim worsened %.2f -> %.2f", oldErr, err)
		}
		oldErr = err
		next, moved := cameraDirectionStep(eye, head, current, 12)
		if !moved {
			break
		}
		current = next
	}
	if dotVectors(current, desired) < 0.9999 || oldErr > 9 {
		t.Fatalf("not converged: dot %.5f err %.1f", dotVectors(current, desired), oldErr)
	}
}
func TestCameraVectorRejectsCorruptReads(t *testing.T) {
	eye := vec3{0, 0, 0}
	head := vec3{10, 0, 5}
	current := vec3{1, 0, 0}
	bad := []vec3{{0, 0, 0}, {0, 0, -1}, {0.1, 0, 0}, {3, 0, 0}, {float32(math.NaN()), 0, 0}}
	for _, v := range bad {
		if _, ok := cameraDirectionStep(eye, head, v, 8); ok {
			t.Fatalf("bad vector accepted %+v", v)
		}
	}
	if _, ok := cameraDirectionStep(eye, vec3{1000, 0, 1}, current, 12); ok {
		t.Fatal("out-of-range head accepted")
	}
}
func TestCameraGuardBlocksWrongDirection(t *testing.T) {
	eye := vec3{0, 0, 0}
	head := vec3{20, 0, 3}
	original := cameraTestView(eye, vec3{1, 0, 0})
	bad := cameraTestView(eye, vec3{1, 0, -0.06})
	good := cameraTestView(eye, vec3{1, 0, 0.06})
	makeGuard := func() cameraAimGuard {
		return cameraAimGuard{pending: true, targetID: 5, previousProjection: original, sentAt: time.Now().Add(-100 * time.Millisecond)}
	}
	g := makeGuard()
	if ready, reason := g.observe(espViewport{W: 1920, H: 1080, Camera: bad}, head, 5); ready || g.faults == 0 || reason == "" {
		t.Fatalf("wrong camera direction not blocked %t %s", ready, reason)
	}
	g = makeGuard()
	if ready, reason := g.observe(espViewport{W: 1920, H: 1080, Camera: good}, head, 5); !ready || g.faults != 0 {
		t.Fatalf("improvement rejected %t %s", ready, reason)
	}
}
