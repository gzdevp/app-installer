# sete7 v14 - desenvolvimento focado nas 3 funções finais

Base: v13.9.70 com correção dos callbacks + varredura Vehicle Pool.

## Mudanças compiladas
- 57 novos hashes de modelos GTA/FiveM identificados no catálogo oficial com hashes da documentação oficial.
- Leitura alternativa limitada de hashes de modelos, apenas quando o modelo alternativo já pertence ao catálogo ou a aliases definidos pelo usuário.
- Friends/lista de jogadores próximos ampliada para até 256 entradas (sem limitação da câmera), sempre ordenada por distância.
- Interface intitulada v14 RC.

## Não resolvido / não validado
- Nome real Steam/FiveM em todas as cidades: CPlayerInfo não fornece nome de sessão confiável em todas as builds. Requer acesso autorizado à API GetPlayerName ou outra fonte de nomes de sessão.
- Nomes de carros personalizados: mapeamento de hash do modelo específico do servidor ou metadados da sua cidade.
- Trancar/destrancar e FIX universais: dependem da autoridade/sincronização do servidor, e a alteração local experimental não concede chaves nem repara deformações de forma garantida.
- Through Wall real: o código ainda só altera campo local de penetração de arma; não é atravessamento real, nem comprovação de acerto servidor.

Não considerar esta compilação como versão final com estas três funções garantidas. Testes no jogo e em cada build ainda necessários.
