package main

import (
	"testing"
	"time"
)

func TestNativeCaptureEdges(t *testing.T) {
	var c keyCaptureScanner
	state := map[uintptr]bool{1: true} // Button pressed while activating UI should never bind mouse1.
	pressed := func(vk uintptr) bool { return state[vk] }
	at := time.Unix(1000, 0)
	c.begin(at, pressed)
	if status, key := c.poll(at.Add(20*time.Millisecond), pressed); status != "waiting" || key != "" {
		t.Fatalf("mouse1 held: %s %s", status, key)
	}
	state[1] = false
	if status, _ := c.poll(at.Add(50*time.Millisecond), pressed); status != "waiting" {
		t.Fatal(status)
	}
	state[0x74] = true // F5
	if status, key := c.poll(at.Add(75*time.Millisecond), pressed); status != "captured" || key != "f5" {
		t.Fatalf("wanted F5 got %s %s", status, key)
	}
	if status, _ := c.poll(at.Add(90*time.Millisecond), pressed); status != "idle" {
		t.Fatal(status)
	}
}

func TestNativeCaptureSideButtonsAndTimeout(t *testing.T) {
	var c keyCaptureScanner
	state := map[uintptr]bool{}
	pressed := func(vk uintptr) bool { return state[vk] }
	now := time.Unix(1000, 0)
	c.begin(now, pressed)
	state[5] = true // XBUTTON1 = Mouse 4
	if status, key := c.poll(now.Add(50*time.Millisecond), pressed); status != "captured" || key != "mouse4" {
		t.Fatalf("got %s %s", status, key)
	}
	c.begin(now, pressed)
	if status, _ := c.poll(now.Add(13*time.Second), pressed); status != "expired" {
		t.Fatal(status)
	}
	c.begin(now, pressed)
	c.cancel()
	if status, _ := c.poll(now.Add(time.Second), pressed); status != "idle" {
		t.Fatal(status)
	}
}
func TestCaptureCandidateKeysAreValid(t *testing.T) {
	seen := map[uintptr]bool{}
	for _, item := range captureCandidates {
		if !validBindingKey(item.name) || genericKeyVK(item.name, 0) != item.vk {
			t.Errorf("mismatch %+v", item)
		}
		if seen[item.vk] {
			t.Errorf("duplicate VK %+v", item)
		}
		seen[item.vk] = true
	}
}
