package main

import (
	"os"
	"strings"
	"testing"
)

func TestInsertBootStateNotResetByTitleChanges(t *testing.T) {
	data, err := os.ReadFile("hotkey_windows.go")
	if err != nil {
		t.Fatal(err)
	}
	s := string(data)
	for _, part := range []string{"openingPending()", "presentMenuAfterLaunch()", "standaloneBrowserHWND.Store(browser)", "showWindow.Call(hwnd, 9)"} {
		if !strings.Contains(s, part) {
			t.Errorf("missing recovery guard %q", part)
		}
	}
}
