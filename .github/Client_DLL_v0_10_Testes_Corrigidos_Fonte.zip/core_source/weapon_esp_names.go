package main

// Only names with known GTA V hashes are displayed. Unsupported/custom
// weapons deliberately have no label, not a guessed model.
var equippedWeaponNames = map[uint32]string{
	0x1B06D571: "Pistola", 0x5EF9FEC4: "Combat Pistol", 0x22D8FE39: "AP Pistol",
	0x99AEEB3B: "Pistol .50", 0xBFEFFF6D: "Assault Rifle", 0x83BF0278: "Carbine Rifle",
	0xAF113F99: "Advanced Rifle", 0x9D07F764: "Micro SMG", 0x2BE6766B: "SMG",
	0x1D073A89: "Pump Shotgun", 0x7846A318: "Sawed-off Shotgun", 0x05FC3C11: "Sniper Rifle",
	0x0C472FE2: "Heavy Sniper", 0xA2719263: "Desarmado", 0xD205520E: "Heavy Pistol",
	0x7FD62962: "Combat MG", 0x13532244: "Micro SMG MkII", 0xBFE256D4: "Pistol Mk II",
	0xDB1AA450: "Machine Pistol", 0x7F229F94: "Bullpup Rifle", 0xD1D5F52B: "Heavy Shotgun",
}

func knownEquippedWeapon(hash uint32) (string, bool) {
	name, ok := equippedWeaponNames[hash]
	return name, ok && hash != 0xA2719263
}
