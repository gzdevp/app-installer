//go:build windows

package main

import "time"

var nativeBindScanner keyCaptureScanner

func nativeBindingPressed(vk uintptr) bool {
	down, _, _ := getAsyncKeyState.Call(vk)
	return down&0x8000 != 0
}
func nativeKeyCaptureAllowed() bool {
	if !menuWanted.Load() {
		return false
	}
	host := menuWindow()
	if host == 0 {
		return false
	}
	visible, _, _ := isWindowVisible.Call(host)
	if visible == 0 {
		return false
	}
	foreground, _, _ := getForeground.Call()
	return foreground == host || foreground == nativeChildHWND.Load() || activeFiveMWindow(foreground)
}
func startNativeKeyCapture() bool {
	if !nativeKeyCaptureAllowed() {
		return false
	}
	nativeBindScanner.begin(time.Now(), nativeBindingPressed)
	return true
}
func pollNativeKeyCapture() (string, string) {
	if !nativeKeyCaptureAllowed() {
		nativeBindScanner.cancel()
		return "inactive", ""
	}
	return nativeBindScanner.poll(time.Now(), nativeBindingPressed)
}
func cancelNativeKeyCapture() { nativeBindScanner.cancel() }
