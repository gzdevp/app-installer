# sete7 v14.5.1 — correção delimitada de Players/Friends

Base: código-fonte da v14.5. Interface e demais funcionalidades preservadas.

## Modificações realizadas
- `esp_windows.go`: a lista de jogadores usa um cache de nome de até 900 ms quando a leitura de `CPlayerInfo` falha temporariamente.
- `player_name_stability.go`: o cache somente usa a identificação anterior se PID do processo, ponteiro do ped, ponteiro `PlayerInfo` e posição forem compatíveis. Expira após 900 ms; não transporta nomes para outros personagens.
- `player_name_stability_test.go`: testes de perda momentânea, troca de processo, troca de ped, troca de `PlayerInfo`, deslocamento grande, expiração e atualização do nome.

## Verificações
- Compilação Windows/amd64 e análise estática Go concluídas.
- Testes isolados da rotina de cache aprovados.
- Sem teste real dentro do FiveM.

## Não implementado nesta compilação
- Obtenção garantida de nomes Steam/FiveM quando `CPlayerInfo` não os disponibiliza.
- Nomes corretos para todo modelo personalizado de toda cidade.
- FIX/Unlock universais ou Through Wall com colisão/dano real em todos os servidores.

Esta versão **não** deve ser anunciada como as três funções prontas. O EXE externo não tem acesso garantido à identidade de sessão nem autoridade sobre mudanças que o servidor pode reverter.
