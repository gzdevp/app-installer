# sete7 v14 - revisão de regressões

Base: v14 RC, sem alteração dos controles de combate/veículos.

## Alterações efetivas
- Varredura de Peds suporta até 256 candidatos por atualização (antes 128), em linha com a capacidade da lista Friends. A capacidade máxima do pool continua limitada a 2048 e as verificações existentes permanecem.
- A interface Friends exibe estrela somente quando `friend` foi confirmado no backend, respeitando ambiguidades/nome duplicado. Antes, apenas o texto salvo bastava e podia marcar o personagem errado.
- A origem dos nomes é rotulada como leitura não verificada, sem apresentar nomes capturados em memória como nomes Steam/FiveM autenticados.

## Ainda NÃO solucionado
- Os nomes de sessão Steam/FiveM não são resolvidos de forma universal via o leitor externo.
- Nomes de modelos customizados não são extraíveis do hash sem metadados/aliases da cidade.
- FIX CAR e Unlock All continuam experiências locais restritas, sem garantia de sincronização ou autorização do servidor.
- Through Wall não modifica raycasts/colisões: continua teste de penetração, sem atravessamento funcional comprovado.

Compilação Windows e análise estática não equivalem a testes em servidor real.
