package main

import (
	"math"
	"testing"
)

func TestPlanHealNormal(t *testing.T) {
	p, e := planHealthWrite(pedVitals{150, 200}, 200)
	if e != nil || p.RaiseMaximum || p.Target != 200 {
		t.Fatalf("bad normal heal: %+v %v", p, e)
	}
}
func TestPlanHealthBoost(t *testing.T) {
	p, e := planHealthWrite(pedVitals{120, 200}, 350)
	if e != nil || !p.RaiseMaximum || p.NewMaximum != 350 {
		t.Fatalf("bad boost: %+v %v", p, e)
	}
}
func TestPlanReviveAllowsZeroHealth(t *testing.T) {
	p, e := planHealthWrite(pedVitals{0, 200}, 200)
	if e != nil || p.Target != 200 {
		t.Fatalf("bad tentative revive %v", e)
	}
}
func TestPlanRejectsCorrupt(t *testing.T) {
	inputs := []struct {
		v         pedVitals
		requested float32
	}{
		{pedVitals{float32(math.NaN()), 200}, 200},
		{pedVitals{160, float32(math.Inf(1))}, 200},
		{pedVitals{150, -1}, 200},
		{pedVitals{-7, 200}, 200},
		{pedVitals{10500, 200}, 200},
		{pedVitals{150, 200}, 501},
		{pedVitals{150, 200}, 100},
		{pedVitals{150, 200}, float32(math.Inf(1))},
	}
	for i, s := range inputs {
		if _, e := planHealthWrite(s.v, s.requested); e == nil {
			t.Fatalf("accepted invalid #%d", i)
		}
	}
}
func TestHealthReadback(t *testing.T) {
	if !confirmedHealthValue(200, 200) || confirmedHealthValue(197, 200) || confirmedHealthValue(float32(math.NaN()), 200) {
		t.Fatal("readback validation")
	}
}

// Regression: the old 0x2A0 offset caused the live panel to report
// "campos de HP incompatíveis". CitizenFX's MaxHealthFloat is at 0x284.
func TestPedMaxHealthFieldMatchesCitizenFX(t *testing.T) {
	if pedHealthField != 0x280 || pedMaxHealthField != 0x284 {
		t.Fatalf("CPed health fields changed: current %x maximum %x", pedHealthField, pedMaxHealthField)
	}
}
func TestHealthBoostMatchesScreenshot(t *testing.T) {
	plan, err := planHealthWrite(pedVitals{150, 200}, 415)
	if err != nil || plan.Target != 415 || plan.NewMaximum != 415 || !plan.RaiseMaximum {
		t.Fatalf("HP boost failed: %+v (%v)", plan, err)
	}
}
func TestArmorValidation(t *testing.T) {
	if !validArmorTarget(0) || !validArmorTarget(100) || validArmorTarget(-1) || validArmorTarget(101) || validArmorTarget(float32(math.NaN())) {
		t.Fatal("armor target validation failed")
	}
	if !plausibleArmorValue(200) || plausibleArmorValue(9999) || plausibleArmorValue(float32(math.Inf(1))) {
		t.Fatal("armor readback guard failed")
	}
}
func TestCustomHealthExceedingMaxIsNotAutoCorrupt(t *testing.T) {
	// Custom servers may temporarily report health above the max field.
	if _, err := planHealthWrite(pedVitals{415, 200}, 450); err != nil {
		t.Fatalf("unexpected rejection: %v", err)
	}
}
