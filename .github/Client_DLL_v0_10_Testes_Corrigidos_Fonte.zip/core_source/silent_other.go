//go:build !windows

package main

func startSilentAim() {}
func silentShutdown() {}
