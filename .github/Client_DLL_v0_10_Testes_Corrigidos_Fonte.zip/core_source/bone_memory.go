package main

// BoneSnapshot is read from the address stored in the ped bone-list pointer,
// NOT from the bytes of the pointer field itself. The 9-joint stride is still
// experimental and will be rejected downstream unless pose checks succeed.
const boneSnapshotBytes = 9*16 - 4

type boneReadStage uint8

const (
	boneReadOK boneReadStage = iota
	boneReadNoPointer
	boneReadFailed
)

func readPedBoneSnapshot(ped, offset uintptr, ptr func(uintptr) uintptr, read func(uintptr, []byte) bool) ([boneSnapshotBytes]byte, boneReadStage) {
	var raw [boneSnapshotBytes]byte
	if ped < 0x10000 || offset == 0 || offset > 0x10000 {
		return raw, boneReadNoPointer
	}
	address := ptr(ped + offset)
	if address < 0x10000 || address > 0x7FFFFFFFFFFF {
		return raw, boneReadNoPointer
	}
	if !read(address, raw[:]) {
		return raw, boneReadFailed
	}
	return raw, boneReadOK
}
