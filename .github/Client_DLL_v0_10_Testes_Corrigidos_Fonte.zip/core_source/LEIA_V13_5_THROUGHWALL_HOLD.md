# sete7 v13.5 – Through Wall (HOLD) TESTE

## O que mudou
- Tecla do Through Wall (campo `magic.key`) funciona enquanto estiver segurada (NAO alterna com um toque).
- Teclas de teclado e botoes do mouse aceitos pelo seletor ja existente: A-Z, 0-9, F1-F12 exceto F6, Shift/Ctrl/Alt/Espaco e Mouse1-5.
- Somente com a opcao "Habilitar Through Wall" ligada e o FiveM em foco.
- Ao soltar a tecla ou perder o foco, o worker tenta restaurar o valor de penetracao original.
- Nao ha escrita de config.json a cada toque; a opcao do painel e o atalho sao estados separados.
- Textos da interface deixam claro que escrita de memoria nao comprova atravessar paredes.

## Compatibilidade e limites
- A alteracao permanece restrita a CWeaponInfo Penetration, na b3258.
- NAO foi adicionada tecnologia de atravesse de parede / Magic Bullets; nao existe comprovacao do efeito real nem garantia em servidores.
- Preservados byte a byte: aim*, silent*, esp*, tpway*, player_vitals* da v13.3.
- Testes de regra de ativacao e de teclas passaram em Go. Compilacao Windows amd64 e checagem de sintaxe JS passaram.
- Sem teste pratico no FiveM; nao chame de '100% funcional' ate observar no jogo.

## Uso
1. Feche v13.4 antes de abrir v13.5.
2. Aim > Through Wall > marque "Habilitar Through Wall".
3. Clique na caixa de tecla e pressione uma letra (ex: G) ou botao do mouse (ex: Mouse 4).
4. Feche o painel com INSERT, coloque FiveM em foco, segure a tecla para testar e solte para terminar.
5. Mantenha seu executavel v13.3 intacto como backup.
