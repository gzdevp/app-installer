package main

import "testing"

func TestStreamClassify(t *testing.T) {
	cases := []struct {
		enabled   bool
		affinity  uintptr
		verified  bool
		protected bool
	}{
		{true, wdaExcludeFromCapture, true, true},
		{true, wdaMonitor, true, false},
		{true, wdaNone, true, false},
		{true, wdaExcludeFromCapture, false, false},
		{false, wdaNone, true, false},
	}
	for _, c := range cases {
		_, got := streamClassify(c.enabled, c.affinity, c.verified)
		if got != c.protected {
			t.Fatalf("classify(%v,%#x,%v) = %v", c.enabled, c.affinity, c.verified, got)
		}
	}
}

func TestStreamReadyLabel(t *testing.T) {
	if streamReadyLabel(true, false) == streamReadyLabel(true, true) {
		t.Fatal("must distinguish error from ready")
	}
	if streamReadyLabel(false, true) != "Desativado" {
		t.Fatal("disabled should take precedence")
	}
}
