//go:build windows

package main

// Experimental, explicitly opted-in game build integration. It never guesses
// unknown offsets and restores original bytes on disable/unload. No anti-cheat
// evasion, drivers, persistence, process-name spoofing or stealth facilities.
import (
	"bytes"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"math"
	"strings"
	"sync"
	"time"
	"unsafe"
)

const (
	silentVMOperation   uintptr = 0x0008
	silentVMWrite       uintptr = 0x0020
	silentMemoryReserve uintptr = 0x3000
	silentMemoryRelease uintptr = 0x8000
	silentExecuteRW     uintptr = 0x40
)

var (
	silentWriteProcessMemory    = kernel32Process.NewProc("WriteProcessMemory")
	silentVirtualAllocEx        = kernel32Process.NewProc("VirtualAllocEx")
	silentVirtualFreeEx         = kernel32Process.NewProc("VirtualFreeEx")
	silentVirtualProtectEx      = kernel32Process.NewProc("VirtualProtectEx")
	silentFlushInstructionCache = kernel32Process.NewProc("FlushInstructionCache")
)

// Offsets supplied with the earlier C++ reference. They are NOT assumed valid:
// bytes are checked against the exact 17-byte instruction sequence every time.
var silentBulletOffsets = map[string]uintptr{
	"b2699": 0xFF9D90, "b2802": 0xFF716C, "b2944": 0x1003F80,
	"b3095": 0x100F5A4, "b3323": 0x1026CAD,
	"b3407": 0x102FF89,
}

type SilentSettings struct {
	Enabled   bool   `json:"enabled"`
	Key       string `json:"key"`
	FOV       int    `json:"fov"`
	Range     int    `json:"range"`
	Visible   bool   `json:"visible"`
	IgnoreNPC bool   `json:"ignoreNpc"`
	Miss      int    `json:"miss"`
}

type silentStatusInfo struct {
	Enabled       bool   `json:"enabled"`
	Applied       bool   `json:"applied"`
	Build         string `json:"build"`
	Target        bool   `json:"target"`
	Status        string `json:"status"`
	Mode          string `json:"mode"`
	Compatibility string `json:"compatibility"`
	LastInGame    string `json:"lastInGame"`
	LastInGameAt  string `json:"lastInGameAt"`
}

var silentState = struct {
	sync.RWMutex
	settings SilentSettings
	status   silentStatusInfo
}{
	settings: SilentSettings{Key: "mouse4", FOV: 120, Range: 250},
	status:   silentStatusInfo{Status: "Desativado", Mode: "Silent via detour experimental (assinatura validada)"},
}

func silentSet(s SilentSettings) {
	if s.Key == "" {
		s.Key = "mouse4"
	}
	if s.FOV < 20 {
		s.FOV = 20
	}
	if s.FOV > 500 {
		s.FOV = 500
	}
	if s.Range < 20 {
		s.Range = 20
	}
	if s.Range > 500 {
		s.Range = 500
	}
	if s.Miss < 0 {
		s.Miss = 0
	}
	if s.Miss > 100 {
		s.Miss = 100
	}
	silentState.Lock()
	silentState.settings = s
	silentState.status.Enabled = s.Enabled
	if !s.Enabled {
		silentState.status.Status = "Desativado"
	}
	silentState.Unlock()
}
func silentIsEnabled() bool {
	silentState.RLock()
	defer silentState.RUnlock()
	return silentState.settings.Enabled
}
func silentGet() silentStatusInfo {
	silentState.RLock()
	defer silentState.RUnlock()
	return silentState.status
}
func silentReportCompatibility(info string) {
	silentState.Lock()
	silentState.status.Compatibility = info
	silentState.Unlock()
}

// A read-only compatibility check runs independently of target acquisition.
// This distinguishes a missing head bone from an incompatible game binary.
func silentReadOnlyPreflight() string {
	p, build, _, err := findESP()
	if err != nil {
		return "Não foi possível localizar o FiveM: " + err.Error()
	}
	defer closeESP(p.handle)
	entry, err := resolveSilentEntry(p.handle, p.base, build)
	if err != nil {
		return err.Error()
	}
	return fmt.Sprintf("%s: sequência compatível no RVA 0x%X (disparos ainda não validados)", build, entry-p.base)
}

func silentReport(text, build string, applied, target bool) {
	silentState.Lock()
	silentState.status.Status = text
	silentState.status.Build = build
	silentState.status.Applied = applied
	silentState.status.Target = target
	// When the menu takes foreground focus, the ESP intentionally pauses.
	// Preserve the last status recorded while FiveM was actually active;
	// otherwise opening INSERT hides the only diagnostic that matters.
	if text != "Desativado" && text != "Aguardando leitura atual e foco no FiveM" &&
		text != "Menu aberto; volte ao FiveM para ativar" {
		silentState.status.LastInGame = text
		silentState.status.LastInGameAt = time.Now().Format("15:04:05")
	}
	silentState.Unlock()
}

type silentRemote struct {
	handle   uintptr
	pid      uint32
	build    string
	entry    uintptr
	entryRVA uintptr
	cave     uintptr
	original []byte
	patch    []byte
	applied  bool
	last     vec3
}

func silentRemoteRead(h, addr uintptr, n int) ([]byte, error) {
	if h == 0 || addr < 0x10000 || n <= 0 || n > 4096 {
		return nil, errors.New("leitura remota inválida")
	}
	b := make([]byte, n)
	var got uintptr
	ok, _, _ := readProcessMemory.Call(h, addr, uintptr(unsafe.Pointer(&b[0])), uintptr(n), uintptr(unsafe.Pointer(&got)))
	if ok == 0 || got != uintptr(n) {
		return nil, errors.New("falha em ReadProcessMemory")
	}
	return b, nil
}
func silentRemoteWrite(h, addr uintptr, b []byte) error {
	if h == 0 || addr < 0x10000 || len(b) == 0 {
		return errors.New("escrita remota inválida")
	}
	var got uintptr
	ok, _, _ := silentWriteProcessMemory.Call(h, addr, uintptr(unsafe.Pointer(&b[0])), uintptr(len(b)), uintptr(unsafe.Pointer(&got)))
	if ok == 0 || got != uintptr(len(b)) {
		return errors.New("falha em WriteProcessMemory")
	}
	return nil
}
func silentCodeWrite(h, addr uintptr, b []byte) error {
	var old uint32
	ok, _, _ := silentVirtualProtectEx.Call(h, addr, uintptr(len(b)), silentExecuteRW, uintptr(unsafe.Pointer(&old)))
	if ok == 0 {
		return errors.New("proteção da página negada")
	}
	err := silentRemoteWrite(h, addr, b)
	var ignored uint32
	restored, _, _ := silentVirtualProtectEx.Call(h, addr, uintptr(len(b)), uintptr(old), uintptr(unsafe.Pointer(&ignored)))
	silentFlushInstructionCache.Call(h, addr, uintptr(len(b)))
	if err != nil {
		return err
	}
	if restored == 0 {
		return errors.New("falha ao restaurar proteção da página")
	}
	return nil
}

// The b3258 offset reference names TWO different functions. Read both
// candidate code regions. Patching is allowed only with a unique complete
// instruction signature, not merely because an RVA was supplied.
func resolveSilentEntry(h, base uintptr, build string) (uintptr, error) {
	if build != "b3258" {
		offset, ok := silentBulletOffsets[build]
		if !ok {
			return 0, fmt.Errorf("Silent indisponível na build %s", build)
		}
		entry := base + offset
		orig, err := silentRemoteRead(h, entry, len(bulletOriginal))
		if err != nil {
			return 0, err
		}
		if !bytes.Equal(orig, bulletOriginal) {
			return 0, fmt.Errorf("assinatura do disparo incompatível na build %s; patch bloqueado", build)
		}
		return entry, nil
	}
	regions := []struct {
		label string
		rva   uintptr
		size  int
	}{
		{"handleBullet", 0x101A5F4, 0x380},
		{"bulletfuncaddr", 0x1044404, 0x200},
	}
	var matches []uintptr
	var notes []string
	for _, region := range regions {
		data, err := silentRemoteRead(h, base+region.rva, region.size)
		if err != nil {
			notes = append(notes, fmt.Sprintf("%s: leitura indisponível", region.label))
			continue
		}
		hits := findBulletSignatures(data)
		notes = append(notes, fmt.Sprintf("%s: %d assinatura(s)", region.label, len(hits)))
		for _, pos := range hits {
			matches = append(matches, base+region.rva+uintptr(pos))
		}
		if region.label == "handleBullet" {
			// Read-only fingerprint at the old b3258 RVA, helpful for
			// diagnosing updated builds without guessing instructions.
			const oldDelta = 0x101A65D - 0x101A5F4
			if oldDelta+len(bulletOriginal) <= len(data) {
				notes = append(notes, "bytes antigos: "+hex.EncodeToString(data[oldDelta:oldDelta+len(bulletOriginal)]))
			}
		}
	}
	if len(matches) == 0 {
		return 0, errors.New("b3258 sem assinatura compatível (somente leitura): " + strings.Join(notes, "; "))
	}
	if len(matches) != 1 {
		return 0, errors.New("b3258: múltiplos locais candidatos; nenhum patch aplicado")
	}
	return matches[0], nil
}

func newSilentRemote() (*silentRemote, error) {
	p, build, _, err := findESP()
	if err != nil {
		return nil, err
	}
	defer closeESP(p.handle)
	handle, _, _ := openProcessProc.Call(processVMRead|processQueryLimited|processSynchronize|silentVMOperation|silentVMWrite, 0, uintptr(p.pid))
	if handle == 0 {
		return nil, errors.New("sem permissão de escrita no processo")
	}
	fail := func(err error) (*silentRemote, error) { closeESP(handle); return nil, err }
	entry, err := resolveSilentEntry(handle, p.base, build)
	if err != nil {
		return fail(err)
	}
	orig, err := silentRemoteRead(handle, entry, len(bulletOriginal))
	if err != nil {
		return fail(err)
	}
	if !bytes.Equal(orig, bulletOriginal) {
		return fail(fmt.Errorf("assinatura mudou durante leitura na build %s; patch bloqueado", build))
	}
	cave, _, _ := silentVirtualAllocEx.Call(handle, 0, 4096, silentMemoryReserve, silentExecuteRW)
	if cave == 0 {
		return fail(errors.New("falha ao alocar memória para hook"))
	}
	patch, err := bulletEntryPatch(cave)
	if err != nil {
		silentVirtualFreeEx.Call(handle, cave, 0, silentMemoryRelease)
		return fail(err)
	}
	return &silentRemote{handle: handle, pid: p.pid, build: build, entry: entry, entryRVA: entry - p.base, cave: cave, original: orig, patch: patch}, nil
}
func (h *silentRemote) enable(target vec3) error {
	if h == nil {
		return errors.New("hook vazio")
	}
	if h.applied {
		return h.update(target)
	}
	current, err := silentRemoteRead(h.handle, h.entry, len(h.original))
	if err != nil {
		return err
	}
	if !bytes.Equal(current, h.original) {
		return errors.New("bytes originais mudaram; Silent bloqueado")
	}
	code, err := bulletTrampoline(h.entry, h.cave, target)
	if err != nil {
		return err
	}
	if err = silentRemoteWrite(h.handle, h.cave, code); err != nil {
		return err
	}
	silentFlushInstructionCache.Call(h.handle, h.cave, uintptr(len(code)))
	if err = silentCodeWrite(h.handle, h.entry, h.patch); err != nil {
		// A write can succeed even when restoration of page protections
		// fails. Read back the bytes before deciding whether the cave is safe
		// to release; never free a cave still referenced by a live jump.
		current, readErr := silentRemoteRead(h.handle, h.entry, len(h.patch))
		if readErr == nil && bytes.Equal(current, h.patch) {
			h.applied = true
			if undoErr := h.disable(); undoErr != nil {
				return fmt.Errorf("partial patch; restoration failed: %w", undoErr)
			}
		}
		return err
	}
	h.applied = true
	h.last = target
	return nil
}
func (h *silentRemote) update(target vec3) error {
	if h == nil {
		return errors.New("hook vazio")
	}
	if !h.applied {
		return h.enable(target)
	}
	if !validBulletWorld(target) {
		return errors.New("coordenadas rejeitadas")
	}
	if math.Abs(float64(target.X-h.last.X)) < 0.005 && math.Abs(float64(target.Y-h.last.Y)) < 0.005 && math.Abs(float64(target.Z-h.last.Z)) < 0.005 {
		return nil
	}
	xyz, err := bulletTargetBytes(target)
	if err != nil {
		return err
	}
	if err = silentRemoteWrite(h.handle, h.cave+bulletCaveTargetOffset, xyz); err != nil {
		return err
	}
	h.last = target
	return nil
}
func (h *silentRemote) disable() error {
	if h == nil || !h.applied {
		return nil
	}
	current, err := silentRemoteRead(h.handle, h.entry, len(h.patch))
	if err != nil {
		return err
	}
	if !bytes.Equal(current, h.patch) {
		return errors.New("código remoto mudou; não sobrescrever terceiros")
	}
	if err = silentCodeWrite(h.handle, h.entry, h.original); err != nil {
		return err
	}
	h.applied = false
	return nil
}
func (h *silentRemote) close() error {
	if h == nil {
		return nil
	}
	err := h.disable()
	// Never release executable memory while the original entry might still jump into it.
	if err == nil && h.cave != 0 {
		silentVirtualFreeEx.Call(h.handle, h.cave, 0, silentMemoryRelease)
		h.cave = 0
	}
	if h.handle != 0 {
		closeESP(h.handle)
		h.handle = 0
	}
	return err
}

// silentSelectionStats exposes why a verified head was not eligible for a
// particular FOV. A visible ESP skeleton is not automatically an aim target.
type silentSelectionStats struct {
	Verified  int
	Eligible  int
	InFOV     int
	NearestPx float64
}

func selectSilentHeadWithStats(targets []targetESP, view espViewport, s SilentSettings) (vec3, uint64, bool, silentSelectionStats) {
	stats := silentSelectionStats{NearestPx: -1}

	if view.W < 320 || view.H < 240 {
		return vec3{}, 0, false, stats
	}
	cx, cy := float64(view.W)/2, float64(view.H)/2
	nearest := math.Inf(1)
	var chosen vec3
	var ped uint64
	for _, t := range targets {
		if t.Vehicle || t.Friend || (t.Downed && espGet().Settings.IgnoreDowned) || (t.IsNPC && s.IgnoreNPC) || t.PedID == 0 || !t.HeadVerified || !t.AimFromBone || !validBulletWorld(t.HeadWorld) {
			continue
		}
		stats.Verified++
		if t.Distance < 1 || t.Distance > s.Range {
			continue
		}
		distFromPed := poseDist(t.HeadWorld, t.World)
		if distFromPed > 3.4 || distFromPed < 0.2 {
			continue
		}
		x, y := float64(t.AimX), float64(t.AimY)
		if x < 0 || y < 0 || x >= float64(view.W) || y >= float64(view.H) {
			continue
		}
		stats.Eligible++
		delta := math.Hypot(x-cx, y-cy)
		if stats.NearestPx < 0 || delta < stats.NearestPx {
			stats.NearestPx = delta
		}
		if delta > float64(s.FOV) {
			continue
		}
		stats.InFOV++
		if delta < nearest {
			nearest = delta
			chosen = t.HeadWorld
			ped = t.PedID
		}
	}
	return chosen, ped, ped != 0, stats
}

func selectSilentHead(targets []targetESP, view espViewport, s SilentSettings) (vec3, uint64, bool) {
	head, id, found, _ := selectSilentHeadWithStats(targets, view, s)
	return head, id, found
}

// Runs independently from the Aimbot and the display. If the game loses focus
// or a fresh, verified head is not present, restore original code promptly.
var silentWorker = struct {
	sync.Mutex
	remote  *silentRemote
	stopped bool
}{}

func silentShutdown() {
	silentWorker.Lock()
	defer silentWorker.Unlock()
	silentWorker.stopped = true
	if silentWorker.remote != nil {
		_ = silentWorker.remote.close()
		silentWorker.remote = nil
	}
}
func startSilentAim() {
	go func() {
        defer recoverServiceWorker("silent_windows.go")
		ticker := time.NewTicker(18 * time.Millisecond)
		defer ticker.Stop()
		// Throttle only failed allocations. Previously every successful hook
		// installation also started a 4-second cooldown. A one-frame target
		// loss then made most subsequent shots ineligible for four seconds.
		lastFailure := time.Time{}
		lastPreflight := time.Time{}
		wasFireDown := false
		missThisShot := false
		for range ticker.C {
			silentWorker.Lock()
			if silentWorker.stopped {
				silentWorker.Unlock()
				return
			}
			silentState.RLock()
			s := silentState.settings
			silentState.RUnlock()
			if !s.Enabled || overlayPaused.Load() {
				if silentWorker.remote != nil {
					_ = silentWorker.remote.close()
					silentWorker.remote = nil
				}
				silentReport("Desativado", "", false, false)
				silentWorker.Unlock()
				continue
			}
			if time.Since(lastPreflight) >= 7*time.Second {
				lastPreflight = time.Now()
				silentReportCompatibility(silentReadOnlyPreflight())
			}
			viewport, targets, _ := espRendered.snapshot(85 * time.Millisecond)
			// An occasional slow/failed ESP frame is not a process restart.
			// Restore the original instructions immediately, but retain the
			// disabled trampoline if FiveM itself is still foreground.
			if silentWorker.remote != nil &&
				(viewport.PID == 0 || espGet().Status != "Leitura ativa (experimental)") &&
				fiveMIsForeground(silentWorker.remote.pid) {
				if e := silentWorker.remote.disable(); e != nil {
					silentReport("Falha ao restaurar hook: "+e.Error(), "", false, false)
				} else {
					silentReport("Leitura do ESP momentaneamente indisponível", "", false, false)
				}
				silentWorker.Unlock()
				continue
			}
			if viewport.PID == 0 || !fiveMIsForeground(viewport.PID) || espGet().Status != "Leitura ativa (experimental)" {
				if silentWorker.remote != nil {
					_ = silentWorker.remote.close()
					silentWorker.remote = nil
				}
				if menuWanted.Load() {
					silentReport("Menu aberto; volte ao FiveM para ativar", "", false, false)
				} else {
					silentReport("Aguardando leitura atual e foco no FiveM", "", false, false)
				}
				silentWorker.Unlock()
				continue
			}
			// Reusing the allocated trampoline is safe only for the same PID.
			if silentWorker.remote != nil && silentWorker.remote.pid != viewport.PID {
				_ = silentWorker.remote.close()
				silentWorker.remote = nil
			}
			state, _, _ := getAsyncKeyState.Call(keyVK(s.Key))
			if !silentKeyHeld(state) {
				// Restore original instructions but keep the validated
				// trampoline allocation for the next press. No re-scan delay.
				if silentWorker.remote != nil {
					if e := silentWorker.remote.disable(); e != nil {
						silentReport("Falha ao restaurar hook: "+e.Error(), "", false, false)
						silentWorker.Unlock()
						continue
					}
				}
				silentReport("Aguardando tecla de ativação", "", false, false)
				silentWorker.Unlock()
				continue
			}
			// The menu's miss-chance is interpreted only on a new physical
			// firing press; the hook is never applied for a deliberately missed shot.
			fire, _, _ := getAsyncKeyState.Call(0x01)
			fireDown := fire&0x8000 != 0
			if fireDown && !wasFireDown {
				var rb [1]byte
				_, e := rand.Read(rb[:])
				missThisShot = e == nil && int(rb[0])%100 < s.Miss
			}
			if !fireDown {
				missThisShot = false
			}
			wasFireDown = fireDown
			if missThisShot {
				if silentWorker.remote != nil {
					if e := silentWorker.remote.disable(); e != nil {
						silentReport("Falha ao restaurar hook: "+e.Error(), "", false, false)
						silentWorker.Unlock()
						continue
					}
				}
				silentReport("Disparo ignorado pela chance de erro", "", false, false)
				silentWorker.Unlock()
				continue
			}
			head, id, found, stats := selectSilentHeadWithStats(targets, viewport, s)
			if !found {
				// An absent target must immediately disable the patch, but
				// it must NOT reset our allocation and reintroduce the retry
				// cooldown when a target returns one frame later.
				if silentWorker.remote != nil {
					if e := silentWorker.remote.disable(); e != nil {
						silentReport("Falha ao restaurar hook: "+e.Error(), "", false, false)
						silentWorker.Unlock()
						continue
					}
				}
				pedCount, verifiedHeads := 0, 0
				for _, candidate := range targets {
					if candidate.Vehicle || candidate.PedID == 0 {
						continue
					}
					pedCount++
					if candidate.HeadVerified && candidate.AimFromBone && validBulletWorld(candidate.HeadWorld) {
						verifiedHeads++
					}
				}
				closest := "nenhum elegível"
				if stats.NearestPx >= 0 {
					closest = fmt.Sprintf("%.0f px", stats.NearestPx)
				}
				silentReport(fmt.Sprintf("Sem alvo no FOV · jogadores=%d · cabeças=%d · elegíveis=%d · mais próximo=%s · FOV=%d px", pedCount, verifiedHeads, stats.Eligible, closest, s.FOV), "", false, false)
				silentWorker.Unlock()
				continue
			}
			if silentWorker.remote == nil || silentWorker.remote.pid != viewport.PID {
				if silentWorker.remote != nil {
					_ = silentWorker.remote.close()
					silentWorker.remote = nil
				}
				if !lastFailure.IsZero() && time.Since(lastFailure) < time.Second {
					silentReport("Nova tentativa após falha de instalação", "", false, true)
					silentWorker.Unlock()
					continue
				}
				remote, e := newSilentRemote()
				if e != nil {
					lastFailure = time.Now()
					silentReport(e.Error(), "", false, true)
					silentWorker.Unlock()
					continue
				}
				if remote.pid != viewport.PID {
					lastFailure = time.Now()
					_ = remote.close()
					silentReport("PID do jogo mudou; revalidando", "", false, false)
					silentWorker.Unlock()
					continue
				}
				silentWorker.remote = remote
			}
			remote := silentWorker.remote
			e := remote.enable(head)
			if e != nil {
				lastFailure = time.Now()
				_ = remote.close()
				silentWorker.remote = nil
				silentReport("Falha no hook: "+e.Error(), remote.build, false, true)
			} else {
				lastFailure = time.Time{}
				_ = id
				silentReport(fmt.Sprintf("Hook RVA 0x%X aplicado; eficácia não validada no FiveM", remote.entryRVA), remote.build, true, true)
			}
			silentWorker.Unlock()
		}
	}()
}
