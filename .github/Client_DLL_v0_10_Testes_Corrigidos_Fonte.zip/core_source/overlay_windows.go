//go:build windows

package main

// Native, click-through FOV/ESP overlay. It draws ONLY over the currently
// focused FiveM client area. The background is a chroma key, while every
// FOV uses GDI NULL_BRUSH (no white/opaque pixels inside the circle).
import (
	"fmt"
	"math"
	"runtime"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

type CrosshairSettings struct {
	Enabled      bool   `json:"enabled"`
	Style        string `json:"style"` // dot, cross, both
	DotSize      int    `json:"dotSize"`
	StretchX     int    `json:"stretchX"`
	StretchY     int    `json:"stretchY"`
	LengthX      int    `json:"lengthX"`
	LengthY      int    `json:"lengthY"`
	Thickness    int    `json:"thickness"`
	Gap          int    `json:"gap"`
	Outline      bool   `json:"outline"`
	OutlineSize  int    `json:"outlineSize"`
	Color        string `json:"color"`
	OutlineColor string `json:"outlineColor"`
}

func normalizeCrosshair(s CrosshairSettings) CrosshairSettings {
	if s.Style != "cross" && s.Style != "both" {
		s.Style = "dot"
	}
	clamp := func(value, min, max int) int {
		if value < min {
			return min
		}
		if value > max {
			return max
		}
		return value
	}
	s.DotSize = clamp(s.DotSize, 1, 24)
	s.StretchX = clamp(s.StretchX, 0, 32)
	s.StretchY = clamp(s.StretchY, 0, 32)
	s.LengthX = clamp(s.LengthX, 1, 48)
	s.LengthY = clamp(s.LengthY, 1, 48)
	s.Thickness = clamp(s.Thickness, 1, 12)
	s.Gap = clamp(s.Gap, 0, 32)
	s.OutlineSize = clamp(s.OutlineSize, 1, 6)
	s.Color = normalizedHex(s.Color, "#FFFFFF")
	s.OutlineColor = normalizedHex(s.OutlineColor, "#000000")
	return s
}

type OverlaySettings struct {
	Crosshair     CrosshairSettings `json:"crosshair"`
	ShowAimFOV    bool              `json:"showAimFov"`
	AimRadius     int               `json:"aimRadius"`
	AimColor      string            `json:"aimColor"`
	ShowSilentFOV bool              `json:"showSilentFov"`
	SilentRadius  int               `json:"silentRadius"`
	SilentColor   string            `json:"silentColor"`
	RenderMS      int               `json:"renderMS"`
}

var overlayPaused atomic.Bool

// Paint only when a static reticle changed; never redraw a full-screen GDI
// surface 125 times a second when nothing on screen is moving.
var overlaySettingsRevision atomic.Uint64
var overlayData = struct {
	sync.RWMutex
	settings OverlaySettings
}{settings: OverlaySettings{AimRadius: 130, SilentRadius: 120, AimColor: "#FFFFFF", SilentColor: "#E50000"}}

func setOverlaySettings(s OverlaySettings) {
	s.Crosshair = normalizeCrosshair(s.Crosshair)
	s.AimColor = normalizedHex(s.AimColor, "#FFFFFF")
	s.SilentColor = normalizedHex(s.SilentColor, "#E50000")
	// Actual paint cadence is frame-driven (new ESP/radar snapshots only),
	// with a 16ms ceiling to avoid repeated full-screen BitBlts.
	s.RenderMS = 16
	if s.AimRadius < 5 {
		s.AimRadius = 5
	}
	if s.AimRadius > 500 {
		s.AimRadius = 500
	}
	if s.SilentRadius < 5 {
		s.SilentRadius = 5
	}
	if s.SilentRadius > 500 {
		s.SilentRadius = 500
	}
	overlayData.Lock()
	overlayData.settings = s
	overlayData.Unlock()
	overlaySettingsRevision.Add(1)
}
func getOverlaySettings() OverlaySettings {
	overlayData.RLock()
	defer overlayData.RUnlock()
	return overlayData.settings
}

var gdi = syscall.NewLazyDLL("gdi32.dll")
var u32 = syscall.NewLazyDLL("user32.dll")
var k32 = syscall.NewLazyDLL("kernel32.dll")
var regCls = u32.NewProc("RegisterClassExW")
var winEx = u32.NewProc("CreateWindowExW")
var defaultProc = u32.NewProc("DefWindowProcW")
var getMsg = u32.NewProc("GetMessageW")
var translateMsg = u32.NewProc("TranslateMessage")
var dispatchMsg = u32.NewProc("DispatchMessageW")
var beginPaint = u32.NewProc("BeginPaint")
var endPaint = u32.NewProc("EndPaint")
var invalidateRect = u32.NewProc("InvalidateRect")
var layeredAttr = u32.NewProc("SetLayeredWindowAttributes")
var setPos = u32.NewProc("SetWindowPos")
var showWin = u32.NewProc("ShowWindow")
var getClientRect = u32.NewProc("GetClientRect")
var toScreen = u32.NewProc("ClientToScreen")
var getWindowPidOverlay = u32.NewProc("GetWindowThreadProcessId")
var setDPIAware = u32.NewProc("SetProcessDPIAware")
var moduleHandle = k32.NewProc("GetModuleHandleW")
var fillRect = u32.NewProc("FillRect")
var solidBrush = gdi.NewProc("CreateSolidBrush")
var createPen = gdi.NewProc("CreatePen")
var selectObject = gdi.NewProc("SelectObject")
var deleteObject = gdi.NewProc("DeleteObject")
var getStock = gdi.NewProc("GetStockObject")
var ellipse = gdi.NewProc("Ellipse")
var rectangle = gdi.NewProc("Rectangle")
var textOut = gdi.NewProc("TextOutW")
var setTextColor = gdi.NewProc("SetTextColor")
var setBkMode = gdi.NewProc("SetBkMode")
var createCompatibleDC = gdi.NewProc("CreateCompatibleDC")
var createCompatibleBitmap = gdi.NewProc("CreateCompatibleBitmap")
var deleteDC = gdi.NewProc("DeleteDC")
var bitBlt = gdi.NewProc("BitBlt")
var moveTo = gdi.NewProc("MoveToEx")
var lineTo = gdi.NewProc("LineTo")

const (
	wmPaint       uintptr = 0x000F
	wsPopup       uintptr = 0x80000000
	exLayered     uintptr = 0x00080000
	exTopmost     uintptr = 0x00000008
	exTransparent uintptr = 0x00000020
	exTool        uintptr = 0x00000080
	exNoActivate  uintptr = 0x08000000
	swShowNA      uintptr = 8
	swHideOverlay uintptr = 0
	swpNoActivate uintptr = 0x0010
	keyColor      uintptr = 0x00030201
)

type wndClassEx struct {
	Size       uint32
	Style      uint32
	WndProc    uintptr
	ClsExtra   int32
	WndExtra   int32
	Instance   uintptr
	Icon       uintptr
	Cursor     uintptr
	Background uintptr
	MenuName   *uint16
	ClassName  *uint16
	IconSmall  uintptr
}
type point struct{ X, Y int32 }
type msg struct {
	Hwnd           uintptr
	Message        uint32
	WParam, LParam uintptr
	Time           uint32
	Pt             point
	Private        uint32
}
type rect struct{ Left, Top, Right, Bottom int32 }
type paintStruct struct {
	DC        uintptr
	Erase     int32
	Paint     rect
	Restore   int32
	IncUpdate int32
	Reserved  [32]byte
}

// A persistent GDI backbuffer prevents partial frames appearing during erase
// and redraw. One BitBlt presents the whole overlay on each WM_PAINT.
type overlayBackbuffer struct {
	dc, bitmap, previous uintptr
	width, height        int32
}

func (b *overlayBackbuffer) release() {
	if b.dc != 0 {
		if b.previous != 0 {
			selectObject.Call(b.dc, b.previous)
		}
		if b.bitmap != 0 {
			deleteObject.Call(b.bitmap)
		}
		deleteDC.Call(b.dc)
	}
	*b = overlayBackbuffer{}
}
func (b *overlayBackbuffer) ensure(windowDC uintptr, width, height int32) uintptr {
	if b.dc != 0 && b.width == width && b.height == height {
		return b.dc
	}
	b.release()
	if width < 1 || height < 1 {
		return 0
	}
	dc, _, _ := createCompatibleDC.Call(windowDC)
	if dc == 0 {
		return 0
	}
	bitmap, _, _ := createCompatibleBitmap.Call(windowDC, uintptr(width), uintptr(height))
	if bitmap == 0 {
		deleteDC.Call(dc)
		return 0
	}
	previous, _, _ := selectObject.Call(dc, bitmap)
	if previous == 0 {
		deleteObject.Call(bitmap)
		deleteDC.Call(dc)
		return 0
	}
	*b = overlayBackbuffer{dc: dc, bitmap: bitmap, previous: previous, width: width, height: height}
	return dc
}

// Returns the coordinates and physical pixel size of a FiveM window.
type gameViewportScan struct {
	pid     uint32
	best    espViewport
	largest int64
}

var gameViewportEnumCallback = syscall.NewCallback(func(hwnd, param uintptr) uintptr {
	entry, ok := windowEnumContexts.Load(param)
	if !ok {
		return 1
	}
	state, ok := entry.(*gameViewportScan)
	if !ok {
		return 1
	}
	var id uint32
	getWindowPidOverlay.Call(hwnd, uintptr(unsafe.Pointer(&id)))
	if id != state.pid {
		return 1
	}
	visible, _, _ := isWindowVisible.Call(hwnd)
	if visible == 0 {
		return 1
	}
	var cr rect
	if ok, _, _ := getClientRect.Call(hwnd, uintptr(unsafe.Pointer(&cr))); ok == 0 {
		return 1
	}
	w, h := cr.Right-cr.Left, cr.Bottom-cr.Top
	if w < 320 || h < 240 {
		return 1
	}
	p := point{}
	if ok, _, _ := toScreen.Call(hwnd, uintptr(unsafe.Pointer(&p))); ok == 0 {
		return 1
	}
	if area := int64(w) * int64(h); area > state.largest {
		state.largest = area
		state.best = espViewport{X: p.X, Y: p.Y, W: w, H: h, PID: state.pid}
	}
	return 1
})

func locateFiveMWindow(pid uint32) (espViewport, bool) {
	state := &gameViewportScan{pid: pid}
	enumWindowsWithContext(gameViewportEnumCallback, state)
	return state.best, state.largest > 0
}

func fiveMIsForeground(pid uint32) bool {
	hwnd, _, _ := getForeground.Call()
	if hwnd == 0 {
		return false
	}
	var id uint32
	getWindowPidOverlay.Call(hwnd, uintptr(unsafe.Pointer(&id)))
	return id == pid
}
func foregroundFiveMViewport() (espViewport, bool) {
	hwnd, _, _ := getForeground.Call()
	if hwnd == 0 || !activeFiveMWindow(hwnd) {
		return espViewport{}, false
	}
	var id uint32
	getWindowPidOverlay.Call(hwnd, uintptr(unsafe.Pointer(&id)))
	var r rect
	if ok, _, _ := getClientRect.Call(hwnd, uintptr(unsafe.Pointer(&r))); ok == 0 {
		return espViewport{}, false
	}
	p := point{}
	if ok, _, _ := toScreen.Call(hwnd, uintptr(unsafe.Pointer(&p))); ok == 0 {
		return espViewport{}, false
	}
	if r.Right-r.Left < 320 || r.Bottom-r.Top < 240 {
		return espViewport{}, false
	}
	return espViewport{X: p.X, Y: p.Y, W: r.Right - r.Left, H: r.Bottom - r.Top, PID: id}, true
}

// A complete frame is already projected by the reader. Never extrapolate
// individual boxes between frames: the bones, health bars, names and boxes
// must remain anchored to the SAME camera sample. The old code predicted
// only X/Y by up to 65% of a frame, causing visible separation from joints.
type painter struct {
	lastSeq   uint64
	lastFrame []targetESP
}

func (p *painter) positions(_ espViewport, current []targetESP, seq uint64) []targetESP {
	if seq != p.lastSeq {
		p.lastSeq = seq
		p.lastFrame = current
	}
	return p.lastFrame
}

func drawFOV(dc uintptr, cx, cy, r int32, color uintptr) {
	pen, _, _ := createPen.Call(0, 2, color)
	oldPen, _, _ := selectObject.Call(dc, pen)
	// Stock index 5 is NULL_BRUSH: circle interior is fully transparent.
	brush, _, _ := getStock.Call(5)
	oldBrush, _, _ := selectObject.Call(dc, brush)
	ellipse.Call(dc, uintptr(cx-r), uintptr(cy-r), uintptr(cx+r), uintptr(cy+r))
	selectObject.Call(dc, oldBrush)
	selectObject.Call(dc, oldPen)
	deleteObject.Call(pen)
}

// Solid, pixel-aligned GDI reticle; the overlay's chroma-key pixels remain
// transparent. The crosshair never reads or changes game memory.
func drawCrosshair(dc uintptr, cx, cy int32, raw CrosshairSettings) {
	if !raw.Enabled {
		return
	}
	s := normalizeCrosshair(raw)
	front, _, _ := solidBrush.Call(uintptr(rgbToColorRef(s.Color, 0x00FFFFFF)))
	if front == 0 {
		return
	}
	defer deleteObject.Call(front)
	outlineBrush := uintptr(0)
	if s.Outline {
		outlineBrush, _, _ = solidBrush.Call(uintptr(rgbToColorRef(s.OutlineColor, 0x00000000)))
		if outlineBrush != 0 {
			defer deleteObject.Call(outlineBrush)
		}
	}
	drawRect := func(x, y, w, h int32) {
		if w <= 0 || h <= 0 {
			return
		}
		if outlineBrush != 0 {
			p := int32(s.OutlineSize)
			outer := rect{Left: x - p, Top: y - p, Right: x + w + p, Bottom: y + h + p}
			fillRect.Call(dc, uintptr(unsafe.Pointer(&outer)), outlineBrush)
		}
		inner := rect{Left: x, Top: y, Right: x + w, Bottom: y + h}
		fillRect.Call(dc, uintptr(unsafe.Pointer(&inner)), front)
	}
	if s.Style == "dot" || s.Style == "both" {
		w := int32(s.DotSize + s.StretchX)
		h := int32(s.DotSize + s.StretchY)
		// GDI's Ellipse draws a filled, rounded point. Explicitly select the
		// stock NULL_PEN to avoid an unwanted square/dark stroke.
		nullPen, _, _ := getStock.Call(8)
		oldPen, _, _ := selectObject.Call(dc, nullPen)
		paintEllipse := func(width, height int32, brush uintptr) {
			oldBrush, _, _ := selectObject.Call(dc, brush)
			ellipse.Call(dc, uintptr(cx-width/2), uintptr(cy-height/2), uintptr(cx-width/2+width), uintptr(cy-height/2+height))
			selectObject.Call(dc, oldBrush)
		}
		if outlineBrush != 0 {
			p := int32(s.OutlineSize)
			paintEllipse(w+2*p, h+2*p, outlineBrush)
		}
		paintEllipse(w, h, front)
		selectObject.Call(dc, oldPen)
	}
	if s.Style == "cross" || s.Style == "both" {
		gap, width, lengthX, lengthY := int32(s.Gap), int32(s.Thickness), int32(s.LengthX), int32(s.LengthY)
		drawRect(cx-gap-lengthX, cy-width/2, lengthX, width)
		drawRect(cx+gap+1, cy-width/2, lengthX, width)
		drawRect(cx-width/2, cy-gap-lengthY, width, lengthY)
		drawRect(cx-width/2, cy+gap+1, width, lengthY)
	}
}
func drawESP(dc uintptr, targets []targetESP, s ESPSettings, width, height int32) {
	// All ESP elements use white by default, independently of skeleton color.
	pen, _, _ := createPen.Call(0, 1, 0x00FFFFFF)
	// Precreate both standard and friend pens once per frame. The friend palette
	// applies to every visual element, not just the player label. Each draw
	// iteration restores its own brush/pen, so colors never leak to other players.
	skeletonPen, _, _ := createPen.Call(0, 1, uintptr(rgbToColorRef(s.SkeletonColor, 0x00FFFFFF)))
	friendColor := uintptr(rgbToColorRef(s.FriendColor, 0x00A0E542))
	friendPen, _, _ := createPen.Call(0, 2, friendColor)
	friendSkeletonPen, _, _ := createPen.Call(0, 2, friendColor)
	oldPen, _, _ := selectObject.Call(dc, pen)
	brush, _, _ := getStock.Call(5)
	oldBrush, _, _ := selectObject.Call(dc, brush)
	setBkMode.Call(dc, 1)
	setTextColor.Call(dc, 0x00FFFFFF)
	for _, t := range targets {
		if (t.Vehicle && !s.Vehicles) || (!t.Vehicle && !s.Enabled) || (t.IsNPC && !s.ShowNPC) {
			continue
		}
		currentPen := pen
		if t.Friend && friendPen != 0 {
			currentPen = friendPen
		}
		if currentPen != 0 {
			selectObject.Call(dc, currentPen)
		}
		if t.Friend {
			setTextColor.Call(dc, friendColor)
		} else {
			setTextColor.Call(dc, 0x00FFFFFF)
		}
		if t.Offscreen {
			if !s.Offscreen {
				continue
			}
			// Arrowhead points outward, two short wings remain inside viewport.
			cx, cy := float64(width)/2, float64(height)/2
			dx, dy := float64(t.X)-cx, float64(t.Y)-cy
			mag := math.Hypot(dx, dy)
			if mag < 1 {
				continue
			}
			ux, uy := dx/mag, dy/mag
			bx, by := float64(t.X)-ux*17, float64(t.Y)-uy*17
			lx, ly := bx-uy*7, by+ux*7
			rx, ry := bx+uy*7, by-ux*7
			moveTo.Call(dc, uintptr(t.X), uintptr(t.Y), 0)
			lineTo.Call(dc, uintptr(int32(lx)), uintptr(int32(ly)))
			moveTo.Call(dc, uintptr(t.X), uintptr(t.Y), 0)
			lineTo.Call(dc, uintptr(int32(rx)), uintptr(int32(ry)))
			continue
		}
		if t.Focus && !t.Friend {
			setTextColor.Call(dc, 0x0000DDFF)
		}
		if s.Boxes {
			if s.BoxStyle == "full" {
				rectangle.Call(dc, uintptr(t.X), uintptr(t.Y), uintptr(t.X+t.W), uintptr(t.Y+t.H))
			} else {
				// Corner boxes are four small, transparent L-shaped outlines.
				lx := t.W / 4
				ly := t.H / 5
				if lx < 5 {
					lx = 5
				}
				if ly < 5 {
					ly = 5
				}
				for _, v := range [][4]int32{
					{t.X, t.Y, t.X + lx, t.Y}, {t.X, t.Y, t.X, t.Y + ly},
					{t.X + t.W, t.Y, t.X + t.W - lx, t.Y}, {t.X + t.W, t.Y, t.X + t.W, t.Y + ly},
					{t.X, t.Y + t.H, t.X + lx, t.Y + t.H}, {t.X, t.Y + t.H, t.X, t.Y + t.H - ly},
					{t.X + t.W, t.Y + t.H, t.X + t.W - lx, t.Y + t.H}, {t.X + t.W, t.Y + t.H, t.X + t.W, t.Y + t.H - ly},
				} {
					moveTo.Call(dc, uintptr(v[0]), uintptr(v[1]), 0)
					lineTo.Call(dc, uintptr(v[2]), uintptr(v[3]))
				}
			}
		}
		if s.Snaplines {
			moveTo.Call(dc, uintptr(width/2), uintptr(height-2), 0)
			lineTo.Call(dc, uintptr(t.X+t.W/2), uintptr(t.Y+t.H))
		}
		showName := s.Names
		showDistance := s.ShowDistance
		if t.Vehicle {
			showName = s.VehicleName
			showDistance = true
		}
		if showName || showDistance || (s.WeaponESP && t.WeaponName != "") {
			title := ""
			if showName {
				title = t.Name
				if t.Friend {
					title = "★ " + title + " (amigo)"
				}
			}
			if s.WeaponESP && t.WeaponName != "" && !t.Vehicle {
				if title != "" {
					title += " · "
				}
				title += t.WeaponName
			}
			if showDistance {
				if title != "" {
					title += " · "
				}
				title += fmt.Sprintf("%dm", t.Distance)
			}
			chars, _ := syscall.UTF16FromString(title)
			if len(chars) > 1 && t.Y >= 20 {
				textOut.Call(dc, uintptr(t.X), uintptr(t.Y-18), uintptr(unsafe.Pointer(&chars[0])), uintptr(len(chars)-1))
			}
		}
		if s.Skeleton && !t.Vehicle && len(t.Bones) > 0 {
			// Other players use the configured skeleton color; friends use their
			// exclusive color even when the default skeleton was customized.
			bonesPen := skeletonPen
			if t.Friend && friendSkeletonPen != 0 {
				bonesPen = friendSkeletonPen
			}
			if bonesPen != 0 {
				selectObject.Call(dc, bonesPen)
			}
			for _, seg := range t.Bones {
				moveTo.Call(dc, uintptr(seg[0]), uintptr(seg[1]), 0)
				lineTo.Call(dc, uintptr(seg[2]), uintptr(seg[3]))
			}
			if bonesPen != 0 {
				selectObject.Call(dc, currentPen) // Restore this entity's own color.
			}
		}
		if s.Health && !t.Vehicle {
			frac := math.Max(0, math.Min(1, (float64(t.Health)-100)/100))
			moveTo.Call(dc, uintptr(t.X-5), uintptr(t.Y+t.H), 0)
			lineTo.Call(dc, uintptr(t.X-5), uintptr(t.Y+t.H-int32(float64(t.H)*frac)))
		}
		if s.Armor && !t.Vehicle {
			frac := math.Max(0, math.Min(1, float64(t.Armor)/100))
			moveTo.Call(dc, uintptr(t.X+t.W+5), uintptr(t.Y+t.H), 0)
			lineTo.Call(dc, uintptr(t.X+t.W+5), uintptr(t.Y+t.H-int32(float64(t.H)*frac)))
		}
	}
	selectObject.Call(dc, oldBrush)
	selectObject.Call(dc, oldPen)
	deleteObject.Call(pen)
	if skeletonPen != 0 {
		deleteObject.Call(skeletonPen)
	}
	if friendPen != 0 {
		deleteObject.Call(friendPen)
	}
	if friendSkeletonPen != 0 {
		deleteObject.Call(friendSkeletonPen)
	}
}
func startOverlay() {
	go func() {
		defer recoverServiceWorker("overlay_windows.go")
		runtime.LockOSThread()
		defer runtime.UnlockOSThread()
		setDPIAware.Call()
		className, _ := syscall.UTF16PtrFromString("Sete7Overlay117")
		inst, _, _ := moduleHandle.Call(0)
		viewport := espViewport{}
		var vmu sync.RWMutex
		painter := &painter{}
		backbuffer := &overlayBackbuffer{}
		cb := syscall.NewCallback(func(hwnd, msg, wparam, lparam uintptr) uintptr {
			defer recoverServiceWorker("overlay_windows.go:native-callback")
			if msg == 0x0014 { // WM_ERASEBKGND: never show a half-erased overlay.
				return 1
			}
			if msg == wmPaint {
				var ps paintStruct
				windowDC, _, _ := beginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
				vmu.RLock()
				currentView := viewport
				vmu.RUnlock()
				dc := backbuffer.ensure(windowDC, currentView.W, currentView.H)
				if dc == 0 {
					endPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
					return 0
				}
				bg, _, _ := solidBrush.Call(keyColor)
				fillRect.Call(dc, uintptr(unsafe.Pointer(&rect{Right: currentView.W, Bottom: currentView.H})), bg)
				deleteObject.Call(bg)
				if currentView.W > 0 && !overlayPaused.Load() {
					os := getOverlaySettings()
					cx, cy := currentView.W/2, currentView.H/2
					drawCrosshair(dc, cx, cy, os.Crosshair)
					if os.ShowAimFOV {
						drawFOV(dc, cx, cy, int32(os.AimRadius), uintptr(rgbToColorRef(os.AimColor, 0x00FFFFFF)))
					}
					if os.ShowSilentFOV {
						drawFOV(dc, cx, cy, int32(os.SilentRadius), uintptr(rgbToColorRef(os.SilentColor, 0x000000E5)))
					}
					es := espGet().Settings
					radarDraw(dc, currentView.W, currentView.H, currentView.PID)
					vp, targets, seq := espRendered.snapshot(450 * time.Millisecond)
					if (es.Enabled || es.Vehicles) && vp.PID == currentView.PID && vp.W == currentView.W && vp.H == currentView.H {
						drawESP(dc, painter.positions(vp, targets, seq), es, currentView.W, currentView.H)
					}
				}
				// Present only after the whole frame has been drawn in memory.
				bitBlt.Call(windowDC, 0, 0, uintptr(currentView.W), uintptr(currentView.H), dc, 0, 0, 0x00CC0020)
				endPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
				return 0
			}
			ret, _, _ := defaultProc.Call(hwnd, msg, wparam, lparam)
			return ret
		})
		cls := wndClassEx{Size: uint32(unsafe.Sizeof(wndClassEx{})), WndProc: cb, Instance: inst, ClassName: className}
		if atom, _, _ := regCls.Call(uintptr(unsafe.Pointer(&cls))); atom == 0 {
			return
		}
		hwnd, _, _ := winEx.Call(exLayered|exTransparent|exTopmost|exTool|exNoActivate,
			uintptr(unsafe.Pointer(className)), 0, wsPopup, 0, 0, 1, 1, 0, 0, inst, 0)
		if hwnd == 0 {
			return
		}
		streamRegisterOverlay(hwnd)
		defer streamUnregisterOverlay(hwnd)
		layeredAttr.Call(hwnd, keyColor, 0, 1)
		go func() {
			defer recoverServiceWorker("overlay_windows.go")
			// 8ms checks reduce waiting for newly scanned targets; rendering itself
			// stays frame-driven and never repaints unchanged dynamic frames.
			tick := time.NewTicker(8 * time.Millisecond)
			defer tick.Stop()
			lastView := espViewport{}
			active := false
			lastCheck := time.Time{}
			paintScheduler := &overlayPaintScheduler{}
			lastOverlayRevision := uint64(0)
			lastEspSettingsRevision := uint64(0)
			lastRadarSettingsRevision := uint64(0)
			forcePaint := true
			cachedView := espViewport{}
			validCached := false
			for range tick.C {
				if overlayPaused.Load() {
					if active {
						showWin.Call(hwnd, swHideOverlay)
						active = false
					}
					forcePaint = true
					continue
				}
				if time.Since(lastCheck) >= 60*time.Millisecond {
					lastCheck = time.Now()
					cachedView, validCached = foregroundFiveMViewport()
				}
				view, ok := cachedView, validCached
				if ok && !fiveMIsForeground(view.PID) {
					ok = false
				}
				cfg := getOverlaySettings()
				esp := espGet().Settings
				needs := cfg.Crosshair.Enabled || cfg.ShowAimFOV || cfg.ShowSilentFOV || esp.Enabled || esp.Vehicles || radarGet().Enabled
				if !ok || !needs {
					if active {
						showWin.Call(hwnd, swHideOverlay)
						active = false
					}
					forcePaint = true
					continue
				}
				if view.X != lastView.X || view.Y != lastView.Y || view.W != lastView.W || view.H != lastView.H || view.PID != lastView.PID {
					vmu.Lock()
					viewport = view
					vmu.Unlock()
					setPos.Call(hwnd, ^uintptr(0), uintptr(view.X), uintptr(view.Y), uintptr(view.W), uintptr(view.H), swpNoActivate)
					lastView = view
					forcePaint = true
				}
				if !active {
					showWin.Call(hwnd, swShowNA)
					active = true
					forcePaint = true
				}
				revision := overlaySettingsRevision.Load()
				if revision != lastOverlayRevision {
					lastOverlayRevision = revision
					forcePaint = true
				}
				if revision := espSettingsRevision.Load(); revision != lastEspSettingsRevision {
					lastEspSettingsRevision = revision
					forcePaint = true
				}
				if revision := radarSettingsRevision.Load(); revision != lastRadarSettingsRevision {
					lastRadarSettingsRevision = revision
					forcePaint = true
				}
				// Draw precisely when fresh projected positions arrive.  The old
				// 33ms limit observed on a 16ms ticker often meant a 48ms
				// effective paint interval and very visible ESP delay.
				dynamic := esp.Enabled || esp.Vehicles || radarGet().Enabled
				espSeq := uint64(0)
				radarSeq := uint64(0)
				if esp.Enabled || esp.Vehicles {
					espSeq = espRendered.revision()
				}
				if radarGet().Enabled {
					radarSeq = radarFrameRevision.Load()
				}
				if paintScheduler.shouldPaint(time.Now(), dynamic, forcePaint, espSeq, radarSeq) {
					forcePaint = false
					invalidateRect.Call(hwnd, 0, 0)
				}
			}
		}()
		var m msg
		for {
			n, _, _ := getMsg.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
			if int32(n) <= 0 {
				backbuffer.release()
				return
			}
			translateMsg.Call(uintptr(unsafe.Pointer(&m)))
			dispatchMsg.Call(uintptr(unsafe.Pointer(&m)))
		}
	}()
}
