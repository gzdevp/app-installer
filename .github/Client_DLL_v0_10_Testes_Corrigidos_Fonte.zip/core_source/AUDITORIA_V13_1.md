# sete7 v13.1 — auditoria corretiva, NÃO HOMOLOGADA NO FIVEM
Data: 2026-10-27

## Veredito
A implementação foi corrigida e passou nas verificações de compilação e nos testes que podem ser executados neste ambiente. **Não está aprovada como Aimbot funcional dentro do FiveM**, pois o jogo e sua câmera real não estão disponíveis para ensaio. Portanto nenhuma afirmação de funcionamento perfeito ou compatibilidade garantida é justificada.

## Achados corrigidos em relação à v13.0
1. **Falso positivo por jitter:** `aimv13.CheckFeedback` aceitava redução de 0,21 px. Agora exige progresso maior que `max(0,8px, min(2,5px, 2,5% do erro))`.
2. **Confirmação usando frame repetido:** `aimv13.FrameGate` exige dois quadros NOVOS após a escrita, verifica sequência, resolução e timeout de 320ms; não aceita repetição de snapshot como evidência independente.
3. **Divergência vertical ocultada por progresso horizontal:** `aimv13.AxisDiverged` barra qualquer eixo cujo erro cresça mais de 2px, mesmo se a distância Euclidiana total cair.
4. **Head/Neck/Chest/Pelvis com filtro de FOV inconsistente:** o selecionador `selectAimTargetInFrame` usa a projeção do mesmo ponto 3D que o controlador efetivamente escolhe para a direção. As alturas de neck/chest/pelvis são **estimativas relativas à cabeça**, não ossos próprios.
5. **Configurações de interface sem integração:** `Visibility check`, `Multi-point`, `All entities` e fallback visual foram ocultados do Aimbot e rotulados como indisponíveis. Preferências antigas permanecem armazenadas, mas não são anunciadas como funções reais.
6. **Código morto de SendInput:** removido do módulo Aimbot para tornar inequívoco que este controlador não utiliza mouse relativo.

## Verificações realizadas
- `go test -count=1 ./aimv13`: 9 testes passaram.
- `go test -race -count=1 ./aimv13`: passou.
- `validation/selection_native/go test -count=1 -v`: 1 teste de integração do seletor passou, executando cópia literal da lógica de seleção da v13.1 em um harness Linux.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-H=windowsgui'`: passou.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test -c`: compilação de testes Windows passou, **sem execução**.
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet ./...`: passou.
- JavaScript extraído do HTML atual: `node --check` passou.
- `silent_windows.go`, `silent_patch.go`, `silent_other.go`, `noclip_windows.go`, `esp_windows.go`, `esp_stabilizer.go` e `cpp_bones.go`: idênticos bit a bit à fonte da v13.0.

## Evidências que faltam para aprovar
- Executar em Windows com FiveM real (build b3258) e verificar leitura/escrita dos dois vetores `FollowPedCamera` e a mudança **visual** da câmera.
- Confirmar matriz de projeção e câmera atual são sincronizadas e representam a mesma câmera de jogo.
- Testar movimento de câmera nos quatro quadrantes, tecla pressionada/solta, head/neck/chest, mudança de resolução, perda de alvo e distância.
- Confirmar que os campos de memória não são substituídos pelo jogo/servidor a cada quadro.
- Testes de regressão em jogo do Silent/ESP/Noclip. Comparação de código não substitui regressão funcional.

## Limitações adicionais
- Cabeça 3D é validada pelo leitor anterior, mas neck/chest/pelvis são deslocamentos estimados, não leitura de junta específica.
- Feedback de viewport em quadros novos ainda não comprova *causalidade*: movimento manual ou entidades móveis podem fazer parecer que a câmera respondeu. O algoritmo barra divergência e baixa resposta, mas não garante headlock.
- Offsets C++ são referências estáticas por build; nem toda instalação atual de FiveM foi verificada ao vivo.
- `go test ./...` na máquina Linux falha no pacote principal porque ele depende de símbolos com build tag Windows. O pacote puro `aimv13` roda nativamente; a raiz e seus testes compilam sob GOOS=windows mas não rodam aqui. Isso não deve ser escondido como sucesso de teste nativo da aplicação completa.

**Conclusão:** esta revisão melhora falhas demonstráveis da v13.0, mas continua um executável NÃO HOMOLOGADO NO FIVEM. É tecnicamente incorreto prometer 100% sem o ensaio que falta.
