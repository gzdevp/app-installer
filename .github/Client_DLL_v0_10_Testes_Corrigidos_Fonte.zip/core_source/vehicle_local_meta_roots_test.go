package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestLocalVehicleMetaScanIncludesFiveMServerCaches(t *testing.T) {
	roots := localVehicleMetaRoots(filepath.Join("C:", "Users", "Tester", "AppData", "Local"))
	if len(roots) != 4 {
		t.Fatalf("expected 4 roots, got %v", roots)
	}
	for _, dir := range []string{"server-cache", "server-cache-priv"} {
		found := false
		for _, root := range roots {
			if filepath.Base(root) == dir {
				found = true
			}
		}
		if !found {
			t.Fatalf("missing %s", dir)
		}
	}
	for _, root := range roots {
		if !strings.Contains(root, "FiveM.app") {
			t.Fatalf("unexpected root %q", root)
		}
	}
	if len(localVehicleMetaRoots("")) != 0 {
		t.Fatal("missing local app data must not select current dir")
	}
}

func TestScanCanFindReadableServerCacheVehicleMeta(t *testing.T) {
	local := t.TempDir()
	t.Setenv("LOCALAPPDATA", local)
	metaDir := filepath.Join(local, "FiveM", "FiveM.app", "data", "server-cache", "car_resource")
	if err := os.MkdirAll(metaDir, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(metaDir, "vehicles.meta"), []byte(`<CVehicleModelInfo__InitDataList><InitDatas><Item><modelName>test_r34_local_2026</modelName></Item></InitDatas></CVehicleModelInfo__InitDataList>`), 0600); err != nil {
		t.Fatal(err)
	}
	scanReadableLocalVehicleMetas()
	got, ok := storedLocalVehicleName(joaatModelName("test_r34_local_2026"))
	if !ok || got != "test_r34_local_2026" {
		t.Fatalf("local resource was missed: %q, %v", got, ok)
	}
}

func TestCustomFilenameVehicleMetaAndIgnoreUnrelatedXML(t *testing.T) {
	local := t.TempDir()
	t.Setenv("LOCALAPPDATA", local)
	dir := filepath.Join(local, "FiveM", "FiveM.app", "data", "server-cache-priv", "addons")
	if err := os.MkdirAll(dir, 0700); err != nil {
		t.Fatal(err)
	}
	vehicleXML := `<?xml version="1.0"?><CVehicleModelInfo__InitDataList><InitDatas><Item><modelName>custom_c63_test</modelName></Item></InitDatas></CVehicleModelInfo__InitDataList>`
	if err := os.WriteFile(filepath.Join(dir, "mercedes_cars.meta"), []byte(vehicleXML), 0600); err != nil {
		t.Fatal(err)
	}
	unrelated := `<CHandlingData><Item><modelName>fake_nonvehicle_test</modelName></Item></CHandlingData>`
	if err := os.WriteFile(filepath.Join(dir, "handling.meta"), []byte(unrelated), 0600); err != nil {
		t.Fatal(err)
	}
	scanReadableLocalVehicleMetas()
	if got, ok := storedLocalVehicleName(joaatModelName("custom_c63_test")); !ok || got != "custom_c63_test" {
		t.Fatalf("custom filename not read: %q %v", got, ok)
	}
	if _, ok := storedLocalVehicleName(joaatModelName("fake_nonvehicle_test")); ok {
		t.Fatal("handling metadata was incorrectly treated as a vehicle model")
	}
}
