package main

// Bounds-check the entire read, not only its first byte. Otherwise the
// external reader may request bytes outside canonical user-mode addresses.
func validProcessReadRange(addr uintptr, size int) bool {
	const maxUserAddress = uintptr(0x7FFFFFFFFFFF)
	if addr < 0x10000 || addr > maxUserAddress || size <= 0 || size > 1<<20 {
		return false
	}
	return uintptr(size-1) <= maxUserAddress-addr
}
