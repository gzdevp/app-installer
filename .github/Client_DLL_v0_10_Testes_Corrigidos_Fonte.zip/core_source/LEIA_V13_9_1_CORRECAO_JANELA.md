# sete7 v13.9.1 — correção da janela (Windows)

## Causa comprovada no código
A v13.9 alterou o HTML `<title>` de `sete7 | External v...` para `sete7 | Black Edition v13.9`, mas `isSete7BrowserTitle` em window_title.go apenas aceitava `sete7 | External v...`. Assim, o Chrome/Edge criava o processo (ícone de globo visível), mas `browserTopWindow` nunca identificava a janela e `attachBrowserToNativeHost` não conseguia incorporá-la ao painel. Pressionar INSERT não exibia o menu.

## Correção
- `window_title.go` reconhece os padrões External e Black Edition.
- `browserTopWindow` agora só seleciona a janela da v13.9.1, evitando incorporar um browser antigo que tenha ficado aberto.
- Testes incluem o título real extraído de `web/index.html` e recusa dos títulos antigos.
- `dataFolder` exclusivo `sete7-v13.9.1-data` para evitar aproveitar o perfil Chromium travado pela versão anterior.
- Não houve alteração nos módulos de jogo (ESP, radar, Silent, Aimbot, Triggerbot, Vehicle ESP, No Recoil, No Spread, Panic, etc.).

## Passos de uso
1. Fechar completamente a v13.9 antiga e sua janela de navegador que ficou aberta (ícone do globo na barra de tarefas). Se necessário, encerrar o executável v13.9 no Gerenciador de Tarefas.
2. Não executar simultaneamente outras versões do sete7 (a tecla INSERT é um atalho global exclusivo).
3. Executar este EXE v13.9.1, colocar o FiveM em primeiro plano e pressionar INSERT.
4. Se não abrir, observar se houve mensagem 'sete7 - Erro ao iniciar' e enviar o que aparece. O código não foi executado em uma sessão Windows/FiveM neste ambiente.

## Verificações automatizadas
- Testes unitários de reconhecimento da janela: aprovados no Linux via `go test window_title.go window_title_test.go`.
- `GOOS=windows GOARCH=amd64 go build`: aprovado.
- `GOOS=windows GOARCH=amd64 go vet ./...`: aprovado.
- Compilação dos testes Windows (`go test -c`): aprovada.
- Checagem sintática JS (`node --check`): aprovada.
- Efeito visual em execução real Windows/FiveM: ainda não validado.

## Backup
As v13.3 e v13.8 originais não foram modificadas. A versão v13.9 anterior também não foi modificada; esta é uma compilação corrigida, separada.
