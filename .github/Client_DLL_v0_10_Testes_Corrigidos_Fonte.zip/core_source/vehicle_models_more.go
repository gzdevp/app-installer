package main

// Nomes oficiais do GTA V adicionados nesta atualização.
// Hash JOAAT calculado a partir do nome de spawn, não de ponteiros supostos.
var recognizedVehicleModelsMore = map[uint32]string{
	165968051:  "Buffalo EVX",               // buffalo5
	177270108:  "Phantom Custom",            // phantom3
	196747873:  "Elegy Retro Custom",        // elegy
	274946574:  "Obey 10F Widebody",         // tenf2
	290013743:  "Shitzu Tropic",             // tropic
	353883353:  "Police Maverick",           // polmav
	464687292:  "Declasse Tornado",          // tornado
	523724515:  "Voodoo Custom",             // voodoo2
	534258863:  "Space Docker",              // dune2
	682434785:  "Armored Boxville",          // boxville5
	686471183:  "Obey 8F Drafter",           // drafter
	728350375:  "Benson",                    // benson2
	838982985:  "Karin 190z",                // z190
	873639469:  "Übermacht Sentinel XS",     // sentinel2
	886934177:  "Karin Intruder",            // intruder
	893081117:  "Burrito",                   // burrito4
	908965411:  "Pfister Comet Safari",      // comet8
	970356638:  "Western Duster",            // duster
	1039032026: "Blista Compact",            // blista2
	1063483177: "Pfister Comet",             // comet
	1076201208: "Annis 300R",                // r300
	1104234922: "Sentinel Classic",          // sentinel3
	1107404867: "Peyote Custom",             // peyote3
	1132262048: "Burrito",                   // burrito5
	1177543287: "Benefactor Dubsta",         // dubsta
	1208856469: "Eudora Taxi",               // taxi2
	1336514315: "Hotring Hellfire",          // gauntlet6
	1343932732: "Mule",                      // mule5
	1348744438: "Übermacht Oracle",          // oracle
	1349725314: "Übermacht Sentinel",        // sentinel
	1353720154: "MTL Flatbed",               // flatbed
	1448677353: "Tropic",                    // tropic2
	1484920335: "Jester RR",                 // jester5
	1531094468: "Tornado Conversível",       // tornado2
	1542143200: "Scarab Future Shock",       // scarab2
	1579902654: "Dominator FX",              // dominator10
	1717532765: "Manana Custom",             // manana2
	1762279763: "Tornado Enferrujado",       // tornado3
	1830407356: "Vapid Peyote",              // peyote
	1897744184: "Dune FAV",                  // dune3
	1909141499: "Cheval Fugitive",           // fugitive
	1922255844: "Schafter LWB Blindado",     // schafter6
	1941029835: "Tourbus",                   // tourbus
	1981688531: "Titan",                     // titan
	2006667053: "Declasse Voodoo",           // voodoo
	2038480341: "Annis Euros",               // euros
	2044532910: "HVY Menacer",               // menacer
	2053223216: "Benson",                    // benson
	2166734073: "Nagasaki Blazer",           // blazer
	2170765704: "Albany Manana",             // manana
	2172320429: "Gauntlet Classic Custom",   // gauntlet5
	2175389151: "Willard Faction",           // faction
	2194326579: "Tug",                       // tug
	2254540506: "Primo Custom",              // primo2
	2255212070: "Faction Custom Donk",       // faction3
	2261744861: "Tornado Enferrujado",       // tornado4
	2336538363: "Coquette D10 Pursuit",      // coquette5
	2411098011: "Declasse Premier",          // premier
	2411965148: "Emperor Enferrujado",       // emperor2
	2490551588: "Peyote Gasser",             // peyote2
	2497353967: "Tornado Custom",            // tornado5
	2504420315: "Faction Custom",            // faction2
	2518351607: "Rumpo",                     // rumpo2
	2519238556: "Declasse Granger",          // granger
	2601952180: "RCV",                       // riot2
	2620582743: "Police Stanier LE Cruiser", // police5
	2633113103: "Dune Buggy",                // dune
	2704629607: "Aqua Blazer",               // blazer5
	2736567667: "Tornado Rat Rod",           // tornado6
	2817386317: "Vapid Stanier",             // stanier
	2849646347: "Stanier LE Cruiser",        // stanier2
	2919906639: "Dominator Future Shock",    // dominator5
	2938086457: "Sentinel Classic Widebody", // sentinel4
	2949104528: "Sultan RS Classic",         // sultanrsclassic
	2971866336: "Towtruck",                  // towtruck
	2999939664: "Buckingham Nimbus",         // nimbus
	3001042683: "Dominator Nightmare",       // dominator6
	3005245074: "Vulcar Ingot",              // ingot
	3025077634: "Hot Rod Blazer",            // blazer3
	3045179290: "Willard Eudora",            // eudora
	3050505892: "Obey Tailgater S",          // tailgater2
	3057713523: "Dubsta 6x6",                // dubsta3
	3061159916: "Race Bike",                 // tribike2
	3089277354: "Police Riot",               // riot
	3144368207: "Albany Primo",              // primo
	3147997943: "Scarab Apocalypse",         // scarab
	3196165219: "Rental Shuttle Bus",        // rentalbus
	3286105550: "Obey Tailgater",            // tailgater
	3314393930: "Dinghy Armado",             // dinghy5
	3338918751: "Taxi",                      // taxi
	3400983137: "Obey 10F",                  // tenf
	3406724313: "Schafter V12 Blindado",     // schafter5
	3452201761: "Boxville",                  // boxville6
	3467805257: "Ramp Buggy",                // dune4
	3606777648: "Dominator Apocalypse",      // dominator4
	3609690755: "Albany Emperor",            // emperor
	3623402354: "Towtruck",                  // towtruck3
	3624880708: "Mil-Spec Patriot",          // patriot3
	3634959571: "Banshee GTS",               // banshee3
	3703315515: "Go Go Monkey Blista",       // blista3
	3708664624: "Sultan RS Classic",         // sultan4
	3715219435: "Scarab Nightmare",          // scarab3
	3728579874: "Elegy RH8",                 // elegy2
	3783366066: "Oracle XS",                 // oracle2
	3852654278: "Towtruck",                  // towtruck2
	3853757601: "Dominator GT",              // dominator9
	3854198872: "Street Blazer",             // blazer4
	3894672200: "Race Bike",                 // tribike3
	3900892662: "Dubsta",                    // dubsta2
	3945366167: "BF Bifta",                  // bifta
	3982671785: "Ramp Buggy",                // dune5
	4033620423: "Granger 3600LX",            // granger2
	4246935337: "Lifeguard Blazer",          // blazer2
	4280472072: "Dundreary Regina",          // regina
}
