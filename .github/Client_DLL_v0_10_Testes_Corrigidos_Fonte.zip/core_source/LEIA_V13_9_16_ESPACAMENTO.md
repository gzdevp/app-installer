# Sete7 v13.9.16 — Espaçamento discreto

Mudança pontual: nome **Sete7** na lateral, de `letter-spacing: -.025em` para `letter-spacing: .25px`.

Logo, dimensões, transparência, fonte Inter e módulos do jogo preservados integralmente.

Nova versão do título e pasta de dados isolada (`sete7-v13.9.16-data`) para não interferir na instalação anterior.

A compilação valida o executável; a aparência no FiveM permanece pendente de teste.
