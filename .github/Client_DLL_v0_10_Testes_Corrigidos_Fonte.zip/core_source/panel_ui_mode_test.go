package main

import "testing"

func TestMenuWindowStartsCompactAndExpandsAfterLogin(t *testing.T) {
	menuAuthenticated.Store(false)
	defer menuAuthenticated.Store(false)
	w, h := menuDimensions()
	if w != 480 || h != 570 {
		t.Fatalf("login dimensions = %dx%d", w, h)
	}
	menuAuthenticated.Store(true)
	w, h = menuDimensions()
	if w != 1120 || h != 740 {
		t.Fatalf("dashboard dimensions = %dx%d", w, h)
	}
}
