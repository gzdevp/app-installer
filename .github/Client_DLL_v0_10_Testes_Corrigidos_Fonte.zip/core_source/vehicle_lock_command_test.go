package main

import "testing"

func TestVehicleLockCommandValidation(t *testing.T) {
	for _, v := range []string{"lock", "unlock", "trancar", "destrancar", "veh_lock"} {
		if !lockCommandPattern.MatchString(v) {
			t.Fatalf("valid command rejected: %s", v)
		}
	}
	for _, v := range []string{"", "/lock;quit", "lock anything", "x\nquit", "../a", "ThisCommandIsMuchMuchMuchTooLong"} {
		if lockCommandPattern.MatchString(v) {
			t.Fatalf("invalid command accepted: %q", v)
		}
	}
}
