# Sete7 v13.9.20 — correção da captura de atalhos

## Problema relatado
Ao clicar no botão compacto para definir a tecla, o clique era reconhecido, mas o teclado não chegava ao Chromium incorporado na janela Win32.

## Alterações
- Mantida a captura por eventos do navegador como fallback.
- Acrescentado capturador **nativo e temporário**, acionado apenas quando se clica no botão de atribuição de atalho no painel visível. Usa `GetAsyncKeyState` e **não instala hook global**, não registra digitação, não escreve logs de teclas.
- A interface solicita a leitura nativa via endpoint local autenticado, consulta em intervalos de 35 ms e aplica a tecla reconhecida ao mesmo campo de configuração já usado pelos módulos existentes.
- Ignora teclas que já estavam pressionadas quando o botão de captura foi acionado (evita capturar o próprio clique Mouse 1); a tecla precisa ser solta e pressionada de novo.
- Depois da escolha, ao cancelar ou após 12 s, a captura para. ESC cancela quando o navegador recebe esse evento.
- Respeita as teclas reservadas Insert e F6 e recusa duplicações e Mouse 1 no Triggerbot.
- Aplica apenas quando o menu está aberto e o foreground é Sete7 ou FiveM. Trocar para outra aplicação cancela.

## O que não mudou
A lógica de Aimbot, Silent, ESP, veículo, Radar, No Recoil/Spread e demais recursos não foi alterada. O EXE continua sem criar pastas de dados ao lado dele; usa arquivos de sessão em `%TEMP%`.

## Limitações
Testes de código, compilação Windows e teste da interface no Chromium isolado passaram. A captura nativa ainda não foi testada em um Windows real com FiveM; a correção é direcionada ao problema observado e requer teste do usuário. O jogo pode tratar algumas teclas reservadas ou interceptadas de forma diferente.
