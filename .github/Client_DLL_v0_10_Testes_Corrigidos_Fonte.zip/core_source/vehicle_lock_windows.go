//go:build windows

package main

import (
	"fmt"
	"strings"
	"sync"
	"time"
	"unsafe"
)

// Only an existing, server-authorized chat command is submitted.
// This does not change arbitrary vehicle memory or circumvent city keys.
var vehicleLockActionMutex sync.Mutex

const vehicleInputKey = 1
const vehicleKeyup = 0x0002
const vehicleUnicode = 0x0004

type vehicleKeyboardInput struct {
	VK        uint16
	Scan      uint16
	Flags     uint32
	Time      uint32
	ExtraInfo uintptr
}
type vehicleInput struct {
	Kind     uint32
	_        uint32
	Keyboard vehicleKeyboardInput
	_        [8]byte // INPUT union is 32 bytes on windows/amd64
}

func sendVehicleKeyboard(vk, scan uint16, flags uint32) bool {
	in := vehicleInput{Kind: vehicleInputKey, Keyboard: vehicleKeyboardInput{VK: vk, Scan: scan, Flags: flags}}
	sent, _, _ := reviveCitySendInput.Call(1, uintptr(unsafe.Pointer(&in)), unsafe.Sizeof(in))
	return sent == 1
}
func pressVehicleKey(vk uint16) bool {
	if !sendVehicleKeyboard(vk, 0, 0) {
		return false
	}
	time.Sleep(25 * time.Millisecond)
	return sendVehicleKeyboard(vk, 0, vehicleKeyup)
}
func sendVehicleText(value string) bool {
	for _, r := range value {
		if r > 127 {
			return false
		}
		if !sendVehicleKeyboard(0, uint16(r), vehicleUnicode) {
			return false
		}
		if !sendVehicleKeyboard(0, uint16(r), vehicleUnicode|vehicleKeyup) {
			return false
		}
		time.Sleep(9 * time.Millisecond)
	}
	return true
}
func selectedCurrentVehicle(id uint64) bool {
	f := vehicleEspGet()
	if id == 0 || f.PID == 0 || f.Count == 0 {
		return false
	}
	for _, car := range f.Cars {
		if car.ID == id && car.IsLocal {
			return true
		}
	}
	return false
}

// A verified foreground FiveM window is required. Sending an input is never
// proof that a server authorized or applied a vehicle-state change.
func submitCityVehicleInput(command, key string) (string, bool) {
	command = strings.TrimSpace(strings.TrimPrefix(command, "/"))
	key = strings.TrimSpace(key)
	if command == "" && key == "" {
		return "Configure um comando ou tecla do servidor em Vehicles", false
	}
	if command != "" && !lockCommandPattern.MatchString(command) {
		return "Comando inválido; use apenas letras, números, - ou _", false
	}
	var vk uint16
	if command == "" {
		var ok bool
		vk, ok = vehicleVK(key)
		if !ok {
			return "Tecla inválida (ex.: L, U, F3, NUM1)", false
		}
	}
	hwnd, ok := locateAnyFiveMWindow()
	if !ok {
		return "FiveM não encontrado", false
	}
	panel := menuWindow()
	wasMenuWanted := menuWanted.Load()
	// Hide briefly to let FiveM receive the configured key/chat command.
	// This action is not an Unload: restore the previous INSERT state when
	// the input has been sent (including an early error return).
	menuWanted.Store(false)
	defer func() {
		if wasMenuWanted {
			menuWanted.Store(true)
			uiOpeningDeadline.Store(time.Now().Add(5 * time.Second).UnixNano())
		}
	}()
	if panel != 0 {
		showWindow.Call(panel, swHide)
	}
	setForeground.Call(hwnd)
	time.Sleep(190 * time.Millisecond)
	fg, _, _ := getForeground.Call()
	if fg != hwnd || !activeFiveMWindow(fg) {
		return "Ação cancelada: FiveM sem foco", false
	}
	if command == "" {
		if !pressVehicleKey(vk) {
			return "Falha ao enviar tecla ao jogo", false
		}
		return fmt.Sprintf("Tecla %s enviada; estado do veículo depende do servidor", strings.ToUpper(key)), true
	}
	if !pressVehicleKey(0x54) {
		return "Não foi possível abrir o chat do jogo", false
	}
	time.Sleep(180 * time.Millisecond)
	if !sendVehicleText("/" + command) {
		return "Não foi possível digitar comando", false
	}
	time.Sleep(40 * time.Millisecond)
	if !pressVehicleKey(0x0D) {
		return "Não foi possível confirmar comando", false
	}
	return fmt.Sprintf("Comando /%s enviado; resultado depende do servidor", command), true
}

func vehicleLockActionForID(vehicleID uint64, lock bool, command, key string) (string, bool) {
	vehicleLockActionMutex.Lock()
	defer vehicleLockActionMutex.Unlock()
	// The server controls which nearby/owned vehicle the configured command
	// applies to. An ESP memory address cannot name a network vehicle to it.
	_ = vehicleID
	status, sent := submitCityVehicleInput(command, key)
	if !sent {
		return status, false
	}
	action := "Destrancar"
	if lock {
		action = "Trancar"
	}
	return action + " solicitado: " + status, true
}
