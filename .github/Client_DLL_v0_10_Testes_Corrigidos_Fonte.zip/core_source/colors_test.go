package main

import "testing"

func TestWindowsColors(t *testing.T) {
	for _, tc := range []struct {
		hex      string
		expected uint32
	}{
		{"#FFFFFF", 0xFFFFFF}, {"#000000", 0x0},
		{"#FF0000", 0x0000FF}, {"#00FF00", 0x00FF00},
		{"#0000FF", 0xFF0000}, {"#8155D4", 0xD45581},
		{"#12AbFf", 0xFFAB12},
	} {
		if got := rgbToColorRef(tc.hex, 0x12345678); got != tc.expected {
			t.Errorf("%s: %#x != %#x", tc.hex, got, tc.expected)
		}
	}
	if got := rgbToColorRef("bad", 0xFFFFFF); got != 0xFFFFFF {
		t.Fatal(got)
	}
	if got := rgbToColorRef("#GG0000", 0xFFFFFF); got != 0xFFFFFF {
		t.Fatal(got)
	}
	if got := normalizedHex("#abc123", "#FFFFFF"); got != "#ABC123" {
		t.Fatal(got)
	}
}
