# sete7 v13.9.30 — instalação local do pacote de materiais RPF

Esta versão substitui a exportação avulsa de `materials.dat` como única etapa por um instalador de pacote RPF7 OPEN de materiais do GTA V. Ela não é uma função universal, não ignora pure mode e não garante atravessar todas as paredes.

## Na aba AIM > Through Wall

- Feche totalmente o FiveM antes de instalar.
- Clique **Instalar pacote ShootThru no FiveM** e escolha o seu `materials.dat` original (formato de texto, limite 1 MiB). O sete7 modifica a coluna `ShootThru` de 0 para 1 no conteúdo do pacote, sem modificar o arquivo original.
- O instalador cria `zz_sete7_shootthru.rpf` em `%LOCALAPPDATA%\FiveM\FiveM.app\mods`, na instalação padrão. O pacote contém `assembly.xml`, a pasta `content` e o arquivo `materials.dat` modificado, como requerido pelo loader de mods FiveM. A instalação portátil ainda não é reconhecida.
- Reinicie o FiveM para carregar o pacote. Em servidores com pure mode, o mod pode ser bloqueado. A aplicação no jogo e os efeitos em colisão/dano ainda **não foram validados**.
- Para desfazer, feche o FiveM e clique **Remover pacote ShootThru**. Ele só remove o arquivo do sete7 quando a identificação é confirmada; não altera arquivos base do GTA V ou arquivos de outros mods.

## Preservação

Os arquivos existentes de Silent Aim, ESP, AIM, veículo etc. foram mantidos. A lógica de penetração nativa experimental original também permanece no programa; o pacote RPF é um caminho separado.

## Verificações de desenvolvimento

- A compilação Windows amd64 sem CGO foi concluída.
- O teste isolado `go test throughwall_rpf.go throughwall_rpf_test.go` passou.
- O JavaScript da interface passou em `node --check`.
- Não houve teste dentro de GTA V/FiveM Windows nesta sessão.
