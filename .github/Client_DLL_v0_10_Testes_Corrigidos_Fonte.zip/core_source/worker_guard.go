package main

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime/debug"
	"sync"
	"time"
)

var guardLogMutex sync.Mutex

// writeCrashRecord writes only technical service/worker errors. The file is
// outside the disposable browser profile so it survives an unexpected exit.
// Cleaner can remove it as a 77-owned file. It never includes session keys,
// HTTP URLs, usernames or game memory.
func writeCrashRecord(area, detail string) {
	guardLogMutex.Lock()
	defer guardLogMutex.Unlock()
	path := filepath.Join(os.TempDir(), "77-diagnostics.log")
	if info, err := os.Stat(path); err == nil && info.Size() > 256*1024 {
		_ = os.Remove(path)
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = fmt.Fprintf(f, "%s [%s] %s\n", time.Now().Format(time.RFC3339), area, detail)
}

// A panic in an optional worker must not terminate the entire GUI. The worker
// is stopped and its failure recorded, rather than hiding it or inventing success.
func recoverServiceWorker(area string) {
	if v := recover(); v != nil {
		stack := debug.Stack()
		if len(stack) > 2500 {
			stack = stack[:2500]
		}
		writeCrashRecord(area, fmt.Sprintf("panic type %T\n%s", v, stack))
	}
}

// restart an essential worker after a recovered panic; never restart after a
// normal return, and never make an unbounded crash loop.
var workerRestartState = struct {
	sync.Mutex
	times map[string][]time.Time
}{times: make(map[string][]time.Time)}

func guardedEssentialWorker(area string, run func()) {
	for {
		crashed := false
		func() {
			defer func() {
				if v := recover(); v != nil {
					crashed = true
					stack := debug.Stack()
					if len(stack) > 2500 {
						stack = stack[:2500]
					}
					writeCrashRecord(area, fmt.Sprintf("panic type %T\n%s", v, stack))
				}
			}()
			run()
		}()
		if !crashed {
			return
		}
		workerRestartState.Lock()
		now := time.Now()
		previous := workerRestartState.times[area]
		recent := make([]time.Time, 0, len(previous)+1)
		for _, t := range previous {
			if now.Sub(t) < time.Minute {
				recent = append(recent, t)
			}
		}
		recent = append(recent, now)
		workerRestartState.times[area] = recent
		workerRestartState.Unlock()
		if len(recent) > 3 {
			writeCrashRecord(area, "worker restart limit reached; main panel remains running")
			return
		}
		time.Sleep(1500 * time.Millisecond)
	}
}
