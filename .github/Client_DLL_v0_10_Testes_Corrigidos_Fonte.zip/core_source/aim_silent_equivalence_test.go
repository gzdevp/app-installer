//go:build windows

package main

import "testing"

func TestAimHeadMatchesValidatedSilentHead(t *testing.T) {
	s := AimSettings{Enabled: true, Bone: "head", FOV: 500, Range: 100}
	x := targetESP{PedID: 42, X: 940, Y: 480, W: 50, H: 180, Distance: 12,
		AimX: 960, AimY: 495, AimFromBone: true,
		World: vec3{X: 100, Y: 200, Z: 30}, HeadWorld: vec3{X: 100, Y: 200, Z: 31}}
	if _, ok := selectAimTarget([]targetESP{x}, 1920, 1080, s, 0); ok {
		t.Fatal("accepted unverified head")
	}
	x.HeadVerified = true
	if got, ok := selectAimTarget([]targetESP{x}, 1920, 1080, s, 0); !ok || !got.RealBone || got.Y != 495 {
		t.Fatalf("missing verified head: %+v %v", got, ok)
	}
	x.HeadWorld = vec3{X: 100, Y: 200, Z: 40}
	if _, ok := selectAimTarget([]targetESP{x}, 1920, 1080, s, 0); ok {
		t.Fatal("accepted implausible head offset")
	}
}
