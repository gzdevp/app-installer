package main

// Identified vanilla model hashes: this is an opt-in read-only allowlist.
// For unknown hashes (including DLC and custom models), do not infer a fake name.
var recognizedVehicleModels = map[uint32]string{
	1118611807: "Asbo", 3950024287: "Blista", 1549126457: "Brioso R/A", 1429622905: "Brioso 300", 15214558: "Brioso 300 Widebody",
	2196012677: "Club", 3164157193: "Dilettante", 1682114128: "Dilettante", 3117103977: "Issi", 931280609: "Issi Classic",
	628003514: "Apocalypse Issi", 1537277726: "Future Shock Issi", 1239571361: "Nightmare Issi", 409049982: "Blista Kanjo", 3863274624: "Panto",
	2844316578: "Prairie", 841808271: "Rhapsody", 1644055914: "Weevil", 3078201489: "Truffade Adder", 1283517198: "Airbus",
	1560980623: "Airtug", 1672195559: "Akuma", 767087018: "Alpha", 1171614426: "Ambulance", 837858166: "Annihilator",
	562680400: "APC", 159274291: "Ardent", 2485144969: "Asea", 2391954683: "Asterope", 2154536331: "Bagger",
	3486135912: "Baller", 142944341: "Baller II", 1878062887: "Baller III", 634118882: "Baller IV", 470404958: "Baller V",
	666166960: "Baller VI", 3253274834: "Banshee", 633712403: "Banshee 900R", 2598821281: "Bullet", 2983812512: "Cheetah",
	3003014393: "Entity XF", 1426219628: "FMJ", 418536135: "Infernus", 1987142870: "Osiris", 2536829930: "Penetrator",
	2922118804: "Kuruma", 410882957: "Kuruma Blindado", 2997294755: "Jester", 3188613414: "Jester (Corrida)", 4080061290: "Jester Classic",
	2712905841: "Jester RR", 3963499524: "Itali GTO", 3145241962: "Itali RSX", 482197771: "Lynx",
	972671128: "Tampa", 3084515313: "Tampa Armado", 2536587772: "Vigero ZX", 3796912450: "Virgo",
	3469130167: "Vigero", 1923400478: "Stallion", 3833117047: "Tahoma Coupe", 1742022738: "Slamvan Nightmare",
	1854776567: "Issi Sport", 4086055493: "Jugular", 544021352: "Khamelion", 3460613305: "Komoda", 3353694737: "Locust",
	3484649228: "Speedo", 219613597: "Speedo Custom", 699456151: "Surfer", 1951180813: "Taco Van", 65402552: "Youga",
	3817135397: "Conada", 744705981: "Frogger", 2310691317: "Havok", 4252008158: "FH-1 Hunter", 2634305738: "Maverick",
}

func vehicleNameByHash(hash uint32) (string, bool) {
	name, ok := recognizedVehicleModels[hash]
	if !ok {
		name, ok = recognizedVehicleModelsExtra[hash]
	}
	if !ok {
		name, ok = recognizedVehicleModelsMore[hash]
	}
	if !ok {
		name, ok = recognizedVehicleModelsVerified67[hash]
	}
	if !ok {
		name, ok = recognizedVehicleModelsV14[hash]
	}
	return name, ok
}
