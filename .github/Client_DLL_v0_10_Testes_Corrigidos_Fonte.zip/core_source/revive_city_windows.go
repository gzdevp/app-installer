//go:build windows

package main

import (
	"fmt"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

var reviveCityActionMutex sync.Mutex
var reviveCityUser32 = syscall.NewLazyDLL("user32.dll")
var reviveCitySetCursor = reviveCityUser32.NewProc("SetCursorPos")
var reviveCitySendInput = reviveCityUser32.NewProc("SendInput")

const reviveCityInputMouse = 0
const reviveCityMouseDown = 0x0002
const reviveCityMouseUp = 0x0004

type reviveCityMouseInput struct {
	Dx        int32
	Dy        int32
	MouseData uint32
	Flags     uint32
	Time      uint32
	ExtraInfo uintptr
}
type reviveCityInput struct {
	Kind  uint32
	_     uint32 // x64 alignment
	Mouse reviveCityMouseInput
}

func reviveCitySendClick(flags uint32) bool {
	input := reviveCityInput{Kind: reviveCityInputMouse, Mouse: reviveCityMouseInput{Flags: flags}}
	r, _, _ := reviveCitySendInput.Call(1, uintptr(unsafe.Pointer(&input)), unsafe.Sizeof(input))
	return r == 1
}

// reviveCityMenuAction only activates the user-visible REVIVER option already
// provided by the city's death screen. It does not modify local HP, inject
// game functions, clear medical flags, or attempt to evade server restrictions.
// A click request is not evidence that the city accepted resurrection.
func reviveCityMenuAction() (string, bool) {
	reviveCityActionMutex.Lock()
	defer reviveCityActionMutex.Unlock()

	game, ok := locateAnyFiveMWindow()
	if !ok {
		return playerVitalsReport("Reviver: FiveM não detectado", false)
	}
	var client rect
	if r, _, _ := getClientRect.Call(game, uintptr(unsafe.Pointer(&client))); r == 0 {
		return playerVitalsReport("Reviver: janela do jogo indisponível", false)
	}
	origin := point{}
	if r, _, _ := toScreen.Call(game, uintptr(unsafe.Pointer(&origin))); r == 0 {
		return playerVitalsReport("Reviver: janela do jogo sem coordenadas", false)
	}
	x, y, ok := reviveCityButtonTarget(origin.X, origin.Y, client.Right-client.Left, client.Bottom-client.Top)
	if !ok {
		return playerVitalsReport("Reviver: resolução da janela incompatível", false)
	}

	// Close only sete7's own menu and return focus to the existing FiveM window.
	panel := menuWindow()
	menuWanted.Store(false)
	if panel != 0 {
		showWindow.Call(panel, swHide)
	}
	setForeground.Call(game)
	time.Sleep(160 * time.Millisecond)
	foreground, _, _ := getForeground.Call()
	if foreground != game || !activeFiveMWindow(foreground) {
		return playerVitalsReport("Reviver: FiveM não recebeu foco; clique cancelado", false)
	}
	if r, _, _ := reviveCitySetCursor.Call(uintptr(x), uintptr(y)); r == 0 {
		return playerVitalsReport("Reviver: não foi possível apontar para a opção da cidade", false)
	}
	time.Sleep(35 * time.Millisecond)
	if !reviveCitySendClick(reviveCityMouseDown) {
		return playerVitalsReport("Reviver: falha ao enviar clique", false)
	}
	time.Sleep(45 * time.Millisecond)
	if !reviveCitySendClick(reviveCityMouseUp) {
		return playerVitalsReport("Reviver: falha ao soltar o clique", false)
	}
	return playerVitalsReport(fmt.Sprintf("Reviver: clique enviado à opção da cidade (%d,%d); resultado depende do servidor", x, y), true)
}
