//go:build windows && cgo

package main

/*
#include <stdint.h>
*/
import "C"

import (
	"fmt"
	"runtime"
	"sync/atomic"
)

// A DLL running in our own authorized host, never injected into another process.
var dllRunning atomic.Bool
var dllEverStarted atomic.Bool
var dllCleanupRequested atomic.Bool

func managedDLLMode() bool { return dllRunning.Load() }
func markManagedCleanup()  { dllCleanupRequested.Store(true) }

//export CoreABIVersion
func CoreABIVersion() C.int { return 2 }

//export CoreProbe
func CoreProbe() C.int { return 6042 }

//export CoreStart
func CoreStart() (exitCode C.int) {
	// A Go runtime loaded from a Windows DLL is not safely restartable
	// after all worker goroutines and GUI hooks have been torn down.
	if !dllEverStarted.CompareAndSwap(false, true) {
		return 4
	}
	if !dllRunning.CompareAndSwap(false, true) {
		return 2
	}
	dllCleanupRequested.Store(false)
	defer dllRunning.Store(false)
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	defer func() {
		if p := recover(); p != nil {
			writeCrashRecord("dll-core", fmt.Sprintf("panic: %v", p))
			exitCode = 3
		}
	}()
	if err := run(); err != nil {
		writeCrashRecord("dll-core", fmt.Sprintf("run error: %v", err))
		showStartupError("Client: " + err.Error())
		return 1
	}
	if dllCleanupRequested.Load() {
		// Signal the authorized host to request verified uninstall outside the DLL.
		// Do not self-delete the loaded host or DLL from inside CoreStart.
		return 77
	}
	return 0
}
