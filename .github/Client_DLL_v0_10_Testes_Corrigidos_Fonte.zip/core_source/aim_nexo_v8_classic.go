package main

import "math"

// classicNexoV8Step is derived from the early Nexo v8 public source patch.
// This does NOT mean the 8.4 updater binary has been decompiled or relinked.
// Smooth 12 reproduces its quarter-speed correction and 32-unit cap.
func classicNexoV8Step(targetX, targetY, viewW, viewH, smooth float64) (int32, int32, bool) {
	for _, value := range []float64{targetX, targetY, viewW, viewH, smooth} {
		if math.IsNaN(value) || math.IsInf(value, 0) {
			return 0, 0, false
		}
	}
	if viewW < 320 || viewH < 240 || targetX < 0 || targetX >= viewW || targetY < 0 || targetY >= viewH {
		return 0, 0, false
	}
	smooth = math.Max(1, math.Min(20, smooth))
	factor := 3.0 / smooth
	dx := math.Max(-32, math.Min(32, (targetX-viewW/2)*factor))
	dy := math.Max(-32, math.Min(32, (targetY-viewH/2)*factor))
	if math.Abs(dx) < 1.25 && math.Abs(dy) < 1.25 {
		return 0, 0, false
	}
	ix, iy := int32(math.Round(dx)), int32(math.Round(dy))
	return ix, iy, ix != 0 || iy != 0
}
