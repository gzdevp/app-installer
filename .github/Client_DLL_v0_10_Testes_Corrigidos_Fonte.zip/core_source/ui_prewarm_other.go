//go:build !windows

package main

func prewarmMenuBrowser(s *service) {}
