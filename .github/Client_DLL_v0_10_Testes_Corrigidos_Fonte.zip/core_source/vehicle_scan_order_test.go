package main

import (
	"os"
	"strings"
	"testing"
)

func TestVehicleScanIndependentOfPedList(t *testing.T) {
	code, err := os.ReadFile("esp_windows.go")
	if err != nil {
		t.Fatal(err)
	}
	s := string(code)
	a := strings.Index(s, "carList = p.scanNearbyVehicles(replay, origin, settings.VehicleRange, settings.VehicleAliases)")
	b := strings.Index(s, `return fail("Interface de personagens ausente")`)
	if a < 0 || b < 0 || a > b {
		t.Fatalf("vehicle scan still depends on a successful ped-interface validation")
	}
}
