package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const (
	ownedSessionPrefix    = "Sete7-session-"
	sessionOwnerFile      = ".77-session-owner.json"
	sessionOwnerSignature = "77-black-edition-disposable-session-v1"
	minimumAbandonedAge   = 24 * time.Hour
	maxAbandonedSessions  = 24
	maxSessionEntries     = 80000
)

type sessionOwnership struct {
	Signature string `json:"signature"`
	PID       int    `json:"pid"`
	Created   int64  `json:"created_unix"`
}

func writeSessionOwnership(folder string) error {
	marker := sessionOwnership{Signature: sessionOwnerSignature, PID: os.Getpid(), Created: time.Now().Unix()}
	b, err := json.Marshal(marker)
	if err != nil {
		return err
	}
	f, err := os.OpenFile(filepath.Join(folder, sessionOwnerFile), os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	if _, err = f.Write(b); err != nil {
		_ = f.Close()
		return err
	}
	return f.Close()
}

// Ownership comes from the exact temp-root parent and dedicated random folder
// name, never from a caller-controlled glob or an arbitrary path.
func ownedSessionDirectory(folder, tempRoot string) (string, error) {
	abs, err := filepath.Abs(folder)
	if err != nil {
		return "", err
	}
	root, err := filepath.Abs(tempRoot)
	if err != nil {
		return "", err
	}
	base := filepath.Base(abs)
	if filepath.Clean(filepath.Dir(abs)) != filepath.Clean(root) ||
		!strings.HasPrefix(base, ownedSessionPrefix) ||
		len(base) <= len(ownedSessionPrefix) {
		return "", errors.New("cleanup outside owned temporary session refused")
	}
	fi, err := os.Lstat(abs)
	if os.IsNotExist(err) {
		return abs, nil
	}
	if err != nil {
		return "", err
	}
	if !fi.IsDir() || fi.Mode()&os.ModeSymlink != 0 || isUnsafeSessionReparsePoint(abs, fi) {
		return "", errors.New("session is not an ordinary directory")
	}
	return abs, nil
}

// Before recursive removal reject symlinks/reparse points anywhere below the
// session. This intentionally fails closed instead of following unexpected
// links into other applications' files. An upper bound prevents huge walks.
func validateSessionContents(folder string) error {
	count := 0
	return filepath.WalkDir(folder, func(path string, d fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		count++
		if count > maxSessionEntries {
			return errors.New("session exceeds cleanup scan limit")
		}
		if d.Type()&os.ModeSymlink != 0 {
			return errors.New("refusing session containing symlink")
		}
		if d.IsDir() {
			fi, err := os.Lstat(path)
			if err != nil {
				return err
			}
			if isUnsafeSessionReparsePoint(path, fi) {
				return errors.New("refusing session containing reparse directory")
			}
		}
		return nil
	})
}

func cleanOwnedSessionPath(folder, tempRoot string) error {
	abs, err := ownedSessionDirectory(folder, tempRoot)
	if err != nil {
		return err
	}
	if _, err := os.Lstat(abs); os.IsNotExist(err) {
		return nil
	} else if err != nil {
		return err
	}
	if err := validateSessionContents(abs); err != nil {
		return err
	}
	var last error
	for i := 0; i < 25; i++ {
		last = os.RemoveAll(abs)
		if _, statErr := os.Lstat(abs); os.IsNotExist(statErr) {
			return nil
		} else if statErr != nil {
			return statErr
		}
		if i < 24 {
			time.Sleep(160 * time.Millisecond)
		}
	}
	if last == nil {
		last = errors.New("session directory still exists")
	}
	return last
}

// Only a session with a valid marker, old creation timestamp and a process
// that is certainly no longer active can be recovered. Ambiguity => skip.
// Never search external folders or perform wildcard file deletion.
func abandonedSessionEligible(folder, tempRoot, current string, now time.Time) bool {
	abs, err := ownedSessionDirectory(folder, tempRoot)
	if err != nil || abs == current {
		return false
	}
	marker := filepath.Join(abs, sessionOwnerFile)
	fi, err := os.Lstat(marker)
	if err != nil || !fi.Mode().IsRegular() || fi.Size() > 256 || fi.Size() < 30 {
		return false
	}
	data, err := os.ReadFile(marker)
	if err != nil {
		return false
	}
	var owner sessionOwnership
	if json.Unmarshal(data, &owner) != nil || owner.Signature != sessionOwnerSignature || owner.PID <= 0 || owner.Created <= 0 {
		return false
	}
	if now.Before(time.Unix(owner.Created, 0).Add(minimumAbandonedAge)) {
		return false
	}
	if owner.Created > now.Unix() {
		return false
	}
	return !ownedProcessStillActive(owner.PID)
}

func cleanAbandonedOwnedSessions(root, current string, now time.Time) error {
	entries, err := os.ReadDir(root)
	if err != nil {
		return err
	}
	count := 0
	var errorsFound []string
	for _, entry := range entries {
		if count >= maxAbandonedSessions {
			break
		}
		if !entry.IsDir() || !strings.HasPrefix(entry.Name(), ownedSessionPrefix) {
			continue
		}
		folder := filepath.Join(root, entry.Name())
		if !abandonedSessionEligible(folder, root, current, now) {
			continue
		}
		count++
		if err := cleanOwnedSessionPath(folder, root); err != nil {
			errorsFound = append(errorsFound, fmt.Sprintf("session cleanup: %v", err))
		}
	}
	if len(errorsFound) > 0 {
		return errors.New(strings.Join(errorsFound, "; "))
	}
	return nil
}
