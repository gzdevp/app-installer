package main

import "testing"

func TestFindBulletSignatures(t *testing.T) {
	empty := make([]byte, 0x180)
	if hits := findBulletSignatures(empty); len(hits) != 0 {
		t.Fatal(hits)
	}
	// The reference location at handleBullet+0x69 must be discovered.
	copy(empty[0x69:], bulletOriginal)
	if hits := findBulletSignatures(empty); len(hits) != 1 || hits[0] != 0x69 {
		t.Fatal(hits)
	}
	// A duplicated sequence is ambiguous and must be rejected by caller.
	copy(empty[0xA0:], bulletOriginal)
	if hits := findBulletSignatures(empty); len(hits) != 2 {
		t.Fatal(hits)
	}
	empty[0x69] = 0x90
	if hits := findBulletSignatures(empty); len(hits) != 1 || hits[0] != 0xA0 {
		t.Fatal(hits)
	}
}
