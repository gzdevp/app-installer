# sete7 Black Edition v14.10 — executável externo sem sete7_names

Mudanças: removidas todas as rotinas do bridge HTTP e o recurso sete7_names do código-fonte; nenhuma instalação no servidor; names/friends usam somente leitura local já existente; veículos usam somente leitura e aliases/modelos locais; Fix/Lock/Unlock somente procedimentos locais anteriores, com verificação limitada; Through Wall conserva o teste anterior do campo Penetration, **não cria disparos por coordenadas e não é funcionalidade comprovada**.

**NÃO foram resolvidos:** nomes do FiveM não visíveis na memória de CPlayerInfo, função de reparo/trava autorizada pelo servidor, nem dano atravessando paredes em qualquer cidade. O código compila, mas não há teste em FiveM real. Nenhuma função já validada de Aim/Silent/ESP foi alterada.

Atenção: executar EXE que interage com memória do jogo pode violar regras de servidores. Não rode drivers desconhecidos, UEFI ou anexos como administrador sem confiança.
