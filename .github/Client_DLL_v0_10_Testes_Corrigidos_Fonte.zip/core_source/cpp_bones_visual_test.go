package main

import (
	"reflect"
	"testing"
)

// Extend the provided fake C++ skeleton with real GTA joint masks.
func addTestCPPVisualBone(r fakeCPPBoneReader, mask uint32, boneIndex uint32, x, y, z float32) {
	const table, mats = uintptr(0x800000), uintptr(0x700000)
	node := uintptr(0xB00000) + uintptr(boneIndex)*0x40
	bucketCount := r.u[0x500000+0x18] & 0xffff
	bucket := table + uintptr(mask%bucketCount)*8
	r.p[node+8] = r.p[bucket]
	r.p[bucket] = node
	r.u[node] = mask
	r.u[node+4] = boneIndex
	r.m[mats+uintptr(boneIndex)*0x40] = identityBoneMatrix(x, y, z)
}

// Use more buckets for the 18-joint fixture, avoiding the 4-link guard
// correctly enforced by the real C++ reader.
func setupVisualFake() fakeCPPBoneReader {
	r := setupCPPFake()
	const table = uintptr(0x800000)
	r.u[0x500000+0x18] = 97
	masks := [...]uint32{cppHead, cppNeck, cppPelvis, 0x3779, 0xcc4d, 0xe39f, 0xca72, 0x49d9, 0xdead}
	for addr := range r.p {
		if addr >= table && addr < table+11*8 {
			delete(r.p, addr)
		}
	}
	for i, mask := range masks {
		node := uintptr(0xA00000 + i*0x40)
		bucket := table + uintptr(mask%97)*8
		r.p[node+8] = r.p[bucket]
		r.p[bucket] = node
	}
	return r
}

func testBoneCamera() matrix44 {
	var m matrix44
	m[1], m[13] = .085, -.85 // 10 => center x
	m[10], m[14] = .18, -3.6 // 20 => center y
	m[15] = 1
	return m
}

func TestPremiumSkeletonAddsShouldersElbowsShinsWithoutChangingBase(t *testing.T) {
	r := setupVisualFake()
	// All local positions, from the original fake (transform adds 10,10,20).
	extras := []struct {
		id, index uint32
		pos       vec3
	}{
		{cppSpine3, 10, vec3{0, 0, 1.30}},
		{cppLClavicle, 11, vec3{-.12, 0, 1.43}},
		{cppRClavicle, 12, vec3{.12, 0, 1.43}},
		{cppLUpperArm, 13, vec3{-.25, 0, 1.37}},
		{cppRUpperArm, 14, vec3{.25, 0, 1.37}},
		{cppLForearm, 15, vec3{-.38, 0, 1.22}},
		{cppRForearm, 16, vec3{.38, 0, 1.22}},
		{cppLCalf, 17, vec3{-.17, 0, .35}},
		{cppRCalf, 18, vec3{.17, 0, .35}},
	}
	for _, e := range extras {
		addTestCPPVisualBone(r, e.id, e.index, e.pos.X, e.pos.Y, e.pos.Z)
	}
	original, oldSkull, oldHead, originalValid, oldStage := cppProjectPose(r, 0x100000, vec3{10, 10, 20}, testBoneCamera(), 1200, 800)
	base, rich, newSkull, newHead, detailedValid, newStage := cppProjectPosePair(r, 0x100000, vec3{10, 10, 20}, testBoneCamera(), 1200, 800, true)
	if !originalValid || !detailedValid || newStage != cppBoneVerified || oldStage != cppBoneVerified {
		t.Fatalf("invalid test pose: %v/%v", oldStage, newStage)
	}
	if !reflect.DeepEqual(original, base) || oldSkull != newSkull || oldHead != newHead {
		t.Fatalf("skeleton geometry changed the original head/box inputs")
	}
	if len(rich) < 15 || len(rich) <= len(base) {
		t.Fatalf("no detailed skeleton: base=%d rich=%d", len(base), len(rich))
	}
	// The long neck->hand diagonal in the original V silhouette must be gone.
	neckX, neckY, _ := worldToScreen(testBoneCamera(), vec3{10, 10, 21.48}, 1200, 800)
	leftX, leftY, _ := worldToScreen(testBoneCamera(), vec3{9.5, 10, 21.12}, 1200, 800)
	for _, seg := range rich {
		a, b := int32(neckX+.5), int32(neckY+.5)
		c, d := int32(leftX+.5), int32(leftY+.5)
		if seg == [4]int32{a, b, c, d} || seg == [4]int32{c, d, a, b} {
			t.Fatalf("old neck-to-hand V still present: %v", seg)
		}
	}
}

func TestPremiumSkeletonMissingOptionalJointsFallsBack(t *testing.T) {
	r := setupVisualFake()
	base, rich, _, _, ok, stage := cppProjectPosePair(r, 0x100000, vec3{10, 10, 20}, testBoneCamera(), 1200, 800, true)
	if !ok || stage != cppBoneVerified || len(base) < 3 || len(rich) < 3 {
		t.Fatalf("missing extra joints should leave old skeleton available: %v, %d/%d", stage, len(base), len(rich))
	}
}
