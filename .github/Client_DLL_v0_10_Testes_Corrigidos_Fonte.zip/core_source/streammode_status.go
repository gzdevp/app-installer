package main

import "fmt"

const (
	wdaNone               uintptr = 0
	wdaMonitor            uintptr = 1
	wdaExcludeFromCapture uintptr = 0x11 // Windows 10 2004+, best effort
)

func streamClassify(enabled bool, actual uintptr, verified bool) (string, bool) {
	if !verified {
		return "Sem confirmação do Windows", false
	}
	if !enabled {
		if actual == wdaNone {
			return "Desativado", false
		}
		return fmt.Sprintf("Falha ao desligar (%#x)", actual), false
	}
	if actual == wdaExcludeFromCapture {
		return "Exclusão confirmada pelo Windows", true
	}
	if actual == wdaMonitor {
		return "Proteção parcial (Windows antigo)", false
	}
	if actual == wdaNone {
		return "Sem proteção de captura", false
	}
	return fmt.Sprintf("Afinidade inesperada (%#x)", actual), false
}

func streamReadyLabel(enabled, ready bool) string {
	if !enabled {
		return "Desativado"
	}
	if ready {
		return "Proteção solicitada e confirmada pelo Windows; teste no OBS"
	}
	return "ATENÇÃO: janela sem proteção confirmada"
}
