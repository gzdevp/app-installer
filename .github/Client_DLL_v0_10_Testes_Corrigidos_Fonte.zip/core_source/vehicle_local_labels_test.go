package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestLocalGameNameOnlyWhenDisplayLabelIsProven(t *testing.T) {
	m := parseLocalVehicleMetaRows(strings.NewReader(`<Item><modelName>r34_custom_v2</modelName><gameName>R34_GXT</gameName></Item>`))
	row := m[joaatModelName("r34_custom_v2")]
	if got := localModelDisplayName(row, nil); got != "r34_custom_v2" {
		t.Fatalf("untranslated label: %q", got)
	}
	entries := parseLocalTextEntries(strings.NewReader(`AddTextEntry('R34_GXT', 'Nissan Skyline GT-R R34')`))
	if got := localModelDisplayName(row, entries); got != "Nissan Skyline GT-R R34" {
		t.Fatalf("translated: %q", got)
	}
}
func TestLocalTextEntriesSkipExpressionsAndUnsafeMarkup(t *testing.T) {
	labels := parseLocalTextEntries(strings.NewReader("AddTextEntry('REAL', 'Mercedes C63 AMG')\nAddTextEntry('DYNAMIC', getName())\nAddTextEntry('BAD', '<script>x</script>')\n"))
	if labels["REAL"] != "Mercedes C63 AMG" || labels["DYNAMIC"] != "" || labels["BAD"] != "" {
		t.Fatalf("bad labels: %#v", labels)
	}
}

func TestReadableResourceNamesJoinToSameResource(t *testing.T) {
	local := t.TempDir()
	t.Setenv("LOCALAPPDATA", local)
	base := filepath.Join(local, "FiveM", "FiveM.app", "data", "server-cache")
	car := filepath.Join(base, "r34_pack")
	other := filepath.Join(base, "unrelated_pack")
	for _, dir := range []string{car, other} {
		if err := os.MkdirAll(dir, 0700); err != nil {
			t.Fatal(err)
		}
	}
	meta := `<CVehicleModelInfo__InitDataList><InitDatas><Item><modelName>r34_special_test</modelName><gameName>R34_KEY_23</gameName></Item></InitDatas></CVehicleModelInfo__InitDataList>`
	if err := os.WriteFile(filepath.Join(car, "cars.meta"), []byte(meta), 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(car, "client.lua"), []byte(`AddTextEntry('R34_KEY_23','Nissan Skyline R34 Test')`), 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(other, "client.lua"), []byte(`AddTextEntry('R34_KEY_23','Wrong Name')`), 0600); err != nil {
		t.Fatal(err)
	}
	scanReadableLocalVehicleMetas()
	if got, ok := storedLocalVehicleName(joaatModelName("r34_special_test")); !ok || got != "Nissan Skyline R34 Test" {
		t.Fatalf("label unexpectedly not scoped to resource: %q %v", got, ok)
	}
}

func TestLocalTextEntriesMultilineAndHashVariant(t *testing.T) {
	src := `-- common split form
AddTextEntry(
   "R34_GXT_TEST", 
   "Nissan Skyline R34"
)
AddTextEntryByHash(
 GetHashKey('M4_GXT_TEST'),
 'BMW M4 Competition'
)
AddTextEntry('DYNAMIC', getLabel())
AddTextEntryByHash(GetHashKey(dynamicKey), 'Do Not Trust')
`
	labels := parseLocalTextEntries(strings.NewReader(src))
	if labels["R34_GXT_TEST"] != "Nissan Skyline R34" || labels["M4_GXT_TEST"] != "BMW M4 Competition" {
		t.Fatalf("split or hash literal lost: %#v", labels)
	}
	if labels["DYNAMIC"] != "" || labels["DONOTTRUST"] != "" {
		t.Fatalf("dynamic label unexpectedly parsed: %#v", labels)
	}
}

func TestLocalVehicleCacheDoesNotSwapCitySpecificLabels(t *testing.T) {
	local := t.TempDir()
	t.Setenv("LOCALAPPDATA", local)
	base := filepath.Join(local, "FiveM", "FiveM.app", "data", "server-cache")
	for _, v := range []struct{ city, label string }{
		{"city_a", "Ford Mustang"}, {"city_b", "Chevrolet Camaro"},
	} {
		dir := filepath.Join(base, v.city)
		if err := os.MkdirAll(dir, 0700); err != nil {
			t.Fatal(err)
		}
		meta := `<CVehicleModelInfo__InitDataList><InitDatas><Item><modelName>testcar_conflict_47</modelName><gameName>CAR47_GXT</gameName></Item></InitDatas></CVehicleModelInfo__InitDataList>`
		if err := os.WriteFile(filepath.Join(dir, "vehicles.meta"), []byte(meta), 0600); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(dir, "vehicles.lua"), []byte("AddTextEntry('CAR47_GXT', '"+v.label+"')"), 0600); err != nil {
			t.Fatal(err)
		}
	}
	scanReadableLocalVehicleMetas()
	got, ok := storedLocalVehicleName(joaatModelName("testcar_conflict_47"))
	if !ok || got != "testcar_conflict_47" {
		t.Fatalf("wrong-city name leaked: %q (%v)", got, ok)
	}
}
