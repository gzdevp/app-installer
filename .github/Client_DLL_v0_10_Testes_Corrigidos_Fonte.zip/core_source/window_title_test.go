package main

import (
	"os"
	"regexp"
	"testing"
)

func TestBrowserTitleMatchesAcrossVersions(t *testing.T) {
	for _, test := range []struct {
		title string
		want  bool
	}{
		{"sete7 | External v12.12", true},
		{"sete7 | External v12.13", true},
		{"sete7 | External v12.14", true},
		{" SETE7 | EXTERNAL V15.0 ", true},
		{"sete7 | Black Edition v13.9", true},
		{"SETE7 | BLACK EDITION V13.9.1", true},
		{"77 | v13.9.59", true},
		{"Edge", false},
		{"sete7 native UI", false},
		{"another sete7 | External v12.14", false},
		{"sete7 | Unknown v13.9", false},
	} {
		if got := isSete7BrowserTitle(test.title); got != test.want {
			t.Errorf("title %q: got %v want %v", test.title, got, test.want)
		}
	}
}

// Guard against a UI title change silently breaking Chromium->native host
// attachment: this was the actual regression in v13.9.
func TestEmbeddedPageTitleRecognized(t *testing.T) {
	html, err := os.ReadFile("web/index.html")
	if err != nil {
		t.Fatal(err)
	}
	match := regexp.MustCompile(`<title>([^<]+)</title>`).FindSubmatch(html)
	if len(match) != 2 {
		t.Fatal("HTML title missing")
	}
	if !isSete7BrowserTitle(string(match[1])) || !isCurrentBrowserTitle(string(match[1])) {
		t.Fatalf("HTML title %q is not recognized as current by the native host", match[1])
	}
}

func TestNeverAttachStaleBrowser(t *testing.T) {
	for _, title := range []string{
		"sete7 | Black Edition v13.9", "sete7 | External v13.8",
		"sete7 | Black Edition v13.9.1", "77 | v13.9.58", "Edge",
	} {
		if isCurrentBrowserTitle(title) {
			t.Errorf("stale/unrelated window %q must not be attached", title)
		}
	}
}
