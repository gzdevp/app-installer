# sete7 v13.9.9 — Rounded & Drag Edition

## Mudanças exclusivas de interface
- Bordas da janela principal arredondadas em CSS e na região nativa Win32 (CreateRoundRectRgn/SetWindowRgn), respeitando recorte do navegador incorporado.
- Cantos de cartões, abas e botões levemente mais arredondados.
- Janela movível: clique e arraste com o botão esquerdo pela barra superior (breadcrumbs/título) ou pela área da marca no topo esquerdo. Os controles clicáveis da barra não iniciam arraste.
- A posição é limitada aos limites da viewport do FiveM para que o painel não saia da tela.
- Localização customizada é preservada ao ocultar/mostrar durante a mesma sessão; reiniciar o executável centraliza novamente.
- Perfil de navegador isolado em sete7-v13.9.9-data. INSERT permanece para abrir/fechar.

## Escopo e preservação
- Base: projeto sete7 v13.9.8 fornecido anteriormente.
- Arquivos existentes alterados: `main.go` (endpoint autenticado de arraste e pasta da versão), `native_host_windows.go` (clipping e posição), `window_other.go` (stub fora do Windows), `window_title.go` (título atual) e `web/index.html` (estética + ação de arraste).
- Novo arquivo: `panel_drag_windows.go` (manipulação apenas da janela do aplicativo).
- Todos os demais 206 arquivos da v13.9.8 permanecem idênticos byte a byte, incluindo as rotinas de jogo.

## Validação
- GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build: OK
- GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet ./...: OK
- GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test -c: OK (testes compilados, não executados no Windows)
- node --check no script da interface: OK
- Chromium headless com HTML em `set_content`: navegação Aim/World/Player Health, estilos, título e ausência de exceções JavaScript: OK
- Movimento do HWND e clipping Win32 não foram executados/testados dentro de um Windows com FiveM neste ambiente: validar manualmente.

## Teste de uso
1. Feche a versão anterior e qualquer painel deixado aberto.
2. Execute a v13.9.9.
3. Dentro do FiveM pressione INSERT.
4. Clique com o botão esquerdo em qualquer área vazia da barra superior ou no bloco da marca, segure e arraste.
5. Teste os controles de perfil, temas e abas para confirmar que não iniciam arraste.
6. Oculte/mostre usando INSERT e confira se o painel permanece na nova posição.
