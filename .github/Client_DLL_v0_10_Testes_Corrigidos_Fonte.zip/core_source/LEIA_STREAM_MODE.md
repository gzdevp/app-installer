# Stream Mode reforçado — 77 Black Edition v13.9.39

O Stream Mode mantém o painel e o ESP localmente visíveis e tenta excluí-los das capturas **compatíveis** feitas pelo Windows.

- A proteção da própria janela é aplicada pelo Windows (`WDA_EXCLUDEFROMCAPTURE`) ao host do painel e ao overlay.
- A cada consulta de estado, verifica a afinidade em ambas as janelas. Se ela desapareceu, solicita novamente ao Windows.
- Verifica se o handle da janela ainda existe e pertence ao processo, se DWM está habilitado e se `GetWindowDisplayAffinity` confirmou a exclusão.
- Em Windows antigo que cai para `WDA_MONITOR`, exibe **Proteção parcial**, sem fingir que a exclusão está completa.
- Mostra **ATENÇÃO** quando qualquer janela não tiver proteção confirmada.
- Preservei as demais abas, as binds e JACK 77. Não altera FiveM nem aplicações de terceiros.

**Limite:** A confirmação de uma flag não prova que o OBS ou outra ferramenta de captura respeitará a proteção. Nem o Windows garante impedir fotografia, captura por placa externa, acesso ao framebuffer via software privilegiado ou captura de conteúdo que já é renderizado pelo jogo. Faça uma gravação curta em OBS antes de transmitir; confira o arquivo.
