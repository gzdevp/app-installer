package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSessionDirectoryIsNotBesideExecutable(t *testing.T) {
	dir := dataFolder()
	if dir == "" {
		t.Fatal("session temp directory missing")
	}
	if !strings.HasPrefix(filepath.Base(dir), "Sete7-session-") {
		t.Fatalf("session directory has wrong prefix: %q", dir)
	}
	exe, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	if filepath.Clean(filepath.Dir(dir)) == filepath.Clean(filepath.Dir(exe)) {
		t.Fatal("session path must never be beside executable")
	}
	if _, err := os.Stat(dir); err != nil {
		t.Fatal(err)
	}
}
