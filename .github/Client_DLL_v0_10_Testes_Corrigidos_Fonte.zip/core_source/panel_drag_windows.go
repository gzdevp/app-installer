//go:build windows

package main

// Drag only our own native menu shell. The service endpoint is already bound
// to loopback and requires the same per-session key as other UI actions.
import (
	"sync"
	"unsafe"
)

var panelDrag = struct {
	sync.Mutex
	dragging       bool
	hwnd           uintptr
	startX, startY int32
	seq            uint64
}{}

var panelPosition = struct {
	sync.Mutex
	custom bool
	x, y   int32
}{}

func ownMenuViewport() (espViewport, bool) {
	game, ok := locateAnyFiveMWindow()
	if !ok {
		return espViewport{}, false
	}
	var r rect
	var origin point
	got, _, _ := getClientRect.Call(game, uintptr(unsafe.Pointer(&r)))
	moved, _, _ := toScreen.Call(game, uintptr(unsafe.Pointer(&origin)))
	if got == 0 || moved == 0 {
		return espViewport{}, false
	}
	w, h := r.Right-r.Left, r.Bottom-r.Top
	if w < 320 || h < 240 {
		return espViewport{}, false
	}
	return espViewport{X: origin.X, Y: origin.Y, W: w, H: h}, true
}

func clampPanel(x, y, w, h int32, vp espViewport) (int32, int32) {
	maxX, maxY := vp.X+vp.W-w, vp.Y+vp.H-h
	if maxX < vp.X {
		maxX = vp.X
	}
	if maxY < vp.Y {
		maxY = vp.Y
	}
	if x < vp.X {
		x = vp.X
	}
	if y < vp.Y {
		y = vp.Y
	}
	if x > maxX {
		x = maxX
	}
	if y > maxY {
		y = maxY
	}
	return x, y
}

func dragOwnPanel(action string, dx, dy int32, seq uint64) bool {
	host := menuWindow()
	if host == 0 || !menuWanted.Load() {
		return false
	}
	switch action {
	case "start":
		var r rect
		if ok, _, _ := getWindowRectFrame.Call(host, uintptr(unsafe.Pointer(&r))); ok == 0 {
			return false
		}
		panelDrag.Lock()
		panelDrag.dragging = true
		panelDrag.hwnd = host
		panelDrag.startX, panelDrag.startY = r.Left, r.Top
		panelDrag.seq = 0
		panelDrag.Unlock()
		return true
	case "move":
		if dx < -12000 || dx > 12000 || dy < -12000 || dy > 12000 {
			return false
		}
		panelDrag.Lock()
		if !panelDrag.dragging || panelDrag.hwnd != host || seq <= panelDrag.seq {
			panelDrag.Unlock()
			return false
		}
		panelDrag.seq = seq
		x, y := panelDrag.startX+dx, panelDrag.startY+dy
		panelDrag.Unlock()
		vp, ok := ownMenuViewport()
		if !ok {
			return false
		}
		var r rect
		if n, _, _ := getWindowRectFrame.Call(host, uintptr(unsafe.Pointer(&r))); n == 0 {
			return false
		}
		x, y = clampPanel(x, y, r.Right-r.Left, r.Bottom-r.Top, vp)
		const flags = uintptr(0x0001 | 0x0010) // SWP_NOSIZE | SWP_NOACTIVATE
		if moved, _, _ := setWindowPos.Call(host, ^uintptr(0), uintptr(int64(x)), uintptr(int64(y)), 0, 0, flags); moved == 0 {
			return false
		}
		panelPosition.Lock()
		panelPosition.custom, panelPosition.x, panelPosition.y = true, x, y
		panelPosition.Unlock()
		return true
	case "end":
		panelDrag.Lock()
		panelDrag.dragging = false
		panelDrag.Unlock()
		return true
	default:
		return false
	}
}
