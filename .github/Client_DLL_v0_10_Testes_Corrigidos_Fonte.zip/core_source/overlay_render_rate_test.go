package main

import (
	"testing"
	"time"
)

func TestOverlayPaintOnFreshFramesWithoutRedundantBitBlts(t *testing.T) {
	var p overlayPaintScheduler
	t0 := time.Unix(123, 0)
	if !p.shouldPaint(t0, true, true, 1, 0) {
		t.Fatal("must paint initial frame")
	}
	if p.shouldPaint(t0.Add(8*time.Millisecond), true, false, 1, 0) {
		t.Fatal("must not repaint same frame")
	}
	if p.shouldPaint(t0.Add(8*time.Millisecond), true, false, 2, 0) {
		t.Fatal("rate ceiling bypassed")
	}
	if !p.shouldPaint(t0.Add(16*time.Millisecond), true, false, 2, 0) {
		t.Fatal("fresh ESP frame must paint at 16ms")
	}
	if p.shouldPaint(t0.Add(32*time.Millisecond), true, false, 2, 0) {
		t.Fatal("unchanged dynamic scene must not repaint")
	}
	if !p.shouldPaint(t0.Add(40*time.Millisecond), true, false, 3, 0) {
		t.Fatal("fresh frame must paint without 33ms fixed delay")
	}
}

func TestOverlayPaintRadarAndStaticReticle(t *testing.T) {
	var p overlayPaintScheduler
	t0 := time.Unix(223, 0)
	if !p.shouldPaint(t0, false, true, 0, 0) {
		t.Fatal("forced first static paint")
	}
	if p.shouldPaint(t0.Add(100*time.Millisecond), false, false, 0, 0) {
		t.Fatal("static reticle must be event driven")
	}
	if !p.shouldPaint(t0.Add(time.Second), false, false, 0, 0) {
		t.Fatal("safety refresh missing")
	}
	if !p.shouldPaint(t0.Add(time.Second+8*time.Millisecond), true, true, 0, 0) {
		t.Fatal("settings changes redraw immediately")
	}
	if !p.shouldPaint(t0.Add(time.Second+24*time.Millisecond), true, false, 0, 1) {
		t.Fatal("new radar frame must trigger draw")
	}
}

func TestOverlayCoalescesHighFrequencySource(t *testing.T) {
	var p overlayPaintScheduler
	t0 := time.Unix(323, 0)
	var paints int
	for i := 0; i < 100; i++ {
		if p.shouldPaint(t0.Add(time.Duration(i)*8*time.Millisecond), true, i == 0, uint64(i+1), 0) {
			paints++
		}
	}
	if paints != 50 {
		t.Fatalf("expected at most 50 paints for 100 8ms samples, got %d", paints)
	}
}

func TestESPFrameDrivenCadenceUnder25msScanner(t *testing.T) {
	// Reproduce the 25ms scan / 8ms overlay poll mismatch with a 180Hz
	// game.  Frame detection delay must stay below one 8ms poll, not 48ms.
	var p overlayPaintScheduler
	t0 := time.Unix(423, 0)
	var seq uint64
	lastPaintedSeq := uint64(0)
	var painted int
	for i := 0; i <= 50; i++ { // 400ms worth of timer samples
		ms := i * 8
		newSeq := uint64(ms/25 + 1)
		if newSeq != seq {
			seq = newSeq
		}
		if p.shouldPaint(t0.Add(time.Duration(ms)*time.Millisecond), true, i == 0, seq, 0) {
			if seq == lastPaintedSeq {
				t.Fatalf("duplicate frame %d at %dms", seq, ms)
			}
			// A new 25ms frame sampled at 8ms granularity should be visible
			// on the next tick; there is no fixed 33ms + ticker quantization.
			if delta := ms - (int(seq)-1)*25; delta > 8 {
				t.Fatalf("ESP delayed %dms", delta)
			}
			lastPaintedSeq = seq
			painted++
		}
	}
	if painted < 15 {
		t.Fatalf("too few fresh frames painted in 400ms: %d", painted)
	}
}
