package main

import (
	"sync"
	"time"
)

// Secondary CPlayerInfo offsets are read-only and never override the modern
// canonical +0x100 field. Two conflicting secondary values are rejected.
// They are not guaranteed to be FiveM, Steam, or roleplay nicknames.
func readFiveMFallbackPlayerName(info uintptr, build string, read memoryNameReader) string {
	if read == nil || info < 0x10000 {
		return ""
	}
	if build == "b2699" || build == "b2802" {
		return ""
	} // already primary there
	if build != "b2944" && build != "b3095" && build != "b3258" && build != "b3323" && build != "b3407" {
		return ""
	}
	found := ""
	for _, offset := range [...]uintptr{0xA4, 0x84} {
		name := readNameAt(info+offset, read)
		if name == "" {
			continue
		}
		if found != "" && found != name {
			return ""
		}
		found = name
	}
	return found
}

type cautiousNameFallbackKey struct {
	pid  uint32
	info uintptr
}
type cautiousNameFallbackEntry struct {
	name  string
	first time.Time
	last  time.Time
}
type cautiousNameFallbackStore struct {
	mu      sync.Mutex
	entries map[cautiousNameFallbackKey]cautiousNameFallbackEntry
}

func (s *cautiousNameFallbackStore) observe(pid uint32, info uintptr, name string, now time.Time) string {
	if pid == 0 || info < 0x10000 {
		return ""
	}
	k := cautiousNameFallbackKey{pid, info}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.entries == nil {
		s.entries = make(map[cautiousNameFallbackKey]cautiousNameFallbackEntry)
	}
	if len(s.entries) > 1024 {
		for key, entry := range s.entries {
			if now.Sub(entry.last) > time.Second || now.Before(entry.last) {
				delete(s.entries, key)
			}
		}
	}
	if name == "" || sanitizeSessionName(name) != name {
		delete(s.entries, k)
		return ""
	}
	prior, ok := s.entries[k]
	if !ok || prior.name != name || now.Before(prior.last) || now.Sub(prior.last) > 500*time.Millisecond {
		s.entries[k] = cautiousNameFallbackEntry{name: name, first: now, last: now}
		return ""
	}
	prior.last = now
	s.entries[k] = prior
	// A single valid string in an adjacent struct field is not sufficient
	// evidence. Observe it across separate 25 ms ESP reads first.
	if now.Sub(prior.first) >= 20*time.Millisecond {
		return name
	}
	return ""
}

var cautiousPlayerNameFallback cautiousNameFallbackStore
