package main

import (
	"strings"
	"unicode"
	"unicode/utf8"
)

// Names obtained from CPlayerInfo are session labels, not permanent identities.
// Avoid falsely linking NPCs, anonymous entities, or two people using one name.
func friendKey(name string) string { return strings.ToLower(strings.TrimSpace(name)) }
func validFriendName(name string) bool {
	name = strings.TrimSpace(name)
	if name == "" || utf8.RuneCountInString(name) > 45 || len(name) > 128 || !utf8.ValidString(name) {
		return false
	}
	if strings.HasPrefix(friendKey(name), "jogador (id interno ") {
		return false
	}
	switch friendKey(name) {
	case "npc", "jogador", "player", "unknown", "desconhecido", "-":
		return false
	}
	for _, r := range name {
		if unicode.IsControl(r) {
			return false
		}
	}
	return true
}
func normalizeFriends(input []string) []string {
	out := make([]string, 0, 32)
	seen := make(map[string]bool, 32)
	for _, item := range input {
		item = strings.TrimSpace(item)
		if !validFriendName(item) {
			continue
		}
		key := friendKey(item)
		if seen[key] {
			continue
		}
		seen[key] = true
		out = append(out, item)
		if len(out) == 256 {
			break
		}
	}
	return out
}
func verifiedFriend(name string, saved []string, count map[string]int) bool {
	if !validFriendName(name) || count[friendKey(name)] != 1 {
		return false
	}
	for _, stored := range saved {
		if strings.EqualFold(strings.TrimSpace(stored), strings.TrimSpace(name)) {
			return true
		}
	}
	return false
}
