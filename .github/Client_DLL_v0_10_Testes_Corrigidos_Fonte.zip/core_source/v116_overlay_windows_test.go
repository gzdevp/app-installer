//go:build windows

package main

import "testing"

func TestSkeletonAndBoxAnchoredToSameFrame(t *testing.T) {
	x, y, w, h := int32(100), int32(45), int32(42), int32(100)
	bones := estimatedSkeleton(x, y, w, h)
	if len(bones) < 8 {
		t.Fatalf("estimated silhouette too short: %d", len(bones))
	}
	for _, b := range bones {
		for _, pt := range [][2]int32{{b[0], b[1]}, {b[2], b[3]}} {
			if pt[0] < x || pt[0] > x+w || pt[1] < y || pt[1] > y+h {
				t.Fatalf("bone out of bounding box: %v", pt)
			}
		}
	}
	target := targetESP{X: 100, Y: 45, W: 42, H: 100, Bones: bones, PedID: 112}
	pp := &painter{}
	before := pp.positions(espViewport{}, []targetESP{target}, 1)
	shifted := target
	shifted.X += 10
	shifted.Y += 5
	shifted.Bones = estimatedSkeleton(shifted.X, shifted.Y, shifted.W, shifted.H)
	after := pp.positions(espViewport{}, []targetESP{shifted}, 2)
	if before[0].X != 100 || after[0].X != 110 || after[0].Bones[0][0]-before[0].Bones[0][0] != 10 {
		t.Fatal("mismatched box and skeleton snapshot")
	}
}
