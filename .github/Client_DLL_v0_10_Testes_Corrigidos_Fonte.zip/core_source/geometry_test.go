//go:build windows

package main

import "testing"

func TestViewportProjection(t *testing.T) {
	m := matrix44{}
	m[15] = 1
	x, y, ok := worldToScreen(m, vec3{}, 1920, 1080)
	if !ok || x != 960 || y != 540 {
		t.Fatalf("center %g %g %t", x, y, ok)
	}
	m[13] = 2
	_, _, ok = worldToScreen(m, vec3{}, 1920, 1080)
	if ok {
		t.Fatal("outside right accepted")
	}
	m[13] = 0
	m[14] = -2
	_, _, ok = worldToScreen(m, vec3{}, 1920, 1080)
	if ok {
		t.Fatal("outside bottom accepted")
	}
	m[14] = 0
	m[15] = -1
	_, _, ok = worldToScreen(m, vec3{}, 1920, 1080)
	if ok {
		t.Fatal("behind camera accepted")
	}
}
func TestESPBoxBounds(t *testing.T) {
	_, _, _, _, ok := espBox(400, 150, 400, 360, 1920, 1080, false)
	if !ok {
		t.Fatal("valid box rejected")
	}
	_, _, _, _, ok = espBox(400, -10, 400, 200, 1920, 1080, false)
	if ok {
		t.Fatal("negative top accepted")
	}
	_, _, _, _, ok = espBox(400, 500, 400, 400, 1920, 1080, false)
	if ok {
		t.Fatal("reversed head and feet accepted")
	}
	_, _, _, _, ok = espBox(400, 150, 1200, 360, 1920, 1080, false)
	if ok {
		t.Fatal("implausible leaning accepted")
	}
}

func TestFarTargetsAreNotAutomaticallyDiscarded(t *testing.T) {
	_, _, w, h, ok := espBox(900, 250, 900, 255, 1920, 1080, false)
	if !ok || h < 2 || w < 2 {
		t.Fatalf("distant target incorrectly discarded: %d %d %t", w, h, ok)
	}
}

func TestRejectsCorruptWorldPositions(t *testing.T) {
	for _, pt := range []vec3{{1e8, 0, 0}, {0, 0, -50000}, {0, 0, 1e7}} {
		if plausibleFiveMPosition(pt) {
			t.Fatalf("accepted corrupt position: %+v", pt)
		}
	}
	if !plausibleFiveMPosition(vec3{-1200, 1700, 40}) {
		t.Fatal("rejected plausible player position")
	}
}

func TestHeadAnchorProjectionLimits(t *testing.T) {
	if !headAnchorInsidePlayer(960, 402, 940, 400, 40, 160) {
		t.Fatal("head at top should pass")
	}
	if headAnchorInsidePlayer(960, 545, 940, 400, 40, 160) {
		t.Fatal("chest/hip should not pass")
	}
	if headAnchorInsidePlayer(1070, 412, 940, 400, 40, 160) {
		t.Fatal("unrelated ped should not pass")
	}
}

func TestESPVisualElementsAnchorToRealSkeleton(t *testing.T) {
	// Body projection is 75 px too high but real head and feet are valid.
	original := targetESP{X: 915, Y: 200, W: 70, H: 160}
	bones := [][4]int32{
		{950, 280, 950, 305}, {950, 305, 950, 366},
		{950, 305, 925, 350}, {950, 305, 977, 351},
		{950, 366, 932, 420}, {932, 420, 932, 445},
		{950, 366, 968, 420}, {968, 420, 968, 445},
	}
	got, ok := alignPlayerBoxToBones(original, bones, [2]int32{950, 280}, 1920, 1080)
	if !ok {
		t.Fatal("expected complete authentic skeleton as box anchor")
	}
	if got.Y >= 280 || got.Y < 265 || got.Y+got.H < 445 {
		t.Fatalf("box does not encompass real skeleton: %+v", got)
	}
	if got.X > 925 || got.X+got.W < 977 {
		t.Fatalf("box excludes articulated hands: %+v", got)
	}
	if len(bones) != 8 || bones[0][1] != 280 {
		t.Fatal("joints must not be altered by visual anchoring")
	}
}

func TestESPPartialSkeletonUsesHeadButRetainsHeight(t *testing.T) {
	original := targetESP{X: 915, Y: 200, W: 70, H: 160}
	bones := [][4]int32{{950, 280, 950, 306}, {950, 306, 950, 352}, {950, 306, 922, 330}}
	got, ok := alignPlayerBoxToBones(original, bones, [2]int32{950, 280}, 1920, 1080)
	if !ok || got.Y != 264 || got.H != 160 || got.X != 915 {
		t.Fatalf("partial skeleton must anchor head without truncation: %+v ok=%t", got, ok)
	}
}

func TestESPRejectsCorruptSkeletonBounds(t *testing.T) {
	original := targetESP{X: 915, Y: 200, W: 70, H: 160}
	bones := [][4]int32{{950, -20, 950, 306}, {950, 306, 950, 352}, {950, 306, 922, 330}}
	got, ok := alignPlayerBoxToBones(original, bones, [2]int32{950, -20}, 1920, 1080)
	if ok || got.X != original.X || got.Y != original.Y || got.W != original.W || got.H != original.H {
		t.Fatalf("rejected skeleton should not change fallback: %+v", got)
	}
}
