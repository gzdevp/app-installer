#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wchar.h>
#include <stdio.h>

typedef int (__cdecl *core_fn)(void);

static int fail(const wchar_t *message, int code, int quiet) {
    if (!quiet) MessageBoxW(NULL, message, L"Client", MB_OK | MB_ICONERROR);
    return code;
}

/* Only two explicit health-check flags. --probe-local is for the CI build. */
static int is_arg(const wchar_t *text, const wchar_t *flag) {
    if (!text) return 0;
    while (*text == L' ' || *text == L'\t') text++;
    size_t n = wcslen(flag);
    return wcsncmp(text, flag, n) == 0 &&
           (text[n] == 0 || text[n] == L' ' || text[n] == L'\t');
}

static int module_directory(wchar_t *path, DWORD count) {
    DWORD n = GetModuleFileNameW(NULL, path, count);
    if (n == 0 || n >= count) return 0;
    wchar_t *sep = wcsrchr(path, L'\\');
    if (!sep) return 0;
    *sep = 0;
    return 1;
}

int WINAPI wWinMain(HINSTANCE a, HINSTANCE b, PWSTR args, int show) {
    (void)a; (void)b; (void)show;
    const int probe = is_arg(args, L"--probe") || is_arg(args, L"--probe-local");
    const int local = is_arg(args, L"--probe-local");
    wchar_t dll_path[32768];
    wchar_t host_dir[32768];
    DWORD base = 0;
    if (!module_directory(host_dir, 32768))
        return fail(L"Caminho do Client.exe invalido.", 10, probe);
    if (local) {
        if (wcslen(host_dir) + 1 + wcslen(L"appcore.dll") + 1 >= 32768)
            return fail(L"Caminho de teste muito longo.", 11, probe);
        wcscpy(dll_path, host_dir);
    } else {
        /* Use the real system directory of this 64-bit process. */
        base = GetSystemDirectoryW(dll_path, 32768);
        if (base == 0 || base >= 32768)
            return fail(L"Nao foi possivel determinar System32.", 11, probe);
    }
    if (wcslen(dll_path) + wcslen(L"\\appcore.dll") + 1 >= 32768)
        return fail(L"Caminho da DLL muito longo.", 11, probe);
    wcscat(dll_path, L"\\appcore.dll");
    /* Exact absolute path: never rely on current directory or PATH. */
    HMODULE dll = LoadLibraryExW(dll_path, NULL,
                                 LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR | LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
    if (!dll)
        return fail(L"Falha ao carregar C:\\Windows\\System32\\appcore.dll. Verifique a instalacao.", 12, probe);
    core_fn abi = (core_fn)GetProcAddress(dll, "CoreABIVersion");
    core_fn health = (core_fn)GetProcAddress(dll, "CoreProbe");
    core_fn start = (core_fn)GetProcAddress(dll, "CoreStart");
    if (!abi || !health || !start || abi() != 2 || health() != 6042)
        return fail(L"appcore.dll incompativel com este Client.exe.", 13, probe);
    if (probe) {
        FreeLibrary(dll);
        return 0;
    }
    /* The UI and session files remain anchored to the EXE's own directory. */
    if (!SetCurrentDirectoryW(host_dir))
        return fail(L"Falha ao definir o diretorio do Client.", 14, 0);
    int result = start();
    if (result == 77) {
        MessageBoxW(NULL,
           L"O painel foi encerrado. O Cleaner so remove dados proprios.\n"
           L"Para desinstalar Client.exe e appcore.dll use o instalador autorizado apos o Unload.",
           L"Client", MB_OK | MB_ICONINFORMATION);
        return 0;
    }
    return result;
}
