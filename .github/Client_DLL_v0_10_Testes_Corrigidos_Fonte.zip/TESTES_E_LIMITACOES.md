# Testes e limitacoes — v0.9

Validado neste ambiente Linux:
- Integração do Host alterada para caminho absoluto System32, appcore.dll minusculo (revisao do fonte).
- Windows Go EXE da base v14.11: compilacao cruzada (CGO_ENABLED=0).
- Analise estatica da base Go: go vet.
- Compilacao cruzada do Setup Go para Windows, incluindo testes (em modo fonte com placeholders).
- Conferencia da estrutura do workflow do GitHub Actions.

Nao realizado neste ambiente:
- Compilacao real Cgo c-shared da DLL para Windows: MinGW-w64 nao esta disponivel aqui.
- Execucao nativa Windows do novo Setup/Host, e permissao de escrita real System32.
- Testes no FiveM e comparacao com v14.12.

O workflow do GitHub Actions deve fazer as etapas Windows pendentes e gerar o Setup apenas se passar. **Isso ainda nao prova a funcionalidade do FiveM.**
